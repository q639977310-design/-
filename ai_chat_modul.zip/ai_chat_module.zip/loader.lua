-- loader.lua - 一键注入器入口（手机可直接跑）
-- 用法：loadstring(game:HttpGet("远程地址/ai_chat_module/loader.lua"))()
-- 本文件已内置 Agnes AI 配置，可直接运行

local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

-- ==================== 配置（供应商自定义） ====================
local AI_CONFIG = {
	url = "https://apihub.agnes-ai.com/v1/chat/completions",
	key = "sk-UbaeS6otwjgUwTCWXxxLrViz8TZ66D1bKs9s5qP9ydVhV5hJ",
	model = "agnes-3.0-flash"
}

-- 远程模块地址（上传到 GitHub Raw 后替换这里）
local MODULE_BASE = "https://raw.githubusercontent.com/你的用户名/仓库名/main/ai_chat_module/"

-- ==================== UI 根容器 ====================
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "DynamicAIModule"
screenGui.ResetOnSpawn = false
screenGui.Parent = playerGui

-- 浮动开关按钮
local toggleBtn = Instance.new("TextButton")
toggleBtn.Size = UDim2.new(0, 56, 0, 56)
toggleBtn.AnchorPoint = Vector2.new(1, 1)
toggleBtn.Position = UDim2.new(1, -12, 1, -12)
toggleBtn.BackgroundColor3 = Color3.fromRGB(0, 170, 255)
toggleBtn.Text = "AI"
toggleBtn.Font = Enum.Font.SourceSansBold
toggleBtn.TextSize = 20
toggleBtn.TextColor3 = Color3.new(1, 1, 1)
toggleBtn.AutoButtonColor = true
toggleBtn.Parent = screenGui
Instance.new("UICorner", toggleBtn).CornerRadius = UDim.new(0.5, 0)

local loaded = nil
local function loadAndRunModule()
	local src
	local ok, result = pcall(function()
		return HttpService:GetAsync(MODULE_BASE .. "main.lua")
	end)
	if not ok or not result then
		warn("无法加载远程 main.lua，请检查 MODULE_BASE 地址")
		return
	end

	local fn, err = load(result)
	if not fn then
		warn("脚本编译失败：" .. tostring(err))
		return
	end

	local ctx = {
		uiRoot = screenGui,
		player = player,
		http = HttpService,
		aiConfig = AI_CONFIG
	}

	local ok2, module = pcall(fn, ctx)
	if ok2 then
		loaded = module
		print("✅ 模块加载成功：AI Chat v1.0.0")
	else
		warn("模块运行错误：" .. tostring(module))
	end
end

-- 首次自动加载
loadAndRunModule()

-- 开关按钮（重开可重新加载）
toggleBtn.MouseButton1Click:Connect(function()
	if loaded then
		loaded:destroy()
		loaded = nil
		toggleBtn.Text = "AI"
	else
		loadAndRunModule()
		toggleBtn.Text = "X"
	end
end)