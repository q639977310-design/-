-- main.lua - AI Chat Module for Roblox Injector
-- 通过 ctx.aiConfig / ctx.http / ctx.player / ctx.uiRoot 运行

return function(ctx)
	local HttpService = ctx.http
	local player = ctx.player
	local aiConfig = ctx.aiConfig

	-- ==================== UI 创建 ====================
	local chatFrame = Instance.new("Frame")
	chatFrame.Size = UDim2.new(0, 300, 0, 400)
	chatFrame.Position = UDim2.new(0.5, -150, 1, -420)
	chatFrame.BackgroundColor3 = Color3.fromRGB(25, 25, 30)
	chatFrame.BorderSizePixel = 0
	chatFrame.Parent = ctx.uiRoot

	Instance.new("UICorner", chatFrame).CornerRadius = UDim.new(0, 12)

	local msgList = Instance.new("ScrollingFrame")
	msgList.Size = UDim2.new(1, -20, 1, -80)
	msgList.Position = UDim2.new(0, 10, 0, 10)
	msgList.CanvasSize = UDim2.new(0, 0, 0, 0)
	msgList.ScrollBarThickness = 6
	msgList.BackgroundTransparency = 1
	msgList.Parent = chatFrame

	local layout = Instance.new("UIListLayout")
	layout.Padding = UDim.new(0, 6)
	layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
	layout.Parent = msgList

	local inputBox = Instance.new("TextBox")
	inputBox.Size = UDim2.new(1, -90, 0, 30)
	inputBox.Position = UDim2.new(0, 10, 1, -40)
	inputBox.BackgroundColor3 = Color3.fromRGB(45, 45, 50)
	inputBox.TextColor3 = Color3.fromRGB(255, 255, 255)
	inputBox.Font = Enum.Font.SourceSans
	inputBox.TextSize = 16
	inputBox.ClearTextOnFocus = false
	inputBox.PlaceholderText = "输入问题..."
	inputBox.Parent = chatFrame

	Instance.new("UICorner", inputBox).CornerRadius = UDim.new(0, 8)

	local sendBtn = Instance.new("TextButton")
	sendBtn.Size = UDim2.new(0, 70, 0, 30)
	sendBtn.Position = UDim2.new(1, -80, 1, -40)
	sendBtn.BackgroundColor3 = Color3.fromRGB(0, 170, 255)
	sendBtn.Text = "发送"
	sendBtn.Font = Enum.Font.SourceSansBold
	sendBtn.TextSize = 16
	sendBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
	sendBtn.Parent = chatFrame

	Instance.new("UICorner", sendBtn).CornerRadius = UDim.new(0, 8)

	-- 获取玩家游戏状态（AI 可访问）
	local function getPlayerState()
		local char = player.Character or workspace:FindFirstChild(player.Name)
		local hum = char and char:FindFirstChildOfClass("Humanoid")
		local root = char and char:FindFirstChild("HumanoidRootPart")
		local stats = {}
		local ls = player:FindFirstChild("leaderstats")
		if ls then
			for _, v in ipairs(ls:GetChildren()) do
				stats[v.Name] = v.Value
			end
		end
		return {
			health = hum and hum.Health or "未知",
			maxHealth = hum and hum.MaxHealth or "?",
			position = root and root.Position or Vector3.new(0, 0, 0),
			leaderstats = stats
		}
	end

	-- 添加消息气泡
	local function addMessage(text, isPlayer)
		local label = Instance.new("TextLabel")
		label.Size = UDim2.new(1, -20, 0, math.max(30, #text * 6))
		label.BackgroundTransparency = 1
		label.Font = Enum.Font.SourceSans
		label.TextSize = 14
		label.TextWrapped = true
		label.TextColor3 = Color3.fromRGB(255, 255, 255)
		label.TextXAlignment = isPlayer and Enum.TextXAlignment.Right or Enum.TextXAlignment.Left
		label.Text = text
		label.Parent = msgList
		msgList.CanvasSize = UDim2.new(0, 0, 0, layout.AbsoluteContentSize.Y + 10)
	end

	-- 构建上下文 prompt（含游戏数据）
	local function buildPrompt(message)
		local s = getPlayerState()
		local statStr = ""
		for k, v in pairs(s.leaderstats) do
			statStr = statStr .. k .. "=" .. tostring(v) .. " "
		end
		local pos = s.position
		return string.format(
			"当前玩家状态：血量 %s/%s，位置 (%.0f,%.0f,%.0f)%s\n玩家说：%s",
			tostring(s.health), tostring(s.maxHealth),
			pos.X, pos.Y, pos.Z,
			(statStr ~= "" and "，数据：" .. statStr) or "",
			message
		)
	end

	-- 调用 AI 接口
	local function sendMessage(message)
		local prompt = buildPrompt(message)
		local headers = {
			["Authorization"] = "Bearer " .. aiConfig.key,
			["Content-Type"] = "application/json"
		}
		local body = HttpService:JSONEncode({
			model = aiConfig.model,
			messages = {
				{ role = "system", content = "你是 Roblox 游戏内的 AI 助手，回答简洁。" },
				{ role = "user", content = prompt }
			}
		})

		addMessage("正在思考…", false)
		local loadingLbl = msgList:GetChildren()
		loadingLbl = loadingLbl[#loadingLbl]

		local success, result = pcall(function()
			return HttpService:RequestAsync({
				Url = aiConfig.url,
				Method = "POST",
				Headers = headers,
				Body = body
			})
		end)

		if success then
			local json
			pcall(function()
				json = HttpService:JSONDecode(result.Body)
			end)
			local reply = json and json.choices and json.choices[1]
				and json.choices[1].message and json.choices[1].message.content
			if reply then
				loadingLbl:Destroy()
				addMessage(reply, false)
			else
				loadingLbl:Destroy()
				addMessage("[AI] 接口返回异常：" .. tostring(result and result.Body), false)
			end
		else
			loadingLbl:Destroy()
			addMessage("[AI] 请求失败：" .. tostring(result), false)
		end
	end

	-- 事件绑定
	sendBtn.MouseButton1Click:Connect(function()
		local msg = inputBox.Text
		if msg == "" then return end
		addMessage(msg, true)
		inputBox.Text = ""
		sendMessage(msg)
	end)

	inputBox.FocusLost:Connect(function(enter)
		if enter then sendBtn:Activate() end
	end)

	-- 欢迎语
	addMessage("你好！我是 AI 助手，可以直接问我游戏相关问题～", false)

	return {
		destroy = function()
			chatFrame:Destroy()
		end
	}
end