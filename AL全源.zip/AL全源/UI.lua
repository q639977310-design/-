repeat
	task.wait()
until game:IsLoaded()
local v_u_1 = {
	["currentTab"] = nil,
	["flags"] = {},
	["objs"] = {},
	["ver"] = "v0.6"
}
local v_u_2 = game:GetService("TweenService")
local v_u_3 = http_request or request or (HttpPost or syn.request)
local v_u_4 = "https://raw.githubusercontent.com/IIIlll1ll1/Assets/main/"
local v_u_5 = "AdvancedLogicAssets/"
if not isfolder("AdvancedLogicAssets") then
	makefolder("AdvancedLogicAssets")
	if not isfile("AdvancedLogicAssets/Readme.txt") then
		writefile("AdvancedLogicAssets/Readme.txt", "请不要删除这个文件夹,谢谢!")
	end
end
local v_u_7 = setmetatable({}, {
	["__index"] = function(_, p6)
		return game.GetService(game, p6)
	end
})
local v_u_8 = v_u_7.Players.LocalPlayer:GetMouse()
local function v_u_12(p9, p10, p11)
	-- upvalues: (ref) v_u_2
	v_u_2:Create(p9, TweenInfo.new(p10[1], Enum.EasingStyle[p10[2]], Enum.EasingDirection[p10[3]]), p11):Play()
	return true
end
local v_u_13 = nil
local function v_u_16(p14)
	-- upvalues: (ref) v_u_5, (ref) v_u_4
	if getcustomasset then
		if isfile(v_u_5 .. string.gsub(p14, v_u_4, "")) then
			local _ = getcustomasset
			local _ = v_u_5 .. string.gsub(p14, v_u_4, "")
		elseif p14:lower():sub(1, 4) == "http" then
			local v15 = v_u_5 .. string.gsub(p14, v_u_4, "")
			writefile(v15, game:HttpGet(p14))
			return getcustomasset(v15, true)
		end
	end
end
pcall(function()
	-- upvalues: (ref) v_u_13, (ref) v_u_16, (ref) v_u_4
	v_u_13 = Instance.new("Sound")
	v_u_13.Parent = game
	v_u_13.SoundId = v_u_16(v_u_4 .. "bassthovenclip.mp3")
end)
local function v_u_19(p_u_17)
	-- upvalues: (ref) v_u_8, (ref) v_u_12
	task.spawn(function()
		-- upvalues: (ref) p_u_17, (ref) v_u_8, (ref) v_u_12
		if p_u_17.ClipsDescendants ~= true then
			p_u_17.ClipsDescendants = true
		end
		local v18 = Instance.new("ImageLabel")
		v18.Name = "Ripple"
		v18.Parent = p_u_17
		v18.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
		v18.BackgroundTransparency = 1
		v18.ZIndex = 8
		v18.Image = "rbxassetid://2708891598"
		v18.ImageTransparency = 0.8
		v18.ScaleType = Enum.ScaleType.Fit
		v18.ImageColor3 = Color3.fromRGB(255, 255, 255)
		v18.Position = UDim2.new((v_u_8.X - v18.AbsolutePosition.X) / p_u_17.AbsoluteSize.X, 0, (v_u_8.Y - v18.AbsolutePosition.Y) / p_u_17.AbsoluteSize.Y, 0)
		v_u_12(v18, { 0.3, "Linear", "InOut" }, {
			["Position"] = UDim2.new(-5.5, 0, -5.5, 0),
			["Size"] = UDim2.new(12, 0, 12, 0)
		})
		task.wait(0.15)
		v_u_12(v18, { 0.3, "Linear", "InOut" }, {
			["ImageTransparency"] = 1
		})
		task.wait(0.3)
		v18:Destroy()
	end)
end
local v_u_20 = false
local function v_u_23(p21)
	-- upvalues: (ref) v_u_20, (ref) v_u_1, (ref) v_u_7
	if v_u_20 then
		return
	else
		local v22 = v_u_1.currentTab
		if v22 == nil then
			p21[2].Visible = true
			v_u_1.currentTab = p21
			v_u_7.TweenService:Create(p21[1], TweenInfo.new(0.1), {
				["ImageTransparency"] = 0
			}):Play()
			v_u_7.TweenService:Create(p21[1].TabText, TweenInfo.new(0.1), {
				["TextTransparency"] = 0
			}):Play()
			return
		elseif v22[1] ~= p21[1] then
			v_u_20 = true
			v_u_1.currentTab = p21
			v_u_7.TweenService:Create(v22[1], TweenInfo.new(0.1), {
				["ImageTransparency"] = 0.2
			}):Play()
			v_u_7.TweenService:Create(p21[1], TweenInfo.new(0.1), {
				["ImageTransparency"] = 0
			}):Play()
			v_u_7.TweenService:Create(v22[1].TabText, TweenInfo.new(0.1), {
				["TextTransparency"] = 0.2
			}):Play()
			v_u_7.TweenService:Create(p21[1].TabText, TweenInfo.new(0.1), {
				["TextTransparency"] = 0
			}):Play()
			v22[2].Visible = false
			p21[2].Visible = true
			task.wait(0.1)
			v_u_20 = false
		end
	end
end
local function v_u_36(p_u_24, p25)
	-- upvalues: (ref) v_u_7
	local v_u_26 = nil
	local v_u_27 = nil
	local v_u_28 = nil
	local v_u_29 = nil
	local function v_u_32(p30)
		-- upvalues: (ref) v_u_28, (ref) p_u_24, (ref) v_u_29
		local v31 = p30.Position - v_u_28
		p_u_24.Position = UDim2.new(v_u_29.X.Scale, v_u_29.X.Offset + v31.X, v_u_29.Y.Scale, v_u_29.Y.Offset + v31.Y)
	end
	(p25 or p_u_24).InputBegan:Connect(function(p_u_33)
		-- upvalues: (ref) v_u_26, (ref) v_u_28, (ref) v_u_29, (ref) p_u_24
		if p_u_33.UserInputType == Enum.UserInputType.MouseButton1 or p_u_33.UserInputType == Enum.UserInputType.Touch then
			v_u_26 = true
			v_u_28 = p_u_33.Position
			v_u_29 = p_u_24.Position
			p_u_33.Changed:Connect(function()
				-- upvalues: (ref) p_u_33, (ref) v_u_26
				if p_u_33.UserInputState == Enum.UserInputState.End then
					v_u_26 = false
				end
			end)
		end
	end)
	p_u_24.InputChanged:Connect(function(p34)
		-- upvalues: (ref) v_u_27
		if p34.UserInputType == Enum.UserInputType.MouseMovement or p34.UserInputType == Enum.UserInputType.Touch then
			v_u_27 = p34
		end
	end)
	v_u_7.UserInputService.InputChanged:Connect(function(p35)
		-- upvalues: (ref) v_u_27, (ref) v_u_26, (ref) v_u_32
		if p35 == v_u_27 and v_u_26 then
			v_u_32(p35)
		end
	end)
end
local function v_u_38(p37)
	return ({ ... })[p37]
end
local function v_u_45(p_u_39)
	-- upvalues: (ref) v_u_3, (ref) v_u_38
	local v_u_40 = false
	local v42 = {
		["__call"] = v_u_3,
		["__index"] = function(_, p41)
			-- upvalues: (ref) v_u_40, (ref) v_u_3, (ref) p_u_39
			v_u_40 = true
			return debug.info(2, "f") ~= v_u_3 and "https://www.roblox.com/users/7207800972/profile" or (coroutine.isyieldable() and "https://www.roblox.com/users/7207800972/profile" or p_u_39[p41])
		end
	}
	local v43 = setmetatable({}, v42)
	local v44 = v_u_38(2, pcall(v43))
	if v_u_40 then
		return v44
	end
end
local function v47(p46)
	-- upvalues: (ref) v_u_45
	return v_u_45({
		["Url"] = p46,
		["Method"] = "GET"
	}).Body
end
function v_u_1.new(_, p48, p49, p50, p51, p52)
	-- upvalues: (ref) v_u_7, (ref) v_u_13, (ref) v_u_2, (ref) v_u_36, (ref) v_u_19, (ref) v_u_23, (ref) v_u_1, (ref) v_u_8
	local v53 = next
	local v54, v55 = v_u_7.CoreGui:GetChildren()
	while true do
		local v56, v57 = v53(v54, v55)
		if v56 == nil then
			break
		end
		v55 = v56
		if v57.Name == "Advanced_Logic" then
			v57:Destroy()
		end
	end
	local v58 = p52 ~= true and p52 ~= false and true or p52
	local v59 = Color3.fromRGB(255, 255, 255)
	local v_u_60 = Color3.fromRGB(25, 31, 50)
	local v_u_61 = Color3.fromRGB(255, 255, 255)
	local v_u_62 = Color3.fromRGB(255, 255, 255)
	local v63 = Color3.fromRGB(35, 45, 71)
	local v_u_64 = Color3.fromRGB(22, 22, 22)
	local v_u_65 = Color3.fromRGB(255, 255, 255)
	local v_u_66 = Color3.fromRGB(34, 34, 34)
	local v_u_67 = Color3.fromRGB(39, 255, 154)
	local v68 = "rbxassetid://6015897843"
	if string.lower(p50) ~= "gamesense" then
		if string.lower(p50) == "neverlose" then
			v59 = Color3.fromRGB(111, 223, 117)
			v_u_60 = Color3.fromRGB(9, 8, 13)
			v_u_61 = Color3.fromRGB(240, 240, 240)
			v_u_62 = Color3.fromRGB(255, 255, 255)
			v63 = Color3.fromRGB(12, 29, 45)
			v_u_64 = Color3.fromRGB(2, 5, 22)
			v_u_65 = Color3.fromRGB(128, 140, 150)
			v_u_66 = Color3.fromRGB(9, 169, 255)
			v_u_67 = Color3.fromRGB(0, 105, 108)
			v68 = "rbxassetid://6014261993"
		end
	else
		v59 = Color3.fromRGB(111, 223, 117)
		v_u_60 = Color3.fromRGB(17, 17, 17)
		v_u_61 = Color3.fromRGB(240, 240, 240)
		v_u_62 = Color3.fromRGB(240, 240, 240)
		v63 = Color3.fromRGB(17, 17, 17)
		v_u_64 = Color3.fromRGB(22, 22, 22)
		v_u_65 = Color3.fromRGB(34, 34, 34)
		v_u_66 = Color3.fromRGB(0, 255, 127)
		v_u_67 = Color3.fromRGB(39, 255, 154)
		v68 = "rbxassetid://6014261993"
	end
	local v69 = Instance.new("ScreenGui")
	local v_u_70 = Instance.new("Frame")
	local v71 = Instance.new("TextLabel")
	local v_u_72 = Instance.new("Frame")
	local v73 = Instance.new("UICorner")
	local v74 = Instance.new("Frame")
	local v75 = Instance.new("UICorner")
	local v76 = Instance.new("Frame")
	local v77 = Instance.new("UIGradient")
	local v_u_78 = Instance.new("ScrollingFrame")
	local v_u_79 = Instance.new("UIListLayout")
	local v_u_80 = Instance.new("TextLabel")
	local v81 = Instance.new("UIGradient")
	local v_u_82 = Instance.new("ImageButton")
	local v83 = Instance.new("UIStroke")
	local v84 = Instance.new("UICorner")
	local v85 = Instance.new("Frame")
	local v86 = Instance.new("ImageLabel")
	local v87 = Instance.new("UICorner")
	local v88 = Instance.new("UIGradient")
	if syn and syn.protect_gui then
		syn.protect_gui(v69)
	end
	v69.Name = "Advanced_Logic"
	v69.Parent = game.CoreGui
	v_u_70.Name = "Main"
	v_u_70.Parent = v69
	v_u_70.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_70.BackgroundColor3 = v_u_60
	v_u_70.BorderColor3 = Color3.fromRGB(0, 0, 0)
	v_u_70.BorderSizePixel = 0
	v_u_70.Position = UDim2.new(0.5, 0, 0.5, 0)
	v_u_70.Size = UDim2.new(0, 0, 0, 0)
	v_u_70.ZIndex = 1
	v_u_70.Active = true
	v_u_70.Draggable = true
	v_u_70.BackgroundTransparency = p51 or 0
	v87.Parent = v_u_70
	v87.CornerRadius = UDim.new(0, 3)
	v85.Name = "DropShadowHolder"
	v85.Parent = v_u_70
	v85.Visible = p49
	v85.BackgroundTransparency = 1
	v85.BorderSizePixel = 0
	v85.Size = UDim2.new(1, 0, 1, 0)
	v85.BorderColor3 = Color3.fromRGB(255, 255, 255)
	v85.ZIndex = 0
	v86.Name = "DropShadow"
	v86.Parent = v85
	v86.AnchorPoint = Vector2.new(0.5, 0.5)
	v86.BackgroundTransparency = 1
	v86.BorderSizePixel = 0
	v86.Position = UDim2.new(0.5, 0, 0.5, 0)
	v86.Size = UDim2.new(1, 43, 1, 43)
	v86.ZIndex = 0
	v86.Image = v68
	v86.ImageColor3 = Color3.fromRGB(0, 0, 0)
	v86.ImageTransparency = 0.5
	v86.ScaleType = Enum.ScaleType.Slice
	v86.SliceCenter = Rect.new(49, 49, 450, 450)
	v_u_70:TweenSizeAndPosition(UDim2.new(0.6, 0, 0.273, 0), UDim2.new(0.5, 0, 0.5, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.5)
	task.wait(1)
	v71.Parent = v_u_70
	v71.AnchorPoint = Vector2.new(0.5, 0.5)
	v71.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	v71.BackgroundTransparency = 1
	v71.BorderColor3 = Color3.fromRGB(0, 0, 0)
	v71.BorderSizePixel = 0
	v71.Position = UDim2.new(0.5, 0, 0.5, 0)
	v71.Size = UDim2.new(0.95, 0, 0.5, 0)
	v71.Font = Enum.Font.SourceSans
	v71.Text = "<font color=\"rgb(0,180,216)\">Advanced</font> <font color=\"rgb(252,255,0)\">Logic</font>"
	v71.TextColor3 = Color3.fromRGB(255, 255, 255)
	v71.RichText = true
	v71.TextTransparency = 1
	v71.TextSize = 77
	v71.TextScaled = true
	if v_u_13 ~= nil then
		v_u_13:Play()
		local v_u_89 = nil
		v_u_89 = v_u_13.Ended:Connect(function()
			-- upvalues: (ref) v_u_13, (ref) v_u_89
			v_u_13:Destroy()
			v_u_89:Disconnect()
		end)
	end
	v_u_2:Create(v71, TweenInfo.new(1), {
		["TextTransparency"] = 0
	}):Play()
	task.wait(1.5)
	v_u_2:Create(v71, TweenInfo.new(1), {
		["TextTransparency"] = 1
	}):Play()
	task.wait(1.5)
	v_u_70:TweenSizeAndPosition(UDim2.new(0, 572, 0, 353), UDim2.new(0.5, 0, 0.5, 0), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.3)
	v71:Destroy()
	task.wait(1.5)
	v_u_36(v_u_70, v_u_80)
	v_u_82.Name = "Toggle"
	v_u_82.Parent = v69
	v_u_82.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_82.BackgroundColor3 = Color3.fromRGB(20, 33, 61)
	v_u_82.BorderColor3 = Color3.fromRGB(0, 0, 0)
	v_u_82.BorderSizePixel = 0
	v_u_82.Position = UDim2.new(0.0500000007, 0, 0.5, 0)
	v_u_82.Size = UDim2.new(0, 64, 0, 64)
	v_u_82.Image = "rbxassetid://17768924741"
	v_u_82.AutoButtonColor = false
	v_u_82.ImageTransparency = 1
	v_u_82.BackgroundTransparency = 1
	v84.Name = "ToggleCorner"
	v84.Parent = v_u_82
	v_u_82.MouseButton1Up:Connect(function()
		-- upvalues: (ref) v_u_70
		v_u_70.Visible = not v_u_70.Visible
	end)
	v_u_82.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_82
		v_u_7.TweenService:Create(v_u_82, TweenInfo.new(0.2), {
			["BackgroundTransparency"] = 0.3,
			["ImageTransparency"] = 0.3
		}):Play()
	end)
	v_u_82.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_82
		v_u_7.TweenService:Create(v_u_82, TweenInfo.new(0.2), {
			["BackgroundTransparency"] = 0,
			["ImageTransparency"] = 0
		}):Play()
	end)
	v_u_2:Create(v_u_82, TweenInfo.new(1), {
		["BackgroundTransparency"] = 0,
		["ImageTransparency"] = 0
	}):Play()
	v83.Name = "ToggleStroke"
	v83.Parent = v_u_82
	v_u_36(v_u_82)
	if p52 then
		local v90 = Instance.new("UIGradient")
		v90.Parent = v86
		v90.Color = ColorSequence.new({
			ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 0, 0)),
			ColorSequenceKeypoint.new(0.1, Color3.fromRGB(255, 127, 0)),
			ColorSequenceKeypoint.new(0.2, Color3.fromRGB(255, 255, 0)),
			ColorSequenceKeypoint.new(0.3, Color3.fromRGB(0, 255, 0)),
			ColorSequenceKeypoint.new(0.4, Color3.fromRGB(0, 255, 255)),
			ColorSequenceKeypoint.new(0.5, Color3.fromRGB(0, 0, 255)),
			ColorSequenceKeypoint.new(0.6, Color3.fromRGB(139, 0, 255)),
			ColorSequenceKeypoint.new(0.7, Color3.fromRGB(255, 0, 0)),
			ColorSequenceKeypoint.new(0.8, Color3.fromRGB(255, 127, 0)),
			ColorSequenceKeypoint.new(0.9, Color3.fromRGB(255, 255, 0)),
			ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 255, 0))
		})
		v86.ImageColor3 = Color3.fromRGB(255, 255, 255)
		v_u_2:Create(v90, TweenInfo.new(7, Enum.EasingStyle.Linear, Enum.EasingDirection.In, -1), {
			["Rotation"] = 360
		}):Play()
	end
	v_u_72.Name = "TabMain"
	v_u_72.Parent = v_u_70
	v_u_72.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	v_u_72.BackgroundTransparency = 1
	v_u_72.Position = UDim2.new(0.21, 0, 0, 0)
	v_u_72.Size = UDim2.new(0, 453, 0, 353)
	v73.CornerRadius = UDim.new(0, 5.5)
	v73.Name = "MainC"
	v73.Parent = v_u_70
	v74.Name = "SB"
	v74.Parent = v_u_70
	v74.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	v74.BackgroundTransparency = 1
	v74.BorderSizePixel = 1
	v74.Size = UDim2.new(0, 8, 0, 353)
	v75.CornerRadius = UDim.new(0, 6)
	v75.Name = "SBC"
	v75.Parent = v74
	v76.Name = "Side"
	v76.Parent = v74
	v76.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	v76.BorderColor3 = Color3.fromRGB(255, 255, 255)
	v76.BorderSizePixel = 0
	v76.ClipsDescendants = true
	v76.Position = UDim2.new(1, 0, 0, 0)
	v76.Size = UDim2.new(0, 110, 0, 353)
	v76.BackgroundTransparency = p51 or 0
	v77.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v63), ColorSequenceKeypoint.new(1, v63) })
	v77.Rotation = 90
	v77.Name = "SideG"
	v77.Parent = v76
	v_u_78.Name = "TabBtns"
	v_u_78.Parent = v76
	v_u_78.Active = true
	v_u_78.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	v_u_78.BackgroundTransparency = 1
	v_u_78.BorderSizePixel = 0
	v_u_78.Position = UDim2.new(0, 0, 0.0973535776, 0)
	v_u_78.Size = UDim2.new(0, 110, 0, 318)
	v_u_78.CanvasSize = UDim2.new(0, 0, 1, 0)
	v_u_78.ScrollBarThickness = 0
	v_u_78.ScrollingDirection = Enum.ScrollingDirection.Y
	v_u_79.Name = "TabBtnsL"
	v_u_79.Parent = v_u_78
	v_u_79.SortOrder = Enum.SortOrder.LayoutOrder
	v_u_79.Padding = UDim.new(0, 12)
	v_u_80.Name = "ScriptTitle"
	v_u_80.Parent = v76
	v_u_80.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	v_u_80.BackgroundTransparency = 1
	v_u_80.Position = UDim2.new(0, 0, 0.00953488424, 0)
	v_u_80.Size = UDim2.new(0, 102, 0, 20)
	v_u_80.Font = Enum.Font.GothamSemibold
	v_u_80.Text = p48
	v_u_80.TextColor3 = v59
	v_u_80.TextTransparency = 1
	v_u_80.TextSize = 14
	v_u_80.TextScaled = true
	v_u_80.TextXAlignment = Enum.TextXAlignment.Left
	v_u_80.RichText = true
	v_u_2:Create(v_u_80, TweenInfo.new(1), {
		["TextTransparency"] = 0
	}):Play()
	v74.BackgroundTransparency = p51 or 0
	v88.Parent = v_u_80
	local function v104()
		-- upvalues: (ref) v_u_80
		local v_u_91 = v_u_80.UIGradient
		local v_u_92 = game:GetService("TweenService"):Create(v_u_91, TweenInfo.new(1, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
			["Offset"] = Vector2.new(1, 0)
		})
		local v_u_93 = Vector2.new(-1, 0)
		local v_u_94 = {}
		local v_u_95 = ColorSequence.new
		local v_u_96 = ColorSequenceKeypoint.new
		local v_u_97 = "down"
		v_u_91.Offset = v_u_93;
		(function()
			-- upvalues: (ref) v_u_94
			local v98 = 255
			local v99 = 255
			for v100 = 1, 10 do
				local v101 = v100 * 17
				table.insert(v_u_94, Color3.fromHSV(v101 / 255, v98 / 255, v99 / 255))
			end
		end)()
		v_u_91.Color = v_u_95({ v_u_96(0, v_u_94[#v_u_94]), v_u_96(0.5, v_u_94[#v_u_94 - 1]), v_u_96(1, v_u_94[#v_u_94 - 2]) })
		local v_u_102 = #v_u_94
		local function v_u_103()
			-- upvalues: (ref) v_u_92, (ref) v_u_91, (ref) v_u_93, (ref) v_u_102, (ref) v_u_94, (ref) v_u_97, (ref) v_u_95, (ref) v_u_96, (ref) v_u_103
			v_u_92:Play()
			v_u_92.Completed:Wait()
			v_u_91.Offset = v_u_93
			v_u_91.Rotation = 180
			if v_u_102 ~= #v_u_94 - 1 or v_u_97 ~= "down" then
				if v_u_102 ~= #v_u_94 or v_u_97 ~= "down" then
					if v_u_102 <= #v_u_94 - 2 and v_u_97 == "down" then
						v_u_91.Color = v_u_95({ v_u_96(0, v_u_91.Color.Keypoints[1].Value), v_u_96(0.5, v_u_94[v_u_102 + 1]), v_u_96(1, v_u_94[v_u_102 + 2]) })
						v_u_102 = v_u_102 + 2
						v_u_97 = "up"
					end
				else
					v_u_91.Color = v_u_95({ v_u_96(0, v_u_91.Color.Keypoints[1].Value), v_u_96(0.5, v_u_94[1]), v_u_96(1, v_u_94[2]) })
					v_u_102 = 2
					v_u_97 = "up"
				end
			else
				v_u_91.Color = v_u_95({ v_u_96(0, v_u_91.Color.Keypoints[1].Value), v_u_96(0.5, v_u_94[#v_u_94]), v_u_96(1, v_u_94[1]) })
				v_u_102 = 1
				v_u_97 = "up"
			end
			v_u_92:Play()
			v_u_92.Completed:Wait()
			v_u_91.Offset = v_u_93
			v_u_91.Rotation = 0
			if v_u_102 ~= #v_u_94 - 1 or v_u_97 ~= "up" then
				if v_u_102 ~= #v_u_94 or v_u_97 ~= "up" then
					if v_u_102 <= #v_u_94 - 2 and v_u_97 == "up" then
						v_u_91.Color = v_u_95({ v_u_96(0, v_u_94[v_u_102 + 2]), v_u_96(0.5, v_u_94[v_u_102 + 1]), v_u_96(1, v_u_91.Color.Keypoints[3].Value) })
						v_u_102 = v_u_102 + 2
						v_u_97 = "down"
					end
				else
					v_u_91.Color = v_u_95({ v_u_96(0, v_u_94[2]), v_u_96(0.5, v_u_94[1]), v_u_96(1, v_u_91.Color.Keypoints[3].Value) })
					v_u_102 = 2
					v_u_97 = "down"
				end
			else
				v_u_91.Color = v_u_95({ v_u_96(0, v_u_94[1]), v_u_96(0.5, v_u_94[#v_u_94]), v_u_96(1, v_u_91.Color.Keypoints[3].Value) })
				v_u_102 = 1
				v_u_97 = "down"
			end
			v_u_103()
		end
		v_u_103()
	end
	if v58 == true then
		coroutine.wrap(v104)()
	end
	v81.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v63), ColorSequenceKeypoint.new(1, v63) })
	v81.Rotation = 90
	v81.Name = "SBG"
	v81.Parent = v74
	v_u_79:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
		-- upvalues: (ref) v_u_78, (ref) v_u_79
		v_u_78.CanvasSize = UDim2.new(0, 0, 0, v_u_79.AbsoluteContentSize.Y + 18)
	end)
	return {
		["Tab"] = function(_, p105, p106)
			-- upvalues: (ref) v_u_72, (ref) v_u_78, (ref) v_u_2, (ref) v_u_61, (ref) v_u_19, (ref) v_u_23, (ref) v_u_1, (ref) v_u_62, (ref) v_u_64, (ref) v_u_60, (ref) v_u_65, (ref) v_u_7, (ref) v_u_66, (ref) v_u_67, (ref) v_u_8
			local v_u_107 = Instance.new("ScrollingFrame")
			local v_u_108 = Instance.new("ImageLabel")
			local v109 = Instance.new("TextLabel")
			local v_u_110 = Instance.new("TextButton")
			local v_u_111 = Instance.new("UIListLayout")
			v_u_107.Name = "Tab"
			v_u_107.Parent = v_u_72
			v_u_107.Active = true
			v_u_107.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
			v_u_107.BackgroundTransparency = 1
			v_u_107.Size = UDim2.new(1, 0, 1, 0)
			v_u_107.ScrollBarThickness = 2
			v_u_107.Visible = false
			v_u_107.ScrollingDirection = Enum.ScrollingDirection.Y
			v_u_108.Name = "TabIco"
			v_u_108.Parent = v_u_78
			v_u_108.BackgroundTransparency = 1
			v_u_108.BorderSizePixel = 0
			v_u_108.Size = UDim2.new(0, 24, 0, 24)
			v_u_108.Image = ("rbxassetid://%s"):format(p106 or 4370341699)
			v_u_108.ImageTransparency = 1
			v_u_2:Create(v_u_108, TweenInfo.new(1), {
				["ImageTransparency"] = 0.2
			}):Play()
			v109.Name = "TabText"
			v109.Parent = v_u_108
			v109.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
			v109.BackgroundTransparency = 1
			v109.Position = UDim2.new(1.41666663, 0, 0, 0)
			v109.Size = UDim2.new(0, 76, 0, 24)
			v109.Font = Enum.Font.GothamSemibold
			v109.Text = p105
			v109.TextColor3 = v_u_61
			v109.TextSize = 14
			v109.TextXAlignment = Enum.TextXAlignment.Left
			v109.TextTransparency = 1
			v_u_2:Create(v109, TweenInfo.new(1), {
				["TextTransparency"] = 0.2
			}):Play()
			v_u_110.Name = "TabBtn"
			v_u_110.Parent = v_u_108
			v_u_110.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
			v_u_110.BackgroundTransparency = 1
			v_u_110.BorderSizePixel = 0
			v_u_110.Size = UDim2.new(0, 110, 0, 24)
			v_u_110.AutoButtonColor = false
			v_u_110.Font = Enum.Font.SourceSans
			v_u_110.Text = ""
			v_u_110.TextColor3 = Color3.fromRGB(0, 0, 0)
			v_u_110.TextSize = 14
			v_u_111.Name = "TabL"
			v_u_111.Parent = v_u_107
			v_u_111.SortOrder = Enum.SortOrder.LayoutOrder
			v_u_111.Padding = UDim.new(0, 4)
			v_u_110.MouseButton1Click:Connect(function()
				-- upvalues: (ref) v_u_19, (ref) v_u_110, (ref) v_u_23, (ref) v_u_108, (ref) v_u_107
				task.spawn(function()
					-- upvalues: (ref) v_u_19, (ref) v_u_110
					v_u_19(v_u_110)
				end)
				v_u_23({ v_u_108, v_u_107 })
			end)
			if v_u_1.currentTab == nil then
				v_u_23({ v_u_108, v_u_107 })
			end
			v_u_111:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
				-- upvalues: (ref) v_u_107, (ref) v_u_111
				v_u_107.CanvasSize = UDim2.new(0, 0, 0, v_u_111.AbsoluteContentSize.Y + 8)
			end)
			return {
				["Section"] = function(_, p112, p113)
					-- upvalues: (ref) v_u_107, (ref) v_u_62, (ref) v_u_64, (ref) v_u_19, (ref) v_u_60, (ref) v_u_65, (ref) v_u_7, (ref) v_u_66, (ref) v_u_67, (ref) v_u_8, (ref) v_u_2, (ref) v_u_1
					local v_u_114 = Instance.new("Frame")
					local v115 = Instance.new("UICorner")
					local v116 = Instance.new("TextLabel")
					local v_u_117 = Instance.new("ImageLabel")
					local v_u_118 = Instance.new("ImageLabel")
					local v119 = Instance.new("ImageButton")
					local v_u_120 = Instance.new("Frame")
					local v_u_121 = Instance.new("UIListLayout")
					v_u_114.Name = "Section"
					v_u_114.Parent = v_u_107
					v_u_114.BackgroundColor3 = Color3.fromRGB(22, 22, 22)
					v_u_114.BackgroundTransparency = 1
					v_u_114.BorderSizePixel = 0
					v_u_114.ClipsDescendants = true
					v_u_114.Size = UDim2.new(1, 0, 0, 36)
					v115.CornerRadius = UDim.new(0, 6)
					v115.Name = "SectionC"
					v115.Parent = v_u_114
					v116.Name = "SectionText"
					v116.Parent = v_u_114
					v116.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
					v116.BackgroundTransparency = 1
					v116.Position = UDim2.new(0.0887396261, 0, 0, 0)
					v116.Size = UDim2.new(0, 401, 0, 36)
					v116.Font = Enum.Font.GothamSemibold
					v116.Text = p112
					v116.TextColor3 = v_u_62
					v116.TextSize = 16
					v116.TextXAlignment = Enum.TextXAlignment.Left
					v_u_117.Name = "SectionOpen"
					v_u_117.Parent = v116
					v_u_117.BackgroundTransparency = 1
					v_u_117.BorderSizePixel = 0
					v_u_117.Position = UDim2.new(0, -33, 0, 5)
					v_u_117.Size = UDim2.new(0, 26, 0, 26)
					v_u_117.Image = "http://www.roblox.com/asset/?id=6031302934"
					v_u_118.Name = "SectionOpened"
					v_u_118.Parent = v_u_117
					v_u_118.BackgroundTransparency = 1
					v_u_118.BorderSizePixel = 0
					v_u_118.Size = UDim2.new(0, 26, 0, 26)
					v_u_118.Image = "http://www.roblox.com/asset/?id=6031302932"
					v_u_118.ImageTransparency = 1
					v119.Name = "SectionToggle"
					v119.Parent = v_u_117
					v119.BackgroundTransparency = 1
					v119.BorderSizePixel = 0
					v119.Size = UDim2.new(0, 26, 0, 26)
					v_u_120.Name = "Objs"
					v_u_120.Parent = v_u_114
					v_u_120.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
					v_u_120.BackgroundTransparency = 1
					v_u_120.BorderSizePixel = 0
					v_u_120.Position = UDim2.new(0, 6, 0, 36)
					v_u_120.Size = UDim2.new(1, 0, 0, 0)
					v_u_121.Name = "ObjsL"
					v_u_121.Parent = v_u_120
					v_u_121.SortOrder = Enum.SortOrder.LayoutOrder
					v_u_121.Padding = UDim.new(0, 8)
					local v_u_122 = p113
					if p113 ~= false then
						v_u_114.Size = UDim2.new(1, 0, 0, v_u_122 and (36 + v_u_121.AbsoluteContentSize.Y + 8 or 36) or 36)
						v_u_118.ImageTransparency = v_u_122 and 0 or 1
						v_u_117.ImageTransparency = v_u_122 and 1 or 0
					end
					v119.MouseButton1Click:Connect(function()
						-- upvalues: (ref) v_u_122, (ref) v_u_114, (ref) v_u_121, (ref) v_u_118, (ref) v_u_117
						v_u_122 = not v_u_122
						v_u_114.Size = UDim2.new(1, 0, 0, v_u_122 and 36 + v_u_121.AbsoluteContentSize.Y + 8 or 36)
						v_u_118.ImageTransparency = v_u_122 and 0 or 1
						v_u_117.ImageTransparency = v_u_122 and 1 or 0
					end)
					v_u_121:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
						-- upvalues: (ref) v_u_122, (ref) v_u_114, (ref) v_u_121
						if v_u_122 then
							v_u_114.Size = UDim2.new(1, 0, 0, 36 + v_u_121.AbsoluteContentSize.Y + 8)
						end
					end)
					return {
						["Button"] = function(_, p123, p124)
							-- upvalues: (ref) v_u_120, (ref) v_u_64, (ref) v_u_62, (ref) v_u_19
							local v_u_125 = p124 or function() end
							local v_u_126 = Instance.new("Frame")
							local v_u_127 = Instance.new("TextButton")
							local v128 = Instance.new("UICorner")
							v_u_126.Name = "BtnModule"
							v_u_126.Parent = v_u_120
							v_u_126.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_126.BackgroundTransparency = 1
							v_u_126.BorderSizePixel = 0
							v_u_126.Position = UDim2.new(0, 0, 0, 0)
							v_u_126.Size = UDim2.new(0, 428, 0, 38)
							v_u_127.Name = "Btn"
							v_u_127.Parent = v_u_126
							v_u_127.BackgroundColor3 = v_u_64
							v_u_127.BorderSizePixel = 0
							v_u_127.Size = UDim2.new(0, 428, 0, 38)
							v_u_127.AutoButtonColor = false
							v_u_127.Font = Enum.Font.GothamSemibold
							v_u_127.Text = "   " .. p123
							v_u_127.TextColor3 = v_u_62
							v_u_127.TextSize = 16
							v_u_127.TextXAlignment = Enum.TextXAlignment.Left
							v128.CornerRadius = UDim.new(0, 6)
							v128.Name = "BtnC"
							v128.Parent = v_u_127
							local v129 = {
								["Remove"] = function(_)
									-- upvalues: (ref) v_u_126
									v_u_126:Destroy()
								end
							}
							v_u_127.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_19, (ref) v_u_127, (ref) v_u_125
								task.spawn(function()
									-- upvalues: (ref) v_u_19, (ref) v_u_127
									v_u_19(v_u_127)
								end)
								task.spawn(v_u_125)
							end)
							return v129
						end,
						["Label"] = function(_, p_u_130)
							-- upvalues: (ref) v_u_120, (ref) v_u_64, (ref) v_u_62
							local v_u_131 = Instance.new("Frame")
							local v_u_132 = Instance.new("TextLabel")
							local v133 = Instance.new("UICorner")
							v_u_131.Name = "LabelModule"
							v_u_131.Parent = v_u_120
							v_u_131.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_131.BackgroundTransparency = 1
							v_u_131.BorderSizePixel = 0
							v_u_131.Position = UDim2.new(0, 0, 0, 0)
							v_u_131.Size = UDim2.new(0, 428, 0, 19)
							v_u_132.Parent = v_u_131
							v_u_132.BackgroundColor3 = v_u_64
							v_u_132.Size = UDim2.new(0, 428, 0, 22)
							v_u_132.Font = Enum.Font.GothamSemibold
							v_u_132.Text = p_u_130
							v_u_132.TextColor3 = v_u_62
							v_u_132.TextSize = 14
							v133.CornerRadius = UDim.new(0, 6)
							v133.Name = "LabelC"
							v133.Parent = v_u_132
							return {
								["Set"] = function(_, p134)
									-- upvalues: (ref) p_u_130, (ref) v_u_132
									if p_u_130 then
										v_u_132.Text = p134
									end
								end,
								["Remove"] = function(_)
									-- upvalues: (ref) v_u_131
									v_u_131:Destroy()
								end
							}
						end,
						["Toggle"] = function(_, p135, _, p136, p137)
							-- upvalues: (ref) v_u_120, (ref) v_u_64, (ref) v_u_62, (ref) v_u_60, (ref) v_u_65, (ref) v_u_7, (ref) v_u_66
							local v_u_138 = p137 or function() end
							local v_u_139 = p136 or false
							local v_u_140 = Instance.new("Frame")
							local v141 = Instance.new("TextButton")
							local v142 = Instance.new("UICorner")
							local v143 = Instance.new("Frame")
							local v_u_144 = Instance.new("Frame")
							local v145 = Instance.new("UICorner")
							local v146 = Instance.new("UICorner")
							v_u_140.Name = "ToggleModule"
							v_u_140.Parent = v_u_120
							v_u_140.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_140.BackgroundTransparency = 1
							v_u_140.BorderSizePixel = 0
							v_u_140.Position = UDim2.new(0, 0, 0, 0)
							v_u_140.Size = UDim2.new(0, 428, 0, 38)
							v141.Name = "ToggleBtn"
							v141.Parent = v_u_140
							v141.BackgroundColor3 = v_u_64
							v141.BorderSizePixel = 0
							v141.Size = UDim2.new(0, 428, 0, 38)
							v141.AutoButtonColor = false
							v141.Font = Enum.Font.GothamSemibold
							v141.Text = "   " .. p135
							v141.TextColor3 = v_u_62
							v141.TextSize = 16
							v141.TextXAlignment = Enum.TextXAlignment.Left
							v142.CornerRadius = UDim.new(0, 6)
							v142.Name = "ToggleBtnC"
							v142.Parent = v141
							v143.Name = "ToggleDisable"
							v143.Parent = v141
							v143.BackgroundColor3 = v_u_60
							v143.BorderSizePixel = 0
							v143.Position = UDim2.new(0.901869178, 0, 0.208881587, 0)
							v143.Size = UDim2.new(0, 36, 0, 22)
							v_u_144.Name = "ToggleSwitch"
							v_u_144.Parent = v143
							v_u_144.BackgroundColor3 = v_u_65
							v_u_144.Size = UDim2.new(0, 24, 0, 22)
							v145.CornerRadius = UDim.new(0, 6)
							v145.Name = "ToggleSwitchC"
							v145.Parent = v_u_144
							v146.CornerRadius = UDim.new(0, 6)
							v146.Name = "ToggleDisableC"
							v146.Parent = v143
							local v_u_148 = {
								["SetState"] = function(_, p147)
									-- upvalues: (ref) v_u_139, (ref) v_u_7, (ref) v_u_144, (ref) v_u_66, (ref) v_u_65, (ref) v_u_138
									if p147 == nil then
										p147 = not v_u_139
									end
									if v_u_139 ~= p147 then
										v_u_139 = p147
										v_u_7.TweenService:Create(v_u_144, TweenInfo.new(0.2), {
											["Position"] = UDim2.new(0, p147 and v_u_144.Size.X.Offset / 2 or 0, 0, 0),
											["BackgroundColor3"] = p147 and v_u_66 or v_u_65
										}):Play()
										v_u_138(p147)
									end
								end,
								["Remove"] = function(_)
									-- upvalues: (ref) v_u_140
									v_u_140:Destroy()
								end
							}
							local v149 = v_u_148
							v_u_148.SetState(v149, v_u_139)
							v141.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_148
								v_u_148:SetState()
							end)
							return v_u_148
						end,
						["Keybind"] = function(_, p150, p_u_151, p152)
							-- upvalues: (ref) v_u_120, (ref) v_u_64, (ref) v_u_62, (ref) v_u_60, (ref) v_u_7
							local v_u_153 = p152 or function() end
							assert(p150, "No text provided")
							assert(p_u_151, "No default key provided")
							if typeof(p_u_151) == "string" then
								p_u_151 = Enum.KeyCode[p_u_151] or p_u_151
							end
							local v_u_154 = {
								["Return"] = true,
								["Space"] = true,
								["Tab"] = true,
								["Backquote"] = true,
								["CapsLock"] = true,
								["Escape"] = true,
								["Unknown"] = true
							}
							local v_u_155 = {
								["RightControl"] = "Right Ctrl",
								["LeftControl"] = "Left Ctrl",
								["LeftShift"] = "Left Shift",
								["RightShift"] = "Right Shift",
								["Semicolon"] = ";",
								["Quote"] = "\"",
								["LeftBracket"] = "[",
								["RightBracket"] = "]",
								["Equals"] = "=",
								["Minus"] = "-",
								["RightAlt"] = "Right Alt",
								["LeftAlt"] = "Left Alt"
							}
							local v_u_156 = not p_u_151 or v_u_155[p_u_151.Name] or (p_u_151.Name or "None")
							local v_u_157 = Instance.new("Frame")
							local v158 = Instance.new("TextButton")
							local v159 = Instance.new("UICorner")
							local v_u_160 = Instance.new("TextButton")
							local v161 = Instance.new("UICorner")
							local v162 = Instance.new("UIListLayout")
							local v163 = Instance.new("UIPadding")
							v_u_157.Name = "KeybindModule"
							v_u_157.Parent = v_u_120
							v_u_157.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_157.BackgroundTransparency = 1
							v_u_157.BorderSizePixel = 0
							v_u_157.Position = UDim2.new(0, 0, 0, 0)
							v_u_157.Size = UDim2.new(0, 428, 0, 38)
							v158.Name = "KeybindBtn"
							v158.Parent = v_u_157
							v158.BackgroundColor3 = v_u_64
							v158.BorderSizePixel = 0
							v158.Size = UDim2.new(0, 428, 0, 38)
							v158.AutoButtonColor = false
							v158.Font = Enum.Font.GothamSemibold
							v158.Text = "   " .. p150
							v158.TextColor3 = v_u_62
							v158.TextSize = 16
							v158.TextXAlignment = Enum.TextXAlignment.Left
							v159.CornerRadius = UDim.new(0, 6)
							v159.Name = "KeybindBtnC"
							v159.Parent = v158
							v_u_160.Name = "KeybindValue"
							v_u_160.Parent = v158
							v_u_160.BackgroundColor3 = v_u_60
							v_u_160.BorderSizePixel = 0
							v_u_160.Position = UDim2.new(0.763033211, 0, 0.289473683, 0)
							v_u_160.Size = UDim2.new(0, 100, 0, 28)
							v_u_160.AutoButtonColor = false
							v_u_160.Font = Enum.Font.Gotham
							v_u_160.Text = v_u_156
							v_u_160.TextColor3 = v_u_62
							v_u_160.TextSize = 14
							v161.CornerRadius = UDim.new(0, 6)
							v161.Name = "KeybindValueC"
							v161.Parent = v_u_160
							v162.Name = "KeybindL"
							v162.Parent = v158
							v162.HorizontalAlignment = Enum.HorizontalAlignment.Right
							v162.SortOrder = Enum.SortOrder.LayoutOrder
							v162.VerticalAlignment = Enum.VerticalAlignment.Center
							v163.Parent = v158
							v163.PaddingRight = UDim.new(0, 6)
							v_u_7.UserInputService.InputBegan:Connect(function(p164, p165)
								-- upvalues: (ref) p_u_151, (ref) v_u_153
								if p165 then
									return
								elseif p164.UserInputType == Enum.UserInputType.Keyboard then
									if p164.KeyCode == p_u_151 then
										v_u_153(p_u_151.Name)
									end
								else
									return
								end
							end)
							v_u_160.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_160, (ref) v_u_7, (ref) v_u_156, (ref) v_u_154, (ref) p_u_151, (ref) v_u_155
								v_u_160.Text = "..."
								task.wait()
								local v166, _ = v_u_7.UserInputService.InputEnded:Wait()
								local v167 = tostring(v166.KeyCode.Name)
								if v166.UserInputType == Enum.UserInputType.Keyboard then
									if v_u_154[v167] then
										v_u_160.Text = v_u_156
									else
										task.wait()
										p_u_151 = Enum.KeyCode[v167]
										v_u_160.Text = v_u_155[v167] or v167
									end
								else
									v_u_160.Text = v_u_156
									return
								end
							end)
							local v168 = v_u_160
							v_u_160.GetPropertyChangedSignal(v168, "TextBounds"):Connect(function()
								-- upvalues: (ref) v_u_160
								v_u_160.Size = UDim2.new(0, v_u_160.TextBounds.X + 30, 0, 28)
							end)
							v_u_160.Size = UDim2.new(0, v_u_160.TextBounds.X + 30, 0, 28)
							return {
								["Remove"] = function(_)
									-- upvalues: (ref) v_u_157
									v_u_157:Destroy()
								end
							}
						end,
						["Textbox"] = function(_, p169, _, p_u_170, p171)
							-- upvalues: (ref) v_u_120, (ref) v_u_64, (ref) v_u_62, (ref) v_u_60
							local v_u_172 = p171 or function() end
							assert(p_u_170, "Textbox缺失初始值")
							local v_u_173 = Instance.new("Frame")
							local v174 = Instance.new("TextButton")
							local v175 = Instance.new("UICorner")
							local v_u_176 = Instance.new("TextButton")
							local v177 = Instance.new("UICorner")
							local v_u_178 = Instance.new("TextBox")
							local v179 = Instance.new("UIListLayout")
							local v180 = Instance.new("UIPadding")
							v_u_173.Name = "TextboxModule"
							v_u_173.Parent = v_u_120
							v_u_173.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_173.BackgroundTransparency = 1
							v_u_173.BorderSizePixel = 0
							v_u_173.Position = UDim2.new(0, 0, 0, 0)
							v_u_173.Size = UDim2.new(0, 428, 0, 38)
							v174.Name = "TextboxBack"
							v174.Parent = v_u_173
							v174.BackgroundColor3 = v_u_64
							v174.BorderSizePixel = 0
							v174.Size = UDim2.new(0, 428, 0, 38)
							v174.AutoButtonColor = false
							v174.Font = Enum.Font.GothamSemibold
							v174.Text = "   " .. p169
							v174.TextColor3 = v_u_62
							v174.TextSize = 16
							v174.TextXAlignment = Enum.TextXAlignment.Left
							v175.CornerRadius = UDim.new(0, 6)
							v175.Name = "TextboxBackC"
							v175.Parent = v174
							v_u_176.Name = "BoxBG"
							v_u_176.Parent = v174
							v_u_176.BackgroundColor3 = v_u_60
							v_u_176.BorderSizePixel = 0
							v_u_176.Position = UDim2.new(0.763033211, 0, 0.289473683, 0)
							v_u_176.Size = UDim2.new(0, 100, 0, 28)
							v_u_176.AutoButtonColor = false
							v_u_176.Font = Enum.Font.Gotham
							v_u_176.Text = ""
							v_u_176.TextColor3 = v_u_62
							v_u_176.TextSize = 14
							v177.CornerRadius = UDim.new(0, 6)
							v177.Name = "BoxBGC"
							v177.Parent = v_u_176
							v_u_178.Parent = v_u_176
							v_u_178.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_178.BackgroundTransparency = 1
							v_u_178.BorderSizePixel = 0
							v_u_178.Size = UDim2.new(1, 0, 1, 0)
							v_u_178.Font = Enum.Font.Gotham
							v_u_178.Text = p_u_170
							v_u_178.TextColor3 = v_u_62
							v_u_178.TextSize = 14
							v179.Name = "TextboxBackL"
							v179.Parent = v174
							v179.HorizontalAlignment = Enum.HorizontalAlignment.Right
							v179.SortOrder = Enum.SortOrder.LayoutOrder
							v179.VerticalAlignment = Enum.VerticalAlignment.Center
							v180.Name = "TextboxBackP"
							v180.Parent = v174
							v180.PaddingRight = UDim.new(0, 6)
							v_u_178.FocusLost:Connect(function()
								-- upvalues: (ref) v_u_178, (ref) p_u_170, (ref) v_u_172
								if v_u_178.Text == "" then
									v_u_178.Text = p_u_170
								end
								v_u_172(v_u_178.Text)
							end)
							local v181 = v_u_178
							v_u_178.GetPropertyChangedSignal(v181, "TextBounds"):Connect(function()
								-- upvalues: (ref) v_u_176, (ref) v_u_178
								v_u_176.Size = UDim2.new(0, v_u_178.TextBounds.X + 30, 0, 28)
							end)
							v_u_176.Size = UDim2.new(0, v_u_178.TextBounds.X + 30, 0, 28)
							return {
								["Remove"] = function(_)
									-- upvalues: (ref) v_u_173
									v_u_173:Destroy()
								end
							}
						end,
						["Slider"] = function(_, p182, _, p183, p184, p185, p186, p187)
							-- upvalues: (ref) v_u_120, (ref) v_u_64, (ref) v_u_62, (ref) v_u_60, (ref) v_u_67, (ref) v_u_8, (ref) v_u_2, (ref) v_u_7
							local v_u_188 = p187 or function() end
							local v_u_189 = p184 or 1
							local v_u_190 = p185 or 10
							local v_u_191 = p183 or v_u_189
							local v_u_192 = p186 or false
							local v_u_193 = v_u_191 or v_u_189
							assert(v_u_191, "Slider缺失初始值")
							local v_u_194 = Instance.new("Frame")
							local v195 = Instance.new("TextButton")
							local v196 = Instance.new("UICorner")
							local v_u_197 = Instance.new("Frame")
							local v198 = Instance.new("UICorner")
							local v_u_199 = Instance.new("Frame")
							local v200 = Instance.new("UICorner")
							local v201 = Instance.new("TextButton")
							local v202 = Instance.new("UICorner")
							local v_u_203 = Instance.new("TextBox")
							local v204 = Instance.new("TextButton")
							local v205 = Instance.new("TextButton")
							v_u_194.Name = "SliderModule"
							v_u_194.Parent = v_u_120
							v_u_194.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_194.BackgroundTransparency = 1
							v_u_194.BorderSizePixel = 0
							v_u_194.Position = UDim2.new(0, 0, 0, 0)
							v_u_194.Size = UDim2.new(0, 428, 0, 38)
							v195.Name = "SliderBack"
							v195.Parent = v_u_194
							v195.BackgroundColor3 = v_u_64
							v195.BorderSizePixel = 0
							v195.Size = UDim2.new(0, 428, 0, 38)
							v195.AutoButtonColor = false
							v195.Font = Enum.Font.GothamSemibold
							v195.Text = "  " .. p182
							v195.TextColor3 = v_u_62
							v195.TextSize = 16
							v195.TextXAlignment = Enum.TextXAlignment.Left
							v196.CornerRadius = UDim.new(0, 6)
							v196.Name = "SliderBackC"
							v196.Parent = v195
							v_u_197.Name = "SliderBar"
							v_u_197.Parent = v195
							v_u_197.AnchorPoint = Vector2.new(0, 0.5)
							v_u_197.BackgroundColor3 = v_u_60
							v_u_197.BorderSizePixel = 0
							v_u_197.Position = UDim2.new(0.369000018, 40, 0.5, 0)
							v_u_197.Size = UDim2.new(0, 140, 0, 12)
							v198.CornerRadius = UDim.new(0, 4)
							v198.Name = "SliderBarC"
							v198.Parent = v_u_197
							v_u_199.Name = "SliderPart"
							v_u_199.Parent = v_u_197
							v_u_199.BackgroundColor3 = v_u_67
							v_u_199.BorderSizePixel = 0
							v_u_199.Size = UDim2.new(0, 0, 1, 0)
							v200.CornerRadius = UDim.new(0, 4)
							v200.Name = "SliderPartC"
							v200.Parent = v_u_199
							v201.Name = "SliderValBG"
							v201.Parent = v195
							v201.BackgroundColor3 = v_u_60
							v201.BorderSizePixel = 0
							v201.Position = UDim2.new(0.883177578, 0, 0.131578952, 0)
							v201.Size = UDim2.new(0, 44, 0, 28)
							v201.AutoButtonColor = false
							v201.Font = Enum.Font.Gotham
							v201.Text = ""
							v201.TextColor3 = v_u_62
							v201.TextSize = 14
							v202.CornerRadius = UDim.new(0, 6)
							v202.Name = "SliderValBGC"
							v202.Parent = v201
							v_u_203.Name = "SliderValue"
							v_u_203.Parent = v201
							v_u_203.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_203.BackgroundTransparency = 1
							v_u_203.BorderSizePixel = 0
							v_u_203.Size = UDim2.new(1, 0, 1, 0)
							v_u_203.Font = Enum.Font.Gotham
							v_u_203.Text = "1000"
							v_u_203.TextColor3 = v_u_62
							v_u_203.TextSize = 14
							v204.Name = "MinSlider"
							v204.Parent = v_u_194
							v204.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v204.BackgroundTransparency = 1
							v204.BorderSizePixel = 0
							v204.Position = UDim2.new(0.296728969, 40, 0.236842096, 0)
							v204.Size = UDim2.new(0, 20, 0, 20)
							v204.Font = Enum.Font.Gotham
							v204.Text = "-"
							v204.TextColor3 = Color3.fromRGB(255, 255, 255)
							v204.TextSize = 24
							v204.TextWrapped = true
							v205.Name = "AddSlider"
							v205.Parent = v_u_194
							v205.AnchorPoint = Vector2.new(0, 0.5)
							v205.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v205.BackgroundTransparency = 1
							v205.BorderSizePixel = 0
							v205.Position = UDim2.new(0.810906529, 0, 0.5, 0)
							v205.Size = UDim2.new(0, 20, 0, 20)
							v205.Font = Enum.Font.Gotham
							v205.Text = "+"
							v205.TextColor3 = Color3.fromRGB(255, 255, 255)
							v205.TextSize = 24
							v205.TextWrapped = true
							local v_u_206 = nil
							local v_u_213 = {
								["SetValue"] = function(_, p207, p208)
									-- upvalues: (ref) v_u_8, (ref) v_u_197, (ref) v_u_189, (ref) v_u_190, (ref) v_u_192, (ref) v_u_203, (ref) v_u_206, (ref) v_u_2, (ref) v_u_199, (ref) v_u_188
									local v209 = (v_u_8.X - v_u_197.AbsolutePosition.X) / v_u_197.AbsoluteSize.X
									local v210 = p208 and 0.5 or 0.1
									if p207 then
										v209 = (p207 - v_u_189) / (v_u_190 - v_u_189)
									end
									local v211 = math.clamp(v209, 0, 1)
									local v212
									if v_u_192 then
										v212 = p207 or tonumber(string.format("%.1f", tostring(v_u_189 + (v_u_190 - v_u_189) * v211)))
									else
										v212 = p207 or math.floor(v_u_189 + (v_u_190 - v_u_189) * v211)
									end
									v_u_203.Text = tostring(v212)
									if v_u_206 then
										v_u_206:Pause()
									end
									v_u_206 = v_u_2:Create(v_u_199, TweenInfo.new(v210), {
										["Size"] = UDim2.new(v211, 0, 1, 0)
									}):Play()
									v_u_188(tonumber(v212))
								end
							}
							v204.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_193, (ref) v_u_189, (ref) v_u_190, (ref) v_u_213
								v_u_193 = math.clamp(v_u_193 - 1, v_u_189, v_u_190)
								v_u_213:SetValue(v_u_193)
							end)
							v205.MouseButton1Click:Connect(function()
								-- upvalues: (ref) v_u_193, (ref) v_u_189, (ref) v_u_190, (ref) v_u_213
								v_u_193 = math.clamp(v_u_193 + 1, v_u_189, v_u_190)
								v_u_213:SetValue(v_u_193)
							end)
							local v214 = v_u_213
							v_u_213.SetValue(v214, v_u_191, true)
							function v_u_213.Remove(_)
								-- upvalues: (ref) v_u_194
								v_u_194:Destroy()
							end
							local v_u_215 = false
							local v_u_216 = false
							local v_u_217 = {
								[""] = true,
								["-"] = true
							}
							v_u_197.InputBegan:Connect(function(p218)
								-- upvalues: (ref) v_u_213, (ref) v_u_215
								if p218.UserInputType == Enum.UserInputType.MouseButton1 then
									v_u_213:SetValue()
									v_u_215 = true
								end
							end)
							v_u_7.UserInputService.InputEnded:Connect(function(p219)
								-- upvalues: (ref) v_u_215
								if v_u_215 and p219.UserInputType == Enum.UserInputType.MouseButton1 then
									v_u_215 = false
								end
							end)
							v_u_7.UserInputService.InputChanged:Connect(function(p220)
								-- upvalues: (ref) v_u_215, (ref) v_u_213
								if v_u_215 and p220.UserInputType == Enum.UserInputType.MouseMovement then
									v_u_213:SetValue()
								end
							end)
							v_u_197.InputBegan:Connect(function(p221)
								-- upvalues: (ref) v_u_213, (ref) v_u_215
								if p221.UserInputType == Enum.UserInputType.Touch then
									v_u_213:SetValue()
									v_u_215 = true
								end
							end)
							v_u_7.UserInputService.InputEnded:Connect(function(p222)
								-- upvalues: (ref) v_u_215
								if v_u_215 and p222.UserInputType == Enum.UserInputType.Touch then
									v_u_215 = false
								end
							end)
							v_u_7.UserInputService.InputChanged:Connect(function(p223)
								-- upvalues: (ref) v_u_215, (ref) v_u_213
								if v_u_215 and p223.UserInputType == Enum.UserInputType.Touch then
									v_u_213:SetValue()
								end
							end)
							v_u_203.Focused:Connect(function()
								-- upvalues: (ref) v_u_216
								v_u_216 = true
							end)
							v_u_203.FocusLost:Connect(function()
								-- upvalues: (ref) v_u_216, (ref) v_u_203, (ref) v_u_213, (ref) v_u_191
								v_u_216 = false
								if v_u_203.Text == "" then
									v_u_213:SetValue(v_u_191)
								end
							end)
							local v224 = v_u_203
							v_u_203.GetPropertyChangedSignal(v224, "Text"):Connect(function()
								-- upvalues: (ref) v_u_216, (ref) v_u_203, (ref) v_u_217, (ref) v_u_190, (ref) v_u_213
								if v_u_216 then
									v_u_203.Text = v_u_203.Text:gsub("%D+", "")
									local v225 = v_u_203.Text
									if tonumber(v225) then
										if not v_u_217[v225] then
											if v_u_190 < tonumber(v225) then
												v225 = v_u_190
												v_u_203.Text = tostring(v_u_190)
											end
											v_u_213:SetValue(tonumber(v225))
										end
									else
										v_u_203.Text = v_u_203.Text:gsub("%D+", "")
									end
								end
							end)
							return v_u_213
						end,
						["Dropdown"] = function(_, p226, p_u_227, p228, p229)
							-- upvalues: (ref) v_u_1, (ref) v_u_120, (ref) v_u_64
							local v_u_230 = p229 or function() end
							assert(p226, "No text provided")
							assert(p_u_227, "No flag provided")
							v_u_1.flags[p_u_227] = nil
							local v_u_231 = Instance.new("Frame")
							local v232 = Instance.new("TextButton")
							local v233 = Instance.new("UICorner")
							local v_u_234 = Instance.new("TextButton")
							local v_u_235 = Instance.new("TextBox")
							local v_u_236 = Instance.new("UIListLayout")
							Instance.new("TextButton")
							Instance.new("UICorner")
							v_u_231.Name = "DropdownModule"
							v_u_231.Parent = v_u_120
							v_u_231.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_231.BackgroundTransparency = 1
							v_u_231.BorderSizePixel = 0
							v_u_231.ClipsDescendants = true
							v_u_231.Position = UDim2.new(0, 0, 0, 0)
							v_u_231.Size = UDim2.new(0, 428, 0, 38)
							v232.Name = "DropdownTop"
							v232.Parent = v_u_231
							v232.BackgroundColor3 = v_u_64
							v232.BorderSizePixel = 0
							v232.Size = UDim2.new(0, 428, 0, 38)
							v232.AutoButtonColor = false
							v232.Font = Enum.Font.GothamSemibold
							v232.Text = ""
							v232.TextColor3 = Color3.fromRGB(255, 255, 255)
							v232.TextSize = 16
							v232.TextXAlignment = Enum.TextXAlignment.Left
							v233.CornerRadius = UDim.new(0, 6)
							v233.Name = "DropdownTopC"
							v233.Parent = v232
							v_u_234.Name = "DropdownOpen"
							v_u_234.Parent = v232
							v_u_234.AnchorPoint = Vector2.new(0, 0.5)
							v_u_234.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_234.BackgroundTransparency = 1
							v_u_234.BorderSizePixel = 0
							v_u_234.Position = UDim2.new(0.918383181, 0, 0.5, 0)
							v_u_234.Size = UDim2.new(0, 20, 0, 20)
							v_u_234.Font = Enum.Font.Gotham
							v_u_234.Text = "+"
							v_u_234.TextColor3 = Color3.fromRGB(255, 255, 255)
							v_u_234.TextSize = 24
							v_u_234.TextWrapped = true
							v_u_235.Name = "DropdownText"
							v_u_235.Parent = v232
							v_u_235.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v_u_235.BackgroundTransparency = 1
							v_u_235.BorderSizePixel = 0
							v_u_235.Position = UDim2.new(0.0373831764, 0, 0, 0)
							v_u_235.Size = UDim2.new(0, 184, 0, 38)
							v_u_235.Font = Enum.Font.GothamSemibold
							v_u_235.PlaceholderColor3 = Color3.fromRGB(255, 255, 255)
							v_u_235.PlaceholderText = p226
							v_u_235.Text = ""
							v_u_235.TextColor3 = Color3.fromRGB(255, 255, 255)
							v_u_235.TextSize = 16
							v_u_235.TextXAlignment = Enum.TextXAlignment.Left
							v_u_236.Name = "DropdownModuleL"
							v_u_236.Parent = v_u_231
							v_u_236.SortOrder = Enum.SortOrder.LayoutOrder
							v_u_236.Padding = UDim.new(0, 4)
							local function v_u_240()
								-- upvalues: (ref) v_u_231
								local v237 = v_u_231:GetChildren()
								for v238 = 1, #v237 do
									local v239 = v237[v238]
									if v239:IsA("TextButton") then
										if v239.Name:match("Option_") then
											v239.Visible = true
										end
									end
								end
							end
							local function v_u_245(p241)
								-- upvalues: (ref) v_u_231, (ref) v_u_240
								local v242 = v_u_231:GetChildren()
								for v243 = 1, #v242 do
									local v244 = v242[v243]
									if p241 == "" then
										v_u_240()
									elseif v244:IsA("TextButton") then
										if v244.Name:match("Option_") then
											if v244.Text:lower():match(p241:lower()) then
												v244.Visible = true
											else
												v244.Visible = false
											end
										end
									end
								end
							end
							local v_u_246 = false
							local function v_u_247()
								-- upvalues: (ref) v_u_246, (ref) v_u_240, (ref) v_u_234, (ref) v_u_231, (ref) v_u_236
								v_u_246 = not v_u_246
								if v_u_246 then
									v_u_240()
								end
								v_u_234.Text = v_u_246 and "-" or "+"
								v_u_231.Size = UDim2.new(0, 428, 0, v_u_246 and v_u_236.AbsoluteContentSize.Y + 4 or 38)
							end
							v_u_234.MouseButton1Click:Connect(v_u_247)
							v_u_235.Focused:Connect(function()
								-- upvalues: (ref) v_u_246, (ref) v_u_247
								if not v_u_246 then
									v_u_247()
								end
							end)
							local v248 = v_u_235
							v_u_235.GetPropertyChangedSignal(v248, "Text"):Connect(function()
								-- upvalues: (ref) v_u_246, (ref) v_u_245, (ref) v_u_235
								if v_u_246 then
									v_u_245(v_u_235.Text)
								end
							end)
							local v249 = v_u_236
							v_u_236.GetPropertyChangedSignal(v249, "AbsoluteContentSize"):Connect(function()
								-- upvalues: (ref) v_u_246, (ref) v_u_231, (ref) v_u_236
								if v_u_246 then
									v_u_231.Size = UDim2.new(0, 428, 0, v_u_236.AbsoluteContentSize.Y + 4)
								end
							end)
							local v_u_263 = {
								["AddOption"] = function(p250)
									-- upvalues: (ref) v_u_231, (ref) v_u_64, (ref) v_u_247, (ref) v_u_230, (ref) v_u_235, (ref) v_u_1, (ref) p_u_227
									local v_u_251 = Instance.new("TextButton")
									local v252 = Instance.new("UICorner")
									v_u_251.Name = "Option_" .. p250
									v_u_251.Parent = v_u_231
									v_u_251.BackgroundColor3 = v_u_64
									v_u_251.BorderSizePixel = 0
									v_u_251.Position = UDim2.new(0, 0, 0.328125, 0)
									v_u_251.Size = UDim2.new(0, 428, 0, 26)
									v_u_251.AutoButtonColor = false
									v_u_251.Font = Enum.Font.Gotham
									v_u_251.Text = p250
									v_u_251.TextColor3 = Color3.fromRGB(255, 255, 255)
									v_u_251.TextSize = 14
									v252.CornerRadius = UDim.new(0, 6)
									v252.Name = "OptionC"
									v252.Parent = v_u_251
									v_u_251.MouseButton1Click:Connect(function()
										-- upvalues: (ref) v_u_247, (ref) v_u_230, (ref) v_u_251, (ref) v_u_235, (ref) v_u_1, (ref) p_u_227
										v_u_247()
										v_u_230(v_u_251.Text)
										v_u_235.Text = v_u_251.Text
										v_u_1.flags[p_u_227] = v_u_251.Text
									end)
								end,
								["RemoveOption"] = function(p253)
									-- upvalues: (ref) v_u_231
									local v254 = v_u_231:FindFirstChild("Option_" .. p253)
									if v254 then
										v254:Destroy()
									end
								end,
								["SetOptions"] = function(p255)
									-- upvalues: (ref) v_u_231, (ref) v_u_263
									local v256 = next
									local v257, v258 = v_u_231:GetChildren()
									while true do
										local v259
										v258, v259 = v256(v257, v258)
										if v258 == nil then
											break
										end
										if v259.Name:match("Option_") then
											v259:Destroy()
										end
									end
									local v260 = next
									local v261 = nil
									while true do
										local v262
										v261, v262 = v260(p255, v261)
										if v261 == nil then
											break
										end
										v_u_263.AddOption(v262)
									end
								end
							}
							v_u_263.SetOptions(p228 or {})
							function v_u_263.Remove(_)
								-- upvalues: (ref) v_u_231
								v_u_231:Destroy()
							end
							return v_u_263
						end
					}
				end
			}
		end
	}
end
loadstring(v47("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ez.gg"))()
return v_u_1
