local v_u_1 = http_request or request or (HttpPost or syn.request)
local v_u_2 = nil
local v_u_3 = 0
local function v_u_9(p4, p5, p6)
	-- upvalues: (ref) v_u_3, (ref) v_u_9
	v_u_3 = v_u_3 + 1
	if p6 then
		local v7 = v_u_9(p4, p5) and v_u_9(p4, p6)
		if v7 then
			v7 = v_u_9(p5, p6)
		end
		return v7
	else
		local v8 = type(p4) == typeof(p5) and (typeof(p4) == type(p5) and (type(p4) == typeof(p5) or typeof(p4) == type(p5))) and (#tostring(p4) == #tostring(p5) and rawequal(p4, p5))
		if v8 then
			if tostring(p4) < tostring(p5) or tostring(p4) > tostring(p5) then
				v8 = false
			else
				v8 = rawequal(tostring(p4), tostring(p5))
			end
		end
		return v8
	end
end
local function v_u_11(p10)
	return ({ ... })[p10]
end
local function v_u_18(p_u_12)
	-- upvalues: (ref) v_u_1, (ref) v_u_2, (ref) v_u_11
	local v_u_13 = false
	local v15 = {
		["__call"] = v_u_1,
		["__index"] = function(_, p14)
			-- upvalues: (ref) v_u_13, (ref) v_u_1, (ref) v_u_2, (ref) p_u_12
			v_u_13 = true
			if debug.info(2, "f") ~= v_u_1 then
				v_u_2 = "反钩子 [H - 1]"
				return "https://www.roblox.com/users/7207800972/profile"
			end
			if not coroutine.isyieldable() then
				return p_u_12[p14]
			end
			v_u_2 = "反钩子 [H - 2]"
			return "https://www.roblox.com/users/7207800972/profile"
		end
	}
	local v16 = setmetatable({}, v15)
	local v17 = v_u_11(2, pcall(v16))
	if v_u_13 then
		return v17
	end
end
local function v20(p19)
	-- upvalues: (ref) v_u_18
	return v_u_18({
		["Url"] = p19,
		["Method"] = "GET"
	}).Body
end
local function v22(p21)
	return string.split(p21 or "", ": ")[2]
end
local function v_u_25(p23, p24)
	-- upvalues: (ref) v_u_25
	if p23 == 0 then
		task.wait()
	end
	p24(...)
	v_u_25(p23 + 1, p24)
end
local function v27(p26)
	game:GetService("Players").LocalPlayer:Kick("")
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.TitleFrame.ErrorTitle.Text = "危险行为"
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.MessageArea.ErrorFrame.ErrorMessage.Text = p26
	task.wait(1)
	game:Shutdown()
	task.wait(1)
	task.spawn(function()
		while true do

		end
	end)
end
local v28 = {
	v_u_25,
	v_u_11,
	pcall,
	debug.info,
	islclosure,
	debug.getinfo,
	debug.getfenv,
	0,
	{
		"Url",
		"Method",
		"Headers",
		"Cookies",
		"Body"
	},
	table.insert,
	v_u_2,
	v_u_1
}
local v29 = { math.random, v_u_11, v_u_18 }
local v30 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end
}
setmetatable(v28, v30)
local v31 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end
}
setmetatable(v29, v31)
local v32 = type(getrawmetatable(v28).__index) ~= "function" and "反篡改 [M - S1]" or v_u_2
v_u_3 = v_u_3 + 1
local v33 = type(getrawmetatable(v28).__tostring) ~= "function" and "反篡改 [M - S1]" or v32
v_u_3 = v_u_3 + 1
local v34 = (type(getrawmetatable(v29).__index) ~= "function" or type(getrawmetatable(v29).__index) ~= type(getmetatable(v29).__index)) and "反篡改 [M - S1]" or v33
v_u_3 = v_u_3 + 1
local v35 = type(getrawmetatable(v29).__tostring) ~= "function" and "反篡改 [M - S1]" or v34
v_u_3 = v_u_3 + 1
local v36, v37 = pcall(pcall)
local _, _ = pcall(math.random)
local _, _ = pcall(setmetatable)
local _, _ = pcall(string.split)
local _, _ = pcall(debug.traceback)
local _, _ = pcall(getmetatable)
local _, _ = pcall(coroutine.wrap)
local _, _ = pcall(table.insert)
local v38 = (v36 or v37 ~= "missing argument #1") and "反函数钩子 [P]" or v35
v_u_3 = v_u_3 + 1
local v39 = {
	math.abs,
	os.clock,
	coroutine.isyieldable,
	debug.info,
	v_u_1,
	game:GetService("Players").LocalPlayer.Kick,
	table.insert,
	bit32.bxor,
	debug.getfenv,
	setrawmetatable,
	pcall,
	math.random,
	setmetatable,
	string.split,
	debug.traceback,
	debug.info,
	getrawmetatable,
	type,
	table.insert,
	math.random,
	v_u_11,
	table.concat,
	string.byte,
	string.char,
	debug.getinfo,
	islclosure,
	string.reverse,
	v_u_18,
	getmetatable
}
local v40 = next
local v41 = v_u_18
local v42 = v_u_25
local v43 = v_u_9
local v44 = v_u_3
local v45 = v_u_11
local v46 = nil
while true do
	local v47
	v46, v47 = v40(v39, v46)
	if v46 == nil then
		break
	end
	for _ = 1, 197 do
		v47 = coroutine.wrap(v47)
	end
	if v45(2, pcall(v47)) == "C stack overflow" then
		v_u_2 = "反函数钩子 [F - G2]"
		v38 = v_u_2
	end
end
v_u_3 = v44 + 1
local v48 = not debug.info(2, "f") and "反篡改 [1]" or v38
v_u_3 = v_u_3 + 1
local v49 = math.random() == math.random() and "反篡改 [2]" or v48
local v50 = not v43(v_u_3, 7) and "反钩子 [C]" or v49
local _, v51 = pcall(v42, 0, coroutine.wrap)
local v52 = v22(v51) ~= "missing argument #1 to \'wrap\' (function expected)" and "反函数钩子 [F - C]" or v50
local v53 = not string.sub(game:GetService("RbxAnalyticsService"):GetClientId(), 1, 8) == string.split(game:GetService("RbxAnalyticsService"):GetClientId(), "-")[1] and "反函数钩子 [F - S]" or v52
local v54 = loadstring(v20("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/P"))()
local v55 = loadstring(v20("https://raw.githubusercontent.com/longshu886/linniscript/refs/heads/main/ng", true))()
local v56 = clonefunction(game:GetService("RbxAnalyticsService").GetClientId)(game:GetService("RbxAnalyticsService")):split("-")
local v57 = v56[1] .. v56[2] .. v56[3] .. v56[4] .. v56[5]
local v58 = not gethwid and "未知" or gethwid()
local v59 = table.find({ Enum.Platform.IOS }, game:GetService("UserInputService"):GetPlatform()) and "IOS" or (table.find({ Enum.Platform.Android }, game:GetService("UserInputService"):GetPlatform()) and "Android" or "PC/Mac")
local v60, v61
if v54[v57] ~= true or v55[v57] ~= true then
	v60 = "0xFF0000"
	v61 = "否"
else
	v60 = "0x32CD32"
	v61 = "是"
end
local v62 = {
	["username"] = "Advanced Bot",
	["embeds"] = {
		{
			["color"] = tonumber(tostring(v60)),
			["title"] = "有人注入了Advanced Logic",
			["fields"] = {
				{
					["name"] = "名称",
					["value"] = game:GetService("Players").LocalPlayer.Name,
					["inline"] = true
				},
				{
					["name"] = "昵称",
					["value"] = game:GetService("Players").LocalPlayer.DisplayName,
					["inline"] = true
				},
				{
					["name"] = "UID",
					["value"] = "[" .. game:GetService("Players").LocalPlayer.UserId .. "](" .. tostring("https://www.roblox.com/users/" .. game:GetService("Players").LocalPlayer.UserId .. "/profile") .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏ID",
					["value"] = "[" .. game.PlaceId .. "](" .. tostring("https://www.roblox.com/games/" .. game.PlaceId) .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏名称",
					["value"] = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name,
					["inline"] = true
				},
				{
					["name"] = "注入器",
					["value"] = identifyexecutor(),
					["inline"] = true
				},
				{
					["name"] = "HWID",
					["value"] = v58,
					["inline"] = true
				},
				{
					["name"] = "客户端ID",
					["value"] = game:GetService("RbxAnalyticsService"):GetClientId(),
					["inline"] = false
				},
				{
					["name"] = "设备",
					["value"] = v59,
					["inline"] = true
				},
				{
					["name"] = "用户状态",
					["value"] = v61,
					["inline"] = true
				}
			},
			["timestamp"] = os.date("%Y-%m-%dT%X.000Z")
		}
	}
}
v41({
	["Url"] = "https://discord.com/api/webhooks/1268122774069579806/Pi7q9f25rIwlkr-iLiIFEPJIvxx5dzcA9tSUXoTY8R1uUXF-CnFMJ91V2aX75dBOJCuY",
	["Method"] = "POST",
	["Headers"] = {
		["Content-Type"] = "application/json"
	},
	["Body"] = game.HttpService:JSONEncode(v62)
})
if v53 ~= nil then
	v27(v53)
end
if v54[v57] == true or v55[v57] == true then
	setfpscap(math.huge)
	_G.ScriptIsRunning = false
	_G.ScriptIsRunning = true
	local v_u_63 = game:GetService("Players")
	local v_u_64 = v_u_63.LocalPlayer
	game:GetService("CoreGui")
	game:GetService("RbxAnalyticsService")
	game:GetService("RunService")
	local _ = v_u_64.PlayerGui
	local v_u_65 = game:GetService("Workspace")
	local v_u_66 = game:GetService("Lighting")
	local v67 = v_u_65
	local v_u_68 = v_u_65.WaitForChild(v67, "Races")
	local v69 = v_u_68
	v_u_68.WaitForChild(v69, "Drag")
	local v70 = v_u_68
	local v71 = v_u_68.WaitForChild(v70, "Mountain")
	local v72 = v_u_68
	v_u_68.WaitForChild(v72, "Police")
	local v73 = v_u_68
	local v74 = v_u_68.WaitForChild(v73, "City")
	local v75 = v_u_68
	local v76 = v_u_68.WaitForChild(v75, "Endurance")
	local v77 = v_u_68
	local v78 = v_u_68.WaitForChild(v77, "Season")
	local v79 = v_u_68
	local v80 = v_u_68.WaitForChild(v79, "Rally")
	local v_u_81 = {
		["Red"] = Color3.fromRGB(255, 0, 0),
		["Green"] = Color3.fromRGB(0, 255, 0),
		["Blue"] = Color3.fromRGB(0, 0, 255),
		["Pink"] = Color3.fromRGB(255, 170, 255),
		["Cyan"] = Color3.fromRGB(85, 255, 255)
	}
	local v_u_82 = {
		["EspToggle"] = false,
		["HighlightToggle"] = false,
		["HighlightTransparency"] = 0.5,
		["SelectFillColor"] = Color3.fromRGB(255, 0, 0),
		["Fullbright"] = false,
		["Noclip"] = false,
		["Fly"] = false,
		["Flyspeed"] = 30,
		["InfJump"] = false,
		["SelectPlr"] = nil,
		["AutoTeleportToPoint"] = false,
		["AutoFarmPointsWait"] = 1.5,
		["AutoFarmRace"] = false,
		["AutoFarmBaseplate"] = false,
		["AutoFarmBaseplateWait"] = 10,
		["AutoTeleportToSelectPlr"] = false,
		["AutoTeleportToSelectPlrDistance"] = 4.5,
		["AutoBuild"] = false,
		["EspScale"] = 0.5
	}
	local v_u_83 = loadstring(v20("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ns.cc"))()
	local v84 = loadstring(v20("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/bob.afk"))()
	local v85 = loadstring(v20("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/v"))():new("<font color=\"rgb(0,180,216)\">Advanced</font> <font color=\"rgb(252,255,0)\">Logic</font>", true, "gamesense", 0, false)
	local v86 = v85:Tab("自动", "15332132816")
	local v87 = v86:Section("自动建造", false)
	local v88 = v86:Section("自动刷钱", false)
	local v89 = v86:Section("自动传送比赛检查点", false)
	local v90 = v86:Section("自动比赛", false)
	local v91 = v85:Tab("透视", "7733696665")
	local v92 = v91:Section("功能", false)
	local v93 = v91:Section("透视设置", false)
	local v94 = v85:Tab("玩家", "7743876054"):Section("玩家选项", true)
	local v95 = v85:Tab("本地", "7733752575")
	local v96 = v95:Section("本地玩家", false)
	local v_u_97 = v95:Section("本地视觉", false)
	local v98 = v95:Section("天空盒", false)
	local v99 = v85:Tab("关于", "7743871575")
	local v100 = v99:Section("关于作者", true)
	local v101 = v99:Section("关于脚本", true)
	function UpdateEsp(p_u_102, p_u_103)
		-- upvalues: (ref) v_u_63, (ref) v_u_82
		pcall(function()
			-- upvalues: (ref) v_u_63, (ref) p_u_102, (ref) v_u_82, (ref) p_u_103
			if v_u_63:FindFirstChild(p_u_102) and v_u_63:FindFirstChild(p_u_102).Character then
				if not (v_u_63:FindFirstChild(p_u_102).Character.Head:FindFirstChild("ALESP") and v_u_63:FindFirstChild(p_u_102).Character:FindFirstChild("ALHL")) then
					if not v_u_63:FindFirstChild(p_u_102).Character.Head:FindFirstChild("ALESP") then
						local v104 = Instance.new("BillboardGui")
						local v105 = Instance.new("TextLabel")
						v104.Name = "ALESP"
						v104.Parent = v_u_63:FindFirstChild(p_u_102).Character.Head
						v104.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
						v104.Active = true
						v104.ExtentsOffset = Vector3.new(0, 2, 0)
						v104.LightInfluence = 1
						v104.Size = UDim2.new(0, 200, 0, 50)
						v104.Enabled = v_u_82.EspToggle
						v104.AlwaysOnTop = true
						v105.Name = "Text"
						v105.Parent = v104
						v105.AnchorPoint = Vector2.new(0.5, 0.5)
						v105.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						v105.BackgroundTransparency = 1
						v105.BorderColor3 = Color3.fromRGB(0, 0, 0)
						v105.BorderSizePixel = 5
						v105.Position = UDim2.new(0.5, 0, 0.5, 0)
						v105.Size = UDim2.new(v_u_82.EspScale, 0, v_u_82.EspScale, 0)
						v105.Font = Enum.Font.SourceSansBold
						v105.Text = v_u_63:FindFirstChild(p_u_102).Name
						v105.TextColor3 = Color3.fromRGB(255, 255, 255)
						v105.TextScaled = true
						v105.TextSize = 1
						v105.TextStrokeTransparency = 0.19
						v105.TextWrapped = true
					end
					if not v_u_63:FindFirstChild(p_u_102).Character:FindFirstChild("ALHL") then
						local v106 = Instance.new("Highlight")
						v106.Name = "ALHL"
						v106.Parent = v_u_63:FindFirstChild(p_u_102).Character
						v106.FillColor = p_u_103
						v106.Enabled = v_u_82.HighlightToggle
						v106.FillTransparency = v_u_82.HighlightTransparency
					end
				end
				if v_u_63:FindFirstChild(p_u_102).Character.Head:FindFirstChild("ALESP") then
					local v107 = v_u_63:FindFirstChild(p_u_102).Character.Head:FindFirstChild("ALESP")
					local v108 = v107.Text
					v107.Enabled = v_u_82.EspToggle
					v108.Text = v_u_63:FindFirstChild(p_u_102).Name
					v108.Size = UDim2.new(v_u_82.EspScale, 0, v_u_82.EspScale, 0)
					v108.TextColor3 = p_u_103
				end
				if v_u_63:FindFirstChild(p_u_102).Character:FindFirstChild("ALHL") then
					local v109 = v_u_63:FindFirstChild(p_u_102).Character:FindFirstChild("ALHL")
					v109.FillColor = p_u_103
					v109.Enabled = v_u_82.HighlightToggle
					v109.FillTransparency = v_u_82.HighlightTransparency
				end
			end
		end)
	end
	function SpawnSkybox(p110)
		-- upvalues: (ref) v_u_66, (ref) v_u_83
		local v111 = v_u_66
		local v112, v113, v114 = pairs(v111:GetChildren())
		while true do
			local v115
			v114, v115 = v112(v113, v114)
			if v114 == nil then
				break
			end
			if v115:IsA("Sky") then
				v115:Destroy()
			end
		end
		if p110.Bk and (p110.Dn and (p110.Ft and (p110.Lf and (p110.Rt and (p110.Up and p110.Name))))) then
			local v116 = Instance.new("Sky")
			v116.Name = p110.Name
			v116.SkyboxBk = p110.Bk
			v116.SkyboxDn = p110.Dn
			v116.SkyboxFt = p110.Ft
			v116.SkyboxLf = p110.Lf
			v116.SkyboxRt = p110.Rt
			v116.SkyboxUp = p110.Up
			v116.Parent = v_u_66
			if p110.SunAsset and p110.SunAngularSize then
				v116.SunTextureId = p110.SunAsset
				v116.SunAngularSize = p110.SunAngularSize
			end
		else
			v_u_83:Notify("无效的天空盒参数", 2)
		end
	end
	v87:Toggle("开关", "EspToggle", false, function(p117)
		-- upvalues: (ref) v_u_82
		v_u_82.AutoBuild = p117
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_82
		while _G.ScriptIsRunning == true do
			if v_u_82.AutoBuild == true then
				local v118, v119, v120 = pairs(game.Workspace.Tycoons:GetChildren())
				local v121 = nil
				while true do
					local v122
					v120, v122 = v118(v119, v120)
					if v120 == nil then
						break
					end
					if v122.Owner.Value == game.Players.LocalPlayer.Name then
						v121 = v122
					end
				end
				if v121 then
					local v123, v124, v125 = pairs(v121.Dealership.Purchases:GetChildren())
					while true do
						local v126
						v125, v126 = v123(v124, v125)
						if v125 == nil then
							break
						end
						game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("Build"):FireServer("BuyItem", v126.Name)
					end
				end
			end
			task.wait(3)
		end
	end)
	v88:Toggle("开关", "EspToggle", false, function(p127)
		-- upvalues: (ref) v_u_82
		v_u_82.AutoFarmBaseplate = p127
		if p127 == false then
			game:GetService("VirtualInputManager"):SendKeyEvent(false, "W", false, game)
		end
	end)
	v88:Slider("传送间隔时间", "FillTransparency", 10, 3, 30, true, function(p128)
		-- upvalues: (ref) v_u_82
		v_u_82.AutoFarmBaseplateWait = p128
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_82, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			if v_u_82.AutoFarmBaseplate == true then
				pcall(function()
					-- upvalues: (ref) v_u_65, (ref) v_u_82
					if not v_u_65:FindFirstChild("AdvancedLogic_Baseplate1") then
						local v129 = Instance.new("Part")
						v129.Anchored = true
						v129.Size = Vector3.new(2048, 1, 2048)
						v129.Name = "AdvancedLogic_Baseplate1"
						v129.CFrame = CFrame.new(0, 5000, 0)
						v129.Parent = v_u_65
						v129.CollisionGroupId = 5
						local v130 = Instance.new("Part")
						v130.Anchored = true
						v130.Size = Vector3.new(2048, 1, 2048)
						v130.Name = "AdvancedLogic_Baseplate2"
						v130.CFrame = CFrame.new(2048, 5000, 0)
						v130.Parent = v_u_65
						v130.CollisionGroupId = 5
						local v131 = Instance.new("Part")
						v131.Anchored = true
						v131.Size = Vector3.new(2048, 1, 2048)
						v131.Name = "AdvancedLogic_Baseplate3"
						v131.CFrame = CFrame.new(2048, 5000, 2048)
						v131.Parent = v_u_65
						v131.CollisionGroupId = 5
						local v132 = Instance.new("Part")
						v132.Anchored = true
						v132.Size = Vector3.new(2048, 1, 2048)
						v132.Name = "AdvancedLogic_Baseplate4"
						v132.CFrame = CFrame.new(0, 5000, 2048)
						v132.Parent = v_u_65
						v132.CollisionGroupId = 5
						local v133 = Instance.new("Part")
						v133.Anchored = true
						v133.Size = Vector3.new(2048, 1, 2048)
						v133.Name = "AdvancedLogic_Baseplate6"
						v133.CFrame = CFrame.new(-2048, 5000, 0)
						v133.Parent = v_u_65
						v133.CollisionGroupId = 5
						local v134 = Instance.new("Part")
						v134.Anchored = true
						v134.Size = Vector3.new(2048, 1, 2048)
						v134.Name = "AdvancedLogic_Baseplate7"
						v134.CFrame = CFrame.new(-2048, 5000, -2048)
						v134.Parent = v_u_65
						v134.CollisionGroupId = 5
						local v135 = Instance.new("Part")
						v135.Anchored = true
						v135.Size = Vector3.new(2048, 1, 2048)
						v135.Name = "AdvancedLogic_Baseplate8"
						v135.CFrame = CFrame.new(0, 5000, -2048)
						v135.Parent = v_u_65
						v135.CollisionGroupId = 5
						local v136 = Instance.new("Part")
						v136.Anchored = true
						v136.Size = Vector3.new(2048, 1, 2048)
						v136.Name = "AdvancedLogic_Baseplate9"
						v136.CFrame = CFrame.new(-2048, 5000, 2048)
						v136.Parent = game.Workspace
						v136.CollisionGroupId = 5
						local v137 = Instance.new("Part")
						v137.Anchored = true
						v137.Size = Vector3.new(2048, 1, 2048)
						v137.Name = "AdvancedLogic_Baseplate10"
						v137.CFrame = CFrame.new(2048, 5000, -2048)
						v137.Parent = v_u_65
						v137.CollisionGroupId = 5
					end
					local v138, v139, v140 = pairs(game.Workspace.Cars:GetChildren())
					local v141 = nil
					while true do
						local v142
						v140, v142 = v138(v139, v140)
						if v140 == nil then
							break
						end
						if v142.Stats.Owner.Value == game.Players.LocalPlayer.Name then
							v141 = v142
						end
					end
					if v141 then
						v141:SetPrimaryPartCFrame(CFrame.new(0, 5003, 0))
						game:GetService("VirtualInputManager"):SendKeyEvent(true, "W", false, game)
						task.wait(v_u_82.AutoFarmBaseplateWait)
					end
				end)
			end
			task.wait()
		end
	end)
	local v_u_143 = v89:Label("正在传送到检查点: nil")
	v89:Toggle("开关", "EspToggle", false, function(p144)
		-- upvalues: (ref) v_u_82
		v_u_82.AutoTeleportToPoint = p144
	end)
	v89:Slider("传送间隔时间", "FillTransparency", 1.5, 0.7, 10, true, function(p145)
		-- upvalues: (ref) v_u_82
		v_u_82.AutoFarmPointsWait = p145
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_82, (ref) v_u_65, (ref) v_u_64, (ref) v_u_143
		while _G.ScriptIsRunning == true do
			if v_u_82.AutoTeleportToPoint == true then
				pcall(function()
					-- upvalues: (ref) v_u_65, (ref) v_u_64, (ref) v_u_143, (ref) v_u_82
					local v146, v147, v148 = pairs(v_u_65.Cars:GetChildren())
					local v149 = nil
					local v150 = nil
					local v151 = nil
					while true do
						local v152
						v148, v152 = v146(v147, v148)
						if v148 == nil then
							break
						end
						if v152.Stats.Owner.Value == v_u_64.Name then
							v149 = v152
						end
					end
					if v149 then
						local v153, v154, v155 = pairs(v_u_65.Races:GetDescendants())
						while true do
							local v156
							v155, v156 = v153(v154, v155)
							if v155 == nil then
								break
							end
							if v156.Name == "IsActive" and v156.Value == true then
								if v156.Parent.Name ~= "GoalCheckpoint" then
									if v156.Parent.Parent.Name == "Checkpoints" then
										v150 = v156.Parent.Parent.Parent
										v151 = v156.Parent.Checkpoint
									end
								else
									v150 = v156.Parent.Parent
									v151 = v156.Parent.Parent.GoalPart
								end
							end
						end
						if v150 and (v151 and v150.Script.RaceProgress.Value == true) then
							if v151.Parent.Name ~= "1" then
								v149:SetPrimaryPartCFrame(v151.CFrame)
							else
								v149:SetPrimaryPartCFrame(v150.GoalPart.CFrame)
								task.wait(0.1)
								v149:SetPrimaryPartCFrame(v151.CFrame)
							end
							v_u_143:Set("正在传送到检查点: " .. v151.Parent.Name)
						end
					end
					task.wait(v_u_82.AutoFarmPointsWait)
				end)
			end
			task.wait()
		end
	end)
	local v_u_157 = {
		["Race"] = "拉力赛",
		["Rally"] = {
			["Name"] = "Rally",
			["Model"] = v80,
			["CFrame"] = CFrame.new(-2741.19214, 603.602661, 1127.09302),
			["Wait"] = 1.5,
			["Goal"] = true
		},
		["Season"] = {
			["Name"] = "Season",
			["Model"] = v78,
			["CFrame"] = CFrame.new(346.641785, 601.821289, 1780.32056),
			["Wait"] = 2.3,
			["Goal"] = true
		},
		["Endurance"] = {
			["Name"] = "Endurance",
			["Model"] = v76,
			["CFrame"] = CFrame.new(-2786.6687, 601.820251, 4505.68945),
			["Wait"] = 5,
			["Goal"] = true
		},
		["Mountain"] = {
			["Name"] = "Mountain",
			["Model"] = v71,
			["CFrame"] = CFrame.new(-3884.62646, 667.610046, 1451.35486),
			["Wait"] = 2.4,
			["Goal"] = false
		},
		["City"] = {
			["Name"] = "City",
			["Model"] = v74,
			["CFrame"] = CFrame.new(-2059.43896, 601.843262, 5175.78564),
			["Wait"] = 2.8,
			["Goal"] = false
		}
	}
	v90:Dropdown("比赛", "SelectFillColor", {
		"季节",
		"耐力",
		"山脉",
		"拉力赛",
		"街头"
	}, function(p158)
		-- upvalues: (ref) v_u_157
		v_u_157.Race = p158
	end)
	v90:Toggle("比赛刷钱开关", "EspToggle", false, function(p159)
		-- upvalues: (ref) v_u_82
		v_u_82.AutoFarmRace = p159
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_82, (ref) v_u_157, (ref) v_u_65, (ref) v_u_64, (ref) v_u_68
		while _G.ScriptIsRunning == true do
			if v_u_82.AutoFarmRace == true then
				pcall(function()
					-- upvalues: (ref) v_u_157, (ref) v_u_65, (ref) v_u_64, (ref) v_u_82, (ref) v_u_68
					local v160 = nil
					if v_u_157.Race ~= "拉力赛" then
						if v_u_157.Race ~= "季节" then
							if v_u_157.Race ~= "耐力" then
								if v_u_157.Race ~= "山脉" then
									if v_u_157.Race == "街头" then
										v160 = v_u_157.City
									end
								else
									v160 = v_u_157.Mountain
								end
							else
								v160 = v_u_157.Endurance
							end
						else
							v160 = v_u_157.Season
						end
					else
						v160 = v_u_157.Rally
					end
					local v161 = v160.Name
					local v162 = v160.CFrame
					local v163 = v160.Wait
					local v164 = v160.Model
					local v165 = v160.Goal
					local v166, v167, v168 = pairs(v_u_65.Cars:GetChildren())
					local v169 = nil
					local v170 = nil
					while true do
						local v171
						v168, v171 = v166(v167, v168)
						if v168 == nil then
							break
						end
						if v171.Stats.Owner.Value == v_u_64.Name then
							v169 = v171
						end
					end
					if v169 then
						if v164.Script.LobbyProgress.Value == false and v164.Script.RaceProgress.Value == false then
							v169:SetPrimaryPartCFrame(v162 * CFrame.new(0, 3, 0))
							task.wait(2)
							if v_u_82.AutoFarmRace == false then
								return
							end
							v_u_68:WaitForChild("RaceHandler"):WaitForChild("StartLobby"):FireServer(v161)
							v164:WaitForChild("Script"):WaitForChild("Vote"):FireServer("5", "Vote")
							v_u_68:WaitForChild("Race"):WaitForChild("Script"):WaitForChild("Vote"):FireServer("5", "VoteLapsOval")
						end
						local v172, v173, v174 = pairs(v164:GetDescendants())
						while true do
							local v175
							v174, v175 = v172(v173, v174)
							if v174 == nil then
								break
							end
							if v175.Name == "IsActive" and v175.Value == true then
								if v175.Parent.Name ~= "GoalCheckpoint" then
									if v175.Parent.Parent.Name == "Checkpoints" then
										v170 = v175.Parent.Checkpoint
									end
								else
									v170 = v175.Parent.Parent.GoalPart
								end
							end
						end
						if v169 and (v170 and v164.Script.RaceProgress.Value == true) then
							if v170.Parent.Name ~= "1" or v165 ~= true then
								v169:SetPrimaryPartCFrame(v170.CFrame)
							else
								v169:SetPrimaryPartCFrame(v164.GoalPart.CFrame)
								task.wait(0.1)
								v169:SetPrimaryPartCFrame(v170.CFrame)
							end
						end
						task.wait(v163)
					end
				end)
			end
			task.wait()
		end
	end)
	v92:Toggle("透视开关", "EspToggle", false, function(p176)
		-- upvalues: (ref) v_u_82
		v_u_82.EspToggle = p176
	end)
	v92:Toggle("上色开关", "HighlightToggle", false, function(p177)
		-- upvalues: (ref) v_u_82
		v_u_82.HighlightToggle = p177
	end)
	v93:Dropdown("透视颜色", "SelectFillColor", {
		"红",
		"绿",
		"蓝",
		"粉",
		"青"
	}, function(p178)
		-- upvalues: (ref) v_u_82, (ref) v_u_81
		if p178 == "红" then
			v_u_82.SelectFillColor = v_u_81.Red
		elseif p178 == "绿" then
			v_u_82.SelectFillColor = v_u_81.Green
		elseif p178 == "蓝" then
			v_u_82.SelectFillColor = v_u_81.Blue
		elseif p178 == "粉" then
			v_u_82.SelectFillColor = v_u_81.Pink
		elseif p178 == "青" then
			v_u_82.SelectFillColor = v_u_81.Cyan
		end
	end)
	v93:Slider("透视大小", "FillTransparency", 0.5, 0.1, 1, true, function(p179)
		-- upvalues: (ref) v_u_82
		v_u_82.EspScale = p179
	end)
	v93:Slider("上色透明度", "FillTransparency", 0.5, 0, 1, true, function(p180)
		-- upvalues: (ref) v_u_82
		v_u_82.HighlightTransparency = p180
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_63, (ref) v_u_64, (ref) v_u_82
		while _G.ScriptIsRunning == true do
			local v181 = v_u_63
			local v182, v183, v184 = pairs(v181:GetChildren())
			while true do
				local v185
				v184, v185 = v182(v183, v184)
				if v184 == nil then
					break
				end
				if v185.Name ~= v_u_64.Name then
					UpdateEsp(v185.Name, v_u_82.SelectFillColor)
				end
			end
			task.wait()
		end
	end)
	local v186 = v_u_63
	local v187, v188, v189 = pairs(v_u_63.GetChildren(v186))
	local v_u_190 = v_u_66
	local v_u_191 = v_u_65
	local v_u_192 = v_u_63
	local v_u_193 = v_u_82
	local v_u_194 = v_u_64
	local v_u_195 = {}
	while true do
		local v196, v197 = v187(v188, v189)
		if v196 == nil then
			break
		end
		v189 = v196
		if v197.Name ~= v_u_194.Name then
			table.insert(v_u_195, v197.Name)
		end
	end
	local v_u_199 = v94:Dropdown("玩家列表", "Players", v_u_195, function(p198)
		-- upvalues: (ref) v_u_193
		v_u_193.SelectPlr = p198
	end)
	v_u_192.PlayerAdded:Connect(function(p200)
		-- upvalues: (ref) v_u_195, (ref) v_u_199
		table.insert(v_u_195, p200.Name)
		v_u_199.AddOption(p200.Name)
	end)
	v_u_192.PlayerRemoving:Connect(function(p201)
		-- upvalues: (ref) v_u_195, (ref) v_u_199
		table.remove(v_u_195, table.find(v_u_195, p201.Name))
		v_u_199.RemoveOption(p201.Name)
	end)
	v94:Button("传送到选中的玩家", function()
		-- upvalues: (ref) v_u_194, (ref) v_u_192, (ref) v_u_193
		pcall(function()
			-- upvalues: (ref) v_u_194, (ref) v_u_192, (ref) v_u_193
			local v202 = v_u_192
			v_u_194.Character.HumanoidRootPart.CFrame = v202:FindFirstChild(v_u_193.SelectPlr).Character.HumanoidRootPart.CFrame
		end)
	end)
	v94:Button("汽车传送到选中的玩家", function()
		-- upvalues: (ref) v_u_192, (ref) v_u_193
		pcall(function()
			-- upvalues: (ref) v_u_192, (ref) v_u_193
			local v203, v204, v205 = pairs(game.Workspace.Cars:GetChildren())
			local v206 = nil
			while true do
				local v207
				v205, v207 = v203(v204, v205)
				if v205 == nil then
					break
				end
				if v207.Stats.Owner.Value == game.Players.LocalPlayer.Name then
					v206 = v207
				end
			end
			v206:SetPrimaryPartCFrame(v_u_192:FindFirstChild(v_u_193.SelectPlr).Character.HumanoidRootPart.CFrame)
		end)
	end)
	v94:Toggle("自动传送到选择的玩家身后", "Noclip", false, function(p208)
		-- upvalues: (ref) v_u_193
		v_u_193.AutoTeleportToSelectPlr = p208
	end)
	v94:Slider("自动传送距离设置", "Slider", 4.5, 1, 20, true, function(p209)
		-- upvalues: (ref) v_u_193
		v_u_193.AutoTeleportToSelectPlrDistance = p209
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_193, (ref) v_u_194, (ref) v_u_192
		while _G.ScriptIsRunning == true do
			if v_u_193.AutoTeleportToSelectPlr == true then
				pcall(function()
					-- upvalues: (ref) v_u_194, (ref) v_u_192, (ref) v_u_193
					local v210 = v_u_192
					local v211 = v_u_192
					v_u_194.Character.HumanoidRootPart.CFrame = v210:FindFirstChild(v_u_193.SelectPlr).Character.HumanoidRootPart.CFrame - v211:FindFirstChild(v_u_193.SelectPlr).Character.HumanoidRootPart.CFrame.LookVector * v_u_193.AutoTeleportToSelectPlrDistance
				end)
			end
			task.wait()
		end
	end)
	local v_u_212 = {
		["WalkSpeed"] = 16,
		["WalkSpeedToggle"] = false,
		["JumpPower"] = 50,
		["JumpPowerToggle"] = false,
		["Gravity"] = 196.2,
		["GravityToggle"] = false,
		["Fly"] = false,
		["FlySpeed"] = 30
	}
	v96:Label("移动速度")
	function WalkSpeed()
		-- upvalues: (ref) v_u_212, (ref) v_u_194
		while v_u_212.WalkSpeedToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_194, (ref) v_u_212
				v_u_194.Character.Humanoid.WalkSpeed = v_u_212.WalkSpeed
			end)
			task.wait()
		end
	end
	v96:Slider("数值", "WalkSpeed", 16, 1, 150, true, function(p213)
		-- upvalues: (ref) v_u_212
		v_u_212.WalkSpeed = p213
	end)
	v96:Toggle("开关", "WalkSpeedToggle", false, function(p214)
		-- upvalues: (ref) v_u_212
		v_u_212.WalkSpeedToggle = p214
		WalkSpeed()
	end)
	v96:Label("跳跃高度")
	function JumpPower()
		-- upvalues: (ref) v_u_212, (ref) v_u_194
		while v_u_212.JumpPowerToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_194, (ref) v_u_212
				v_u_194.Character.Humanoid.JumpPower = v_u_212.JumpPower
			end)
			task.wait()
		end
	end
	v96:Slider("数值", "JumpPower", 50, 1, 150, true, function(p215)
		-- upvalues: (ref) v_u_212
		v_u_212.JumpPower = p215
	end)
	v96:Toggle("开关", "JumpPowerToggle", false, function(p216)
		-- upvalues: (ref) v_u_212
		v_u_212.JumpPowerToggle = p216
		JumpPower()
	end)
	v96:Label("重力")
	function Gravity()
		-- upvalues: (ref) v_u_212, (ref) v_u_191
		while v_u_212.GravityToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_191, (ref) v_u_212
				v_u_191.Gravity = v_u_212.Gravity
			end)
			task.wait()
		end
	end
	v96:Slider("数值", "Gravity", 196.2, 1, 1000, true, function(p217)
		-- upvalues: (ref) v_u_212
		v_u_212.Gravity = p217
	end)
	v96:Toggle("开关", "GravityToggle", false, function(p218)
		-- upvalues: (ref) v_u_212
		v_u_212.GravityToggle = p218
		Gravity()
	end)
	function NoclipFunc()
		-- upvalues: (ref) v_u_193, (ref) v_u_194
		while v_u_193.Noclip == true do
			pcall(function()
				-- upvalues: (ref) v_u_194
				local v219, v220, v221 = pairs(v_u_194.Character:GetChildren())
				while true do
					local v222
					v221, v222 = v219(v220, v221)
					if v221 == nil then
						break
					end
					if v222:IsA("BasePart") then
						v222.CanCollide = false
					end
				end
			end)
			task.wait()
		end
	end
	v96:Toggle("穿墙", "Noclip", false, function(p223)
		-- upvalues: (ref) v_u_193, (ref) v_u_194
		v_u_193.Noclip = p223
		if p223 == false then
			pcall(function()
				-- upvalues: (ref) v_u_194
				local v224, v225, v226 = pairs(v_u_194.Character:GetChildren())
				while true do
					local v227
					v226, v227 = v224(v225, v226)
					if v226 == nil then
						break
					end
					if v227:IsA("BasePart") and (v227.Name == "Head" or (v227.Name == "Torso" or (v227.Name == "UpperTorso" or v227.Name == "LowerTorso"))) then
						v227.CanCollide = true
					end
				end
			end)
		end
		NoclipFunc()
	end)
	v96:Toggle("无限跳", "InfJump", false, function(p228)
		-- upvalues: (ref) v_u_193
		v_u_193.InfJump = p228
	end)
	game:GetService("UserInputService").JumpRequest:Connect(function()
		-- upvalues: (ref) v_u_193, (ref) v_u_194
		if v_u_193.InfJump == true then
			v_u_194.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
		end
	end)
	local function v_u_233()
		-- upvalues: (ref) v_u_212, (ref) v_u_194, (ref) v_u_191
		while v_u_212.Fly == true do
			pcall(function()
				-- upvalues: (ref) v_u_194, (ref) v_u_191, (ref) v_u_212
				if not v_u_194.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
					local v229 = Instance.new("BodyVelocity")
					v229.Name = "FlyVelocity"
					v229.Parent = v_u_194.Character.HumanoidRootPart
					v229.MaxForce = Vector3.new(0, 0, 0)
					v229.Velocity = Vector3.new(0, 0, 0)
				end
				if not v_u_194.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
					local v230 = Instance.new("BodyGyro")
					v230.Name = "FlyGyro"
					v230.Parent = v_u_194.Character.HumanoidRootPart
					v230.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
					v230.P = 1000
					v230.D = 50
				end
				if v_u_194.Character and (v_u_194.Character:FindFirstChildOfClass("Humanoid") and v_u_194.Character.Humanoid.RootPart and (v_u_194.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") and v_u_194.Character.HumanoidRootPart:FindFirstChild("FlyGyro"))) then
					local v231 = v_u_191.CurrentCamera
					v_u_194.Character.HumanoidRootPart.FlyGyro.CFrame = v_u_191.CurrentCamera.CFrame
					local v232 = require(v_u_194.PlayerScripts:WaitForChild("PlayerModule"):WaitForChild("ControlModule")):GetMoveVector()
					v_u_194.Character.HumanoidRootPart.FlyVelocity.Velocity = Vector3.new()
					if v232.X > 0 then
						v_u_194.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_194.Character.HumanoidRootPart.FlyVelocity.Velocity + v231.CFrame.RightVector * (v232.X * v_u_212.FlySpeed)
					end
					if v232.X < 0 then
						v_u_194.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_194.Character.HumanoidRootPart.FlyVelocity.Velocity + v231.CFrame.RightVector * (v232.X * v_u_212.FlySpeed)
					end
					if v232.Z > 0 then
						v_u_194.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_194.Character.HumanoidRootPart.FlyVelocity.Velocity - v231.CFrame.LookVector * (v232.Z * v_u_212.FlySpeed)
					end
					if v232.Z < 0 then
						v_u_194.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_194.Character.HumanoidRootPart.FlyVelocity.Velocity - v231.CFrame.LookVector * (v232.Z * v_u_212.FlySpeed)
					end
					v_u_194.Character.Humanoid.PlatformStand = true
					v_u_194.Character.HumanoidRootPart.FlyVelocity.MaxForce = Vector3.new(9000000000, 9000000000, 9000000000)
					v_u_194.Character.HumanoidRootPart.FlyGyro.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
				end
			end)
			task.wait()
		end
	end
	v96:Toggle("飞行", "Fly", false, function(p234)
		-- upvalues: (ref) v_u_212, (ref) v_u_194, (ref) v_u_233
		v_u_212.Fly = p234
		if p234 == false then
			v_u_194.Character.Humanoid.PlatformStand = false
			if v_u_194.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
				v_u_194.Character.HumanoidRootPart:FindFirstChild("FlyVelocity"):Destroy()
			end
			if v_u_194.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
				v_u_194.Character.HumanoidRootPart:FindFirstChild("FlyGyro"):Destroy()
			end
		end
		v_u_233()
	end)
	v96:Slider("飞行速度", "Slider", 30, 1, 150, true, function(p235)
		-- upvalues: (ref) v_u_212
		v_u_212.FlySpeed = p235
	end)
	local v_u_236 = {
		["DefFOV"] = v_u_191.CurrentCamera.FieldOfView,
		["DefCameraMaxZoomDistance"] = v_u_194.CameraMaxZoomDistance,
		["DefCameraMinZoomDistance"] = v_u_194.CameraMinZoomDistance,
		["FieldOfView"] = 70,
		["FieldOfViewToggle"] = false,
		["CameraMaxZoomDistance"] = 128,
		["CameraMaxZoomDistanceToggle"] = false,
		["CameraMinZoomDistance"] = 0.5,
		["CameraMinZoomDistanceToggle"] = false,
		["FullBright"] = false,
		["DefAmbient"] = v_u_190.Ambient
	}
	function FieldOfView()
		-- upvalues: (ref) v_u_236, (ref) v_u_191, (ref) v_u_97
		while v_u_236.FieldOfViewToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_191, (ref) v_u_97
				v_u_191.CurrentCamera.FieldOfView = v_u_97.FieldOfView
			end)
			task.wait()
		end
	end
	function CameraMaxZoomDistance()
		-- upvalues: (ref) v_u_236, (ref) v_u_194, (ref) v_u_97
		while v_u_236.CameraMaxZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_194, (ref) v_u_97
				v_u_194.CameraMaxZoomDistance = v_u_97.CameraMaxZoomDistance
			end)
			task.wait()
		end
	end
	function CameraMinZoomDistance()
		-- upvalues: (ref) v_u_236, (ref) v_u_194
		while v_u_236.CameraMinZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_194, (ref) v_u_236
				v_u_194.CameraMinZoomDistance = v_u_236.CameraMinZoomDistance
			end)
			task.wait()
		end
	end
	v_u_97:Slider("Fov", "Slider", 70, 1, 120, true, function(p237)
		-- upvalues: (ref) v_u_97, (ref) v_u_191, (ref) v_u_236
		v_u_97.FieldOfView = p237
		if p237 == false then
			v_u_191.CurrentCamera.FieldOfView = v_u_236.DefFOV
		end
		FieldOfView()
	end)
	v_u_97:Slider("最大相机聚焦距离", "Slider", 128, 1, 1200, true, function(p238)
		-- upvalues: (ref) v_u_97, (ref) v_u_194
		v_u_97.CameraMaxZoomDistance = p238
		if p238 == false then
			v_u_194.CameraMaxZoomDistance = v_u_97.DefCameraMaxZoomDistance
		end
		CameraMaxZoomDistance()
	end)
	v_u_97:Slider("最小相机聚焦距离", "Slider", 0.5, 1, 50, true, function(p239)
		-- upvalues: (ref) v_u_97, (ref) v_u_194, (ref) v_u_236
		v_u_97.CameraMinZoomDistance = p239
		if p239 == false then
			v_u_194.CameraMinZoomDistance = v_u_236.DefCameraMinZoomDistance
		end
		CameraMinZoomDistance()
	end)
	function FullBright()
		-- upvalues: (ref) v_u_212, (ref) v_u_190
		while v_u_212.FullBright == true do
			pcall(function()
				-- upvalues: (ref) v_u_190
				v_u_190.Ambient = Color3.new(1, 1, 1)
			end)
			task.wait()
		end
	end
	v_u_97:Toggle("全局高亮", "FullBright", false, function(p240)
		-- upvalues: (ref) v_u_236, (ref) v_u_190
		v_u_236.FullBright = p240
		if p240 == false then
			v_u_190.Ambient = v_u_236.DefAmbient
		end
		FullBright()
	end)
	local v_u_241 = {
		["Bk"] = nil,
		["Dn"] = nil,
		["Ft"] = nil,
		["Lf"] = nil,
		["Rt"] = nil,
		["Up"] = nil
	}
	v98:Dropdown("天空盒", "Skybox", { "cs_办公室", "Always.win", "Advanced Logic" }, function(p242)
		if p242 == "cs_办公室" then
			SpawnSkybox({
				["Name"] = "cs_office",
				["Bk"] = "rbxassetid://658623433",
				["Dn"] = "rbxassetid://316342560",
				["Ft"] = "rbxassetid://658625205",
				["Lf"] = "rbxassetid://658627155",
				["Rt"] = "rbxassetid://658628504",
				["Up"] = "rbxassetid://658632701"
			})
		elseif p242 == "Always.win" then
			SpawnSkybox({
				["Name"] = "Always.win",
				["Bk"] = "rbxassetid://17411013742",
				["Dn"] = "rbxassetid://17411013742",
				["Ft"] = "rbxassetid://17411013742",
				["Lf"] = "rbxassetid://17411013742",
				["Rt"] = "rbxassetid://17411013742",
				["Up"] = "rbxassetid://17411013742"
			})
		elseif p242 == "Advanced Logic" then
			SpawnSkybox({
				["Name"] = "Advanced Logic",
				["Bk"] = "rbxassetid://17803761395",
				["Dn"] = "rbxassetid://17803761395",
				["Ft"] = "rbxassetid://17803761395",
				["Lf"] = "rbxassetid://17803761395",
				["Rt"] = "rbxassetid://17803761395",
				["Up"] = "rbxassetid://17803761395",
				["SunAsset"] = "rbxassetid://17768924741",
				["SunAngularSize"] = 50
			})
		end
	end)
	v98:Textbox("自定义天空盒Bk", "Textbox", "请输入SkyboxBk贴图ID", function(p_u_243)
		-- upvalues: (ref) v_u_241
		pcall(function()
			-- upvalues: (ref) p_u_243, (ref) v_u_241
			if p_u_243:find("rbx") then
				v_u_241.Bk = p_u_243
			else
				v_u_241.Bk = "rbxassetid://" .. p_u_243
			end
		end)
	end)
	v98:Textbox("自定义天空盒Dn", "Textbox", "请输入SkyboxDn贴图ID", function(p_u_244)
		-- upvalues: (ref) v_u_241
		pcall(function()
			-- upvalues: (ref) p_u_244, (ref) v_u_241
			if p_u_244:find("rbx") then
				v_u_241.Dn = p_u_244
			else
				v_u_241.Dn = "rbxassetid://" .. p_u_244
			end
		end)
	end)
	v98:Textbox("自定义天空盒Ft", "Textbox", "请输入SkyboxFt贴图ID", function(p_u_245)
		-- upvalues: (ref) v_u_241
		pcall(function()
			-- upvalues: (ref) p_u_245, (ref) v_u_241
			if p_u_245:find("rbx") then
				v_u_241.Ft = p_u_245
			else
				v_u_241.Ft = "rbxassetid://" .. p_u_245
			end
		end)
	end)
	v98:Textbox("自定义天空盒Lf", "Textbox", "请输入SkyboxLf贴图ID", function(p_u_246)
		-- upvalues: (ref) v_u_241
		pcall(function()
			-- upvalues: (ref) p_u_246, (ref) v_u_241
			if p_u_246:find("rbx") then
				v_u_241.Lf = p_u_246
			else
				v_u_241.Lf = "rbxassetid://" .. p_u_246
			end
		end)
	end)
	v98:Textbox("自定义天空盒Rt", "Textbox", "请输入SkyboxRt贴图ID", function(p_u_247)
		-- upvalues: (ref) v_u_241
		pcall(function()
			-- upvalues: (ref) p_u_247, (ref) v_u_241
			if p_u_247:find("rbx") then
				v_u_241.Rt = p_u_247
			else
				v_u_241.Rt = "rbxassetid://" .. p_u_247
			end
		end)
	end)
	v98:Textbox("自定义天空盒Up", "Textbox", "请输入SkyboxUp贴图ID", function(p_u_248)
		-- upvalues: (ref) v_u_241
		pcall(function()
			-- upvalues: (ref) p_u_248, (ref) v_u_241
			if p_u_248:find("rbx") then
				v_u_241.Up = p_u_248
			else
				v_u_241.Up = "rbxassetid://" .. p_u_248
			end
		end)
	end)
	v98:Button("修改自定义天空盒", function()
		-- upvalues: (ref) v_u_241
		pcall(function()
			-- upvalues: (ref) v_u_241
			SpawnSkybox({
				["Name"] = "我爱手冲",
				["Bk"] = v_u_241.Bk,
				["Dn"] = v_u_241.Dn,
				["Ft"] = v_u_241.Ft,
				["Lf"] = v_u_241.Lf,
				["Rt"] = v_u_241.Rt,
				["Up"] = v_u_241.Up
			})
		end)
	end)
	v100:Label("团队")
	v100:Label("Advanced Logic")
	v100:Label("群号: 684407929")
	v101:Label("当前版本 " .. v84)
else
	game:GetService("Players").LocalPlayer:Kick("您不是白名单用户,请加入684407929(Adavanced Logic官方群)购买")
	setclipboard(game:GetService("RbxAnalyticsService"):GetClientId())
end
