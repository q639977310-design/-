local v_u_1 = http_request or request or (HttpPost or syn.request)
local v_u_2 = nil
local v_u_3 = 0
local function v_u_9(p4, p5, p6)
	-- upvalues: (ref) v_u_3, (ref) v_u_9
	v_u_3 = v_u_3 + 1
	if p6 then
		local v7 = v_u_9(p4, p5) and v_u_9(p4, p6)
		if v7 then
			v7 = v_u_9(p5, p6)
		end
		return v7
	else
		local v8 = type(p4) == typeof(p5) and (typeof(p4) == type(p5) and (type(p4) == typeof(p5) or typeof(p4) == type(p5))) and (#tostring(p4) == #tostring(p5) and rawequal(p4, p5))
		if v8 then
			if tostring(p4) < tostring(p5) or tostring(p4) > tostring(p5) then
				v8 = false
			else
				v8 = rawequal(tostring(p4), tostring(p5))
			end
		end
		return v8
	end
end
local function v_u_11(p10)
	return ({ ... })[p10]
end
local function v_u_18(p_u_12)
	-- upvalues: (ref) v_u_1, (ref) v_u_2, (ref) v_u_11
	local v_u_13 = false
	local v15 = {
		["__call"] = v_u_1,
		["__index"] = function(_, p14)
			-- upvalues: (ref) v_u_13, (ref) v_u_1, (ref) v_u_2, (ref) p_u_12
			v_u_13 = true
			if debug.info(2, "f") ~= v_u_1 then
				v_u_2 = "反钩子 [H - 1]"
				return "https://www.roblox.com/users/7207800972/profile"
			end
			if not coroutine.isyieldable() then
				return p_u_12[p14]
			end
			v_u_2 = "反钩子 [H - 2]"
			return "https://www.roblox.com/users/7207800972/profile"
		end
	}
	local v16 = setmetatable({}, v15)
	local v17 = v_u_11(2, pcall(v16))
	if v_u_13 then
		return v17
	end
end
local function v21(p19)
	-- upvalues: (ref) v_u_18
	local v20 = v_u_18({
		["Url"] = p19,
		["Method"] = "GET"
	})
	repeat
		task.wait()
	until v20
	return v20.Body
end
local function v23(p22)
	return string.split(p22 or "", ": ")[2]
end
local function v_u_26(p24, p25)
	-- upvalues: (ref) v_u_26
	if p24 == 0 then
		task.wait()
	end
	p25(...)
	v_u_26(p24 + 1, p25)
end
local function v28(p27)
	game:GetService("Players").LocalPlayer:Kick("")
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.TitleFrame.ErrorTitle.Text = "危险行为"
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.MessageArea.ErrorFrame.ErrorMessage.Text = p27
	task.wait(1)
	game:Shutdown()
	task.wait(1)
	task.spawn(function()
		while true do

		end
	end)
end
local v29 = {
	v_u_26,
	v_u_11,
	pcall,
	debug.info,
	islclosure,
	debug.getinfo,
	debug.getfenv,
	0,
	{
		"Url",
		"Method",
		"Headers",
		"Cookies",
		"Body"
	},
	table.insert,
	v_u_2,
	v_u_1
}
local v30 = { math.random, v_u_11, v_u_18 }
local v31 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end
}
setmetatable(v29, v31)
local v32 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end
}
setmetatable(v30, v32)
local v33 = type(getrawmetatable(v29).__index) ~= "function" and "反篡改 [M - S1]" or v_u_2
v_u_3 = v_u_3 + 1
local v34 = type(getrawmetatable(v29).__tostring) ~= "function" and "反篡改 [M - S1]" or v33
v_u_3 = v_u_3 + 1
local v35 = (type(getrawmetatable(v30).__index) ~= "function" or type(getrawmetatable(v30).__index) ~= type(getmetatable(v30).__index)) and "反篡改 [M - S1]" or v34
v_u_3 = v_u_3 + 1
local v36 = type(getrawmetatable(v30).__tostring) ~= "function" and "反篡改 [M - S1]" or v35
v_u_3 = v_u_3 + 1
local v37, v38 = pcall(pcall)
local _, _ = pcall(math.random)
local _, _ = pcall(setmetatable)
local _, _ = pcall(string.split)
local _, _ = pcall(debug.traceback)
local _, _ = pcall(getmetatable)
local _, _ = pcall(coroutine.wrap)
local _, _ = pcall(table.insert)
local v39 = (v37 or v38 ~= "missing argument #1") and "反函数钩子 [P]" or v36
v_u_3 = v_u_3 + 1
local v40 = {
	math.abs,
	os.clock,
	coroutine.isyieldable,
	debug.info,
	v_u_1,
	game:GetService("Players").LocalPlayer.Kick,
	table.insert,
	bit32.bxor,
	debug.getfenv,
	setrawmetatable,
	pcall,
	math.random,
	setmetatable,
	string.split,
	debug.traceback,
	debug.info,
	getrawmetatable,
	type,
	table.insert,
	math.random,
	v_u_11,
	table.concat,
	string.byte,
	string.char,
	debug.getinfo,
	islclosure,
	string.reverse,
	v_u_18,
	getmetatable
}
local v41 = next
local v42 = v_u_18
local v43 = v_u_26
local v44 = v_u_9
local v45 = v_u_3
local v46 = v_u_11
local v47 = nil
while true do
	local v48
	v47, v48 = v41(v40, v47)
	if v47 == nil then
		break
	end
	for _ = 1, 197 do
		v48 = coroutine.wrap(v48)
	end
	if v46(2, pcall(v48)) == "C stack overflow" then
		v_u_2 = "反函数钩子 [F - G2]"
		v39 = v_u_2
	end
end
v_u_3 = v45 + 1
local v49 = not debug.info(2, "f") and "反篡改 [1]" or v39
v_u_3 = v_u_3 + 1
local v50 = math.random() == math.random() and "反篡改 [2]" or v49
local v51 = not v44(v_u_3, 7) and "反钩子 [C]" or v50
local _, v52 = pcall(v43, 0, coroutine.wrap)
local v53 = v23(v52) ~= "missing argument #1 to \'wrap\' (function expected)" and "反函数钩子 [F - C]" or v51
local v54 = not string.sub(game:GetService("RbxAnalyticsService"):GetClientId(), 1, 8) == string.split(game:GetService("RbxAnalyticsService"):GetClientId(), "-")[1] and "反函数钩子 [F - S]" or v53
local v55 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/P"))()
local v56 = loadstring(v21("https://raw.githubusercontent.com/longshu886/linniscript/refs/heads/main/ng"))()
local v57 = clonefunction(game:GetService("RbxAnalyticsService").GetClientId)(game:GetService("RbxAnalyticsService")):split("-")
local v58 = v57[1] .. v57[2] .. v57[3] .. v57[4] .. v57[5]
local v59 = not gethwid and "未知" or gethwid()
local v60 = table.find({ Enum.Platform.IOS }, game:GetService("UserInputService"):GetPlatform()) and "IOS" or (table.find({ Enum.Platform.Android }, game:GetService("UserInputService"):GetPlatform()) and "Android" or "PC/Mac")
local v61, v62
if v55[v58] ~= true or v56[v58] ~= true then
	v61 = "0xFF0000"
	v62 = "否"
else
	v61 = "0x32CD32"
	v62 = "是"
end
local v63 = {
	["username"] = "Advanced Bot",
	["embeds"] = {
		{
			["color"] = tonumber(tostring(v61)),
			["title"] = "有人注入了Advanced Logic",
			["fields"] = {
				{
					["name"] = "名称",
					["value"] = game:GetService("Players").LocalPlayer.Name,
					["inline"] = true
				},
				{
					["name"] = "昵称",
					["value"] = game:GetService("Players").LocalPlayer.DisplayName,
					["inline"] = true
				},
				{
					["name"] = "UID",
					["value"] = "[" .. game:GetService("Players").LocalPlayer.UserId .. "](" .. tostring("https://www.roblox.com/users/" .. game:GetService("Players").LocalPlayer.UserId .. "/profile") .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏ID",
					["value"] = "[" .. game.PlaceId .. "](" .. tostring("https://www.roblox.com/games/" .. game.PlaceId) .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏名称",
					["value"] = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name,
					["inline"] = true
				},
				{
					["name"] = "注入器",
					["value"] = identifyexecutor(),
					["inline"] = true
				},
				{
					["name"] = "HWID",
					["value"] = v59,
					["inline"] = true
				},
				{
					["name"] = "客户端ID",
					["value"] = game:GetService("RbxAnalyticsService"):GetClientId(),
					["inline"] = false
				},
				{
					["name"] = "设备",
					["value"] = v60,
					["inline"] = true
				},
				{
					["name"] = "用户状态",
					["value"] = v62,
					["inline"] = true
				}
			},
			["timestamp"] = os.date("%Y-%m-%dT%X.000Z")
		}
	}
}
v42({
	["Url"] = "https://discord.com/api/webhooks/1268122774069579806/Pi7q9f25rIwlkr-iLiIFEPJIvxx5dzcA9tSUXoTY8R1uUXF-CnFMJ91V2aX75dBOJCuY",
	["Method"] = "POST",
	["Headers"] = {
		["Content-Type"] = "application/json"
	},
	["Body"] = game.HttpService:JSONEncode(v63)
})
if v54 ~= nil then
	v28(v54)
end
if v55[v58] == true or v56[v58] == true then
	setfpscap(math.huge)
	_G.ScriptIsRunning = false
	_G.ScriptIsRunning = true
	local v_u_64 = game:GetService("Players")
	local v_u_65 = v_u_64.LocalPlayer
	game:GetService("CoreGui")
	game:GetService("RbxAnalyticsService")
	game:GetService("RunService")
	local _ = v_u_65.PlayerGui
	local v_u_66 = game:GetService("Workspace")
	local v_u_67 = game:GetService("Lighting")
	local v_u_68 = v_u_66.DeliverySys
	local v_u_69 = v_u_66.TaxiSys
	local v_u_70 = {
		["Red"] = Color3.fromRGB(255, 0, 0),
		["Green"] = Color3.fromRGB(0, 255, 0),
		["Blue"] = Color3.fromRGB(0, 0, 255),
		["Pink"] = Color3.fromRGB(255, 170, 255),
		["Cyan"] = Color3.fromRGB(85, 255, 255)
	}
	local v_u_71 = {
		["EspToggle"] = false,
		["HighlightToggle"] = false,
		["HighlightTransparency"] = 0.5,
		["SelectFillColor"] = Color3.fromRGB(255, 0, 0),
		["Fullbright"] = false,
		["Noclip"] = false,
		["Fly"] = false,
		["Flyspeed"] = 30,
		["InfJump"] = false,
		["SelectPlr"] = nil,
		["AutoFarmDeliveryMan"] = false,
		["AutoFarmTaxi"] = false,
		["CarTeleportSelectPlr"] = nil,
		["AutoTeleportToSelectPlr"] = false,
		["AutoTeleportToSelectPlrDistance"] = 4.5,
		["AutoFarmFlyCar"] = false
	}
	local v_u_72 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ns.cc"))()
	local v73 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/bob.afk"))()
	local v74 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/v"))():new("<font color=\"rgb(0,180,216)\">Advanced</font> <font color=\"rgb(252,255,0)\">Logic</font>", true, "gamesense", 0, false)
	local v75 = v74:Tab("自动", "15332132816")
	local v76 = v75:Section("汽车飞行刷钱", true)
	local v77 = v75:Section("送货员刷钱", false)
	local v78 = v75:Section("出租车刷钱", false)
	local v79 = v74:Tab("汽车", "7733708835"):Section("汽车传送", true)
	local v80 = v74:Tab("透视", "7733696665")
	local v81 = v80:Section("功能", false)
	local v82 = v80:Section("透视设置", false)
	local v83 = v74:Tab("玩家", "7743876054"):Section("玩家选项", true)
	local v84 = v74:Tab("本地", "7733752575")
	local v85 = v84:Section("本地玩家", false)
	local v_u_86 = v84:Section("本地视觉", false)
	local v87 = v84:Section("天空盒", false)
	local v88 = v74:Tab("关于", "7743871575")
	local v89 = v88:Section("关于作者", true)
	local v90 = v88:Section("关于脚本", true)
	function UpdateEsp(p_u_91, p_u_92)
		-- upvalues: (ref) v_u_64, (ref) v_u_71
		pcall(function()
			-- upvalues: (ref) v_u_64, (ref) p_u_91, (ref) v_u_71, (ref) p_u_92
			if v_u_64:FindFirstChild(p_u_91) and v_u_64:FindFirstChild(p_u_91).Character then
				if not (v_u_64:FindFirstChild(p_u_91).Character.Head:FindFirstChild("ALESP") and v_u_64:FindFirstChild(p_u_91).Character:FindFirstChild("ALHL")) then
					if not v_u_64:FindFirstChild(p_u_91).Character.Head:FindFirstChild("ALESP") then
						local v93 = Instance.new("BillboardGui")
						local v94 = Instance.new("TextLabel")
						v93.Name = "ALESP"
						v93.Parent = v_u_64:FindFirstChild(p_u_91).Character.Head
						v93.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
						v93.Active = true
						v93.ExtentsOffset = Vector3.new(0, 2, 0)
						v93.LightInfluence = 1
						v93.Size = UDim2.new(0, 200, 0, 50)
						v93.Enabled = v_u_71.EspToggle
						v93.AlwaysOnTop = true
						v94.Name = "Text"
						v94.Parent = v93
						v94.AnchorPoint = Vector2.new(0.5, 0.5)
						v94.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						v94.BackgroundTransparency = 1
						v94.BorderColor3 = Color3.fromRGB(0, 0, 0)
						v94.BorderSizePixel = 5
						v94.Position = UDim2.new(0.5, 0, 0.5, 0)
						v94.Size = UDim2.new(v_u_71.EspScale, 0, v_u_71.EspScale, 0)
						v94.Font = Enum.Font.SourceSansBold
						v94.Text = v_u_64:FindFirstChild(p_u_91).Name
						v94.TextColor3 = Color3.fromRGB(255, 255, 255)
						v94.TextScaled = true
						v94.TextSize = 1
						v94.TextStrokeTransparency = 0.19
						v94.TextWrapped = true
					end
					if not v_u_64:FindFirstChild(p_u_91).Character:FindFirstChild("ALHL") then
						local v95 = Instance.new("Highlight")
						v95.Name = "ALHL"
						v95.Parent = v_u_64:FindFirstChild(p_u_91).Character
						v95.FillColor = p_u_92
						v95.Enabled = v_u_71.HighlightToggle
						v95.FillTransparency = v_u_71.HighlightTransparency
					end
				end
				if v_u_64:FindFirstChild(p_u_91).Character.Head:FindFirstChild("ALESP") then
					local v96 = v_u_64:FindFirstChild(p_u_91).Character.Head:FindFirstChild("ALESP")
					local v97 = v96.Text
					v96.Enabled = v_u_71.EspToggle
					v97.Text = v_u_64:FindFirstChild(p_u_91).Name
					v97.Size = UDim2.new(v_u_71.EspScale, 0, v_u_71.EspScale, 0)
					v97.TextColor3 = p_u_92
				end
				if v_u_64:FindFirstChild(p_u_91).Character:FindFirstChild("ALHL") then
					local v98 = v_u_64:FindFirstChild(p_u_91).Character:FindFirstChild("ALHL")
					v98.FillColor = p_u_92
					v98.Enabled = v_u_71.HighlightToggle
					v98.FillTransparency = v_u_71.HighlightTransparency
				end
			end
		end)
	end
	function SpawnSkybox(p99)
		-- upvalues: (ref) v_u_67, (ref) v_u_72
		local v100 = v_u_67
		local v101, v102, v103 = pairs(v100:GetChildren())
		while true do
			local v104
			v103, v104 = v101(v102, v103)
			if v103 == nil then
				break
			end
			if v104:IsA("Sky") then
				v104:Destroy()
			end
		end
		if p99.Bk and (p99.Dn and (p99.Ft and (p99.Lf and (p99.Rt and (p99.Up and p99.Name))))) then
			local v105 = Instance.new("Sky")
			v105.Name = p99.Name
			v105.SkyboxBk = p99.Bk
			v105.SkyboxDn = p99.Dn
			v105.SkyboxFt = p99.Ft
			v105.SkyboxLf = p99.Lf
			v105.SkyboxRt = p99.Rt
			v105.SkyboxUp = p99.Up
			v105.Parent = v_u_67
			if p99.SunAsset and p99.SunAngularSize then
				v105.SunTextureId = p99.SunAsset
				v105.SunAngularSize = p99.SunAngularSize
			end
		else
			v_u_72:Notify("无效的天空盒参数", 2)
		end
	end
	v76:Button("汽车飞行刷钱", function()
		-- upvalues: (ref) v_u_65, (ref) v_u_72
		pcall(function()
			-- upvalues: (ref) v_u_65, (ref) v_u_72
			if game.Workspace.SpanwedCars:FindFirstChild(v_u_65.Name .. "\'s Car") and v_u_65.Character.Humanoid.SeatPart then
				local v106 = Instance.new("BodyGyro")
				local v107 = Instance.new("BodyVelocity")
				v106.Name = "BG"
				v107.Name = "BV"
				v106.Parent = v_u_65.Character.HumanoidRootPart
				v106.MaxTorque = Vector3.new(math.huge, math.huge, math.huge)
				v106.D = 50000
				v106.P = 50000
				game.Workspace.CurrentCamera.CameraType = Enum.CameraType.Scriptable
				v106.CFrame = game.Workspace.CurrentCamera.CFrame
				v107.Parent = v_u_65.Character.HumanoidRootPart
				v107.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
				v107.Velocity = Vector3.new(0, 1, 0) * 10000000000
				task.wait(0.5)
				v107.Velocity = Vector3.new(0, 1, 0) * 0
			else
				v_u_72:Notify("请先生成车辆并上车!", 2)
			end
		end)
	end)
	local v_u_108 = {
		["DeliveryManWaitingTime"] = 2.5,
		["TaxiWaitingTime"] = 5
	}
	v77:Toggle("开启刷钱", "EspToggle", false, function(p109)
		-- upvalues: (ref) v_u_71
		v_u_71.AutoFarmDeliveryMan = p109
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_71, (ref) v_u_65, (ref) v_u_68, (ref) v_u_108
		while _G.ScriptIsRunning == true do
			if v_u_71.AutoFarmDeliveryMan == true then
				pcall(function()
					-- upvalues: (ref) v_u_65, (ref) v_u_68, (ref) v_u_108
					if v_u_65.Team == game:GetService("Teams")["Delivery Driver"] then
						fireclickdetector(v_u_68.Misc["Package Pile"].ClickDetector)
						task.wait(v_u_108.WaitingTime)
						local v110, v111, v112 = pairs(v_u_68.DeliveryPoints:GetChildren())
						while true do
							local v113
							v112, v113 = v110(v111, v112)
							if v112 == nil then
								break
							end
							if v113.Locate.Locate.Enabled == true then
								v_u_65.Character.HumanoidRootPart.CFrame = v113.CFrame * CFrame.new(0, 2, 0)
							end
						end
					end
				end)
			end
			task.wait()
		end
	end)
	v77:Slider("传送等待时间", "FillTransparency", 2.5, 0.1, 5, true, function(p114)
		-- upvalues: (ref) v_u_108
		v_u_108.DeliveryManWaitingTime = p114
	end)
	v78:Toggle("开启刷钱", "EspToggle", false, function(p115)
		-- upvalues: (ref) v_u_71
		v_u_71.AutoFarmTaxi = p115
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_71, (ref) v_u_65, (ref) v_u_66, (ref) v_u_69, (ref) v_u_108
		while _G.ScriptIsRunning == true do
			if v_u_71.AutoFarmTaxi == true and v_u_65.Team == game:GetService("Teams")["Taxi Driver"] then
				pcall(function()
					-- upvalues: (ref) v_u_66, (ref) v_u_65, (ref) v_u_69, (ref) v_u_108
					if v_u_66.SpanwedCars:FindFirstChild(v_u_65.Name .. "\'s Car") then
						local v116 = v_u_66.SpanwedCars:FindFirstChild(v_u_65.Name .. "\'s Car")
						if v_u_65.PlayerGui.OCCUPATION.JobThings.TAXI_SYS.Runner.DispatchButton.Visible == true then
							game:GetService("VirtualInputManager"):SendMouseButtonEvent(v_u_65.PlayerGui.OCCUPATION.JobThings.TAXI_SYS.Runner.DispatchButton.AbsolutePosition.X, v_u_65.PlayerGui.OCCUPATION.JobThings.TAXI_SYS.Runner.DispatchButton.AbsolutePosition.Y, 1, true, game, 1)
							game:GetService("VirtualInputManager"):SendMouseButtonEvent(v_u_65.PlayerGui.OCCUPATION.JobThings.TAXI_SYS.Runner.DispatchButton.AbsolutePosition.X, v_u_65.PlayerGui.OCCUPATION.JobThings.TAXI_SYS.Runner.DispatchButton.AbsolutePosition.Y, 1, false, game, 1)
						end
						local v117 = v_u_69
						local v118, v119, v120 = pairs(v117:GetDescendants())
						while true do
							local v121
							v120, v121 = v118(v119, v120)
							if v120 == nil then
								break
							end
							if v121.Name == "Point" and v121.Locate.Locate.Enabled == true then
								v116:TranslateBy(v121.Position - v116.Body["#Weight"].Position)
								task.wait(v_u_108.TaxiWaitingTime)
							end
						end
					end
				end)
			end
			task.wait()
		end
	end)
	v78:Slider("传送等待时间", "FillTransparency", 5, 1, 10, true, function(p122)
		-- upvalues: (ref) v_u_108
		v_u_108.TaxiWaitingTime = p122
	end)
	v78:Label("生成车辆之后请手动开启任务(建议用连点器)")
	local v123 = v_u_64
	local v124, v125, v126 = pairs(v_u_64.GetChildren(v123))
	local v_u_127 = v_u_72
	local v_u_128 = v_u_71
	local v_u_129 = v_u_66
	local v_u_130 = v_u_64
	local v_u_131 = v_u_67
	local v_u_132 = v_u_65
	local v_u_133 = {}
	while true do
		local v134, v135 = v124(v125, v126)
		if v134 == nil then
			break
		end
		v126 = v134
		if v135.Name ~= v_u_132.Name then
			table.insert(v_u_133, v135.Name)
		end
	end
	v79:Dropdown("玩家列表", "Players", v_u_133, function(p136)
		-- upvalues: (ref) v_u_128
		v_u_128.CarTeleportSelectPlr = p136
	end)
	v79:Button("汽车传送到选择的玩家", function()
		-- upvalues: (ref) v_u_132, (ref) v_u_130, (ref) v_u_128, (ref) v_u_127
		pcall(function()
			-- upvalues: (ref) v_u_132, (ref) v_u_130, (ref) v_u_128, (ref) v_u_127
			local v137 = game.Workspace.SpanwedCars:FindFirstChild(v_u_132.Name .. "\'s Car")
			if v137 and (v_u_130:FindFirstChild(v_u_128.CarTeleportSelectPlr) and v_u_130:FindFirstChild(v_u_128.CarTeleportSelectPlr).Character ~= nil) then
				v137:TranslateBy(v_u_130:FindFirstChild(v_u_128.CarTeleportSelectPlr).Character.HumanoidRootPart.Position - v137.Body["#Weight"].Position)
			elseif not v137 then
				v_u_127:Notify("无法找到车辆,请先生成车辆", 1)
			end
		end)
	end)
	v81:Toggle("透视开关", "EspToggle", false, function(p138)
		-- upvalues: (ref) v_u_128
		v_u_128.EspToggle = p138
	end)
	v81:Toggle("上色开关", "HighlightToggle", false, function(p139)
		-- upvalues: (ref) v_u_128
		v_u_128.HighlightToggle = p139
	end)
	v82:Dropdown("透视颜色", "SelectFillColor", {
		"红",
		"绿",
		"蓝",
		"粉",
		"青"
	}, function(p140)
		-- upvalues: (ref) v_u_128, (ref) v_u_70
		if p140 == "红" then
			v_u_128.SelectFillColor = v_u_70.Red
		elseif p140 == "绿" then
			v_u_128.SelectFillColor = v_u_70.Green
		elseif p140 == "蓝" then
			v_u_128.SelectFillColor = v_u_70.Blue
		elseif p140 == "粉" then
			v_u_128.SelectFillColor = v_u_70.Pink
		elseif p140 == "青" then
			v_u_128.SelectFillColor = v_u_70.Cyan
		end
	end)
	v82:Slider("透视大小", "FillTransparency", 0.5, 0.1, 1, true, function(p141)
		-- upvalues: (ref) v_u_128
		v_u_128.EspScale = p141
	end)
	v82:Slider("上色透明度", "FillTransparency", 0.5, 0, 1, true, function(p142)
		-- upvalues: (ref) v_u_128
		v_u_128.HighlightTransparency = p142
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_130, (ref) v_u_132, (ref) v_u_128
		while _G.ScriptIsRunning == true do
			local v143 = v_u_130
			local v144, v145, v146 = pairs(v143:GetChildren())
			while true do
				local v147
				v146, v147 = v144(v145, v146)
				if v146 == nil then
					break
				end
				if v147.Name ~= v_u_132.Name then
					UpdateEsp(v147.Name, v_u_128.SelectFillColor)
				end
			end
			task.wait()
		end
	end)
	local v_u_149 = v83:Dropdown("玩家列表", "Players", v_u_133, function(p148)
		-- upvalues: (ref) v_u_128
		v_u_128.SelectPlr = p148
	end)
	v_u_130.PlayerAdded:Connect(function(p150)
		-- upvalues: (ref) v_u_133, (ref) v_u_149
		table.insert(v_u_133, p150.Name)
		v_u_149.AddOption(p150.Name)
	end)
	v_u_130.PlayerRemoving:Connect(function(p151)
		-- upvalues: (ref) v_u_133, (ref) v_u_149
		table.remove(v_u_133, table.find(v_u_133, p151.Name))
		v_u_149.RemoveOption(p151.Name)
	end)
	v83:Button("传送到选中的玩家", function()
		-- upvalues: (ref) v_u_132, (ref) v_u_130, (ref) v_u_128
		pcall(function()
			-- upvalues: (ref) v_u_132, (ref) v_u_130, (ref) v_u_128
			local v152 = v_u_130
			v_u_132.Character.HumanoidRootPart.CFrame = v152:FindFirstChild(v_u_128.SelectPlr).Character.HumanoidRootPart.CFrame
		end)
	end)
	v83:Toggle("自动传送到选择的玩家身后", "Noclip", false, function(p153)
		-- upvalues: (ref) v_u_128
		v_u_128.AutoTeleportToSelectPlr = p153
	end)
	v83:Slider("自动传送距离设置", "Slider", 4.5, 1, 20, true, function(p154)
		-- upvalues: (ref) v_u_128
		v_u_128.AutoTeleportToSelectPlrDistance = p154
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_128, (ref) v_u_132, (ref) v_u_130
		while _G.ScriptIsRunning == true do
			if v_u_128.AutoTeleportToSelectPlr == true then
				pcall(function()
					-- upvalues: (ref) v_u_132, (ref) v_u_130, (ref) v_u_128
					local v155 = v_u_130
					local v156 = v_u_130
					v_u_132.Character.HumanoidRootPart.CFrame = v155:FindFirstChild(v_u_128.SelectPlr).Character.HumanoidRootPart.CFrame - v156:FindFirstChild(v_u_128.SelectPlr).Character.HumanoidRootPart.CFrame.LookVector * v_u_128.AutoTeleportToSelectPlrDistance
				end)
			end
			task.wait()
		end
	end)
	local v_u_157 = {
		["WalkSpeed"] = 16,
		["WalkSpeedToggle"] = false,
		["JumpPower"] = 50,
		["JumpPowerToggle"] = false,
		["Gravity"] = 196.2,
		["GravityToggle"] = false,
		["Fly"] = false,
		["FlySpeed"] = 30
	}
	v85:Label("移动速度")
	function WalkSpeed()
		-- upvalues: (ref) v_u_157, (ref) v_u_132
		while v_u_157.WalkSpeedToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_132, (ref) v_u_157
				v_u_132.Character.Humanoid.WalkSpeed = v_u_157.WalkSpeed
			end)
			task.wait()
		end
	end
	v85:Slider("数值", "WalkSpeed", 16, 1, 150, true, function(p158)
		-- upvalues: (ref) v_u_157
		v_u_157.WalkSpeed = p158
	end)
	v85:Toggle("开关", "WalkSpeedToggle", false, function(p159)
		-- upvalues: (ref) v_u_157
		v_u_157.WalkSpeedToggle = p159
		WalkSpeed()
	end)
	v85:Label("跳跃高度")
	function JumpPower()
		-- upvalues: (ref) v_u_157, (ref) v_u_132
		while v_u_157.JumpPowerToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_132, (ref) v_u_157
				v_u_132.Character.Humanoid.JumpPower = v_u_157.JumpPower
			end)
			task.wait()
		end
	end
	v85:Slider("数值", "JumpPower", 50, 1, 150, true, function(p160)
		-- upvalues: (ref) v_u_157
		v_u_157.JumpPower = p160
	end)
	v85:Toggle("开关", "JumpPowerToggle", false, function(p161)
		-- upvalues: (ref) v_u_157
		v_u_157.JumpPowerToggle = p161
		JumpPower()
	end)
	v85:Label("重力")
	function Gravity()
		-- upvalues: (ref) v_u_157, (ref) v_u_129
		while v_u_157.GravityToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_129, (ref) v_u_157
				v_u_129.Gravity = v_u_157.Gravity
			end)
			task.wait()
		end
	end
	v85:Slider("数值", "Gravity", 196.2, 1, 1000, true, function(p162)
		-- upvalues: (ref) v_u_157
		v_u_157.Gravity = p162
	end)
	v85:Toggle("开关", "GravityToggle", false, function(p163)
		-- upvalues: (ref) v_u_157
		v_u_157.GravityToggle = p163
		Gravity()
	end)
	function NoclipFunc()
		-- upvalues: (ref) v_u_128, (ref) v_u_132
		while v_u_128.Noclip == true do
			pcall(function()
				-- upvalues: (ref) v_u_132
				local v164, v165, v166 = pairs(v_u_132.Character:GetChildren())
				while true do
					local v167
					v166, v167 = v164(v165, v166)
					if v166 == nil then
						break
					end
					if v167:IsA("BasePart") then
						v167.CanCollide = false
					end
				end
			end)
			task.wait()
		end
	end
	v85:Toggle("穿墙", "Noclip", false, function(p168)
		-- upvalues: (ref) v_u_128, (ref) v_u_132
		v_u_128.Noclip = p168
		if p168 == false then
			pcall(function()
				-- upvalues: (ref) v_u_132
				local v169, v170, v171 = pairs(v_u_132.Character:GetChildren())
				while true do
					local v172
					v171, v172 = v169(v170, v171)
					if v171 == nil then
						break
					end
					if v172:IsA("BasePart") and (v172.Name == "Head" or (v172.Name == "Torso" or (v172.Name == "UpperTorso" or v172.Name == "LowerTorso"))) then
						v172.CanCollide = true
					end
				end
			end)
		end
		NoclipFunc()
	end)
	v85:Toggle("无限跳", "InfJump", false, function(p173)
		-- upvalues: (ref) v_u_128
		v_u_128.InfJump = p173
	end)
	game:GetService("UserInputService").JumpRequest:Connect(function()
		-- upvalues: (ref) v_u_128, (ref) v_u_132
		if v_u_128.InfJump == true then
			v_u_132.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
		end
	end)
	local function v_u_178()
		-- upvalues: (ref) v_u_157, (ref) v_u_132, (ref) v_u_129
		while v_u_157.Fly == true do
			pcall(function()
				-- upvalues: (ref) v_u_132, (ref) v_u_129, (ref) v_u_157
				if not v_u_132.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
					local v174 = Instance.new("BodyVelocity")
					v174.Name = "FlyVelocity"
					v174.Parent = v_u_132.Character.HumanoidRootPart
					v174.MaxForce = Vector3.new(0, 0, 0)
					v174.Velocity = Vector3.new(0, 0, 0)
				end
				if not v_u_132.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
					local v175 = Instance.new("BodyGyro")
					v175.Name = "FlyGyro"
					v175.Parent = v_u_132.Character.HumanoidRootPart
					v175.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
					v175.P = 1000
					v175.D = 50
				end
				if v_u_132.Character and (v_u_132.Character:FindFirstChildOfClass("Humanoid") and v_u_132.Character.Humanoid.RootPart and (v_u_132.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") and v_u_132.Character.HumanoidRootPart:FindFirstChild("FlyGyro"))) then
					local v176 = v_u_129.CurrentCamera
					v_u_132.Character.HumanoidRootPart.FlyGyro.CFrame = v_u_129.CurrentCamera.CFrame
					local v177 = require(v_u_132.PlayerScripts:WaitForChild("PlayerModule"):WaitForChild("ControlModule")):GetMoveVector()
					v_u_132.Character.HumanoidRootPart.FlyVelocity.Velocity = Vector3.new()
					if v177.X > 0 then
						v_u_132.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_132.Character.HumanoidRootPart.FlyVelocity.Velocity + v176.CFrame.RightVector * (v177.X * v_u_157.FlySpeed)
					end
					if v177.X < 0 then
						v_u_132.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_132.Character.HumanoidRootPart.FlyVelocity.Velocity + v176.CFrame.RightVector * (v177.X * v_u_157.FlySpeed)
					end
					if v177.Z > 0 then
						v_u_132.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_132.Character.HumanoidRootPart.FlyVelocity.Velocity - v176.CFrame.LookVector * (v177.Z * v_u_157.FlySpeed)
					end
					if v177.Z < 0 then
						v_u_132.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_132.Character.HumanoidRootPart.FlyVelocity.Velocity - v176.CFrame.LookVector * (v177.Z * v_u_157.FlySpeed)
					end
					v_u_132.Character.Humanoid.PlatformStand = true
					v_u_132.Character.HumanoidRootPart.FlyVelocity.MaxForce = Vector3.new(9000000000, 9000000000, 9000000000)
					v_u_132.Character.HumanoidRootPart.FlyGyro.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
				end
			end)
			task.wait()
		end
	end
	v85:Toggle("飞行", "Fly", false, function(p179)
		-- upvalues: (ref) v_u_157, (ref) v_u_132, (ref) v_u_178
		v_u_157.Fly = p179
		if p179 == false then
			v_u_132.Character.Humanoid.PlatformStand = false
			if v_u_132.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
				v_u_132.Character.HumanoidRootPart:FindFirstChild("FlyVelocity"):Destroy()
			end
			if v_u_132.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
				v_u_132.Character.HumanoidRootPart:FindFirstChild("FlyGyro"):Destroy()
			end
		end
		v_u_178()
	end)
	v85:Slider("飞行速度", "Slider", 30, 1, 150, true, function(p180)
		-- upvalues: (ref) v_u_157
		v_u_157.FlySpeed = p180
	end)
	local v_u_181 = {
		["DefFOV"] = v_u_129.CurrentCamera.FieldOfView,
		["DefCameraMaxZoomDistance"] = v_u_132.CameraMaxZoomDistance,
		["DefCameraMinZoomDistance"] = v_u_132.CameraMinZoomDistance,
		["FieldOfView"] = 70,
		["FieldOfViewToggle"] = false,
		["CameraMaxZoomDistance"] = 128,
		["CameraMaxZoomDistanceToggle"] = false,
		["CameraMinZoomDistance"] = 0.5,
		["CameraMinZoomDistanceToggle"] = false,
		["FullBright"] = false,
		["DefAmbient"] = v_u_131.Ambient
	}
	function FieldOfView()
		-- upvalues: (ref) v_u_181, (ref) v_u_129, (ref) v_u_86
		while v_u_181.FieldOfViewToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_129, (ref) v_u_86
				v_u_129.CurrentCamera.FieldOfView = v_u_86.FieldOfView
			end)
			task.wait()
		end
	end
	function CameraMaxZoomDistance()
		-- upvalues: (ref) v_u_181, (ref) v_u_132, (ref) v_u_86
		while v_u_181.CameraMaxZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_132, (ref) v_u_86
				v_u_132.CameraMaxZoomDistance = v_u_86.CameraMaxZoomDistance
			end)
			task.wait()
		end
	end
	function CameraMinZoomDistance()
		-- upvalues: (ref) v_u_181, (ref) v_u_132
		while v_u_181.CameraMinZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_132, (ref) v_u_181
				v_u_132.CameraMinZoomDistance = v_u_181.CameraMinZoomDistance
			end)
			task.wait()
		end
	end
	v_u_86:Slider("Fov", "Slider", 70, 1, 120, true, function(p182)
		-- upvalues: (ref) v_u_86, (ref) v_u_129, (ref) v_u_181
		v_u_86.FieldOfView = p182
		if p182 == false then
			v_u_129.CurrentCamera.FieldOfView = v_u_181.DefFOV
		end
		FieldOfView()
	end)
	v_u_86:Slider("最大相机聚焦距离", "Slider", 128, 1, 1200, true, function(p183)
		-- upvalues: (ref) v_u_86, (ref) v_u_132
		v_u_86.CameraMaxZoomDistance = p183
		if p183 == false then
			v_u_132.CameraMaxZoomDistance = v_u_86.DefCameraMaxZoomDistance
		end
		CameraMaxZoomDistance()
	end)
	v_u_86:Slider("最小相机聚焦距离", "Slider", 0.5, 1, 50, true, function(p184)
		-- upvalues: (ref) v_u_86, (ref) v_u_132, (ref) v_u_181
		v_u_86.CameraMinZoomDistance = p184
		if p184 == false then
			v_u_132.CameraMinZoomDistance = v_u_181.DefCameraMinZoomDistance
		end
		CameraMinZoomDistance()
	end)
	function FullBright()
		-- upvalues: (ref) v_u_157, (ref) v_u_131
		while v_u_157.FullBright == true do
			pcall(function()
				-- upvalues: (ref) v_u_131
				v_u_131.Ambient = Color3.new(1, 1, 1)
			end)
			task.wait()
		end
	end
	v_u_86:Toggle("全局高亮", "FullBright", false, function(p185)
		-- upvalues: (ref) v_u_181, (ref) v_u_131
		v_u_181.FullBright = p185
		if p185 == false then
			v_u_131.Ambient = v_u_181.DefAmbient
		end
		FullBright()
	end)
	local v_u_186 = {
		["Bk"] = nil,
		["Dn"] = nil,
		["Ft"] = nil,
		["Lf"] = nil,
		["Rt"] = nil,
		["Up"] = nil
	}
	v87:Dropdown("天空盒", "Skybox", { "cs_办公室", "Always.win", "Advanced Logic" }, function(p187)
		if p187 == "cs_办公室" then
			SpawnSkybox({
				["Name"] = "cs_office",
				["Bk"] = "rbxassetid://658623433",
				["Dn"] = "rbxassetid://316342560",
				["Ft"] = "rbxassetid://658625205",
				["Lf"] = "rbxassetid://658627155",
				["Rt"] = "rbxassetid://658628504",
				["Up"] = "rbxassetid://658632701"
			})
		elseif p187 == "Always.win" then
			SpawnSkybox({
				["Name"] = "Always.win",
				["Bk"] = "rbxassetid://17411013742",
				["Dn"] = "rbxassetid://17411013742",
				["Ft"] = "rbxassetid://17411013742",
				["Lf"] = "rbxassetid://17411013742",
				["Rt"] = "rbxassetid://17411013742",
				["Up"] = "rbxassetid://17411013742"
			})
		elseif p187 == "Advanced Logic" then
			SpawnSkybox({
				["Name"] = "Advanced Logic",
				["Bk"] = "rbxassetid://17803761395",
				["Dn"] = "rbxassetid://17803761395",
				["Ft"] = "rbxassetid://17803761395",
				["Lf"] = "rbxassetid://17803761395",
				["Rt"] = "rbxassetid://17803761395",
				["Up"] = "rbxassetid://17803761395",
				["SunAsset"] = "rbxassetid://17768924741",
				["SunAngularSize"] = 50
			})
		end
	end)
	v87:Textbox("自定义天空盒Bk", "Textbox", "请输入SkyboxBk贴图ID", function(p_u_188)
		-- upvalues: (ref) v_u_186
		pcall(function()
			-- upvalues: (ref) p_u_188, (ref) v_u_186
			if p_u_188:find("rbx") then
				v_u_186.Bk = p_u_188
			else
				v_u_186.Bk = "rbxassetid://" .. p_u_188
			end
		end)
	end)
	v87:Textbox("自定义天空盒Dn", "Textbox", "请输入SkyboxDn贴图ID", function(p_u_189)
		-- upvalues: (ref) v_u_186
		pcall(function()
			-- upvalues: (ref) p_u_189, (ref) v_u_186
			if p_u_189:find("rbx") then
				v_u_186.Dn = p_u_189
			else
				v_u_186.Dn = "rbxassetid://" .. p_u_189
			end
		end)
	end)
	v87:Textbox("自定义天空盒Ft", "Textbox", "请输入SkyboxFt贴图ID", function(p_u_190)
		-- upvalues: (ref) v_u_186
		pcall(function()
			-- upvalues: (ref) p_u_190, (ref) v_u_186
			if p_u_190:find("rbx") then
				v_u_186.Ft = p_u_190
			else
				v_u_186.Ft = "rbxassetid://" .. p_u_190
			end
		end)
	end)
	v87:Textbox("自定义天空盒Lf", "Textbox", "请输入SkyboxLf贴图ID", function(p_u_191)
		-- upvalues: (ref) v_u_186
		pcall(function()
			-- upvalues: (ref) p_u_191, (ref) v_u_186
			if p_u_191:find("rbx") then
				v_u_186.Lf = p_u_191
			else
				v_u_186.Lf = "rbxassetid://" .. p_u_191
			end
		end)
	end)
	v87:Textbox("自定义天空盒Rt", "Textbox", "请输入SkyboxRt贴图ID", function(p_u_192)
		-- upvalues: (ref) v_u_186
		pcall(function()
			-- upvalues: (ref) p_u_192, (ref) v_u_186
			if p_u_192:find("rbx") then
				v_u_186.Rt = p_u_192
			else
				v_u_186.Rt = "rbxassetid://" .. p_u_192
			end
		end)
	end)
	v87:Textbox("自定义天空盒Up", "Textbox", "请输入SkyboxUp贴图ID", function(p_u_193)
		-- upvalues: (ref) v_u_186
		pcall(function()
			-- upvalues: (ref) p_u_193, (ref) v_u_186
			if p_u_193:find("rbx") then
				v_u_186.Up = p_u_193
			else
				v_u_186.Up = "rbxassetid://" .. p_u_193
			end
		end)
	end)
	v87:Button("修改自定义天空盒", function()
		-- upvalues: (ref) v_u_186
		pcall(function()
			-- upvalues: (ref) v_u_186
			SpawnSkybox({
				["Name"] = "我爱手冲",
				["Bk"] = v_u_186.Bk,
				["Dn"] = v_u_186.Dn,
				["Ft"] = v_u_186.Ft,
				["Lf"] = v_u_186.Lf,
				["Rt"] = v_u_186.Rt,
				["Up"] = v_u_186.Up
			})
		end)
	end)
	v89:Label("团队")
	v89:Label("Advanced Logic")
	v89:Label("群号: 684407929")
	v90:Label("当前版本 " .. v73)
else
	game:GetService("Players").LocalPlayer:Kick("您不是白名单用户,请加入684407929(Adavanced Logic官方群)购买")
	setclipboard(game:GetService("RbxAnalyticsService"):GetClientId())
end
