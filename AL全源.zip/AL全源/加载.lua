game:GetService("TweenService"):SetAttribute("Bitches", 9285)
local v_u_1 = http_request or request or (HttpPost or syn.request)
local function v_u_3(p2)
	return ({ ... })[p2]
end
local function v_u_10(p_u_4)
	-- upvalues: (ref) v_u_1, (ref) v_u_3
	local v_u_5 = false
	local v7 = {
		["__call"] = v_u_1,
		["__index"] = function(_, p6)
			-- upvalues: (ref) v_u_5, (ref) v_u_1, (ref) p_u_4
			v_u_5 = true
			return debug.info(2, "f") ~= v_u_1 and "https://www.roblox.com/users/7207800972/profile" or (coroutine.isyieldable() and "https://www.roblox.com/users/7207800972/profile" or p_u_4[p6])
		end
	}
	local v8 = setmetatable({}, v7)
	local v9 = v_u_3(2, pcall(v8))
	if v_u_5 then
		return v9
	end
end
local function v12(p11)
	-- upvalues: (ref) v_u_10
	return v_u_10({
		["Url"] = p11,
		["Method"] = "GET"
	}).Body
end
local v13 = loadstring(v12("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ihate.jews"))()
local _ = game.PlaceId
if v13 then
	local v14, v15, v16 = pairs(v13)
	while true do
		local v17
		v16, v17 = v14(v15, v16)
		if v16 == nil then
			break
		end
		local v18 = game:GetService("RbxAnalyticsService"):GetClientId()
		local v19 = v17.ClientId
		local v20 = game:GetService("Players").LocalPlayer.UserId
		local v21 = v17.UserId
		local v22 = gethwid and gethwid() or "未知"
		local v23 = v17.Hwid
		local v24 = v17.Reason
		if v19 == v18 then
			game:GetService("Players").LocalPlayer:Kick("您的客户端已被禁止使用Advanced Logic 原因: " .. v24)
			task.wait(2)
			game:shutdown()
		elseif v21 == v20 then
			game:GetService("Players").LocalPlayer:Kick("您的账户已被禁止使用Advanced Logic 原因: " .. v24)
			task.wait(2)
			game:shutdown()
		elseif v23 == v22 then
			game:GetService("Players").LocalPlayer:Kick("您的设备已被禁止使用Advanced Logic 原因: " .. v24)
			task.wait(2)
			game:shutdown()
		end
	end
	local v25 = {
		["5780309044"] = "SA",
		["11423467063"] = "SAB",
		["7239319209"] = "Oh",
		["11958318242"] = "Oh",
		["14767933027"] = "Oh",
		["15180005553"] = "Oh",
		["4618049391"] = "TC",
		["1554960397"] = "CDT",
		["155615604"] = "PL",
		["14216737767"] = "GB",
		["12334109280"] = "GB",
		["10449761463"] = "TSB",
		["3623096087"] = "ML",
		["142823291"] = "MM2",
		["335132309"] = "MM2",
		["636649648"] = "MM2",
		["73210641948512"] = "MM2",
		["11630038968"] = "BD",
		["12011959048"] = "BD",
		["13432875469"] = "BD",
		["14191889582"] = "BD",
		["14662411059"] = "BD",
		["15221657720"] = "BD",
		["Universal"] = "U"
	}
	if v25[tostring(game.PlaceId)] then
		loadstring(v12("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/" .. v25[tostring(game.PlaceId)]))()
	else
		loadstring(v12("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/" .. v25.Universal))()
	end
	table.clear(v25)
	if #v25 > 0 then
		game:Shutdown()
	end
	game:GetService("TweenService"):SetAttribute("Bitches", nil)
else
	game:shutdown()
end
