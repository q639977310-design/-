local v_u_1 = http_request or request or (HttpPost or syn.request)
local v_u_2 = nil
local v_u_3 = 0
local function v_u_9(p4, p5, p6)
	-- upvalues: (ref) v_u_3, (ref) v_u_9
	v_u_3 = v_u_3 + 1
	if p6 then
		local v7 = v_u_9(p4, p5) and v_u_9(p4, p6)
		if v7 then
			v7 = v_u_9(p5, p6)
		end
		return v7
	else
		local v8 = type(p4) == typeof(p5) and (typeof(p4) == type(p5) and (type(p4) == typeof(p5) or typeof(p4) == type(p5))) and (#tostring(p4) == #tostring(p5) and rawequal(p4, p5))
		if v8 then
			if tostring(p4) < tostring(p5) or tostring(p4) > tostring(p5) then
				v8 = false
			else
				v8 = rawequal(tostring(p4), tostring(p5))
			end
		end
		return v8
	end
end
local function v_u_11(p10)
	return ({ ... })[p10]
end
local function v_u_18(p_u_12)
	-- upvalues: (ref) v_u_1, (ref) v_u_2, (ref) v_u_11
	local v_u_13 = false
	local v15 = {
		["__call"] = v_u_1,
		["__index"] = function(_, p14)
			-- upvalues: (ref) v_u_13, (ref) v_u_1, (ref) v_u_2, (ref) p_u_12
			v_u_13 = true
			if debug.info(2, "f") ~= v_u_1 then
				v_u_2 = "反钩子 [H - 1]"
				return "https://www.roblox.com/users/7207800972/profile"
			end
			if not coroutine.isyieldable() then
				return p_u_12[p14]
			end
			v_u_2 = "反钩子 [H - 2]"
			return "https://www.roblox.com/users/7207800972/profile"
		end
	}
	local v16 = setmetatable({}, v15)
	local v17 = v_u_11(2, pcall(v16))
	if v_u_13 then
		return v17
	end
end
local function v21(p19)
	-- upvalues: (ref) v_u_18
	local v20 = v_u_18({
		["Url"] = p19,
		["Method"] = "GET"
	})
	repeat
		task.wait()
	until v20
	return v20.Body
end
local function v23(p22)
	return string.split(p22 or "", ": ")[2]
end
local function v_u_26(p24, p25)
	-- upvalues: (ref) v_u_26
	if p24 == 0 then
		task.wait()
	end
	p25(...)
	v_u_26(p24 + 1, p25)
end
local function v28(p27)
	game:GetService("Players").LocalPlayer:Kick("")
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.TitleFrame.ErrorTitle.Text = "危险行为"
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.MessageArea.ErrorFrame.ErrorMessage.Text = p27
	task.wait(1)
	game:Shutdown()
	task.wait(1)
	task.spawn(function()
		while true do

		end
	end)
end
local v29 = {
	v_u_26,
	v_u_11,
	pcall,
	debug.info,
	islclosure,
	debug.getinfo,
	debug.getfenv,
	0,
	{
		"Url",
		"Method",
		"Headers",
		"Cookies",
		"Body"
	},
	table.insert,
	v_u_2,
	v_u_1
}
local v30 = { math.random, v_u_11, v_u_18 }
local v31 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end
}
setmetatable(v29, v31)
local v32 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end
}
setmetatable(v30, v32)
local v33 = type(getrawmetatable(v29).__index) ~= "function" and "反篡改 [M - S1]" or v_u_2
v_u_3 = v_u_3 + 1
local v34 = type(getrawmetatable(v29).__tostring) ~= "function" and "反篡改 [M - S1]" or v33
v_u_3 = v_u_3 + 1
local v35 = (type(getrawmetatable(v30).__index) ~= "function" or type(getrawmetatable(v30).__index) ~= type(getmetatable(v30).__index)) and "反篡改 [M - S1]" or v34
v_u_3 = v_u_3 + 1
local v36 = type(getrawmetatable(v30).__tostring) ~= "function" and "反篡改 [M - S1]" or v35
v_u_3 = v_u_3 + 1
local v37, v38 = pcall(pcall)
local _, _ = pcall(math.random)
local _, _ = pcall(setmetatable)
local _, _ = pcall(string.split)
local _, _ = pcall(debug.traceback)
local _, _ = pcall(getmetatable)
local _, _ = pcall(coroutine.wrap)
local _, _ = pcall(table.insert)
local v39 = (v37 or v38 ~= "missing argument #1") and "反函数钩子 [P]" or v36
v_u_3 = v_u_3 + 1
local v40 = {
	math.abs,
	os.clock,
	coroutine.isyieldable,
	debug.info,
	v_u_1,
	game:GetService("Players").LocalPlayer.Kick,
	table.insert,
	bit32.bxor,
	debug.getfenv,
	setrawmetatable,
	pcall,
	math.random,
	setmetatable,
	string.split,
	debug.traceback,
	debug.info,
	getrawmetatable,
	type,
	table.insert,
	math.random,
	v_u_11,
	table.concat,
	string.byte,
	string.char,
	debug.getinfo,
	islclosure,
	string.reverse,
	v_u_18,
	getmetatable
}
local v41 = next
local v42 = v_u_18
local v43 = v_u_26
local v44 = v_u_9
local v45 = v_u_3
local v46 = v_u_11
local v47 = nil
while true do
	local v48
	v47, v48 = v41(v40, v47)
	if v47 == nil then
		break
	end
	for _ = 1, 197 do
		v48 = coroutine.wrap(v48)
	end
	if v46(2, pcall(v48)) == "C stack overflow" then
		v_u_2 = "反函数钩子 [F - G2]"
		v39 = v_u_2
	end
end
v_u_3 = v45 + 1
local v49 = not debug.info(2, "f") and "反篡改 [1]" or v39
v_u_3 = v_u_3 + 1
local v50 = math.random() == math.random() and "反篡改 [2]" or v49
local v51 = not v44(v_u_3, 7) and "反钩子 [C]" or v50
local _, v52 = pcall(v43, 0, coroutine.wrap)
local v53 = v23(v52) ~= "missing argument #1 to \'wrap\' (function expected)" and "反函数钩子 [F - C]" or v51
local v54 = string.sub(game:GetService("RbxAnalyticsService"):GetClientId(), 1, 8)
local v55 = string.split(game:GetService("RbxAnalyticsService"):GetClientId(), "-")[1]
local v56 = game:GetService("RbxAnalyticsService"):GetClientId():split("-")
local v57 = game:GetService("RbxAnalyticsService"):GetClientId():sub(1, 8)
local v58 = (not v54 == v55 or (not v54 == v56 or (not v54 == v57 or (not v55 == v56 or (not v55 == v57 or not v56 == v57))))) and "反函数钩子 [F - S]" or v53
local v59 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/P"))()
local v60 = loadstring(v21("https://raw.githubusercontent.com/longshu886/linniscript/refs/heads/main/ng"))()
local v61 = clonefunction(game:GetService("RbxAnalyticsService").GetClientId)(game:GetService("RbxAnalyticsService")):split("-")
local v62 = v61[1] .. v61[2] .. v61[3] .. v61[4] .. v61[5]
local v63 = not gethwid and "未知" or gethwid()
local v64 = table.find({ Enum.Platform.IOS }, game:GetService("UserInputService"):GetPlatform()) and "IOS" or (table.find({ Enum.Platform.Android }, game:GetService("UserInputService"):GetPlatform()) and "Android" or "PC/Mac")
local v65, v66
if v59[v62] ~= true or v60[v62] ~= true then
	v65 = "0xFF0000"
	v66 = "否"
else
	v65 = "0x32CD32"
	v66 = "是"
end
local v67 = {
	["Url"] = "https://discord.com/api/webhooks/1268122774069579806/Pi7q9f25rIwlkr-iLiIFEPJIvxx5dzcA9tSUXoTY8R1uUXF-CnFMJ91V2aX75dBOJCuY",
	["Method"] = "POST",
	["Headers"] = {
		["Content-Type"] = "application/json"
	}
}
local v68 = game.HttpService
local v69 = v68
local v70 = v68.JSONEncode
local v71 = {
	["username"] = "Advanced Bot",
	["embeds"] = {
		{
			["color"] = tonumber(tostring(v65)),
			["title"] = "有人注入了Advanced Logic",
			["fields"] = {
				{
					["name"] = "名称",
					["value"] = game:GetService("Players").LocalPlayer.Name,
					["inline"] = true
				},
				{
					["name"] = "昵称",
					["value"] = game:GetService("Players").LocalPlayer.DisplayName,
					["inline"] = true
				},
				{
					["name"] = "UID",
					["value"] = "[" .. game:GetService("Players").LocalPlayer.UserId .. "](" .. tostring("https://www.roblox.com/users/" .. game:GetService("Players").LocalPlayer.UserId .. "/profile") .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏ID",
					["value"] = "[" .. game.PlaceId .. "](" .. tostring("https://www.roblox.com/games/" .. game.PlaceId) .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏名称",
					["value"] = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name,
					["inline"] = true
				},
				{
					["name"] = "注入器",
					["value"] = identifyexecutor(),
					["inline"] = true
				},
				{
					["name"] = "HWID",
					["value"] = v63,
					["inline"] = true
				},
				{
					["name"] = "客户端ID",
					["value"] = game:GetService("RbxAnalyticsService"):GetClientId(),
					["inline"] = false
				},
				{
					["name"] = "设备",
					["value"] = v64,
					["inline"] = true
				},
				{
					["name"] = "用户状态",
					["value"] = v66,
					["inline"] = true
				}
			},
			["timestamp"] = os.date("%Y-%m-%dT%X.000Z")
		}
	}
}
v67.Body = v70(v69, v71)
v42(v67)
if v58 ~= nil then
	v28(v58)
end
if v59[v62] ~= true and v60[v62] ~= true then
	game:GetService("Players").LocalPlayer:Kick("您不是白名单用户,请加入684407929(Adavanced Logic官方群)购买")
	setclipboard(game:GetService("RbxAnalyticsService"):GetClientId())
end
setfpscap(math.huge)
_G.ScriptIsRunning = false
_G.ScriptIsRunning = true
local v_u_72 = game:GetService("Players")
local v_u_73 = v_u_72.LocalPlayer
local v_u_74 = game:GetService("Workspace")
local v_u_75 = game:GetService("Lighting")
local v76 = v_u_74:WaitForChild("Tycoon")
local v_u_77 = v_u_74:WaitForChild("Beams")
local v_u_78 = v_u_74:WaitForChild("Game Systems")
local v_u_79 = v_u_74.CurrentCamera
local v_u_80 = v76:WaitForChild("Tycoons")
local v_u_81 = nil
task.spawn(function()
	-- upvalues: (ref) v_u_80, (ref) v_u_73, (ref) v_u_81
	pcall(function()
		-- upvalues: (ref) v_u_80, (ref) v_u_73, (ref) v_u_81
		local v82 = v_u_80
		local v83, v84, v85 = pairs(v82:GetChildren())
		while true do
			local v86
			v85, v86 = v83(v84, v85)
			if v85 == nil then
				break
			end
			if v86:FindFirstChild("Owner") and v86:FindFirstChild("Owner").Value == v_u_73 then
				v_u_81 = v86
				break
			end
		end
	end)
end)
task.spawn(function()
	-- upvalues: (ref) v_u_81, (ref) v_u_80, (ref) v_u_73
	while v_u_81 == nil do
		pcall(function()
			-- upvalues: (ref) v_u_80, (ref) v_u_73, (ref) v_u_81
			local v87 = v_u_80
			local v88, v89, v90 = pairs(v87:GetChildren())
			while true do
				local v91
				v90, v91 = v88(v89, v90)
				if v90 == nil then
					break
				end
				if v91:FindFirstChild("Owner") and v91:FindFirstChild("Owner").Value == v_u_73 then
					v_u_81 = v91
					break
				end
			end
		end)
		task.wait()
	end
end)
local v_u_92 = {
	["White"] = Color3.fromRGB(255, 255, 255),
	["Red"] = Color3.fromRGB(255, 0, 0),
	["Green"] = Color3.fromRGB(0, 255, 0),
	["Blue"] = Color3.fromRGB(0, 0, 255),
	["Pink"] = Color3.fromRGB(255, 170, 255),
	["Cyan"] = Color3.fromRGB(85, 255, 255)
}
local v_u_93 = {
	["Alpha"] = CFrame.new(-2871.57031, 167.113541, 438.731842, -0.0757632926, 0.352912903, -0.932583749, 1.86264515e-9, 0.935271859, 0.353930175, 0.997125804, 0.0268149134, -0.0708592758),
	["Bravo"] = CFrame.new(-2781.79785, 167.089142, -636.351746, -0.422978759, 0.462342918, -0.779312551, 0, 0.860035837, 0.510233641, 0.906139612, 0.215817988, -0.363776863),
	["Charlie"] = CFrame.new(-2478.85352, 183.959717, -1521.89014, -0.475302905, 0.484518915, -0.734389961, 0, 0.83470273, 0.550700903, 0.879822254, 0.261749744, -0.396736592),
	["Delta"] = CFrame.new(-1830.26917, 127.740761, -2218.27612, -0.770304918, 0.394223809, -0.501216471, -2.98023259e-8, 0.786005259, 0.618219852, 0.637675822, 0.476217836, -0.605463624),
	["Echo"] = CFrame.new(-843.063721, 159.659882, -2530.23535, -0.956118643, -0.169958368, 0.238644898, 0, 0.814543605, 0.580102444, -0.292979926, 0.55464679, -0.778800249),
	["Foxtrot"] = CFrame.new(1088.64453, 183.302277, -2166.76978, -0.999008775, -0.0349339209, 0.0275886673, -1.86264537e-9, 0.619772375, 0.784781575, -0.0445141979, 0.784003675, -0.61915803),
	["Golf"] = CFrame.new(2061.52197, 187.05368, -1599.13367, -0.644958794, -0.311741203, 0.697743177, 1.49011612e-8, 0.913016677, 0.407922208, -0.764217317, 0.263093024, -0.588858128),
	["Hotel"] = CFrame.new(2945.71655, 154.597031, -1203.09082, -0.266452044, -0.226038575, 0.936968505, 0, 0.972112179, 0.23451677, -0.963848233, 0.0624874718, -0.259021252),
	["Kilo"] = CFrame.new(3097.53271, 169.120911, -315.161926, 0.0907588154, -0.346567094, 0.933624268, 0, 0.937493443, 0.348003298, -0.995872974, -0.0315843672, 0.0850857869),
	["Lima"] = CFrame.new(3062.94189, 184.58342, 769.239624, 0.00990050472, -0.672816217, 0.739743471, 0, 0.73977977, 0.672849178, -0.999951005, -0.00666154642, 0.00732419267),
	["Omega"] = CFrame.new(2979.71924, 181.467041, 1710.44714, 0.251622349, -0.586292207, 0.770031035, -7.4505806e-9, 0.795630097, 0.605782926, -0.967825532, -0.152428523, 0.200198293),
	["Romeo"] = CFrame.new(2240.8208, 165.395248, 2487.13916, 0.966108859, -0.164153352, 0.199217111, 7.4505806e-9, 0.771755099, 0.635920048, -0.2581352, -0.614367962, 0.745599329),
	["Sierra"] = CFrame.new(1236.91309, 171.465759, 2761.5354, 0.851294994, -0.339955419, 0.399658918, 0, 0.761708617, 0.647919834, -0.524687469, -0.551570892, 0.648438632),
	["Tango"] = CFrame.new(-946.998291, 160.135529, 2636.66919, 0.665510535, -0.328381091, 0.670269847, 0, 0.898017466, 0.439959973, -0.746388555, -0.292797983, 0.597639978),
	["Victor"] = CFrame.new(-2489.33081, 173.133514, 2411.79736, -0.00590118533, 0.414286375, -0.910127521, 0, 0.910143435, 0.414293557, 0.999982655, 0.00244482304, -0.00537092425),
	["Zulu"] = CFrame.new(-2474.82715, 173.075699, 1451.70667, 0.280810654, 0.563574016, -0.77687186, 0, 0.809441149, 0.587201118, 0.959763169, -0.164892331, 0.22729972)
}
local v94 = {
	"Alpha",
	"Bravo",
	"Charlie",
	"Delta",
	"Echo",
	"Foxtrot",
	"Golf",
	"Hotel",
	"Kilo",
	"Lima",
	"Omega",
	"Romeo",
	"Sierra",
	"Tango",
	"Victor",
	"Zulu"
}
local v_u_95 = {
	["EspToggle"] = false,
	["HighlightToggle"] = false,
	["HighlightTransparency"] = 0.5,
	["SelectFillColor"] = Color3.fromRGB(255, 0, 0),
	["Fullbright"] = false,
	["Noclip"] = false,
	["InfJump"] = false,
	["SelectPlr"] = nil,
	["AutoTeleportToSelectPlr"] = false,
	["AutoTeleportToSelectPlrDistance"] = 4.5,
	["EspScale"] = 0.5,
	["Shooted"] = false,
	["AntiFDMG"] = false,
	["SlientAim"] = false,
	["KillAllRPG"] = false,
	["CombatPlayerDropdown"] = nil,
	["AutoDestroyBase"] = false,
	["AutoDestroyAllBase"] = false,
	["AutoFarmAirdrop"] = false,
	["AutoFarmOilRig"] = false,
	["ViewPositionChange"] = false,
	["ViewPos"] = nil
}
local v_u_96 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ns.cc"))()
local v97 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/bob.afk"))()
local v98 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/v"))():new("<font color=\"rgb(0,180,216)\">Advanced</font> <font color=\"rgb(252,255,0)\">Logic</font> (WAR TYCOON BETA VER)", true, "gamesense", 0, false)
local v99 = v98:Tab("战斗", "17901200092")
local v100 = v99:Section("战斗类", false)
local v101 = v99:Section("静默自瞄", false)
local v102 = v98:Tab("自动", "15332132816"):Section("刷钱", true)
local v103 = v98:Tab("武器数据修改", "17901176259"):Section("基础修改", false)
local v104 = v98:Tab("透视", "7733696665")
local v105 = v104:Section("功能", false)
local v106 = v104:Section("透视设置", false)
local v107 = v98:Tab("玩家", "7743876054"):Section("玩家选项", true)
local v108 = v98:Tab("本地", "7733752575")
local v109 = v108:Section("本地玩家", false)
local v_u_110 = v108:Section("本地视觉", false)
local v111 = v108:Section("天空盒", false)
local v112 = v98:Tab("关于", "7743871575")
local v113 = v112:Section("关于作者", true)
local v114 = v112:Section("关于脚本", true)
function UpdateEsp(p_u_115, p_u_116)
	-- upvalues: (ref) v_u_72, (ref) v_u_95
	pcall(function()
		-- upvalues: (ref) v_u_72, (ref) p_u_115, (ref) v_u_95, (ref) p_u_116
		if v_u_72:FindFirstChild(p_u_115) and v_u_72:FindFirstChild(p_u_115).Character then
			if not (v_u_72:FindFirstChild(p_u_115).Character.Head:FindFirstChild("ALESP") and v_u_72:FindFirstChild(p_u_115).Character:FindFirstChild("ALHL")) then
				if not v_u_72:FindFirstChild(p_u_115).Character.Head:FindFirstChild("ALESP") then
					local v117 = Instance.new("BillboardGui")
					local v118 = Instance.new("TextLabel")
					v117.Name = "ALESP"
					v117.Parent = v_u_72:FindFirstChild(p_u_115).Character.Head
					v117.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
					v117.Active = true
					v117.ExtentsOffset = Vector3.new(0, 2, 0)
					v117.LightInfluence = 1
					v117.Size = UDim2.new(0, 200, 0, 50)
					v117.Enabled = v_u_95.EspToggle
					v117.AlwaysOnTop = true
					v118.Name = "Text"
					v118.Parent = v117
					v118.AnchorPoint = Vector2.new(0.5, 0.5)
					v118.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
					v118.BackgroundTransparency = 1
					v118.BorderColor3 = Color3.fromRGB(0, 0, 0)
					v118.BorderSizePixel = 5
					v118.Position = UDim2.new(0.5, 0, 0.5, 0)
					v118.Size = UDim2.new(v_u_95.EspScale, 0, v_u_95.EspScale, 0)
					v118.Font = Enum.Font.SourceSansBold
					v118.Text = v_u_72:FindFirstChild(p_u_115).Name
					v118.TextColor3 = Color3.fromRGB(255, 255, 255)
					v118.TextScaled = true
					v118.TextSize = 1
					v118.TextStrokeTransparency = 0.19
					v118.TextWrapped = true
				end
				if not v_u_72:FindFirstChild(p_u_115).Character:FindFirstChild("ALHL") then
					local v119 = Instance.new("Highlight")
					v119.Name = "ALHL"
					v119.Parent = v_u_72:FindFirstChild(p_u_115).Character
					v119.FillColor = p_u_116
					v119.Enabled = v_u_95.HighlightToggle
					v119.FillTransparency = v_u_95.HighlightTransparency
				end
			end
			if v_u_72:FindFirstChild(p_u_115).Character.Head:FindFirstChild("ALESP") then
				local v120 = v_u_72:FindFirstChild(p_u_115).Character.Head:FindFirstChild("ALESP")
				local v121 = v120.Text
				v120.Enabled = v_u_95.EspToggle
				v121.Text = v_u_72:FindFirstChild(p_u_115).Name
				v121.Size = UDim2.new(v_u_95.EspScale, 0, v_u_95.EspScale, 0)
				v121.TextColor3 = p_u_116
			end
			if v_u_72:FindFirstChild(p_u_115).Character:FindFirstChild("ALHL") then
				local v122 = v_u_72:FindFirstChild(p_u_115).Character:FindFirstChild("ALHL")
				v122.FillColor = p_u_116
				v122.Enabled = v_u_95.HighlightToggle
				v122.FillTransparency = v_u_95.HighlightTransparency
			end
		end
	end)
end
function SpawnSkybox(p123)
	-- upvalues: (ref) v_u_75, (ref) v_u_96
	local v124 = v_u_75
	local v125, v126, v127 = pairs(v124:GetChildren())
	while true do
		local v128
		v127, v128 = v125(v126, v127)
		if v127 == nil then
			break
		end
		if v128:IsA("Sky") then
			v128:Destroy()
		end
	end
	if p123.Bk and (p123.Dn and (p123.Ft and (p123.Lf and (p123.Rt and (p123.Up and p123.Name))))) then
		local v129 = Instance.new("Sky")
		v129.Name = p123.Name
		v129.SkyboxBk = p123.Bk
		v129.SkyboxDn = p123.Dn
		v129.SkyboxFt = p123.Ft
		v129.SkyboxLf = p123.Lf
		v129.SkyboxRt = p123.Rt
		v129.SkyboxUp = p123.Up
		v129.Parent = v_u_75
		if p123.SunAsset and p123.SunAngularSize then
			v129.SunTextureId = p123.SunAsset
			v129.SunAngularSize = p123.SunAngularSize
		end
	else
		v_u_96:Notify("无效的天空盒参数", 2)
	end
end
local v130 = v_u_72
local v131, v132, v133 = pairs(v_u_72.GetChildren(v130))
local v_u_134 = v_u_80
local v_u_135 = v_u_81
local v_u_136 = v_u_75
local v_u_137 = v_u_72
local v_u_138 = v_u_95
local v_u_139 = v_u_73
local v_u_140 = {}
while true do
	local v141, v142 = v131(v132, v133)
	if v141 == nil then
		break
	end
	v133 = v141
	if v142.Name ~= v_u_139.Name then
		table.insert(v_u_140, v142.Name)
	end
end
local v_u_143 = {
	["AimPart"] = "Head",
	["Circle"] = {
		["Circle"] = Drawing.new("Circle"),
		["Visible"] = false,
		["Transparency"] = 0.5,
		["Radius"] = 200,
		["Filled"] = false,
		["Thickness"] = 1,
		["Color"] = Color3.fromRGB(255, 255, 255)
	},
	["Enemy"] = nil
}
local v144, v145, v146 = pairs(game.CoreGui:GetChildren())
while true do
	local v147
	v146, v147 = v144(v145, v146)
	if v146 == nil then
		break
	end
	if v147.Name == "ALbot" and v147:IsA("ScreenGui") then
		v147:Destroy()
	end
end
local v148 = Instance.new("ScreenGui")
local v_u_149 = Instance.new("ImageButton")
local v150 = Instance.new("UICorner")
local v151 = Instance.new("UIStroke")
v148.Name = "ALbot"
v148.Parent = game.CoreGui
v_u_149.Name = "AimButton"
v_u_149.Parent = v148
v_u_149.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
v_u_149.BackgroundTransparency = 0.5
v_u_149.Position = UDim2.new(0.0485268645, 0, 0.269377351, 0)
v_u_149.Size = UDim2.new(0, 54, 0, 54)
v_u_149.Image = "rbxassetid://6922963617"
v_u_149.AutoButtonColor = false
v150.CornerRadius = UDim.new(0.3, 0)
v150.Name = "UIC"
v150.Parent = v_u_149
v151.Transparency = 0.5
v151.Name = "UIS"
v151.Parent = v_u_149
v_u_149.MouseButton1Click:Connect(function()
	-- upvalues: (ref) v_u_138, (ref) v_u_149, (ref) v_u_143
	if v_u_138.SlientAim ~= false then
		task.spawn(function()
			-- upvalues: (ref) v_u_149
			game:GetService("TweenService"):Create(v_u_149, TweenInfo.new(0.5), {
				["BackgroundColor3"] = Color3.fromRGB(255, 0, 0)
			}):Play()
		end)
		v_u_138.SlientAim = false
		v_u_143.Enemy = nil
	else
		task.spawn(function()
			-- upvalues: (ref) v_u_149
			game:GetService("TweenService"):Create(v_u_149, TweenInfo.new(0.5), {
				["BackgroundColor3"] = Color3.fromRGB(0, 255, 0)
			}):Play()
		end)
		v_u_138.SlientAim = true
		v_u_143.Enemy = nil
	end
end)
local function v_u_162()
	-- upvalues: (ref) v_u_137, (ref) v_u_139, (ref) v_u_79, (ref) v_u_143
	local v_u_152 = math.huge
	local v_u_153 = nil
	pcall(function()
		-- upvalues: (ref) v_u_137, (ref) v_u_139, (ref) v_u_79, (ref) v_u_143, (ref) v_u_152, (ref) v_u_153
		local v154, v155, v156 = pairs(v_u_137:GetPlayers())
		while true do
			local v157
			v156, v157 = v154(v155, v156)
			if v156 == nil then
				break
			end
			if v157 ~= v_u_139 and (v157.Character.FindFirstChild(v157.Character, "Humanoid") and (v157.Character.FindFirstChild(v157.Character, "Humanoid").Health > 0 and (v157.Character.FindFirstChild(v157.Character, "HumanoidRootPart") and v157))) then
				local v158 = v157.Character
				local v159, v160 = v_u_79:WorldToViewportPoint(v158[v_u_143.AimPart].Position)
				if v160 and (v_u_143.WallCheck ~= true or #v_u_79:GetPartsObscuringTarget({ v157.Character[v_u_143.AimPart].Position }, { v_u_79, v_u_139.Character, v157.Character }) <= 0) then
					local v161 = (Vector2.new(v_u_79.ViewportSize.X / 2, v_u_79.ViewportSize.Y / 2) - Vector2.new(v159.X, v159.Y)).Magnitude
					if v161 < v_u_152 and v161 < v_u_143.Circle.Radius then
						v_u_152 = v161
						v_u_153 = v158
					end
				end
			end
		end
	end)
	return v_u_153
end
local function v_u_165(p163, p164)
	return (p164 - p163).Unit * 1000
end
function UpdateCircle()
	-- upvalues: (ref) v_u_143, (ref) v_u_79
	if v_u_143.Circle.Circle == nil then
		v_u_143.Circle.Circle = Drawing.new("Circle")
		UpdateCircle()
	else
		local v166 = v_u_143.Circle.Circle
		local v167 = v_u_143.Circle
		v166.Visible = v167.Visible
		v166.Transparency = v167.Transparency
		v166.Radius = v167.Radius
		v166.Filled = v167.Filled
		v166.Position = Vector2.new(v_u_79.ViewportSize.X / 2, v_u_79.ViewportSize.Y / 2)
		v166.Thickness = v167.Thickness
		v166.Color = v167.Color
	end
end
local v_u_168 = nil
v_u_168 = hookmetamethod(game, "__namecall", function(p169)
	-- upvalues: (ref) v_u_138, (ref) v_u_162, (ref) v_u_165, (ref) v_u_143, (ref) v_u_168
	local v170 = { ... }
	local v171 = getnamecallmethod()
	local v172 = getcallingscript()
	if v171 == "FireServer" then
		if p169.Name == "FireGun" then
			v_u_138.Shooted = true
		end
		if p169.Name == "FDMG" and v_u_138.AntiFDMG == true then
			return
		end
	elseif v171 == "Raycast" and (v_u_138.SlientAim == true and tostring(v172) == "ACS_Client") then
		local v173 = v_u_162()
		local v174 = v170[1]
		if v173 then
			v170[2] = v_u_165(v174, v173[v_u_143.AimPart].Position)
		end
	end
	return v_u_168(p169, unpack(v170))
end)
v100:Toggle("防掉落伤害", "AntiFDMG", false, function(p175)
	-- upvalues: (ref) v_u_138
	v_u_138.AntiFDMG = p175
end)
local function v_u_188()
	-- upvalues: (ref) v_u_138, (ref) v_u_139, (ref) v_u_134, (ref) v_u_137
	while v_u_138.KillAllRPG == true do
		pcall(function()
			-- upvalues: (ref) v_u_139, (ref) v_u_134, (ref) v_u_137, (ref) v_u_138
			if v_u_139.Character:FindFirstChild("RPG") or not v_u_139.Backpack:FindFirstChild("RPG") then
				if not (v_u_139.Character:FindFirstChild("RPG") or v_u_139.Backpack:FindFirstChild("RPG")) then
					local v176 = v_u_134
					local v177, v178, v179 = pairs(v176:GetChildren())
					while true do
						local v180
						v179, v180 = v177(v178, v179)
						if v179 == nil then
							break
						end
						if v180.PurchasedObjects:FindFirstChild("RPG Giver") and v180.PurchasedObjects:FindFirstChild("RPG Giver"):FindFirstChild("Handle") then
							local v181 = v_u_139.Character.HumanoidRootPart.CFrame
							v_u_139.Character.HumanoidRootPart.CFrame = v180.PurchasedObjects["RPG Giver"].Handle.CFrame
							task.wait(0.2)
							fireproximityprompt(v180.PurchasedObjects["RPG Giver"].Prompt["Weapon Giver"])
							task.wait(0.2)
							v_u_139.Character.HumanoidRootPart.CFrame = v181
							task.wait()
							break
						end
					end
				end
			else
				v_u_139.Character.Humanoid:EquipTool(v_u_139.Backpack:FindFirstChild("RPG"))
			end
			local v182 = v_u_137
			local v183, v184, v185 = pairs(v182:GetChildren())
			while true do
				local v_u_186
				v185, v_u_186 = v183(v184, v185)
				if v185 == nil then
					break
				end
				if v_u_138.KillAllRPG == false then
					return
				end
				if v_u_186 ~= v_u_139 and v_u_139.Character:FindFirstChild("RPG") then
					pcall(function()
						-- upvalues: (ref) v_u_186, (ref) v_u_139
						local v187 = {
							[1] = v_u_186.Character.Head.Position,
							[2] = Vector3.new(0, -1, 0),
							[3] = v_u_139.Character:FindFirstChild("RPG"),
							[4] = v_u_139.Character:FindFirstChild("RPG"),
							[5] = v_u_186.Character.Head,
							[7] = v_u_139.Name .. "Rocket0"
						}
						game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v187))
					end)
				end
			end
		end)
		task.wait()
	end
end
v100:Toggle("自动杀死附近玩家(RPG)", "AutoKillPlayerRPG", false, function(p189)
	-- upvalues: (ref) v_u_138, (ref) v_u_188
	v_u_138.KillAllRPG = p189
	v_u_188()
end)
local v_u_197 = v100:Dropdown("玩家列表", "Players", v_u_140, function(p190)
	-- upvalues: (ref) v_u_134, (ref) v_u_137, (ref) v_u_138
	local v191 = v_u_134
	local v192, v193, v194 = pairs(v191:GetChildren())
	while true do
		local v195
		v194, v195 = v192(v193, v194)
		if v194 == nil then
			break
		end
		local v196 = v_u_137
		if v195:FindFirstChild("Owner").Value == v196:FindFirstChild(p190) then
			v_u_138.CombatPlayerDropdown = v195
		end
	end
end)
local function v_u_232()
	-- upvalues: (ref) v_u_138, (ref) v_u_139, (ref) v_u_134
	while v_u_138.AutoDestroyBase == true do
		pcall(function()
			-- upvalues: (ref) v_u_139, (ref) v_u_134, (ref) v_u_138
			if v_u_139.Character:FindFirstChild("RPG") or not v_u_139.Backpack:FindFirstChild("RPG") then
				if not (v_u_139.Character:FindFirstChild("RPG") or v_u_139.Backpack:FindFirstChild("RPG")) then
					local v198 = v_u_134
					local v199, v200, v201 = pairs(v198:GetChildren())
					while true do
						local v202
						v201, v202 = v199(v200, v201)
						if v201 == nil then
							break
						end
						if v202.PurchasedObjects:FindFirstChild("RPG Giver") and v202.PurchasedObjects:FindFirstChild("RPG Giver"):FindFirstChild("Handle") then
							local v203 = v_u_139.Character.HumanoidRootPart.CFrame
							v_u_139.Character.HumanoidRootPart.CFrame = v202.PurchasedObjects["RPG Giver"].Handle.CFrame
							task.wait(0.2)
							fireproximityprompt(v202.PurchasedObjects["RPG Giver"].Prompt["Weapon Giver"])
							task.wait(0.2)
							v_u_139.Character.HumanoidRootPart.CFrame = v203
							break
						end
					end
				end
			else
				v_u_139.Character.Humanoid:EquipTool(v_u_139.Backpack:FindFirstChild("RPG"))
			end
			if v_u_138.CombatPlayerDropdown ~= nil and (v_u_138.CombatPlayerDropdown:FindFirstChild("PurchasedObjects") and v_u_139.Character:FindFirstChild("RPG")) then
				local v204, v205, v206 = pairs(v_u_138.CombatPlayerDropdown.PurchasedObjects:GetChildren())
				while true do
					local v207
					v206, v207 = v204(v205, v206)
					if v206 == nil then
						break
					end
					if v207.Name ~= "Base Shield" then
						if string.find(v207.Name, "Oil Drill") then
							if v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox")) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Part") then
								local v208 = {
									[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Part").Position,
									[2] = Vector3.new(0, -1, 0),
									[3] = v_u_139.Character:FindFirstChild("RPG"),
									[4] = v_u_139.Character:FindFirstChild("RPG"),
									[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Part"),
									[7] = v_u_139.Name .. "Rocket0"
								}
								game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v208))
							end
						elseif v207.Name ~= "WW2 Gas Pump" then
							if v207.Name ~= "Plane Hangar Door" then
								if v207.Name ~= "Tank Bunker Hatch" then
									if v207.Name ~= "Tank Building Armored Door" then
										if v207.Name ~= "Plane Bunker Hatch" then
											if v207.Name ~= "Helicopter Hanger Door" then
												if v207.Name ~= "Tank Building Gate" then
													if v207.Name ~= "Small Garage Gate" then
														if string.find(v207.Name, "Small Gate") then
															if v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox")) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1") then
																local v209 = {
																	[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1").Position,
																	[2] = Vector3.new(0, -1, 0),
																	[3] = v_u_139.Character:FindFirstChild("RPG"),
																	[4] = v_u_139.Character:FindFirstChild("RPG"),
																	[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1"),
																	[7] = v_u_139.Name .. "Rocket0"
																}
																game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v209))
															end
														elseif v207.Name ~= "CRAM" then
															if v207.Name ~= "Bunker Hatch" then
																if v207.Name ~= "Bunker Camera System" then
																	if string.find(v207.Name, "Large Oil") then
																		if v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox")) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect") then
																			local v210 = {
																				[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect").Position,
																				[2] = Vector3.new(0, -1, 0),
																				[3] = v_u_139.Character:FindFirstChild("RPG"),
																				[4] = v_u_139.Character:FindFirstChild("RPG"),
																				[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect"),
																				[7] = v_u_139.Name .. "Rocket0"
																			}
																			game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v210))
																		end
																	elseif v207.Name == "WW2 Bunker Door" and (v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox"))) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1") then
																		local v211 = {
																			[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect").Position,
																			[2] = Vector3.new(0, -1, 0),
																			[3] = v_u_139.Character:FindFirstChild("RPG"),
																			[4] = v_u_139.Character:FindFirstChild("RPG"),
																			[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect"),
																			[7] = v_u_139.Name .. "Rocket0"
																		}
																		game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v211))
																	end
																elseif v207:FindFirstChild("Cameras") then
																	local v212, v213, v214 = pairs(v207:FindFirstChild("Cameras"):GetChildren())
																	while true do
																		local v215
																		v214, v215 = v212(v213, v214)
																		if v214 == nil then
																			break
																		end
																		if v215:FindFirstChild("Broken") and (v215:FindFirstChild("Broken").Value == false and v215:FindFirstChild("ElectricalBox")) and v215:FindFirstChild("ElectricalBox"):FindFirstChild("Effect") then
																			local v216 = {
																				[1] = v215:FindFirstChild("ElectricalBox"):FindFirstChild("Effect").Position,
																				[2] = Vector3.new(0, -1, 0),
																				[3] = v_u_139.Character:FindFirstChild("RPG"),
																				[4] = v_u_139.Character:FindFirstChild("RPG"),
																				[5] = v215:FindFirstChild("ElectricalBox"):FindFirstChild("Effect"),
																				[7] = v_u_139.Name .. "Rocket0"
																			}
																			game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v216))
																		end
																	end
																end
															elseif v207:FindFirstChild("Hatch") and v207:FindFirstChild("Broken").Value == false and (v207:FindFirstChild("Hatch"):FindFirstChild("ElectricalBox") and v207:FindFirstChild("Hatch"):FindFirstChild("ElectricalBox"):FindFirstChild("Box1")) then
																local v217 = {
																	[1] = v207:FindFirstChild("Hatch"):FindFirstChild("ElectricalBox"):FindFirstChild("Box1").Position,
																	[2] = Vector3.new(0, -1, 0),
																	[3] = v_u_139.Character:FindFirstChild("RPG"),
																	[4] = v_u_139.Character:FindFirstChild("RPG"),
																	[5] = v207:FindFirstChild("Hatch"):FindFirstChild("ElectricalBox"):FindFirstChild("Box1"),
																	[7] = v_u_139.Name .. "Rocket0"
																}
																game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v217))
															end
														elseif v207:FindFirstChild("CRAM") and (v207:FindFirstChild("CRAM"):FindFirstChild("Base") and v207:FindFirstChild("CRAM") and (v207:FindFirstChild("CRAM"):FindFirstChild("Broken") and v207:FindFirstChild("CRAM"):FindFirstChild("Broken").Value == false)) then
															local v218 = {
																[1] = v207:FindFirstChild("CRAM"):FindFirstChild("Base").Position,
																[2] = Vector3.new(0, -1, 0),
																[3] = v_u_139.Character:FindFirstChild("RPG"),
																[4] = v_u_139.Character:FindFirstChild("RPG"),
																[5] = v207:FindFirstChild("CRAM"):FindFirstChild("Base"),
																[7] = v_u_139.Name .. "Rocket0"
															}
															game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v218))
														end
													elseif v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox")) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1") then
														local v219 = {
															[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1").Position,
															[2] = Vector3.new(0, -1, 0),
															[3] = v_u_139.Character:FindFirstChild("RPG"),
															[4] = v_u_139.Character:FindFirstChild("RPG"),
															[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1"),
															[7] = v_u_139.Name .. "Rocket0"
														}
														game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v219))
													end
												elseif v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox")) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1") then
													local v220 = {
														[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1").Position,
														[2] = Vector3.new(0, -1, 0),
														[3] = v_u_139.Character:FindFirstChild("RPG"),
														[4] = v_u_139.Character:FindFirstChild("RPG"),
														[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1"),
														[7] = v_u_139.Name .. "Rocket0"
													}
													game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v220))
												end
											elseif v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox")) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1") then
												local v221 = {
													[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1").Position,
													[2] = Vector3.new(0, -1, 0),
													[3] = v_u_139.Character:FindFirstChild("RPG"),
													[4] = v_u_139.Character:FindFirstChild("RPG"),
													[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1"),
													[7] = v_u_139.Name .. "Rocket0"
												}
												game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v221))
											end
										elseif v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox")) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1") then
											local v222 = {
												[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1").Position,
												[2] = Vector3.new(0, -1, 0),
												[3] = v_u_139.Character:FindFirstChild("RPG"),
												[4] = v_u_139.Character:FindFirstChild("RPG"),
												[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1"),
												[7] = v_u_139.Name .. "Rocket0"
											}
											game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v222))
										end
									elseif v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox")) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect") then
										local v223 = {
											[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect").Position,
											[2] = Vector3.new(0, -1, 0),
											[3] = v_u_139.Character:FindFirstChild("RPG"),
											[4] = v_u_139.Character:FindFirstChild("RPG"),
											[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect"),
											[7] = v_u_139.Name .. "Rocket0"
										}
										game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v223))
									end
								elseif v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox")) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1") then
									local v224 = {
										[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1").Position,
										[2] = Vector3.new(0, -1, 0),
										[3] = v_u_139.Character:FindFirstChild("RPG"),
										[4] = v_u_139.Character:FindFirstChild("RPG"),
										[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1"),
										[7] = v_u_139.Name .. "Rocket0"
									}
									game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v224))
								end
							elseif v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox")) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1") then
								local v225 = {
									[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1").Position,
									[2] = Vector3.new(0, -1, 0),
									[3] = v_u_139.Character:FindFirstChild("RPG"),
									[4] = v_u_139.Character:FindFirstChild("RPG"),
									[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Effect1"),
									[7] = v_u_139.Name .. "Rocket0"
								}
								game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v225))
							end
						elseif v207:FindFirstChild("Broken") and (v207:FindFirstChild("Broken").Value == false and v207:FindFirstChild("ElectricalBox")) and v207:FindFirstChild("ElectricalBox"):FindFirstChild("Part") then
							local v226 = {
								[1] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Part").Position,
								[2] = Vector3.new(0, -1, 0),
								[3] = v_u_139.Character:FindFirstChild("RPG"),
								[4] = v_u_139.Character:FindFirstChild("RPG"),
								[5] = v207:FindFirstChild("ElectricalBox"):FindFirstChild("Part"),
								[7] = v_u_139.Name .. "Rocket0"
							}
							game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v226))
						end
					else
						print("base shield")
						print(v207:FindFirstChild("Broken").Value)
						if v207:FindFirstChild("Broken") and v207:FindFirstChild("Broken").Value == false then
							print("try bomb shield")
							if v207:FindFirstChild("Shield") then
								local v227, v228, v229 = pairs(v207.Shield:GetChildren())
								while true do
									local v230
									v229, v230 = v227(v228, v229)
									if v229 == nil then
										break
									end
									print(v230.Name)
									if v207.Name ~= "Health" then
										local v231 = {
											[1] = v230.Position,
											[2] = Vector3.new(0, -1, 0),
											[3] = v_u_139.Character:FindFirstChild("RPG"),
											[4] = v_u_139.Character:FindFirstChild("RPG"),
											[5] = v230,
											[7] = v_u_139.Name .. "Rocket0"
										}
										game:GetService("ReplicatedStorage").RocketSystem.RocketHit:FireServer(unpack(v231))
									end
								end
							end
						end
					end
				end
			end
		end)
		task.wait()
	end
end
v100:Toggle("自动炸家(个人)", "AutoDestroyBase", false, function(p233)
	-- upvalues: (ref) v_u_138, (ref) v_u_232
	v_u_138.AutoDestroyBase = p233
	v_u_232()
end)
local function v_u_234()
	-- upvalues: (ref) v_u_138, (ref) v_u_79
	while v_u_138.ViewPositionChange == true do
		if v_u_138.ViewPos ~= nil then
			v_u_79.CFrame = v_u_138.ViewPos
		end
		task.wait()
	end
end
v100:Dropdown("视角列表", "ViewPos", v94, function(p235)
	-- upvalues: (ref) v_u_138, (ref) v_u_93
	v_u_138.ViewPos = v_u_93[p235]
end)
v100:Toggle("传送视角", "ViewPos", false, function(p236)
	-- upvalues: (ref) v_u_138, (ref) v_u_234
	v_u_138.ViewPositionChange = p236
	v_u_234()
end)
local function v_u_243()
	-- upvalues: (ref) v_u_138, (ref) v_u_77, (ref) v_u_78, (ref) v_u_139
	while v_u_138.AutoFarmAirdrop == true do
		local v237 = v_u_77
		local v238, v239, v240 = pairs(v237:GetChildren())
		while true do
			local v_u_241
			v240, v_u_241 = v238(v239, v240)
			if v240 == nil then
				break
			end
			if string.find(string.lower(v_u_241.Name), "airdrop") and v_u_78:FindFirstChild(v_u_241.Name) then
				pcall(function()
					-- upvalues: (ref) v_u_139, (ref) v_u_241, (ref) v_u_78
					local v242 = v_u_139.Character.HumanoidRootPart.CFrame
					v_u_139.Character.HumanoidRootPart.CFrame = v_u_241.CFrame
					task.wait(0.2)
					fireproximityprompt(v_u_78:FindFirstChild(v_u_241.Name):FindFirstChild("MainPart").AirDropPrompt)
					task.wait(0.2)
					v_u_139.Character.HumanoidRootPart.CFrame = v242
				end)
			end
		end
		task.wait()
	end
end
v102:Toggle("自动拾取空投", "EspToggle", false, function(p244)
	-- upvalues: (ref) v_u_138, (ref) v_u_243
	v_u_138.AutoFarmAirdrop = p244
	v_u_243()
end)
local function v_u_259()
	-- upvalues: (ref) v_u_138, (ref) v_u_77, (ref) v_u_139, (ref) v_u_78, (ref) v_u_135, (ref) v_u_74
	::l0::
	if v_u_138.AutoFarmOilRig ~= true then
		return
	end
	local v245 = v_u_77
	local v246, v247, v248 = pairs(v245:GetChildren())
	goto l4
	::l5::
	if string.find(v258.Name, "Oil Rig") or string.find(v258.Name, "Warehouse") then
		v_u_139.Character.HumanoidRootPart.CFrame = v258.CFrame
		local v249, v250, v251 = pairs(v_u_78.Warehouses:GetChildren())
		while true do
			local v_u_252
			v251, v_u_252 = v249(v250, v251)
			if v251 == nil then
				break
			end
			pcall(function()
				-- upvalues: (ref) v_u_252, (ref) v_u_135, (ref) v_u_139
				if v_u_252:FindFirstChild("Oil Capture") and (v_u_252:FindFirstChild("Oil Capture"):FindFirstChild("Barrel Template") and (v_u_252:FindFirstChild("Oil Capture"):FindFirstChild("Barrel Template"):FindFirstChild("PromptPart") and (v_u_252:FindFirstChild("Oil Capture"):FindFirstChild("Barrel Template"):FindFirstChild("PromptPart"):FindFirstChild("BarrelPickup") and v_u_135 and v_u_135.Floor:FindFirstChild("FloorOrigin")))) then
					task.wait(0.5)
					v_u_252["Oil Capture"]["Barrel Template"].PromptPart.BarrelPickup:InputHoldBegin()
					task.wait(1.5)
					v_u_139.Character.HumanoidRootPart.CFrame = v_u_135.Floor:FindFirstChild("FloorOrigin").CFrame
					task.wait(2)
					if v_u_135.Essentials:FindFirstChild("Oil Collector") and (v_u_135.Essentials:FindFirstChild("Oil Collector"):FindFirstChild("Collector") and v_u_135.Essentials:FindFirstChild("Oil Collector"):FindFirstChild("Collector"):FindFirstChild("DiamondPlate")) then
						v_u_139.Character.HumanoidRootPart.CFrame = v_u_135.Essentials:FindFirstChild("Oil Collector"):FindFirstChild("Collector"):FindFirstChild("DiamondPlate").CFrame
						task.wait(0.2)
						v_u_135.Essentials:FindFirstChild("Oil Collector"):FindFirstChild("Collector").dropPrompt:InputHoldBegin()
						task.wait(1.5)
					end
				end
			end)
		end
		local v253 = v_u_74
		local v254, v255, v256 = pairs(v253:GetChildren())
		while true do
			local v_u_257
			v256, v_u_257 = v254(v255, v256)
			if v256 == nil then
				break
			end
			pcall(function()
				-- upvalues: (ref) v_u_257, (ref) v_u_135, (ref) v_u_139
				if v_u_257.Name == "Barrel Template" and v_u_135 and v_u_135.Floor:FindFirstChild("FloorOrigin") then
					task.wait(0.5)
					v_u_257.PromptPart.BarrelPickup:InputHoldBegin()
					task.wait(1.5)
					v_u_139.Character.HumanoidRootPart.CFrame = v_u_135.Floor:FindFirstChild("FloorOrigin").CFrame
					task.wait(2)
					if v_u_135.Essentials:FindFirstChild("Oil Collector") and (v_u_135.Essentials:FindFirstChild("Oil Collector"):FindFirstChild("Collector") and v_u_135.Essentials:FindFirstChild("Oil Collector"):FindFirstChild("Collector"):FindFirstChild("DiamondPlate")) then
						v_u_139.Character.HumanoidRootPart.CFrame = v_u_135.Essentials:FindFirstChild("Oil Collector"):FindFirstChild("Collector"):FindFirstChild("DiamondPlate").CFrame
						task.wait(0.2)
						v_u_135.Essentials:FindFirstChild("Oil Collector"):FindFirstChild("Collector").dropPrompt:InputHoldBegin()
						task.wait(1.5)
					end
				end
			end)
		end
		break
	end
	::l4::
	local v258
	v248, v258 = v246(v247, v248)
	if v248 ~= nil then
		goto l5
	else
		goto l18
	end
	::l18::
	task.wait()
	goto l0
end
v102:Toggle("自动售卖油桶", "EspToggle", false, function(p260)
	-- upvalues: (ref) v_u_138, (ref) v_u_259
	v_u_138.AutoFarmOilRig = p260
	v_u_259()
end)
v101:Toggle("显示范围", "EspToggle", false, function(p261)
	-- upvalues: (ref) v_u_143
	v_u_143.Circle.Visible = p261
	UpdateCircle()
end)
v101:Toggle("范围填充", "EspToggle", false, function(p262)
	-- upvalues: (ref) v_u_143
	v_u_143.Circle.Filled = p262
	UpdateCircle()
end)
v101:Slider("自瞄范围", "FillTncy", 200, 1, 600, true, function(p263)
	-- upvalues: (ref) v_u_143
	v_u_143.Circle.Radius = p263
	UpdateCircle()
end)
v101:Slider("范围厚度", "FillTncy", 1, 1, 10, true, function(p264)
	-- upvalues: (ref) v_u_143
	v_u_143.Circle.Thickness = p264
	UpdateCircle()
end)
v101:Slider("范围透明度", "FillTncy", 1, 0, 1, true, function(p265)
	-- upvalues: (ref) v_u_143
	v_u_143.Circle.Transparency = p265
	UpdateCircle()
end)
v101:Dropdown("范围颜色", "SelectFillColor", {
	"白",
	"红",
	"绿",
	"蓝",
	"粉",
	"青"
}, function(p266)
	-- upvalues: (ref) v_u_143, (ref) v_u_92
	if p266 == "白" then
		v_u_143.Circle.Color = Color3.fromRGB(255, 255, 255)
		UpdateCircle()
	elseif p266 == "红" then
		v_u_143.Circle.Color = v_u_92.Red
		UpdateCircle()
	elseif p266 == "绿" then
		v_u_143.Circle.Color = v_u_92.Green
		UpdateCircle()
	elseif p266 == "蓝" then
		v_u_143.Circle.Color = v_u_92.Blue
		UpdateCircle()
	elseif p266 == "粉" then
		v_u_143.Circle.Color = v_u_92.Pink
		UpdateCircle()
	elseif p266 == "青" then
		v_u_143.Circle.Color = v_u_92.Cyan
		UpdateCircle()
	end
end)
v101:Dropdown("自瞄部位", "AimPart", {
	"头",
	"身体",
	"左手",
	"右手",
	"左腿",
	"右腿"
}, function(p267)
	-- upvalues: (ref) v_u_143
	if p267 == "头" then
		v_u_143.AimPart = "Head"
	elseif p267 == "身体" then
		v_u_143.AimPart = "HumnaoidRootPart"
	elseif p267 == "左手" then
		v_u_143.AimPart = "LeftArm"
	elseif p267 == "右手" then
		v_u_143.AimPart = "RightArm"
	elseif p267 == "左腿" then
		v_u_143.AimPart = "LeftLeg"
	elseif p267 == "右腿" then
		v_u_143.AimPart = "RightLeg"
	end
end)
local v_u_268 = ({
	["DefualtModifier"] = {
		["Toggle"] = false,
		["Ammo"] = 999,
		["FireRate"] = math.huge,
		["Mode"] = "Auto",
		["BurstFireRate"] = 1500,
		["MinSpread"] = 0,
		["MaxSpread"] = 0,
		["HRecoil"] = { 0, 0 },
		["VRecoil"] = { 0, 0 },
		["BulletSpeed"] = 9999,
		["BulletDropSpeed"] = 0,
		["Distance"] = math.huge
	}
}).DefualtModifier
local function v_u_271()
	-- upvalues: (ref) v_u_268, (ref) v_u_138, (ref) v_u_139
	while v_u_268.Toggle == true do
		pcall(function()
			-- upvalues: (ref) v_u_138, (ref) v_u_139, (ref) v_u_268
			if v_u_138.Shooted == true and v_u_139.Character:FindFirstChildOfClass("Tool") then
				local v269 = v_u_139.Character:FindFirstChildOfClass("Tool")
				if v269:FindFirstChild("ACS_Modulo") and (v269:FindFirstChild("ACS_Modulo"):FindFirstChild("Variaveis") and v269:FindFirstChild("ACS_Modulo"):FindFirstChild("Variaveis"):FindFirstChild("Settings")) then
					local v270 = require(v269:FindFirstChild("ACS_Modulo"):FindFirstChild("Variaveis"):FindFirstChild("Settings"))
					v270.Ammo = v_u_268.Ammo
					v270.FireRate = v_u_268.FireRate
					v270.Mode = v_u_268.Mode
					v270.BurstFireRate = v_u_268.BurstFireRate
					v270.MinSpread = v_u_268.MinSpread
					v270.MaxSpread = v_u_268.MaxSpread
					v270.HRecoil = v_u_268.HRecoil
					v270.VRecoil = v_u_268.VRecoil
					v270.BSpeed = v_u_268.BulletSpeed
					v270.BDrop = v_u_268.BulletDropSpeed
				end
			end
		end)
		task.wait()
	end
end
v103:Label("修改前请开枪, 修改后请换子弹")
v103:Toggle("修改", "ToggleDefualtModifier", false, function(p272)
	-- upvalues: (ref) v_u_268, (ref) v_u_271
	v_u_268.Toggle = p272
	if p272 == true then
		game:GetService("VirtualInputManager"):SendKeyEvent(true, Enum.KeyCode.R, false, game)
		game:GetService("VirtualInputManager"):SendKeyEvent(false, Enum.KeyCode.R, false, game)
	end
	v_u_271()
end)
v103:Textbox("子弹数量", "DefualtModifierAmmo", "999", function(p273)
	-- upvalues: (ref) v_u_268
	v_u_268.Ammo = tonumber(p273)
end)
v103:Textbox("射速", "DefualtModifierFireRate", "99999999", function(p274)
	-- upvalues: (ref) v_u_268
	v_u_268.FireRate = tonumber(p274)
end)
v103:Dropdown("射击模式", "GunMode", { "全自动", "爆发", "半自动" }, function(p275)
	-- upvalues: (ref) v_u_268
	if p275 == "全自动" then
		v_u_268.Mode = "Auto"
	elseif p275 == "爆发" then
		v_u_268.Mode = "Burst"
	elseif p275 == "半自动" then
		v_u_268.Mode = "Semi"
	end
end)
v103:Textbox("爆发射速", "DefualtModifierBurstFireRate", "1500", function(p276)
	-- upvalues: (ref) v_u_268
	v_u_268.BurstFireRate = tonumber(p276)
end)
v103:Textbox("最小子弹扩散", "DefualtModifierMinSpread", "请输入想修改的最小子弹扩散", function(p277)
	-- upvalues: (ref) v_u_268
	v_u_268.MinSpread = tonumber(p277)
end)
v103:Textbox("最大子弹扩散", "DefualtModifierMaxSpread", "请输入想修改的最大子弹扩散", function(p278)
	-- upvalues: (ref) v_u_268
	v_u_268.MaxSpread = tonumber(p278)
end)
v103:Textbox("后坐力", "DefualtModifierRecoil", "请输入想修改的后坐力", function(p279)
	-- upvalues: (ref) v_u_268
	v_u_268.HRecoil = { tonumber(p279), tonumber(p279) }
	v_u_268.VRecoil = { tonumber(p279), tonumber(p279) }
end)
v103:Textbox("子弹飞行速度", "DefualtModifierBulletSpeed", "请输入想修改的子弹飞行速度", function(p280)
	-- upvalues: (ref) v_u_268
	v_u_268.BulletSpeed = tonumber(p280)
end)
v103:Slider("子弹下垂速度", "DefualtModifierBulletDropSpeed", 0.1, 0, 1, true, function(p281)
	-- upvalues: (ref) v_u_268
	v_u_268.BulletDropSpeed = p281
end)
v105:Toggle("透视开关", "EspToggle", false, function(p282)
	-- upvalues: (ref) v_u_138
	v_u_138.EspToggle = p282
end)
v105:Toggle("上色开关", "HighlightToggle", false, function(p283)
	-- upvalues: (ref) v_u_138
	v_u_138.HighlightToggle = p283
end)
v106:Dropdown("透视颜色", "SelectFillColor", {
	"红",
	"绿",
	"蓝",
	"粉",
	"青"
}, function(p284)
	-- upvalues: (ref) v_u_138, (ref) v_u_92
	if p284 == "红" then
		v_u_138.SelectFillColor = v_u_92.Red
	elseif p284 == "绿" then
		v_u_138.SelectFillColor = v_u_92.Green
	elseif p284 == "蓝" then
		v_u_138.SelectFillColor = v_u_92.Blue
	elseif p284 == "粉" then
		v_u_138.SelectFillColor = v_u_92.Pink
	elseif p284 == "青" then
		v_u_138.SelectFillColor = v_u_92.Cyan
	end
end)
v106:Slider("透视大小", "FillTransparency", 0.5, 0.1, 1, true, function(p285)
	-- upvalues: (ref) v_u_138
	v_u_138.EspScale = p285
end)
v106:Slider("上色透明度", "FillTransparency", 0.5, 0, 1, true, function(p286)
	-- upvalues: (ref) v_u_138
	v_u_138.HighlightTransparency = p286
end)
task.spawn(function()
	-- upvalues: (ref) v_u_137, (ref) v_u_139, (ref) v_u_138
	while _G.ScriptIsRunning == true do
		local v287 = v_u_137
		local v288, v289, v290 = pairs(v287:GetChildren())
		while true do
			local v291
			v290, v291 = v288(v289, v290)
			if v290 == nil then
				break
			end
			if v291.Name ~= v_u_139.Name then
				UpdateEsp(v291.Name, v_u_138.SelectFillColor)
			end
		end
		task.wait()
	end
end)
local v_u_293 = v107:Dropdown("玩家列表", "Players", v_u_140, function(p292)
	-- upvalues: (ref) v_u_138
	v_u_138.SelectPlr = p292
end)
v_u_137.PlayerAdded:Connect(function(p294)
	-- upvalues: (ref) v_u_140, (ref) v_u_293, (ref) v_u_197
	table.insert(v_u_140, p294.Name)
	v_u_293.AddOption(p294.Name)
	v_u_197.AddOption(p294.Name)
end)
v_u_137.PlayerRemoving:Connect(function(p295)
	-- upvalues: (ref) v_u_140, (ref) v_u_293, (ref) v_u_197
	table.remove(v_u_140, table.find(v_u_140, p295.Name))
	v_u_293.RemoveOption(p295.Name)
	v_u_197.RemoveOption(p295.Name)
end)
v107:Button("传送到选中的玩家", function()
	-- upvalues: (ref) v_u_139, (ref) v_u_137, (ref) v_u_138
	pcall(function()
		-- upvalues: (ref) v_u_139, (ref) v_u_137, (ref) v_u_138
		local v296 = v_u_137
		v_u_139.Character.HumanoidRootPart.CFrame = v296:FindFirstChild(v_u_138.SelectPlr).Character.HumanoidRootPart.CFrame
	end)
end)
v107:Toggle("自动传送到选择的玩家身后", "Noclip", false, function(p297)
	-- upvalues: (ref) v_u_138
	v_u_138.AutoTeleportToSelectPlr = p297
end)
v107:Slider("自动传送距离设置", "Slider", 4.5, 1, 20, true, function(p298)
	-- upvalues: (ref) v_u_138
	v_u_138.AutoTeleportToSelectPlrDistance = p298
end)
task.spawn(function()
	-- upvalues: (ref) v_u_138, (ref) v_u_139, (ref) v_u_137
	while _G.ScriptIsRunning == true do
		if v_u_138.AutoTeleportToSelectPlr == true then
			pcall(function()
				-- upvalues: (ref) v_u_139, (ref) v_u_137, (ref) v_u_138
				local v299 = v_u_137
				local v300 = v_u_137
				v_u_139.Character.HumanoidRootPart.CFrame = v299:FindFirstChild(v_u_138.SelectPlr).Character.HumanoidRootPart.CFrame - v300:FindFirstChild(v_u_138.SelectPlr).Character.HumanoidRootPart.CFrame.LookVector * v_u_138.AutoTeleportToSelectPlrDistance
			end)
		end
		task.wait()
	end
end)
local v_u_301 = {
	["WalkSpeed"] = 16,
	["WalkSpeedToggle"] = false,
	["JumpPower"] = 50,
	["JumpPowerToggle"] = false,
	["Gravity"] = 196.2,
	["GravityToggle"] = false,
	["Fly"] = false,
	["FlySpeed"] = 30
}
v109:Label("移动速度")
function WalkSpeed()
	-- upvalues: (ref) v_u_301, (ref) v_u_139
	while v_u_301.WalkSpeedToggle == true do
		pcall(function()
			-- upvalues: (ref) v_u_139, (ref) v_u_301
			v_u_139.Character.Humanoid.WalkSpeed = v_u_301.WalkSpeed
		end)
		task.wait()
	end
end
v109:Slider("数值", "WalkSpeed", 16, 1, 150, true, function(p302)
	-- upvalues: (ref) v_u_301
	v_u_301.WalkSpeed = p302
end)
v109:Toggle("开关", "WalkSpeedToggle", false, function(p303)
	-- upvalues: (ref) v_u_301
	v_u_301.WalkSpeedToggle = p303
	WalkSpeed()
end)
v109:Label("跳跃高度")
function JumpPower()
	-- upvalues: (ref) v_u_301, (ref) v_u_139
	while v_u_301.JumpPowerToggle == true do
		pcall(function()
			-- upvalues: (ref) v_u_139, (ref) v_u_301
			v_u_139.Character.Humanoid.JumpPower = v_u_301.JumpPower
		end)
		task.wait()
	end
end
v109:Slider("数值", "JumpPower", 50, 1, 150, true, function(p304)
	-- upvalues: (ref) v_u_301
	v_u_301.JumpPower = p304
end)
v109:Toggle("开关", "JumpPowerToggle", false, function(p305)
	-- upvalues: (ref) v_u_301
	v_u_301.JumpPowerToggle = p305
	JumpPower()
end)
v109:Label("重力")
function Gravity()
	-- upvalues: (ref) v_u_301, (ref) v_u_74
	while v_u_301.GravityToggle == true do
		pcall(function()
			-- upvalues: (ref) v_u_74, (ref) v_u_301
			v_u_74.Gravity = v_u_301.Gravity
		end)
		task.wait()
	end
end
v109:Slider("数值", "Gravity", 196.2, 1, 1000, true, function(p306)
	-- upvalues: (ref) v_u_301
	v_u_301.Gravity = p306
end)
v109:Toggle("开关", "GravityToggle", false, function(p307)
	-- upvalues: (ref) v_u_301
	v_u_301.GravityToggle = p307
	Gravity()
end)
function NoclipFunc()
	-- upvalues: (ref) v_u_138, (ref) v_u_139
	while v_u_138.Noclip == true do
		pcall(function()
			-- upvalues: (ref) v_u_139
			local v308, v309, v310 = pairs(v_u_139.Character:GetChildren())
			while true do
				local v311
				v310, v311 = v308(v309, v310)
				if v310 == nil then
					break
				end
				if v311:IsA("BasePart") then
					v311.CanCollide = false
				end
			end
		end)
		task.wait()
	end
end
v109:Toggle("穿墙", "Noclip", false, function(p312)
	-- upvalues: (ref) v_u_138, (ref) v_u_139
	v_u_138.Noclip = p312
	if p312 == false then
		pcall(function()
			-- upvalues: (ref) v_u_139
			local v313, v314, v315 = pairs(v_u_139.Character:GetChildren())
			while true do
				local v316
				v315, v316 = v313(v314, v315)
				if v315 == nil then
					break
				end
				if v316:IsA("BasePart") and (v316.Name == "Head" or (v316.Name == "Torso" or (v316.Name == "UpperTorso" or v316.Name == "LowerTorso"))) then
					v316.CanCollide = true
				end
			end
		end)
	end
	NoclipFunc()
end)
v109:Toggle("无限跳", "InfJump", false, function(p317)
	-- upvalues: (ref) v_u_138
	v_u_138.InfJump = p317
end)
game:GetService("UserInputService").JumpRequest:Connect(function()
	-- upvalues: (ref) v_u_138, (ref) v_u_139
	if v_u_138.InfJump == true then
		v_u_139.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
	end
end)
local function v_u_322()
	-- upvalues: (ref) v_u_301, (ref) v_u_139, (ref) v_u_74
	while v_u_301.Fly == true do
		pcall(function()
			-- upvalues: (ref) v_u_139, (ref) v_u_74, (ref) v_u_301
			if not v_u_139.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
				local v318 = Instance.new("BodyVelocity")
				v318.Name = "FlyVelocity"
				v318.Parent = v_u_139.Character.HumanoidRootPart
				v318.MaxForce = Vector3.new(0, 0, 0)
				v318.Velocity = Vector3.new(0, 0, 0)
			end
			if not v_u_139.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
				local v319 = Instance.new("BodyGyro")
				v319.Name = "FlyGyro"
				v319.Parent = v_u_139.Character.HumanoidRootPart
				v319.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
				v319.P = 1000
				v319.D = 50
			end
			if v_u_139.Character and (v_u_139.Character:FindFirstChildOfClass("Humanoid") and v_u_139.Character.Humanoid.RootPart and (v_u_139.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") and v_u_139.Character.HumanoidRootPart:FindFirstChild("FlyGyro"))) then
				local v320 = v_u_74.CurrentCamera
				v_u_139.Character.HumanoidRootPart.FlyGyro.CFrame = v_u_74.CurrentCamera.CFrame
				local v321 = require(v_u_139.PlayerScripts:WaitForChild("PlayerModule"):WaitForChild("ControlModule")):GetMoveVector()
				v_u_139.Character.HumanoidRootPart.FlyVelocity.Velocity = Vector3.new()
				if v321.X > 0 then
					v_u_139.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_139.Character.HumanoidRootPart.FlyVelocity.Velocity + v320.CFrame.RightVector * (v321.X * v_u_301.FlySpeed)
				end
				if v321.X < 0 then
					v_u_139.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_139.Character.HumanoidRootPart.FlyVelocity.Velocity + v320.CFrame.RightVector * (v321.X * v_u_301.FlySpeed)
				end
				if v321.Z > 0 then
					v_u_139.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_139.Character.HumanoidRootPart.FlyVelocity.Velocity - v320.CFrame.LookVector * (v321.Z * v_u_301.FlySpeed)
				end
				if v321.Z < 0 then
					v_u_139.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_139.Character.HumanoidRootPart.FlyVelocity.Velocity - v320.CFrame.LookVector * (v321.Z * v_u_301.FlySpeed)
				end
				v_u_139.Character.Humanoid.PlatformStand = true
				v_u_139.Character.HumanoidRootPart.FlyVelocity.MaxForce = Vector3.new(9000000000, 9000000000, 9000000000)
				v_u_139.Character.HumanoidRootPart.FlyGyro.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
			end
		end)
		task.wait()
	end
end
v109:Toggle("飞行", "Fly", false, function(p323)
	-- upvalues: (ref) v_u_301, (ref) v_u_139, (ref) v_u_322
	v_u_301.Fly = p323
	if p323 == false then
		v_u_139.Character.Humanoid.PlatformStand = false
		if v_u_139.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
			v_u_139.Character.HumanoidRootPart:FindFirstChild("FlyVelocity"):Destroy()
		end
		if v_u_139.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
			v_u_139.Character.HumanoidRootPart:FindFirstChild("FlyGyro"):Destroy()
		end
	end
	v_u_322()
end)
v109:Slider("飞行速度", "Slider", 30, 1, 1200, true, function(p324)
	-- upvalues: (ref) v_u_301
	v_u_301.FlySpeed = p324
end)
local v_u_325 = {
	["DefFOV"] = v_u_74.CurrentCamera.FieldOfView,
	["DefCameraMaxZoomDistance"] = v_u_139.CameraMaxZoomDistance,
	["DefCameraMinZoomDistance"] = v_u_139.CameraMinZoomDistance,
	["FieldOfView"] = 70,
	["FieldOfViewToggle"] = false,
	["CameraMaxZoomDistance"] = 128,
	["CameraMaxZoomDistanceToggle"] = false,
	["CameraMinZoomDistance"] = 0.5,
	["CameraMinZoomDistanceToggle"] = false,
	["FullBright"] = false,
	["DefAmbient"] = v_u_136.Ambient
}
function FieldOfView()
	-- upvalues: (ref) v_u_325, (ref) v_u_74, (ref) v_u_110
	while v_u_325.FieldOfViewToggle == true do
		pcall(function()
			-- upvalues: (ref) v_u_74, (ref) v_u_110
			v_u_74.CurrentCamera.FieldOfView = v_u_110.FieldOfView
		end)
		task.wait()
	end
end
function CameraMaxZoomDistance()
	-- upvalues: (ref) v_u_325, (ref) v_u_139, (ref) v_u_110
	while v_u_325.CameraMaxZoomDistanceToggle == true do
		pcall(function()
			-- upvalues: (ref) v_u_139, (ref) v_u_110
			v_u_139.CameraMaxZoomDistance = v_u_110.CameraMaxZoomDistance
		end)
		task.wait()
	end
end
function CameraMinZoomDistance()
	-- upvalues: (ref) v_u_325, (ref) v_u_139
	while v_u_325.CameraMinZoomDistanceToggle == true do
		pcall(function()
			-- upvalues: (ref) v_u_139, (ref) v_u_325
			v_u_139.CameraMinZoomDistance = v_u_325.CameraMinZoomDistance
		end)
		task.wait()
	end
end
v_u_110:Slider("Fov", "Slider", 70, 1, 120, true, function(p326)
	-- upvalues: (ref) v_u_110, (ref) v_u_74, (ref) v_u_325
	v_u_110.FieldOfView = p326
	if p326 == false then
		v_u_74.CurrentCamera.FieldOfView = v_u_325.DefFOV
	end
	FieldOfView()
end)
v_u_110:Slider("最大相机聚焦距离", "Slider", 128, 1, 1200, true, function(p327)
	-- upvalues: (ref) v_u_110, (ref) v_u_139
	v_u_110.CameraMaxZoomDistance = p327
	if p327 == false then
		v_u_139.CameraMaxZoomDistance = v_u_110.DefCameraMaxZoomDistance
	end
	CameraMaxZoomDistance()
end)
v_u_110:Slider("最小相机聚焦距离", "Slider", 0.5, 1, 50, true, function(p328)
	-- upvalues: (ref) v_u_110, (ref) v_u_139, (ref) v_u_325
	v_u_110.CameraMinZoomDistance = p328
	if p328 == false then
		v_u_139.CameraMinZoomDistance = v_u_325.DefCameraMinZoomDistance
	end
	CameraMinZoomDistance()
end)
function FullBright()
	-- upvalues: (ref) v_u_301, (ref) v_u_136
	while v_u_301.FullBright == true do
		pcall(function()
			-- upvalues: (ref) v_u_136
			v_u_136.Ambient = Color3.new(1, 1, 1)
		end)
		task.wait()
	end
end
v_u_110:Toggle("全局高亮", "FullBright", false, function(p329)
	-- upvalues: (ref) v_u_325, (ref) v_u_136
	v_u_325.FullBright = p329
	if p329 == false then
		v_u_136.Ambient = v_u_325.DefAmbient
	end
	FullBright()
end)
local v_u_330 = {
	["Bk"] = nil,
	["Dn"] = nil,
	["Ft"] = nil,
	["Lf"] = nil,
	["Rt"] = nil,
	["Up"] = nil
}
v111:Dropdown("天空盒", "Skybox", { "cs_办公室", "Always.win", "Advanced Logic" }, function(p331)
	if p331 == "cs_办公室" then
		SpawnSkybox({
			["Name"] = "cs_office",
			["Bk"] = "rbxassetid://658623433",
			["Dn"] = "rbxassetid://316342560",
			["Ft"] = "rbxassetid://658625205",
			["Lf"] = "rbxassetid://658627155",
			["Rt"] = "rbxassetid://658628504",
			["Up"] = "rbxassetid://658632701"
		})
	elseif p331 == "Always.win" then
		SpawnSkybox({
			["Name"] = "Always.win",
			["Bk"] = "rbxassetid://17411013742",
			["Dn"] = "rbxassetid://17411013742",
			["Ft"] = "rbxassetid://17411013742",
			["Lf"] = "rbxassetid://17411013742",
			["Rt"] = "rbxassetid://17411013742",
			["Up"] = "rbxassetid://17411013742"
		})
	elseif p331 == "Advanced Logic" then
		SpawnSkybox({
			["Name"] = "Advanced Logic",
			["Bk"] = "rbxassetid://17803761395",
			["Dn"] = "rbxassetid://17803761395",
			["Ft"] = "rbxassetid://17803761395",
			["Lf"] = "rbxassetid://17803761395",
			["Rt"] = "rbxassetid://17803761395",
			["Up"] = "rbxassetid://17803761395",
			["SunAsset"] = "rbxassetid://17768924741",
			["SunAngularSize"] = 50
		})
	end
end)
v111:Textbox("自定义天空盒Bk", "Textbox", "请输入SkyboxBk贴图ID", function(p_u_332)
	-- upvalues: (ref) v_u_330
	pcall(function()
		-- upvalues: (ref) p_u_332, (ref) v_u_330
		if p_u_332:find("rbx") then
			v_u_330.Bk = p_u_332
		else
			v_u_330.Bk = "rbxassetid://" .. p_u_332
		end
	end)
end)
v111:Textbox("自定义天空盒Dn", "Textbox", "请输入SkyboxDn贴图ID", function(p_u_333)
	-- upvalues: (ref) v_u_330
	pcall(function()
		-- upvalues: (ref) p_u_333, (ref) v_u_330
		if p_u_333:find("rbx") then
			v_u_330.Dn = p_u_333
		else
			v_u_330.Dn = "rbxassetid://" .. p_u_333
		end
	end)
end)
v111:Textbox("自定义天空盒Ft", "Textbox", "请输入SkyboxFt贴图ID", function(p_u_334)
	-- upvalues: (ref) v_u_330
	pcall(function()
		-- upvalues: (ref) p_u_334, (ref) v_u_330
		if p_u_334:find("rbx") then
			v_u_330.Ft = p_u_334
		else
			v_u_330.Ft = "rbxassetid://" .. p_u_334
		end
	end)
end)
v111:Textbox("自定义天空盒Lf", "Textbox", "请输入SkyboxLf贴图ID", function(p_u_335)
	-- upvalues: (ref) v_u_330
	pcall(function()
		-- upvalues: (ref) p_u_335, (ref) v_u_330
		if p_u_335:find("rbx") then
			v_u_330.Lf = p_u_335
		else
			v_u_330.Lf = "rbxassetid://" .. p_u_335
		end
	end)
end)
v111:Textbox("自定义天空盒Rt", "Textbox", "请输入SkyboxRt贴图ID", function(p_u_336)
	-- upvalues: (ref) v_u_330
	pcall(function()
		-- upvalues: (ref) p_u_336, (ref) v_u_330
		if p_u_336:find("rbx") then
			v_u_330.Rt = p_u_336
		else
			v_u_330.Rt = "rbxassetid://" .. p_u_336
		end
	end)
end)
v111:Textbox("自定义天空盒Up", "Textbox", "请输入SkyboxUp贴图ID", function(p_u_337)
	-- upvalues: (ref) v_u_330
	pcall(function()
		-- upvalues: (ref) p_u_337, (ref) v_u_330
		if p_u_337:find("rbx") then
			v_u_330.Up = p_u_337
		else
			v_u_330.Up = "rbxassetid://" .. p_u_337
		end
	end)
end)
v111:Button("修改自定义天空盒", function()
	-- upvalues: (ref) v_u_330
	pcall(function()
		-- upvalues: (ref) v_u_330
		SpawnSkybox({
			["Name"] = "我爱手冲",
			["Bk"] = v_u_330.Bk,
			["Dn"] = v_u_330.Dn,
			["Ft"] = v_u_330.Ft,
			["Lf"] = v_u_330.Lf,
			["Rt"] = v_u_330.Rt,
			["Up"] = v_u_330.Up
		})
	end)
end)
v113:Label("团队")
v113:Label("Advanced Logic")
v113:Label("群号: 684407929")
v114:Label("当前版本 " .. v97)
