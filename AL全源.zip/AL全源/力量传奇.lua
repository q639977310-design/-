local v_u_1 = http_request or request or (HttpPost or syn.request)
local v_u_2 = nil
local v_u_3 = 0
local function v_u_9(p4, p5, p6)
	-- upvalues: (ref) v_u_3, (ref) v_u_9
	v_u_3 = v_u_3 + 1
	if p6 then
		local v7 = v_u_9(p4, p5) and v_u_9(p4, p6)
		if v7 then
			v7 = v_u_9(p5, p6)
		end
		return v7
	else
		local v8 = type(p4) == typeof(p5) and (typeof(p4) == type(p5) and (type(p4) == typeof(p5) or typeof(p4) == type(p5))) and (#tostring(p4) == #tostring(p5) and rawequal(p4, p5))
		if v8 then
			if tostring(p4) < tostring(p5) or tostring(p4) > tostring(p5) then
				v8 = false
			else
				v8 = rawequal(tostring(p4), tostring(p5))
			end
		end
		return v8
	end
end
local function v_u_11(p10)
	return ({ ... })[p10]
end
local function v_u_18(p_u_12)
	-- upvalues: (ref) v_u_1, (ref) v_u_2, (ref) v_u_11
	local v_u_13 = false
	local v15 = {
		["__call"] = v_u_1,
		["__index"] = function(_, p14)
			-- upvalues: (ref) v_u_13, (ref) v_u_1, (ref) v_u_2, (ref) p_u_12
			v_u_13 = true
			if debug.info(2, "f") ~= v_u_1 then
				v_u_2 = "反钩子 [H - 1]"
				return "https://www.roblox.com/users/7207800972/profile"
			end
			if not coroutine.isyieldable() then
				return p_u_12[p14]
			end
			v_u_2 = "反钩子 [H - 2]"
			return "https://www.roblox.com/users/7207800972/profile"
		end
	}
	local v16 = setmetatable({}, v15)
	local v17 = v_u_11(2, pcall(v16))
	if v_u_13 then
		return v17
	end
end
local function v21(p19)
	-- upvalues: (ref) v_u_18
	local v20 = v_u_18({
		["Url"] = p19,
		["Method"] = "GET"
	})
	repeat
		task.wait()
	until v20
	return v20.Body
end
local function v23(p22)
	return string.split(p22 or "", ": ")[2]
end
local function v_u_26(p24, p25)
	-- upvalues: (ref) v_u_26
	if p24 == 0 then
		task.wait()
	end
	p25(...)
	v_u_26(p24 + 1, p25)
end
local function v28(p27)
	game:GetService("Players").LocalPlayer:Kick("")
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.TitleFrame.ErrorTitle.Text = "危险行为"
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.MessageArea.ErrorFrame.ErrorMessage.Text = p27
	task.wait(1)
	game:Shutdown()
	task.wait(1)
	task.spawn(function()
		while true do

		end
	end)
end
local v29 = {
	v_u_26,
	v_u_11,
	pcall,
	debug.info,
	islclosure,
	debug.getinfo,
	debug.getfenv,
	0,
	{
		"Url",
		"Method",
		"Headers",
		"Cookies",
		"Body"
	},
	table.insert,
	v_u_2,
	v_u_1
}
local v30 = { math.random, v_u_11, v_u_18 }
local v31 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end
}
setmetatable(v29, v31)
local v32 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end
}
setmetatable(v30, v32)
local v33 = type(getrawmetatable(v29).__index) ~= "function" and "反篡改 [M - S1]" or v_u_2
v_u_3 = v_u_3 + 1
local v34 = type(getrawmetatable(v29).__tostring) ~= "function" and "反篡改 [M - S1]" or v33
v_u_3 = v_u_3 + 1
local v35 = (type(getrawmetatable(v30).__index) ~= "function" or type(getrawmetatable(v30).__index) ~= type(getmetatable(v30).__index)) and "反篡改 [M - S1]" or v34
v_u_3 = v_u_3 + 1
local v36 = type(getrawmetatable(v30).__tostring) ~= "function" and "反篡改 [M - S1]" or v35
v_u_3 = v_u_3 + 1
local v37, v38 = pcall(pcall)
local _, _ = pcall(math.random)
local _, _ = pcall(setmetatable)
local _, _ = pcall(string.split)
local _, _ = pcall(debug.traceback)
local _, _ = pcall(getmetatable)
local _, _ = pcall(coroutine.wrap)
local _, _ = pcall(table.insert)
local v39 = (v37 or v38 ~= "missing argument #1") and "反函数钩子 [P]" or v36
v_u_3 = v_u_3 + 1
local v40 = {
	math.abs,
	os.clock,
	coroutine.isyieldable,
	debug.info,
	v_u_1,
	game:GetService("Players").LocalPlayer.Kick,
	table.insert,
	bit32.bxor,
	debug.getfenv,
	setrawmetatable,
	pcall,
	math.random,
	setmetatable,
	string.split,
	debug.traceback,
	debug.info,
	getrawmetatable,
	type,
	table.insert,
	math.random,
	v_u_11,
	table.concat,
	string.byte,
	string.char,
	debug.getinfo,
	islclosure,
	string.reverse,
	v_u_18,
	getmetatable
}
local v41 = next
local v42 = v_u_18
local v43 = v_u_26
local v44 = v_u_9
local v45 = v_u_3
local v46 = v_u_11
local v47 = nil
while true do
	local v48
	v47, v48 = v41(v40, v47)
	if v47 == nil then
		break
	end
	for _ = 1, 197 do
		v48 = coroutine.wrap(v48)
	end
	if v46(2, pcall(v48)) == "C stack overflow" then
		v_u_2 = "反函数钩子 [F - G2]"
		v39 = v_u_2
	end
end
v_u_3 = v45 + 1
local v49 = not debug.info(2, "f") and "反篡改 [1]" or v39
v_u_3 = v_u_3 + 1
local v50 = math.random() == math.random() and "反篡改 [2]" or v49
local v51 = not v44(v_u_3, 7) and "反钩子 [C]" or v50
local _, v52 = pcall(v43, 0, coroutine.wrap)
local v53 = v23(v52) ~= "missing argument #1 to \'wrap\' (function expected)" and "反函数钩子 [F - C]" or v51
local v54 = not string.sub(game:GetService("RbxAnalyticsService"):GetClientId(), 1, 8) == string.split(game:GetService("RbxAnalyticsService"):GetClientId(), "-")[1] and "反函数钩子 [F - S]" or v53
local v55 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/P"))()
local v56 = loadstring(v21("https://raw.githubusercontent.com/longshu886/linniscript/refs/heads/main/ng", true))()
local v57 = clonefunction(game:GetService("RbxAnalyticsService").GetClientId)(game:GetService("RbxAnalyticsService")):split("-")
local v58 = v57[1] .. v57[2] .. v57[3] .. v57[4] .. v57[5]
local v59 = not gethwid and "未知" or gethwid()
local v60 = table.find({ Enum.Platform.IOS }, game:GetService("UserInputService"):GetPlatform()) and "IOS" or (table.find({ Enum.Platform.Android }, game:GetService("UserInputService"):GetPlatform()) and "Android" or "PC/Mac")
local v61, v62
if v55[v58] ~= true or v56[v58] ~= true then
	v61 = "0xFF0000"
	v62 = "否"
else
	v61 = "0x32CD32"
	v62 = "是"
end
local v63 = {
	["username"] = "Advanced Bot",
	["embeds"] = {
		{
			["color"] = tonumber(tostring(v61)),
			["title"] = "有人注入了Advanced Logic",
			["fields"] = {
				{
					["name"] = "名称",
					["value"] = game:GetService("Players").LocalPlayer.Name,
					["inline"] = true
				},
				{
					["name"] = "昵称",
					["value"] = game:GetService("Players").LocalPlayer.DisplayName,
					["inline"] = true
				},
				{
					["name"] = "UID",
					["value"] = "[" .. game:GetService("Players").LocalPlayer.UserId .. "](" .. tostring("https://www.roblox.com/users/" .. game:GetService("Players").LocalPlayer.UserId .. "/profile") .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏ID",
					["value"] = "[" .. game.PlaceId .. "](" .. tostring("https://www.roblox.com/games/" .. game.PlaceId) .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏名称",
					["value"] = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name,
					["inline"] = true
				},
				{
					["name"] = "注入器",
					["value"] = identifyexecutor(),
					["inline"] = true
				},
				{
					["name"] = "HWID",
					["value"] = v59,
					["inline"] = true
				},
				{
					["name"] = "客户端ID",
					["value"] = game:GetService("RbxAnalyticsService"):GetClientId(),
					["inline"] = false
				},
				{
					["name"] = "设备",
					["value"] = v60,
					["inline"] = true
				},
				{
					["name"] = "用户状态",
					["value"] = v62,
					["inline"] = true
				}
			},
			["timestamp"] = os.date("%Y-%m-%dT%X.000Z")
		}
	}
}
v42({
	["Url"] = "https://discord.com/api/webhooks/1268122774069579806/Pi7q9f25rIwlkr-iLiIFEPJIvxx5dzcA9tSUXoTY8R1uUXF-CnFMJ91V2aX75dBOJCuY",
	["Method"] = "POST",
	["Headers"] = {
		["Content-Type"] = "application/json"
	},
	["Body"] = game.HttpService:JSONEncode(v63)
})
if v54 ~= nil then
	v28(v54)
end
if v55[v58] == true or v56[v58] == true then
	setfpscap(math.huge)
	_G.ScriptIsRunning = false
	_G.ScriptIsRunning = true
	local v_u_64 = game:GetService("Players")
	local v_u_65 = v_u_64.LocalPlayer
	game:GetService("CoreGui")
	game:GetService("RbxAnalyticsService")
	game:GetService("RunService")
	local _ = v_u_65.PlayerGui
	local v_u_66 = game:GetService("Workspace")
	local v_u_67 = game:GetService("Lighting")
	local v_u_68 = {
		["Red"] = Color3.fromRGB(255, 0, 0),
		["Green"] = Color3.fromRGB(0, 255, 0),
		["Blue"] = Color3.fromRGB(0, 0, 255),
		["Pink"] = Color3.fromRGB(255, 170, 255),
		["Cyan"] = Color3.fromRGB(85, 255, 255)
	}
	local v_u_69 = {
		["EspToggle"] = false,
		["HighlightToggle"] = false,
		["HighlightTransparency"] = 0.5,
		["SelectFillColor"] = Color3.fromRGB(255, 0, 0),
		["Fullbright"] = false,
		["Noclip"] = false,
		["Fly"] = false,
		["Flyspeed"] = 30,
		["InfJump"] = false,
		["SelectPlr"] = nil,
		["AutoTeleportToSelectPlr"] = false,
		["AutoTeleportToSelectPlrDistance"] = 4.5,
		["EspScale"] = 0.5,
		["AutoRep"] = false,
		["AutoReb"] = false,
		["AutoRebLimite"] = 18980,
		["Safeplate"] = false,
		["AutoFarmKills"] = false,
		["AutoFarmKillsDis"] = 6,
		["AntiVoid"] = false,
		["AutoFarmRocks"] = false
	}
	local v_u_70 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ns.cc"))()
	local v71 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/bob.afk"))()
	local v72 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/v"))():new("<font color=\"rgb(0,180,216)\">Advanced</font> <font color=\"rgb(252,255,0)\">Logic</font>", true, "gamesense", 0, false)
	local v73 = v72:Tab("主界面", "7733960981"):Section("摇头", false)
	local v74 = v72:Tab("自动", "15332132816")
	local v75 = v74:Section("举重", false)
	local v76 = v74:Section("重生", false)
	local v77 = v74:Section("石头", false)
	local v78 = v74:Section("杀人", false)
	local v79 = v72:Tab("安全", "7734056608")
	local v80 = v79:Section("安全板", false)
	local v81 = v79:Section("防虚空", false)
	local v82 = v72:Tab("透视", "7733696665")
	local v83 = v82:Section("功能", false)
	local v84 = v82:Section("透视设置", false)
	local v85 = v72:Tab("玩家", "7743876054"):Section("玩家选项", true)
	local v86 = v72:Tab("本地", "7733752575")
	local v87 = v86:Section("本地玩家", false)
	local v_u_88 = v86:Section("本地视觉", false)
	local v89 = v86:Section("天空盒", false)
	local v90 = v72:Tab("关于", "7743871575")
	local v91 = v90:Section("关于作者", true)
	local v92 = v90:Section("关于脚本", true)
	function UpdateEsp(p_u_93, p_u_94)
		-- upvalues: (ref) v_u_64, (ref) v_u_69
		pcall(function()
			-- upvalues: (ref) v_u_64, (ref) p_u_93, (ref) v_u_69, (ref) p_u_94
			if v_u_64:FindFirstChild(p_u_93) and v_u_64:FindFirstChild(p_u_93).Character then
				if not (v_u_64:FindFirstChild(p_u_93).Character.Head:FindFirstChild("ALESP") and v_u_64:FindFirstChild(p_u_93).Character:FindFirstChild("ALHL")) then
					if not v_u_64:FindFirstChild(p_u_93).Character.Head:FindFirstChild("ALESP") then
						local v95 = Instance.new("BillboardGui")
						local v96 = Instance.new("TextLabel")
						v95.Name = "ALESP"
						v95.Parent = v_u_64:FindFirstChild(p_u_93).Character.Head
						v95.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
						v95.Active = true
						v95.ExtentsOffset = Vector3.new(0, 2, 0)
						v95.LightInfluence = 1
						v95.Size = UDim2.new(0, 200, 0, 50)
						v95.Enabled = v_u_69.EspToggle
						v95.AlwaysOnTop = true
						v96.Name = "Text"
						v96.Parent = v95
						v96.AnchorPoint = Vector2.new(0.5, 0.5)
						v96.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						v96.BackgroundTransparency = 1
						v96.BorderColor3 = Color3.fromRGB(0, 0, 0)
						v96.BorderSizePixel = 5
						v96.Position = UDim2.new(0.5, 0, 0.5, 0)
						v96.Size = UDim2.new(v_u_69.EspScale, 0, v_u_69.EspScale, 0)
						v96.Font = Enum.Font.SourceSansBold
						v96.Text = v_u_64:FindFirstChild(p_u_93).Name
						v96.TextColor3 = Color3.fromRGB(255, 255, 255)
						v96.TextScaled = true
						v96.TextSize = 1
						v96.TextStrokeTransparency = 0.19
						v96.TextWrapped = true
					end
					if not v_u_64:FindFirstChild(p_u_93).Character:FindFirstChild("ALHL") then
						local v97 = Instance.new("Highlight")
						v97.Name = "ALHL"
						v97.Parent = v_u_64:FindFirstChild(p_u_93).Character
						v97.FillColor = p_u_94
						v97.Enabled = v_u_69.HighlightToggle
						v97.FillTransparency = v_u_69.HighlightTransparency
					end
				end
				if v_u_64:FindFirstChild(p_u_93).Character.Head:FindFirstChild("ALESP") then
					local v98 = v_u_64:FindFirstChild(p_u_93).Character.Head:FindFirstChild("ALESP")
					local v99 = v98.Text
					v98.Enabled = v_u_69.EspToggle
					v99.Text = v_u_64:FindFirstChild(p_u_93).Name
					v99.Size = UDim2.new(v_u_69.EspScale, 0, v_u_69.EspScale, 0)
					v99.TextColor3 = p_u_94
				end
				if v_u_64:FindFirstChild(p_u_93).Character:FindFirstChild("ALHL") then
					local v100 = v_u_64:FindFirstChild(p_u_93).Character:FindFirstChild("ALHL")
					v100.FillColor = p_u_94
					v100.Enabled = v_u_69.HighlightToggle
					v100.FillTransparency = v_u_69.HighlightTransparency
				end
			end
		end)
	end
	function SpawnSkybox(p101)
		-- upvalues: (ref) v_u_67, (ref) v_u_70
		local v102 = v_u_67
		local v103, v104, v105 = pairs(v102:GetChildren())
		while true do
			local v106
			v105, v106 = v103(v104, v105)
			if v105 == nil then
				break
			end
			if v106:IsA("Sky") then
				v106:Destroy()
			end
		end
		if p101.Bk and (p101.Dn and (p101.Ft and (p101.Lf and (p101.Rt and (p101.Up and p101.Name))))) then
			local v107 = Instance.new("Sky")
			v107.Name = p101.Name
			v107.SkyboxBk = p101.Bk
			v107.SkyboxDn = p101.Dn
			v107.SkyboxFt = p101.Ft
			v107.SkyboxLf = p101.Lf
			v107.SkyboxRt = p101.Rt
			v107.SkyboxUp = p101.Up
			v107.Parent = v_u_67
			if p101.SunAsset and p101.SunAngularSize then
				v107.SunTextureId = p101.SunAsset
				v107.SunAngularSize = p101.SunAngularSize
			end
		else
			v_u_70:Notify("无效的天空盒参数", 2)
		end
	end
	local v_u_108 = {
		["Toggle"] = false,
		["Yaw"] = 0,
		["RandomYaw"] = false,
		["RandomYawValue"] = 360
	}
	v73:Toggle("主开关", "EspToggle", false, function(p109)
		-- upvalues: (ref) v_u_108
		v_u_108.Toggle = p109
	end)
	v73:Slider("Y轴", "FillTransparency", 0, 0, 240, true, function(p110)
		-- upvalues: (ref) v_u_108
		v_u_108.Yaw = p110
	end)
	v73:Toggle("无序Y轴", "EspToggle", false, function(p111)
		-- upvalues: (ref) v_u_108
		v_u_108.RandomYaw = p111
	end)
	v73:Slider("无序Y轴", "FillTransparency", 240, 0, 240, true, function(p112)
		-- upvalues: (ref) v_u_108
		v_u_108.RandomYawValue = p112
	end)
	local v_u_113 = nil
	v_u_113 = hookmetamethod(game, "__namecall", function(p114)
		-- upvalues: (ref) v_u_108, (ref) v_u_113
		local v115 = { ... }
		local v116 = getnamecallmethod()
		if p114.Name == "bodyMovementEvent" and (v116 == "FireServer" and (v115[1] and v_u_108.Toggle == true)) then
			if v_u_108.RandomYaw ~= true then
				v115[1] = math.rad(v_u_108.Yaw)
			else
				v115[1] = math.rad(math.random(0, v_u_108.RandomYawValue))
			end
		end
		return v_u_113(p114, unpack(v115))
	end)
	v75:Toggle("自动锻炼", "EspToggle", false, function(p117)
		-- upvalues: (ref) v_u_69
		v_u_69.AutoFarmRep = p117
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_69, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_69, (ref) v_u_65
				if v_u_69.AutoFarmRep == true then
					if not v_u_65.Character:FindFirstChild("Weight") then
						local v118, v119, v120 = pairs(v_u_65.Backpack:GetChildren())
						while true do
							local v121
							v120, v121 = v118(v119, v120)
							if v120 == nil then
								break
							end
							if v_u_69.AutoFarmRep == false then
								return
							end
							if v121.Name ~= "Punch" and (v121.Name ~= "Stomp" and v121.Name ~= "Ground Slam") then
								v_u_65.Character.Humanoid:EquipTool(v121)
							end
						end
					end
					v_u_65.muscleEvent:FireServer("rep")
				end
			end)
			task.wait()
		end
	end)
	v76:Toggle("自动重生", "EspToggle", false, function(p122)
		-- upvalues: (ref) v_u_69
		v_u_69.AutoFarmRep = p122
	end)
	v76:Slider("自动重生停止数值", "FillTransparency", 0.5, 0.1, 1, true, function(p123)
		-- upvalues: (ref) v_u_69
		v_u_69.AutoRebLimite = p123
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_69, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_69, (ref) v_u_65
				if v_u_69.AutoFarmReb == true then
					local v124 = v_u_65.leaderstats
					if v124 and v124.Rebirths < v_u_69.AutoRebLimite then
						game:GetService("ReplicatedStorage").rEvents.rebirthRemote:InvokeServer()
					end
				end
			end)
			task.wait()
		end
	end)
	local v_u_125 = {
		["TinyRock"] = {
			["Pos1"] = CFrame.new(11.9587145, 3.40896416, 2097.48584, -0.877739251, 0.0715042949, -0.473773062, -7.04943659e-9, 0.988801718, 0.149235114, 0.479138583, 0.130989522, -0.867910087),
			["Pos2"] = CFrame.new(24.0511417, 2.72551298, 2097.21558, -0.79679805, -0.0835706145, 0.598438621, -1.97340755e-10, 0.990389585, 0.138305694, -0.604245663, 0.110201709, -0.789140522),
			["Pos3"] = CFrame.new(28.0633564, 2.72748637, 2110.28882, 0.354349315, -0.0880910009, 0.930954635, 9.00273811e-9, 0.995552957, 0.094203569, -0.935113132, -0.0333809629, 0.352773517),
			["Pos4"] = CFrame.new(28.0633564, 2.72748637, 2110.28882, 0.354349315, -0.0880910009, 0.930954635, 9.00273811e-9, 0.995552957, 0.094203569, -0.935113132, -0.0333809629, 0.352773517)
		},
		["PunchingRock"] = {
			["Pos1"] = CFrame.new(-164.348206, 3.66624141, 424.265381, 0.118749753, 4.42494077e-8, -0.992924213, -1.13367182e-9, 1, 4.44291572e-8, 0.992924213, -4.15030099e-9, 0.118749753),
			["Pos2"] = CFrame.new(-152.276352, 3.66624165, 437.19397, 0.997297406, -1.30800641e-8, -0.073470667, 1.13969501e-8, 1, -2.3327889e-8, 0.073470667, 2.24275016e-8, 0.997297406),
			["Pos3"] = CFrame.new(-137.984604, 3.66624022, 426.428223, 0.150321931, -6.10428614e-8, 0.98863709, 4.78385012e-8, 1, 5.44706289e-8, -0.98863709, 3.91067836e-8, 0.150321931),
			["Pos4"] = CFrame.new(-152.662231, 3.66624165, 408.825775, -0.989927053, -7.19749877e-8, -0.141578183, -8.15297199e-8, 1, 6.16867126e-8, 0.141578183, 7.26081737e-8, -0.989927053)
		},
		["LargeRock"] = {
			["Pos1"] = CFrame.new(162.06218, 3.80344152, -139.589478, 0.918153644, -6.52839871e-9, -0.396224588, -3.76148579e-9, 1, -2.51928345e-8, 0.396224588, 2.46212863e-8, 0.918153644),
			["Pos2"] = CFrame.new(180.602676, 3.66624165, -150.312561, 0.000738032046, -9.94880889e-9, 0.999999702, -1.74711428e-8, 1, 9.96170613e-9, -0.999999702, -1.74784898e-8, 0.000738032046),
			["Pos3"] = CFrame.new(166.48703, 3.66624117, -166.711411, -0.997990966, 3.64843444e-8, -0.0633566454, 3.60275649e-8, 1, 8.35211633e-9, 0.0633566454, 6.05275119e-9, -0.997990966),
			["Pos4"] = CFrame.new(153.807266, 3.68643212, -151.119202, 0.0663535669, -2.59886335e-9, -0.997796178, 3.46634401e-8, 1, -2.99480329e-10, 0.997796178, -3.45671758e-8, 0.0663535669)
		},
		["GoldenRock"] = {
			["Pos1"] = CFrame.new(320.70874, 3.66517043, -562.809998, 0.905616522, -1.73379551e-8, 0.424097538, 3.65331978e-8, 1, -3.71308744e-8, -0.424097538, 4.91199721e-8, 0.905616522),
			["Pos2"] = CFrame.new(340.684418, 3.66435051, -597.900024, -0.152164847, -5.69301406e-8, 0.9883551, -6.69093296e-8, 1, 4.72996931e-8, -0.9883551, -5.89328266e-8, -0.152164847),
			["Pos3"] = CFrame.new(307.829041, 3.66424417, -624.960449, -0.960634649, -6.35420179e-8, -0.277814925, -7.18211624e-8, 1, 1.96241228e-8, 0.277814925, 3.88046004e-8, -0.960634649),
			["Pos4"] = CFrame.new(281.689606, 3.665169, -594.886475, -0.045585826, -1.434928e-8, -0.998960435, -1.61171094e-8, 1, -1.36287364e-8, 0.998960435, 1.54790776e-8, -0.045585826)
		},
		["FrozenRock"] = {
			["Pos1"] = CFrame.new(-2588.71558, 3.66624856, -237.649063, 0.191434518, -1.03452152e-7, -0.981505394, 2.19609699e-8, 1, -1.01118204e-7, 0.981505394, -2.19729679e-9, 0.191434518),
			["Pos2"] = CFrame.new(-2551.44946, 3.666224, -200.600128, 0.958792806, -1.04019349e-9, -0.284106225, 3.17087423e-9, 1, 7.0396835e-9, 0.284106225, -7.65046249e-9, 0.958792806),
			["Pos3"] = CFrame.new(-2518.271, 3.66624784, -223.931396, 0.451512784, -3.25510752e-9, 0.892264664, -1.0512589e-8, 1, 8.96782737e-9, -0.892264664, -1.34290996e-8, 0.451512784),
			["Pos4"] = CFrame.new(-2545.35693, 3.66624808, -284.734009, -0.982746243, -2.82544965e-9, 0.184959054, -2.48351428e-9, 1, 2.0803812e-9, -0.184959054, 1.58513824e-9, -0.982746243)
		},
		["MysticRock"] = {
			["Pos1"] = CFrame.new(2183.52979, 3.66624951, 1207.97278, -0.996247828, 4.60593128e-8, -0.0865462422, 4.47580248e-8, 1, 1.69762107e-8, 0.0865462422, 1.3038874e-8, -0.996247828),
			["Pos2"] = CFrame.new(2146.94507, 3.6662488, 1254.52136, -0.123169534, 2.6081338e-8, -0.992385626, -2.81813595e-8, 1, 2.97791729e-8, 0.992385626, 3.16346629e-8, -0.123169534),
			["Pos3"] = CFrame.new(2177.76489, 3.66624832, 1291.81335, 0.970683217, 7.4807005e-8, -0.240362316, -6.72512073e-8, 1, 3.96376265e-8, 0.240362316, -2.23109247e-8, 0.970683217),
			["Pos4"] = CFrame.new(2222.85083, 4.03795242, 1249.63586, 0.00387934386, -1.59166138e-8, 0.99999249, 1.68666112e-8, 1, 1.58513007e-8, -0.99999249, 1.6804993e-8, 0.00387934386)
		},
		["InfernoRock"] = {
			["Pos1"] = CFrame.new(-7224.51611, 3.6662488, -1260.66345, -0.0420976467, -1.62026588e-8, 0.9991135, 3.37135369e-8, 1, 1.76375554e-8, -0.9991135, 3.44261508e-8, -0.0420976467),
			["Pos2"] = CFrame.new(-7255.84473, 3.66624856, -1299.20801, -0.974251449, -3.76607758e-8, 0.225464225, -4.04344469e-8, 1, -7.68434116e-9, -0.225464225, -1.66030016e-8, -0.974251449),
			["Pos3"] = CFrame.new(-7302.38818, 3.66624975, -1267.31519, -0.0985401496, 1.35011744e-8, -0.995133102, -4.96532202e-8, 1, 1.84839699e-8, 0.995133102, 5.1232977e-8, -0.0985401496),
			["Pos4"] = CFrame.new(-7263.32764, 3.66624975, -1218.10034, 0.949764311, -1.89185325e-8, 0.312965959, 1.76589108e-8, 1, 6.85930779e-9, -0.312965959, -9.88087834e-10, 0.949764311)
		},
		["RockofLegends"] = {
			["Pos1"] = CFrame.new(4180.76611, 987.869141, -4058.06543, 0.660455227, -1.36494382e-9, 0.7508654, 7.79167397e-10, 1, 1.132478e-9, -0.7508654, -1.62901193e-10, 0.660455227),
			["Pos2"] = CFrame.new(4168.75879, 987.829163, -4131.7168, -0.809934974, -3.05757084e-7, 0.586519659, -0.0000104842311, 1, -0.0000139565464, -0.586519659, -0.0000174531033, -0.809934974),
			["Pos3"] = CFrame.new(4109.43457, 980.426636, -4130.49316, -0.755784154, 7.19284188e-8, -0.6548208, 4.81956555e-8, 1, 5.42177467e-8, 0.6548208, 9.41739398e-9, -0.755784154),
			["Pos4"] = CFrame.new(4094.55591, 987.829163, -4070.00195, 0.409321517, -2.686245e-8, -0.912390232, 4.24020428e-8, 1, -1.04192068e-8, 0.912390232, -3.44224027e-8, 0.409321517)
		},
		["MuscleLegendMountain"] = {
			["Pos1"] = CFrame.new(-8982.78223, 5.53625107, -6127.00635, -0.982740283, 5.35928502e-9, -0.184990704, 5.28820987e-9, 1, 8.77603434e-10, 0.184990704, -1.15813366e-10, -0.982740283),
			["Pos2"] = CFrame.new(-9035.37793, 5.53625107, -6065.65186, -0.180476651, 5.48228378e-8, -0.983579278, -3.87735462e-8, 1, 6.28526422e-8, 0.983579278, 4.94802883e-8, -0.180476651)
		}
	}
	v77:Toggle("自动耐力(石头)", "EspToggle", false, function(p126)
		-- upvalues: (ref) v_u_69
		v_u_69.AutoFarmRocks = p126
	end)
	local v_u_127 = nil
	local v_u_128 = "Tiny Rock"
	v77:Dropdown("石头", "SelectFillColor", {
		"小号岩石",
		"拳击岩石",
		"大号岩石",
		"黄金岩石",
		"冰冻岩石",
		"神话岩石",
		"地狱岩石",
		"传说之岩",
		"肌肉之王山"
	}, function(p_u_129)
		-- upvalues: (ref) v_u_128, (ref) v_u_127, (ref) v_u_125
		pcall(function()
			-- upvalues: (ref) p_u_129, (ref) v_u_128, (ref) v_u_127, (ref) v_u_125
			if p_u_129 ~= "小号岩石" then
				if p_u_129 ~= "拳击岩石" then
					if p_u_129 ~= "大号岩石" then
						if p_u_129 ~= "黄金岩石" then
							if p_u_129 ~= "冰冻岩石" then
								if p_u_129 ~= "神话岩石" then
									if p_u_129 ~= "地狱岩石" then
										if p_u_129 ~= "传说之岩" then
											if p_u_129 == "肌肉之王山" then
												v_u_128 = "Muscle King Mountain"
												v_u_127 = v_u_125.MuscleLegendMountain.Pos1
											end
										else
											v_u_128 = "Rock of Legends"
											v_u_127 = v_u_125.RockofLegends.Pos1
										end
									else
										v_u_128 = "Inferno Rock"
										v_u_127 = v_u_125.InfernoRock.Pos1
									end
								else
									v_u_128 = "Mystic Rock"
									v_u_127 = v_u_125.MysticRock.Pos1
								end
							else
								v_u_128 = "Frozen Rock"
								v_u_127 = v_u_125.FrozenRock.Pos1
							end
						else
							v_u_128 = "Golden Rock"
							v_u_127 = v_u_125.GoldenRock.Pos1
						end
					else
						v_u_128 = "Large Rock"
						v_u_127 = v_u_125.LargeRock.Pos1
					end
				else
					v_u_128 = "Punching Rock"
					v_u_127 = v_u_125.PunchingRock.Pos1
				end
			else
				v_u_128 = "Tiny Rock"
				v_u_127 = v_u_125.TinyRock.Pos1
			end
		end)
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_69, (ref) v_u_65, (ref) v_u_128, (ref) v_u_64, (ref) v_u_127, (ref) v_u_125
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_69, (ref) v_u_65, (ref) v_u_128, (ref) v_u_64, (ref) v_u_127, (ref) v_u_125
				if v_u_69.AutoFarmRocks == true then
					if v_u_65.Backpack:FindFirstChild("Punch") then
						v_u_65.Character.Humanoid:EquipTool(v_u_65.Backpack:FindFirstChild("Punch"))
					end
					if v_u_128 ~= "Tiny Rock" then
						if v_u_128 ~= "Punching Rock" then
							if v_u_128 ~= "Large Rock" then
								if v_u_128 ~= "Golden Rock" then
									if v_u_128 ~= "Frozen Rock" then
										if v_u_128 ~= "Mystic Rock" then
											if v_u_128 ~= "Inferno Rock" then
												if v_u_128 ~= "Rock Of Legends" then
													if v_u_128 == "Muscle King Mountain" then
														pcall(function()
															-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_127, (ref) v_u_125
															local v130 = v_u_64
															local v131, v132, v133 = pairs(v130:GetChildren())
															while true do
																local v134
																v133, v134 = v131(v132, v133)
																if v133 == nil then
																	break
																end
																if v134 ~= v_u_65 and (v134.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - v134.Character.HumanoidRootPart.Position).Magnitude < 10) then
																	local v135 = math.random(1, 2)
																	if v135 == 1 then
																		v_u_127 = v_u_125.MuscleLegendMountain.Pos1
																	elseif v135 == 2 then
																		v_u_127 = v_u_125.MuscleLegendMountain.Pos2
																	end
																end
															end
														end)
														v_u_65.Character.HumanoidRootPart.CFrame = v_u_127
														v_u_65.Character.Punch:Activate()
													end
												else
													pcall(function()
														-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_127, (ref) v_u_125
														local v136 = v_u_64
														local v137, v138, v139 = pairs(v136:GetChildren())
														while true do
															local v140
															v139, v140 = v137(v138, v139)
															if v139 == nil then
																break
															end
															if v140 ~= v_u_65 and (v140.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - v140.Character.HumanoidRootPart.Position).Magnitude < 10) then
																local v141 = math.random(1, 4)
																if v141 == 1 then
																	v_u_127 = v_u_125.RockofLegends.Pos1
																elseif v141 == 2 then
																	v_u_127 = v_u_125.RockofLegends.Pos2
																elseif v141 == 3 then
																	v_u_127 = v_u_125.RockofLegends.Pos3
																elseif v141 == 4 then
																	v_u_127 = v_u_125.RockofLegends.Pos4
																end
															end
														end
													end)
													v_u_65.Character.HumanoidRootPart.CFrame = v_u_127
													v_u_65.Character.Punch:Activate()
												end
											else
												pcall(function()
													-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_127, (ref) v_u_125
													local v142 = v_u_64
													local v143, v144, v145 = pairs(v142:GetChildren())
													while true do
														local v146
														v145, v146 = v143(v144, v145)
														if v145 == nil then
															break
														end
														if v146 ~= v_u_65 and (v146.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - v146.Character.HumanoidRootPart.Position).Magnitude < 10) then
															local v147 = math.random(1, 4)
															if v147 == 1 then
																v_u_127 = v_u_125.InfernoRock.Pos1
															elseif v147 == 2 then
																v_u_127 = v_u_125.InfernoRock.Pos2
															elseif v147 == 3 then
																v_u_127 = v_u_125.InfernoRock.Pos3
															elseif v147 == 4 then
																v_u_127 = v_u_125.InfernoRock.Pos4
															end
														end
													end
												end)
												v_u_65.Character.HumanoidRootPart.CFrame = v_u_127
												v_u_65.Character.Punch:Activate()
											end
										else
											pcall(function()
												-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_127, (ref) v_u_125
												local v148 = v_u_64
												local v149, v150, v151 = pairs(v148:GetChildren())
												while true do
													local v152
													v151, v152 = v149(v150, v151)
													if v151 == nil then
														break
													end
													if v152 ~= v_u_65 and (v152.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - v152.Character.HumanoidRootPart.Position).Magnitude < 10) then
														local v153 = math.random(1, 4)
														if v153 == 1 then
															v_u_127 = v_u_125.MysticRock.Pos1
														elseif v153 == 2 then
															v_u_127 = v_u_125.MysticRock.Pos2
														elseif v153 == 3 then
															v_u_127 = v_u_125.MysticRock.Pos3
														elseif v153 == 4 then
															v_u_127 = v_u_125.MysticRock.Pos4
														end
													end
												end
											end)
											v_u_65.Character.HumanoidRootPart.CFrame = v_u_127
											v_u_65.Character.Punch:Activate()
										end
									else
										pcall(function()
											-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_127, (ref) v_u_125
											local v154 = v_u_64
											local v155, v156, v157 = pairs(v154:GetChildren())
											while true do
												local v158
												v157, v158 = v155(v156, v157)
												if v157 == nil then
													break
												end
												if v158 ~= v_u_65 and (v158.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - v158.Character.HumanoidRootPart.Position).Magnitude < 10) then
													local v159 = math.random(1, 4)
													if v159 == 1 then
														v_u_127 = v_u_125.FrozenRock.Pos1
													elseif v159 == 2 then
														v_u_127 = v_u_125.FrozenRock.Pos2
													elseif v159 == 3 then
														v_u_127 = v_u_125.FrozenRock.Pos3
													elseif v159 == 4 then
														v_u_127 = v_u_125.FrozenRock.Pos4
													end
												end
											end
										end)
										v_u_65.Character.HumanoidRootPart.CFrame = v_u_127
										v_u_65.Character.Punch:Activate()
									end
								else
									pcall(function()
										-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_127, (ref) v_u_125
										local v160 = v_u_64
										local v161, v162, v163 = pairs(v160:GetChildren())
										while true do
											local v164
											v163, v164 = v161(v162, v163)
											if v163 == nil then
												break
											end
											if v164 ~= v_u_65 and (v164.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - v164.Character.HumanoidRootPart.Position).Magnitude < 10) then
												local v165 = math.random(1, 4)
												if v165 == 1 then
													v_u_127 = v_u_125.GoldenRock.Pos1
												elseif v165 == 2 then
													v_u_127 = v_u_125.GoldenRock.Pos2
												elseif v165 == 3 then
													v_u_127 = v_u_125.GoldenRock.Pos3
												elseif v165 == 4 then
													v_u_127 = v_u_125.GoldenRock.Pos4
												end
											end
										end
									end)
									v_u_65.Character.HumanoidRootPart.CFrame = v_u_127
									v_u_65.Character.Punch:Activate()
								end
							else
								pcall(function()
									-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_127, (ref) v_u_125
									local v166 = v_u_64
									local v167, v168, v169 = pairs(v166:GetChildren())
									while true do
										local v170
										v169, v170 = v167(v168, v169)
										if v169 == nil then
											break
										end
										if v170 ~= v_u_65 and (v170.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - v170.Character.HumanoidRootPart.Position).Magnitude < 10) then
											local v171 = math.random(1, 4)
											if v171 == 1 then
												v_u_127 = v_u_125.LargeRock.Pos1
											elseif v171 == 2 then
												v_u_127 = v_u_125.LargeRock.Pos2
											elseif v171 == 3 then
												v_u_127 = v_u_125.LargeRock.Pos3
											elseif v171 == 4 then
												v_u_127 = v_u_125.LargeRock.Pos4
											end
										end
									end
								end)
								v_u_65.Character.HumanoidRootPart.CFrame = v_u_127
								v_u_65.Character.Punch:Activate()
							end
						else
							pcall(function()
								-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_127, (ref) v_u_125
								local v172 = v_u_64
								local v173, v174, v175 = pairs(v172:GetChildren())
								while true do
									local v176
									v175, v176 = v173(v174, v175)
									if v175 == nil then
										break
									end
									if v176 ~= v_u_65 and (v176.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - v176.Character.HumanoidRootPart.Position).Magnitude < 10) then
										local v177 = math.random(1, 4)
										if v177 == 1 then
											v_u_127 = v_u_125.PunchingRock.Pos1
										elseif v177 == 2 then
											v_u_127 = v_u_125.PunchingRock.Pos2
										elseif v177 == 3 then
											v_u_127 = v_u_125.PunchingRock.Pos3
										elseif v177 == 4 then
											v_u_127 = v_u_125.PunchingRock.Pos4
										end
									end
								end
							end)
							v_u_65.Character.HumanoidRootPart.CFrame = v_u_127
							v_u_65.Character.Punch:Activate()
						end
					else
						pcall(function()
							-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_127, (ref) v_u_125
							local v178 = v_u_64
							local v179, v180, v181 = pairs(v178:GetChildren())
							while true do
								local v182
								v181, v182 = v179(v180, v181)
								if v181 == nil then
									break
								end
								if v182 ~= v_u_65 and (v182.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - v182.Character.HumanoidRootPart.Position).Magnitude < 10) then
									local v183 = math.random(1, 4)
									if v183 == 1 then
										v_u_127 = v_u_125.TinyRock.Pos1
									elseif v183 == 2 then
										v_u_127 = v_u_125.TinyRock.Pos2
									elseif v183 == 3 then
										v_u_127 = v_u_125.TinyRock.Pos3
									elseif v183 == 4 then
										v_u_127 = v_u_125.TinyRock.Pos4
									end
								end
							end
						end)
						v_u_65.Character.HumanoidRootPart.CFrame = v_u_127
						v_u_65.Character.Punch:Activate()
					end
				end
			end)
			task.wait()
		end
	end)
	v78:Toggle("自动杀人", "EspToggle", false, function(p184)
		-- upvalues: (ref) v_u_69
		v_u_69.AutoFarmKills = p184
	end)
	v78:Slider("距离", "FillTransparency", 6, 0.1, 100, true, function(p185)
		-- upvalues: (ref) v_u_69
		v_u_69.AutoFarmKillsDis = p185
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_69, (ref) v_u_64, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_69, (ref) v_u_64, (ref) v_u_65
				if v_u_69.AutoFarmKills == true then
					local v186 = v_u_64
					local v187, v188, v189 = pairs(v186:GetChildren())
					while true do
						local v190
						v189, v190 = v187(v188, v189)
						if v189 == nil then
							break
						end
						if v_u_69.AutoFarmKills == false then
							return
						end
						if v_u_65.Backpack:FindFirstChild("Punch") then
							v_u_65.Character.Humanoid:EquipTool(v_u_65.Backpack:FindFirstChild("Punch"))
						end
						if v190 ~= v_u_65 then
							local v191, v192, v193 = pairs(game:GetService("Players"):GetChildren())
							while true do
								local v194
								v193, v194 = v191(v192, v193)
								if v193 == nil then
									break
								end
								firetouchinterest(v194.Character.HumanoidRootPart, game:GetService("Players").LocalPlayer.Character.RightHand, 1)
								game:GetService("Players").LocalPlayer.muscleEvent:FireServer(unpack({ "punch", "rightHand" }))
							end
						end
					end
				end
			end)
			task.wait()
		end
	end)
	v80:Toggle("自动传送到安全板", "EspToggle", false, function(p195)
		-- upvalues: (ref) v_u_69
		v_u_69.Safeplate = p195
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_69, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_69, (ref) v_u_65
				if v_u_69.Safeplate == true then
					if not game.Workspace:FindFirstChild("ALSafeBoard") then
						local v196 = Instance.new("Part")
						v196.Parent = game.Workspace
						v196.Name = "ALSafeBoard"
						v196.Size = Vector3.new(2048, 1, 2048)
						v196.CFrame = CFrame.new(0, 1000, 0)
						v196.Anchored = true
					end
					v_u_65.Character.HumanoidRootPart.CFrame = CFrame.new(0, 1010, 0)
				end
			end)
			task.wait()
		end
	end)
	v81:Toggle("自动传送到安全板", "EspToggle", false, function(p197)
		-- upvalues: (ref) v_u_69
		v_u_69.AntiVoid = p197
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_69, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_69, (ref) v_u_65
				if v_u_69.AntiVoid == true and v_u_65.Character.HumanoidRootPart.CFrame.Y < -10 then
					if game.Workspace:FindFirstChild("ALAntiVoid") then
						game.Workspace:FindFirstChild("ALAntiVoid"):Destroy()
					end
					local v198 = Instance.new("Part")
					v198.Parent = game.Workspace
					v198.Name = "ALAntiVoid"
					v198.Size = Vector3.new(2048, 1, 2048)
					v198.CFrame = CFrame.new(v_u_65.Character.HumanoidRootPart.CFrame.X, game.Workspace.seaPart.CFrame.Y, v_u_65.Character.HumanoidRootPart.CFrame.Z)
					v198.Anchored = true
					v_u_65.Character.HumanoidRootPart.CFrame = v_u_65.Character.HumanoidRootPart.CFrame * CFrame.new(0, 10, 0)
				end
			end)
			task.wait()
		end
	end)
	v83:Toggle("透视开关", "EspToggle", false, function(p199)
		-- upvalues: (ref) v_u_69
		v_u_69.EspToggle = p199
	end)
	v83:Toggle("上色开关", "HighlightToggle", false, function(p200)
		-- upvalues: (ref) v_u_69
		v_u_69.HighlightToggle = p200
	end)
	v84:Dropdown("透视颜色", "SelectFillColor", {
		"红",
		"绿",
		"蓝",
		"粉",
		"青"
	}, function(p201)
		-- upvalues: (ref) v_u_69, (ref) v_u_68
		if p201 == "红" then
			v_u_69.SelectFillColor = v_u_68.Red
		elseif p201 == "绿" then
			v_u_69.SelectFillColor = v_u_68.Green
		elseif p201 == "蓝" then
			v_u_69.SelectFillColor = v_u_68.Blue
		elseif p201 == "粉" then
			v_u_69.SelectFillColor = v_u_68.Pink
		elseif p201 == "青" then
			v_u_69.SelectFillColor = v_u_68.Cyan
		end
	end)
	v84:Slider("透视大小", "FillTransparency", 0.5, 0.1, 1, true, function(p202)
		-- upvalues: (ref) v_u_69
		v_u_69.EspScale = p202
	end)
	v84:Slider("上色透明度", "FillTransparency", 0.5, 0, 1, true, function(p203)
		-- upvalues: (ref) v_u_69
		v_u_69.HighlightTransparency = p203
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_69
		while _G.ScriptIsRunning == true do
			local v204 = v_u_64
			local v205, v206, v207 = pairs(v204:GetChildren())
			while true do
				local v208
				v207, v208 = v205(v206, v207)
				if v207 == nil then
					break
				end
				if v208.Name ~= v_u_65.Name then
					UpdateEsp(v208.Name, v_u_69.SelectFillColor)
				end
			end
			task.wait()
		end
	end)
	local v209 = v_u_64
	local v210, v211, v212 = pairs(v_u_64.GetChildren(v209))
	local v_u_213 = v_u_67
	local v_u_214 = v_u_64
	local v_u_215 = v_u_69
	local v_u_216 = v_u_65
	local v_u_217 = {}
	while true do
		local v218, v219 = v210(v211, v212)
		if v218 == nil then
			break
		end
		v212 = v218
		if v219.Name ~= v_u_216.Name then
			table.insert(v_u_217, v219.Name)
		end
	end
	local v_u_221 = v85:Dropdown("玩家列表", "Players", v_u_217, function(p220)
		-- upvalues: (ref) v_u_215
		v_u_215.SelectPlr = p220
	end)
	v_u_214.PlayerAdded:Connect(function(p222)
		-- upvalues: (ref) v_u_217, (ref) v_u_221
		table.insert(v_u_217, p222.Name)
		v_u_221.AddOption(p222.Name)
	end)
	v_u_214.PlayerRemoving:Connect(function(p223)
		-- upvalues: (ref) v_u_217, (ref) v_u_221
		table.remove(v_u_217, table.find(v_u_217, p223.Name))
		v_u_221.RemoveOption(p223.Name)
	end)
	v85:Button("传送到选中的玩家", function()
		-- upvalues: (ref) v_u_216, (ref) v_u_214, (ref) v_u_215
		pcall(function()
			-- upvalues: (ref) v_u_216, (ref) v_u_214, (ref) v_u_215
			local v224 = v_u_214
			v_u_216.Character.HumanoidRootPart.CFrame = v224:FindFirstChild(v_u_215.SelectPlr).Character.HumanoidRootPart.CFrame
		end)
	end)
	v85:Toggle("自动传送到选择的玩家身后", "Noclip", false, function(p225)
		-- upvalues: (ref) v_u_215
		v_u_215.AutoTeleportToSelectPlr = p225
	end)
	v85:Slider("自动传送距离设置", "Slider", 4.5, 1, 20, true, function(p226)
		-- upvalues: (ref) v_u_215
		v_u_215.AutoTeleportToSelectPlrDistance = p226
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_215, (ref) v_u_216, (ref) v_u_214
		while _G.ScriptIsRunning == true do
			if v_u_215.AutoTeleportToSelectPlr == true then
				pcall(function()
					-- upvalues: (ref) v_u_216, (ref) v_u_214, (ref) v_u_215
					local v227 = v_u_214
					local v228 = v_u_214
					v_u_216.Character.HumanoidRootPart.CFrame = v227:FindFirstChild(v_u_215.SelectPlr).Character.HumanoidRootPart.CFrame - v228:FindFirstChild(v_u_215.SelectPlr).Character.HumanoidRootPart.CFrame.LookVector * v_u_215.AutoTeleportToSelectPlrDistance
				end)
			end
			task.wait()
		end
	end)
	local v_u_229 = {
		["WalkSpeed"] = 16,
		["WalkSpeedToggle"] = false,
		["JumpPower"] = 50,
		["JumpPowerToggle"] = false,
		["Gravity"] = 196.2,
		["GravityToggle"] = false,
		["Fly"] = false,
		["FlySpeed"] = 30
	}
	v87:Label("移动速度")
	function WalkSpeed()
		-- upvalues: (ref) v_u_229, (ref) v_u_216
		while v_u_229.WalkSpeedToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_216, (ref) v_u_229
				v_u_216.Character.Humanoid.WalkSpeed = v_u_229.WalkSpeed
			end)
			task.wait()
		end
	end
	v87:Slider("数值", "WalkSpeed", 16, 1, 150, true, function(p230)
		-- upvalues: (ref) v_u_229
		v_u_229.WalkSpeed = p230
	end)
	v87:Toggle("开关", "WalkSpeedToggle", false, function(p231)
		-- upvalues: (ref) v_u_229
		v_u_229.WalkSpeedToggle = p231
		WalkSpeed()
	end)
	v87:Label("跳跃高度")
	function JumpPower()
		-- upvalues: (ref) v_u_229, (ref) v_u_216
		while v_u_229.JumpPowerToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_216, (ref) v_u_229
				v_u_216.Character.Humanoid.JumpPower = v_u_229.JumpPower
			end)
			task.wait()
		end
	end
	v87:Slider("数值", "JumpPower", 50, 1, 150, true, function(p232)
		-- upvalues: (ref) v_u_229
		v_u_229.JumpPower = p232
	end)
	v87:Toggle("开关", "JumpPowerToggle", false, function(p233)
		-- upvalues: (ref) v_u_229
		v_u_229.JumpPowerToggle = p233
		JumpPower()
	end)
	v87:Label("重力")
	function Gravity()
		-- upvalues: (ref) v_u_229, (ref) v_u_66
		while v_u_229.GravityToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_66, (ref) v_u_229
				v_u_66.Gravity = v_u_229.Gravity
			end)
			task.wait()
		end
	end
	v87:Slider("数值", "Gravity", 196.2, 1, 1000, true, function(p234)
		-- upvalues: (ref) v_u_229
		v_u_229.Gravity = p234
	end)
	v87:Toggle("开关", "GravityToggle", false, function(p235)
		-- upvalues: (ref) v_u_229
		v_u_229.GravityToggle = p235
		Gravity()
	end)
	function NoclipFunc()
		-- upvalues: (ref) v_u_215, (ref) v_u_216
		while v_u_215.Noclip == true do
			pcall(function()
				-- upvalues: (ref) v_u_216
				local v236, v237, v238 = pairs(v_u_216.Character:GetChildren())
				while true do
					local v239
					v238, v239 = v236(v237, v238)
					if v238 == nil then
						break
					end
					if v239:IsA("BasePart") then
						v239.CanCollide = false
					end
				end
			end)
			task.wait()
		end
	end
	v87:Toggle("穿墙", "Noclip", false, function(p240)
		-- upvalues: (ref) v_u_215, (ref) v_u_216
		v_u_215.Noclip = p240
		if p240 == false then
			pcall(function()
				-- upvalues: (ref) v_u_216
				local v241, v242, v243 = pairs(v_u_216.Character:GetChildren())
				while true do
					local v244
					v243, v244 = v241(v242, v243)
					if v243 == nil then
						break
					end
					if v244:IsA("BasePart") and (v244.Name == "Head" or (v244.Name == "Torso" or (v244.Name == "UpperTorso" or v244.Name == "LowerTorso"))) then
						v244.CanCollide = true
					end
				end
			end)
		end
		NoclipFunc()
	end)
	v87:Toggle("无限跳", "InfJump", false, function(p245)
		-- upvalues: (ref) v_u_215
		v_u_215.InfJump = p245
	end)
	game:GetService("UserInputService").JumpRequest:Connect(function()
		-- upvalues: (ref) v_u_215, (ref) v_u_216
		if v_u_215.InfJump == true then
			v_u_216.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
		end
	end)
	local function v_u_250()
		-- upvalues: (ref) v_u_229, (ref) v_u_216, (ref) v_u_66
		while v_u_229.Fly == true do
			pcall(function()
				-- upvalues: (ref) v_u_216, (ref) v_u_66, (ref) v_u_229
				if not v_u_216.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
					local v246 = Instance.new("BodyVelocity")
					v246.Name = "FlyVelocity"
					v246.Parent = v_u_216.Character.HumanoidRootPart
					v246.MaxForce = Vector3.new(0, 0, 0)
					v246.Velocity = Vector3.new(0, 0, 0)
				end
				if not v_u_216.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
					local v247 = Instance.new("BodyGyro")
					v247.Name = "FlyGyro"
					v247.Parent = v_u_216.Character.HumanoidRootPart
					v247.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
					v247.P = 1000
					v247.D = 50
				end
				if v_u_216.Character and (v_u_216.Character:FindFirstChildOfClass("Humanoid") and v_u_216.Character.Humanoid.RootPart and (v_u_216.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") and v_u_216.Character.HumanoidRootPart:FindFirstChild("FlyGyro"))) then
					local v248 = v_u_66.CurrentCamera
					v_u_216.Character.HumanoidRootPart.FlyGyro.CFrame = v_u_66.CurrentCamera.CFrame
					local v249 = require(v_u_216.PlayerScripts:WaitForChild("PlayerModule"):WaitForChild("ControlModule")):GetMoveVector()
					v_u_216.Character.HumanoidRootPart.FlyVelocity.Velocity = Vector3.new()
					if v249.X > 0 then
						v_u_216.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_216.Character.HumanoidRootPart.FlyVelocity.Velocity + v248.CFrame.RightVector * (v249.X * v_u_229.FlySpeed)
					end
					if v249.X < 0 then
						v_u_216.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_216.Character.HumanoidRootPart.FlyVelocity.Velocity + v248.CFrame.RightVector * (v249.X * v_u_229.FlySpeed)
					end
					if v249.Z > 0 then
						v_u_216.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_216.Character.HumanoidRootPart.FlyVelocity.Velocity - v248.CFrame.LookVector * (v249.Z * v_u_229.FlySpeed)
					end
					if v249.Z < 0 then
						v_u_216.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_216.Character.HumanoidRootPart.FlyVelocity.Velocity - v248.CFrame.LookVector * (v249.Z * v_u_229.FlySpeed)
					end
					v_u_216.Character.Humanoid.PlatformStand = true
					v_u_216.Character.HumanoidRootPart.FlyVelocity.MaxForce = Vector3.new(9000000000, 9000000000, 9000000000)
					v_u_216.Character.HumanoidRootPart.FlyGyro.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
				end
			end)
			task.wait()
		end
	end
	v87:Toggle("飞行", "Fly", false, function(p251)
		-- upvalues: (ref) v_u_229, (ref) v_u_216, (ref) v_u_250
		v_u_229.Fly = p251
		if p251 == false then
			v_u_216.Character.Humanoid.PlatformStand = false
			if v_u_216.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
				v_u_216.Character.HumanoidRootPart:FindFirstChild("FlyVelocity"):Destroy()
			end
			if v_u_216.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
				v_u_216.Character.HumanoidRootPart:FindFirstChild("FlyGyro"):Destroy()
			end
		end
		v_u_250()
	end)
	v87:Slider("飞行速度", "Slider", 30, 1, 150, true, function(p252)
		-- upvalues: (ref) v_u_229
		v_u_229.FlySpeed = p252
	end)
	local v_u_253 = {
		["DefFOV"] = v_u_66.CurrentCamera.FieldOfView,
		["DefCameraMaxZoomDistance"] = v_u_216.CameraMaxZoomDistance,
		["DefCameraMinZoomDistance"] = v_u_216.CameraMinZoomDistance,
		["FieldOfView"] = 70,
		["FieldOfViewToggle"] = false,
		["CameraMaxZoomDistance"] = 128,
		["CameraMaxZoomDistanceToggle"] = false,
		["CameraMinZoomDistance"] = 0.5,
		["CameraMinZoomDistanceToggle"] = false,
		["FullBright"] = false,
		["DefAmbient"] = v_u_213.Ambient
	}
	function FieldOfView()
		-- upvalues: (ref) v_u_253, (ref) v_u_66, (ref) v_u_88
		while v_u_253.FieldOfViewToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_66, (ref) v_u_88
				v_u_66.CurrentCamera.FieldOfView = v_u_88.FieldOfView
			end)
			task.wait()
		end
	end
	function CameraMaxZoomDistance()
		-- upvalues: (ref) v_u_253, (ref) v_u_216, (ref) v_u_88
		while v_u_253.CameraMaxZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_216, (ref) v_u_88
				v_u_216.CameraMaxZoomDistance = v_u_88.CameraMaxZoomDistance
			end)
			task.wait()
		end
	end
	function CameraMinZoomDistance()
		-- upvalues: (ref) v_u_253, (ref) v_u_216
		while v_u_253.CameraMinZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_216, (ref) v_u_253
				v_u_216.CameraMinZoomDistance = v_u_253.CameraMinZoomDistance
			end)
			task.wait()
		end
	end
	v_u_88:Slider("Fov", "Slider", 70, 1, 120, true, function(p254)
		-- upvalues: (ref) v_u_88, (ref) v_u_66, (ref) v_u_253
		v_u_88.FieldOfView = p254
		if p254 == false then
			v_u_66.CurrentCamera.FieldOfView = v_u_253.DefFOV
		end
		FieldOfView()
	end)
	v_u_88:Slider("最大相机聚焦距离", "Slider", 128, 1, 1200, true, function(p255)
		-- upvalues: (ref) v_u_88, (ref) v_u_216
		v_u_88.CameraMaxZoomDistance = p255
		if p255 == false then
			v_u_216.CameraMaxZoomDistance = v_u_88.DefCameraMaxZoomDistance
		end
		CameraMaxZoomDistance()
	end)
	v_u_88:Slider("最小相机聚焦距离", "Slider", 0.5, 1, 50, true, function(p256)
		-- upvalues: (ref) v_u_88, (ref) v_u_216, (ref) v_u_253
		v_u_88.CameraMinZoomDistance = p256
		if p256 == false then
			v_u_216.CameraMinZoomDistance = v_u_253.DefCameraMinZoomDistance
		end
		CameraMinZoomDistance()
	end)
	function FullBright()
		-- upvalues: (ref) v_u_229, (ref) v_u_213
		while v_u_229.FullBright == true do
			pcall(function()
				-- upvalues: (ref) v_u_213
				v_u_213.Ambient = Color3.new(1, 1, 1)
			end)
			task.wait()
		end
	end
	v_u_88:Toggle("全局高亮", "FullBright", false, function(p257)
		-- upvalues: (ref) v_u_253, (ref) v_u_213
		v_u_253.FullBright = p257
		if p257 == false then
			v_u_213.Ambient = v_u_253.DefAmbient
		end
		FullBright()
	end)
	local v_u_258 = {
		["Bk"] = nil,
		["Dn"] = nil,
		["Ft"] = nil,
		["Lf"] = nil,
		["Rt"] = nil,
		["Up"] = nil
	}
	v89:Dropdown("天空盒", "Skybox", { "cs_办公室", "Always.win", "Advanced Logic" }, function(p259)
		if p259 == "cs_办公室" then
			SpawnSkybox({
				["Name"] = "cs_office",
				["Bk"] = "rbxassetid://658623433",
				["Dn"] = "rbxassetid://316342560",
				["Ft"] = "rbxassetid://658625205",
				["Lf"] = "rbxassetid://658627155",
				["Rt"] = "rbxassetid://658628504",
				["Up"] = "rbxassetid://658632701"
			})
		elseif p259 == "Always.win" then
			SpawnSkybox({
				["Name"] = "Always.win",
				["Bk"] = "rbxassetid://17411013742",
				["Dn"] = "rbxassetid://17411013742",
				["Ft"] = "rbxassetid://17411013742",
				["Lf"] = "rbxassetid://17411013742",
				["Rt"] = "rbxassetid://17411013742",
				["Up"] = "rbxassetid://17411013742"
			})
		elseif p259 == "Advanced Logic" then
			SpawnSkybox({
				["Name"] = "Advanced Logic",
				["Bk"] = "rbxassetid://17803761395",
				["Dn"] = "rbxassetid://17803761395",
				["Ft"] = "rbxassetid://17803761395",
				["Lf"] = "rbxassetid://17803761395",
				["Rt"] = "rbxassetid://17803761395",
				["Up"] = "rbxassetid://17803761395",
				["SunAsset"] = "rbxassetid://17768924741",
				["SunAngularSize"] = 50
			})
		end
	end)
	v89:Textbox("自定义天空盒Bk", "Textbox", "请输入SkyboxBk贴图ID", function(p_u_260)
		-- upvalues: (ref) v_u_258
		pcall(function()
			-- upvalues: (ref) p_u_260, (ref) v_u_258
			if p_u_260:find("rbx") then
				v_u_258.Bk = p_u_260
			else
				v_u_258.Bk = "rbxassetid://" .. p_u_260
			end
		end)
	end)
	v89:Textbox("自定义天空盒Dn", "Textbox", "请输入SkyboxDn贴图ID", function(p_u_261)
		-- upvalues: (ref) v_u_258
		pcall(function()
			-- upvalues: (ref) p_u_261, (ref) v_u_258
			if p_u_261:find("rbx") then
				v_u_258.Dn = p_u_261
			else
				v_u_258.Dn = "rbxassetid://" .. p_u_261
			end
		end)
	end)
	v89:Textbox("自定义天空盒Ft", "Textbox", "请输入SkyboxFt贴图ID", function(p_u_262)
		-- upvalues: (ref) v_u_258
		pcall(function()
			-- upvalues: (ref) p_u_262, (ref) v_u_258
			if p_u_262:find("rbx") then
				v_u_258.Ft = p_u_262
			else
				v_u_258.Ft = "rbxassetid://" .. p_u_262
			end
		end)
	end)
	v89:Textbox("自定义天空盒Lf", "Textbox", "请输入SkyboxLf贴图ID", function(p_u_263)
		-- upvalues: (ref) v_u_258
		pcall(function()
			-- upvalues: (ref) p_u_263, (ref) v_u_258
			if p_u_263:find("rbx") then
				v_u_258.Lf = p_u_263
			else
				v_u_258.Lf = "rbxassetid://" .. p_u_263
			end
		end)
	end)
	v89:Textbox("自定义天空盒Rt", "Textbox", "请输入SkyboxRt贴图ID", function(p_u_264)
		-- upvalues: (ref) v_u_258
		pcall(function()
			-- upvalues: (ref) p_u_264, (ref) v_u_258
			if p_u_264:find("rbx") then
				v_u_258.Rt = p_u_264
			else
				v_u_258.Rt = "rbxassetid://" .. p_u_264
			end
		end)
	end)
	v89:Textbox("自定义天空盒Up", "Textbox", "请输入SkyboxUp贴图ID", function(p_u_265)
		-- upvalues: (ref) v_u_258
		pcall(function()
			-- upvalues: (ref) p_u_265, (ref) v_u_258
			if p_u_265:find("rbx") then
				v_u_258.Up = p_u_265
			else
				v_u_258.Up = "rbxassetid://" .. p_u_265
			end
		end)
	end)
	v89:Button("修改自定义天空盒", function()
		-- upvalues: (ref) v_u_258
		pcall(function()
			-- upvalues: (ref) v_u_258
			SpawnSkybox({
				["Name"] = "我爱手冲",
				["Bk"] = v_u_258.Bk,
				["Dn"] = v_u_258.Dn,
				["Ft"] = v_u_258.Ft,
				["Lf"] = v_u_258.Lf,
				["Rt"] = v_u_258.Rt,
				["Up"] = v_u_258.Up
			})
		end)
	end)
	v91:Label("团队")
	v91:Label("Advanced Logic")
	v91:Label("群号: 684407929")
	v92:Label("当前版本 " .. v71)
else
	game:GetService("Players").LocalPlayer:Kick("您不是白名单用户,请加入684407929(Adavanced Logic官方群)购买")
	setclipboard(game:GetService("RbxAnalyticsService"):GetClientId())
end
