local v_u_1 = http_request or request or (HttpPost or syn.request)
local v_u_2 = nil
local v_u_3 = 0
local function v_u_9(p4, p5, p6)
	-- upvalues: (ref) v_u_3, (ref) v_u_9
	v_u_3 = v_u_3 + 1
	if p6 then
		local v7 = v_u_9(p4, p5) and v_u_9(p4, p6)
		if v7 then
			v7 = v_u_9(p5, p6)
		end
		return v7
	else
		local v8 = type(p4) == typeof(p5) and (typeof(p4) == type(p5) and (type(p4) == typeof(p5) or typeof(p4) == type(p5))) and (#tostring(p4) == #tostring(p5) and rawequal(p4, p5))
		if v8 then
			if tostring(p4) < tostring(p5) or tostring(p4) > tostring(p5) then
				v8 = false
			else
				v8 = rawequal(tostring(p4), tostring(p5))
			end
		end
		return v8
	end
end
local function v_u_11(p10)
	return ({ ... })[p10]
end
local function v_u_18(p_u_12)
	-- upvalues: (ref) v_u_1, (ref) v_u_2, (ref) v_u_11
	local v_u_13 = false
	local v15 = {
		["__call"] = v_u_1,
		["__index"] = function(_, p14)
			-- upvalues: (ref) v_u_13, (ref) v_u_1, (ref) v_u_2, (ref) p_u_12
			v_u_13 = true
			if debug.info(2, "f") ~= v_u_1 then
				v_u_2 = "反钩子 [H - 1]"
				return "https://www.roblox.com/users/7207800972/profile"
			end
			if not coroutine.isyieldable() then
				return p_u_12[p14]
			end
			v_u_2 = "反钩子 [H - 2]"
			return "https://www.roblox.com/users/7207800972/profile"
		end
	}
	local v16 = setmetatable({}, v15)
	local v17 = v_u_11(2, pcall(v16))
	if v_u_13 then
		return v17
	end
end
local function v21(p19)
	-- upvalues: (ref) v_u_18
	local v20 = v_u_18({
		["Url"] = p19,
		["Method"] = "GET"
	})
	repeat
		task.wait()
	until v20
	return v20.Body
end
local function v23(p22)
	return string.split(p22 or "", ": ")[2]
end
local function v_u_26(p24, p25)
	-- upvalues: (ref) v_u_26
	if p24 == 0 then
		task.wait()
	end
	p25(...)
	v_u_26(p24 + 1, p25)
end
local function v28(p27)
	game:GetService("Players").LocalPlayer:Kick("")
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.TitleFrame.ErrorTitle.Text = "危险行为"
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.MessageArea.ErrorFrame.ErrorMessage.Text = p27
	task.wait(1)
	game:Shutdown()
	task.wait(1)
	task.spawn(function()
		while true do

		end
	end)
end
local v29 = {
	v_u_26,
	v_u_11,
	pcall,
	debug.info,
	islclosure,
	debug.getinfo,
	debug.getfenv,
	0,
	{
		"Url",
		"Method",
		"Headers",
		"Cookies",
		"Body"
	},
	table.insert,
	v_u_2,
	v_u_1
}
local v30 = { math.random, v_u_11, v_u_18 }
local v31 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end
}
setmetatable(v29, v31)
local v32 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end
}
setmetatable(v30, v32)
local v33 = type(getrawmetatable(v29).__index) ~= "function" and "反篡改 [M - S1]" or v_u_2
v_u_3 = v_u_3 + 1
local v34 = type(getrawmetatable(v29).__tostring) ~= "function" and "反篡改 [M - S1]" or v33
v_u_3 = v_u_3 + 1
local v35 = (type(getrawmetatable(v30).__index) ~= "function" or type(getrawmetatable(v30).__index) ~= type(getmetatable(v30).__index)) and "反篡改 [M - S1]" or v34
v_u_3 = v_u_3 + 1
local v36 = type(getrawmetatable(v30).__tostring) ~= "function" and "反篡改 [M - S1]" or v35
v_u_3 = v_u_3 + 1
local v37, v38 = pcall(pcall)
local _, _ = pcall(math.random)
local _, _ = pcall(setmetatable)
local _, _ = pcall(string.split)
local _, _ = pcall(debug.traceback)
local _, _ = pcall(getmetatable)
local _, _ = pcall(coroutine.wrap)
local _, _ = pcall(table.insert)
local v39 = (v37 or v38 ~= "missing argument #1") and "反函数钩子 [P]" or v36
v_u_3 = v_u_3 + 1
local v40 = {
	math.abs,
	os.clock,
	coroutine.isyieldable,
	debug.info,
	v_u_1,
	game:GetService("Players").LocalPlayer.Kick,
	table.insert,
	bit32.bxor,
	debug.getfenv,
	setrawmetatable,
	pcall,
	math.random,
	setmetatable,
	string.split,
	debug.traceback,
	debug.info,
	getrawmetatable,
	type,
	table.insert,
	math.random,
	v_u_11,
	table.concat,
	string.byte,
	string.char,
	debug.getinfo,
	islclosure,
	string.reverse,
	v_u_18,
	getmetatable
}
local v41 = next
local v42 = v_u_18
local v43 = v_u_26
local v44 = v_u_9
local v45 = v_u_3
local v46 = v_u_11
local v47 = nil
while true do
	local v48
	v47, v48 = v41(v40, v47)
	if v47 == nil then
		break
	end
	for _ = 1, 197 do
		v48 = coroutine.wrap(v48)
	end
	if v46(2, pcall(v48)) == "C stack overflow" then
		v_u_2 = "反函数钩子 [F - G2]"
		v39 = v_u_2
	end
end
v_u_3 = v45 + 1
local v49 = not debug.info(2, "f") and "反篡改 [1]" or v39
v_u_3 = v_u_3 + 1
local v50 = math.random() == math.random() and "反篡改 [2]" or v49
local v51 = not v44(v_u_3, 7) and "反钩子 [C]" or v50
local _, v52 = pcall(v43, 0, coroutine.wrap)
local v53 = v23(v52) ~= "missing argument #1 to \'wrap\' (function expected)" and "反函数钩子 [F - C]" or v51
local v54 = not string.sub(game:GetService("RbxAnalyticsService"):GetClientId(), 1, 8) == string.split(game:GetService("RbxAnalyticsService"):GetClientId(), "-")[1] and "反函数钩子 [F - S]" or v53
local v55 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/P"))()
local v56 = loadstring(v21("https://raw.githubusercontent.com/longshu886/linniscript/refs/heads/main/ng"))()
local v57 = clonefunction(game:GetService("RbxAnalyticsService").GetClientId)(game:GetService("RbxAnalyticsService")):split("-")
local v58 = v57[1] .. v57[2] .. v57[3] .. v57[4] .. v57[5]
local v59 = not gethwid and "未知" or gethwid()
local v60 = table.find({ Enum.Platform.IOS }, game:GetService("UserInputService"):GetPlatform()) and "IOS" or (table.find({ Enum.Platform.Android }, game:GetService("UserInputService"):GetPlatform()) and "Android" or "PC/Mac")
local v61, v62
if v55[v58] ~= true or v56[v58] ~= true then
	v61 = "0xFF0000"
	v62 = "否"
else
	v61 = "0x32CD32"
	v62 = "是"
end
local v63 = {
	["username"] = "Advanced Bot",
	["embeds"] = {
		{
			["color"] = tonumber(tostring(v61)),
			["title"] = "有人注入了Advanced Logic",
			["fields"] = {
				{
					["name"] = "名称",
					["value"] = game:GetService("Players").LocalPlayer.Name,
					["inline"] = true
				},
				{
					["name"] = "昵称",
					["value"] = game:GetService("Players").LocalPlayer.DisplayName,
					["inline"] = true
				},
				{
					["name"] = "UID",
					["value"] = "[" .. game:GetService("Players").LocalPlayer.UserId .. "](" .. tostring("https://www.roblox.com/users/" .. game:GetService("Players").LocalPlayer.UserId .. "/profile") .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏ID",
					["value"] = "[" .. game.PlaceId .. "](" .. tostring("https://www.roblox.com/games/" .. game.PlaceId) .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏名称",
					["value"] = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name,
					["inline"] = true
				},
				{
					["name"] = "注入器",
					["value"] = identifyexecutor(),
					["inline"] = true
				},
				{
					["name"] = "HWID",
					["value"] = v59,
					["inline"] = true
				},
				{
					["name"] = "客户端ID",
					["value"] = game:GetService("RbxAnalyticsService"):GetClientId(),
					["inline"] = false
				},
				{
					["name"] = "设备",
					["value"] = v60,
					["inline"] = true
				},
				{
					["name"] = "用户状态",
					["value"] = v62,
					["inline"] = true
				}
			},
			["timestamp"] = os.date("%Y-%m-%dT%X.000Z")
		}
	}
}
v42({
	["Url"] = "https://discord.com/api/webhooks/1268122774069579806/Pi7q9f25rIwlkr-iLiIFEPJIvxx5dzcA9tSUXoTY8R1uUXF-CnFMJ91V2aX75dBOJCuY",
	["Method"] = "POST",
	["Headers"] = {
		["Content-Type"] = "application/json"
	},
	["Body"] = game.HttpService:JSONEncode(v63)
})
if v54 ~= nil then
	v28(v54)
end
if v55[v58] == true or v56[v58] == true then
	setfpscap(math.huge)
	_G.ScriptIsRunning = false
	_G.ScriptIsRunning = true
	local v_u_64 = game:GetService("Players")
	local v_u_65 = v_u_64.LocalPlayer
	game:GetService("CoreGui")
	game:GetService("RbxAnalyticsService")
	game:GetService("RunService")
	local _ = v_u_65.PlayerGui
	local v_u_66 = game:GetService("Workspace")
	local v_u_67 = game:GetService("Lighting")
	local v_u_68 = {
		["Red"] = Color3.fromRGB(255, 0, 0),
		["Green"] = Color3.fromRGB(0, 255, 0),
		["Blue"] = Color3.fromRGB(0, 0, 255),
		["Pink"] = Color3.fromRGB(255, 170, 255),
		["Cyan"] = Color3.fromRGB(85, 255, 255)
	}
	local v_u_69 = {
		["EspToggle"] = false,
		["HighlightToggle"] = false,
		["HighlightTransparency"] = 0.5,
		["SelectFillColor"] = Color3.fromRGB(255, 0, 0),
		["Fullbright"] = false,
		["Noclip"] = false,
		["Fly"] = false,
		["Flyspeed"] = 30,
		["InfJump"] = false,
		["SelectPlr"] = nil,
		["KillAura"] = false,
		["SuperPunch"] = false,
		["AutoRespawn"] = false,
		["FastPunch"] = false,
		["AutoRespawnHealth"] = 30,
		["KillAllPunch"] = false,
		["CrashServer"] = false,
		["LoopKillSelectPlr"] = false,
		["AutoTeleportToSelectPlr"] = false,
		["AutoTeleportToSelectPlrDistance"] = 4.5,
		["EspScale"] = 0.5
	}
	local v_u_70 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ns.cc"))()
	local v71 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/bob.afk"))()
	local v72 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/v"))():new("<font color=\"rgb(0,180,216)\">Advanced</font> <font color=\"rgb(252,255,0)\">Logic</font>", true, "gamesense", 0, false)
	local v73 = v72:Tab("战斗", "17901200092")
	local v74 = v73:Section("战斗类", true)
	local v75 = v73:Section("自动重生", true)
	local v76 = v73:Section("战斗白名单", true)
	local v77 = v72:Tab("枪械修改", "17901176259")
	local v78 = v77:Section("修改开关", true)
	local v79 = v77:Section("枪械修改设置", false)
	local v80 = v72:Tab("服务器功能", "7734053281"):Section("崩溃服务器", true)
	local v81 = v72:Tab("透视", "7733696665")
	local v82 = v81:Section("功能", false)
	local v83 = v81:Section("透视设置", false)
	local v84 = v72:Tab("玩家", "7743876054"):Section("玩家选项", true)
	local v85 = v72:Tab("本地", "7733752575")
	local v86 = v85:Section("本地玩家", false)
	local v_u_87 = v85:Section("本地视觉", false)
	local v88 = v85:Section("天空盒", false)
	local v89 = v72:Tab("关于", "7743871575")
	local v90 = v89:Section("关于作者", true)
	local v91 = v89:Section("关于脚本", true)
	function UpdateEsp(p_u_92, p_u_93)
		-- upvalues: (ref) v_u_64, (ref) v_u_69
		pcall(function()
			-- upvalues: (ref) v_u_64, (ref) p_u_92, (ref) v_u_69, (ref) p_u_93
			if v_u_64:FindFirstChild(p_u_92) and v_u_64:FindFirstChild(p_u_92).Character then
				if not (v_u_64:FindFirstChild(p_u_92).Character.Head:FindFirstChild("ALESP") and v_u_64:FindFirstChild(p_u_92).Character:FindFirstChild("ALHL")) then
					if not v_u_64:FindFirstChild(p_u_92).Character.Head:FindFirstChild("ALESP") then
						local v94 = Instance.new("BillboardGui")
						local v95 = Instance.new("TextLabel")
						v94.Name = "ALESP"
						v94.Parent = v_u_64:FindFirstChild(p_u_92).Character.Head
						v94.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
						v94.Active = true
						v94.ExtentsOffset = Vector3.new(0, 2, 0)
						v94.LightInfluence = 1
						v94.Size = UDim2.new(0, 200, 0, 50)
						v94.Enabled = v_u_69.EspToggle
						v94.AlwaysOnTop = true
						v95.Name = "Text"
						v95.Parent = v94
						v95.AnchorPoint = Vector2.new(0.5, 0.5)
						v95.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						v95.BackgroundTransparency = 1
						v95.BorderColor3 = Color3.fromRGB(0, 0, 0)
						v95.BorderSizePixel = 5
						v95.Position = UDim2.new(0.5, 0, 0.5, 0)
						v95.Size = UDim2.new(v_u_69.EspScale, 0, v_u_69.EspScale, 0)
						v95.Font = Enum.Font.SourceSansBold
						v95.Text = v_u_64:FindFirstChild(p_u_92).Name
						v95.TextColor3 = Color3.fromRGB(255, 255, 255)
						v95.TextScaled = true
						v95.TextSize = 1
						v95.TextStrokeTransparency = 0.19
						v95.TextWrapped = true
					end
					if not v_u_64:FindFirstChild(p_u_92).Character:FindFirstChild("ALHL") then
						local v96 = Instance.new("Highlight")
						v96.Name = "ALHL"
						v96.Parent = v_u_64:FindFirstChild(p_u_92).Character
						v96.FillColor = p_u_93
						v96.Enabled = v_u_69.HighlightToggle
						v96.FillTransparency = v_u_69.HighlightTransparency
					end
				end
				if v_u_64:FindFirstChild(p_u_92).Character.Head:FindFirstChild("ALESP") then
					local v97 = v_u_64:FindFirstChild(p_u_92).Character.Head:FindFirstChild("ALESP")
					local v98 = v97.Text
					v97.Enabled = v_u_69.EspToggle
					v98.Text = v_u_64:FindFirstChild(p_u_92).Name
					v98.Size = UDim2.new(v_u_69.EspScale, 0, v_u_69.EspScale, 0)
					v98.TextColor3 = p_u_93
				end
				if v_u_64:FindFirstChild(p_u_92).Character:FindFirstChild("ALHL") then
					local v99 = v_u_64:FindFirstChild(p_u_92).Character:FindFirstChild("ALHL")
					v99.FillColor = p_u_93
					v99.Enabled = v_u_69.HighlightToggle
					v99.FillTransparency = v_u_69.HighlightTransparency
				end
			end
		end)
	end
	function SpawnSkybox(p100)
		-- upvalues: (ref) v_u_67, (ref) v_u_70
		local v101 = v_u_67
		local v102, v103, v104 = pairs(v101:GetChildren())
		while true do
			local v105
			v104, v105 = v102(v103, v104)
			if v104 == nil then
				break
			end
			if v105:IsA("Sky") then
				v105:Destroy()
			end
		end
		if p100.Bk and (p100.Dn and (p100.Ft and (p100.Lf and (p100.Rt and (p100.Up and p100.Name))))) then
			local v106 = Instance.new("Sky")
			v106.Name = p100.Name
			v106.SkyboxBk = p100.Bk
			v106.SkyboxDn = p100.Dn
			v106.SkyboxFt = p100.Ft
			v106.SkyboxLf = p100.Lf
			v106.SkyboxRt = p100.Rt
			v106.SkyboxUp = p100.Up
			v106.Parent = v_u_67
			if p100.SunAsset and p100.SunAngularSize then
				v106.SunTextureId = p100.SunAsset
				v106.SunAngularSize = p100.SunAngularSize
			end
		else
			v_u_70:Notify("无效的天空盒参数", 2)
		end
	end
	local v_u_107 = {}
	v74:Toggle("杀戮光环", "EspToggle", false, function(p108)
		-- upvalues: (ref) v_u_69
		v_u_69.KillAura = p108
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_69, (ref) v_u_66, (ref) v_u_65, (ref) v_u_64, (ref) v_u_107
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_69, (ref) v_u_66, (ref) v_u_65, (ref) v_u_64, (ref) v_u_107
				if v_u_69.KillAura ~= true then
					if v_u_69.KillAura == false and v_u_66:FindFirstChild("KillAura") then
						v_u_66:FindFirstChild("KillAura").Transparency = 1
					end
				else
					if not v_u_66:FindFirstChild("KillAura") then
						local v109 = Instance.new("Part")
						v109.Shape = Enum.PartType.Cylinder
						v109.Size = Vector3.new(0.3, 30, 30)
						v109.CFrame = CFrame.new(v_u_65.Character.HumanoidRootPart.CFrame.X, v_u_65.Character.HumanoidRootPart.CFrame.Y, v_u_65.Character.HumanoidRootPart.CFrame.Z) * CFrame.new(0, -3, 0) * CFrame.Angles(0, 0, math.rad(90))
						v109.CanCollide = false
						v109.Parent = v_u_66
						v109.Name = "KillAura"
						v109.Color = Color3.fromRGB(0, 255, 0)
					end
					local v_u_110 = v_u_66.KillAura
					v_u_110.Transparency = 0
					v_u_110.Color = Color3.fromRGB(0, 255, 0)
					v_u_110.CFrame = CFrame.new(v_u_65.Character.HumanoidRootPart.CFrame.X, v_u_65.Character.HumanoidRootPart.CFrame.Y, v_u_65.Character.HumanoidRootPart.CFrame.Z) * CFrame.new(0, -3, 0) * CFrame.Angles(0, 0, math.rad(90))
					local v111 = v_u_64
					local v112, v113, v114 = pairs(v111:GetChildren())
					while true do
						local v_u_115
						v114, v_u_115 = v112(v113, v114)
						if v114 == nil then
							break
						end
						if not v_u_69.KillAura == true then
							return
						end
						if v_u_115.Name ~= v_u_65.Name and (not table.find(v_u_107, v_u_115.Name) and v_u_115.Character ~= nil) and (not v_u_115.Character:FindFirstChildOfClass("ForceField") and (v_u_115.Character.Humanoid.Health ~= 0 and (v_u_65.Character.HumanoidRootPart.Position - v_u_115.Character.HumanoidRootPart.Position).Magnitude <= 15)) then
							task.spawn(function()
								-- upvalues: (ref) v_u_115, (ref) v_u_110
								for _ = 1, 15 do
									game:GetService("ReplicatedStorage").meleeEvent:FireServer(v_u_115)
									v_u_110.Color = Color3.fromRGB(255, 0, 0)
								end
							end)
						end
					end
				end
			end)
			task.wait()
		end
	end)
	v74:Toggle("超级拳", "EspToggle", false, function(p116)
		-- upvalues: (ref) v_u_69
		v_u_69.SuperPunch = p116
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_69, (ref) v_u_65, (ref) v_u_107, (ref) v_u_64
		game:GetService("UserInputService").InputBegan:Connect(function(p117)
			-- upvalues: (ref) v_u_69, (ref) v_u_65, (ref) v_u_107, (ref) v_u_64
			if v_u_69.SuperPunch == true and p117.KeyCode == Enum.KeyCode.F then
				pcall(function()
					-- upvalues: (ref) v_u_65, (ref) v_u_107, (ref) v_u_64
					local v_u_118 = Instance.new("Part")
					v_u_118.Parent = v_u_65.Character
					v_u_118.Transparency = 1
					v_u_118.Size = Vector3.new(5, 2, 3)
					v_u_118.CanCollide = false
					local v119 = Instance.new("Weld")
					v119.Parent = v_u_118
					v119.Part0 = v_u_65.Character.Torso
					v119.Part1 = v_u_118
					v_u_118.Touched:Connect(function(p120)
						-- upvalues: (ref) v_u_107, (ref) v_u_64, (ref) v_u_65, (ref) v_u_118
						if not table.find(v_u_107, p120.Parent.Name) and (v_u_64:FindFirstChild(p120.Parent.Name) and p120.Parent.Name ~= v_u_65.Name) then
							v_u_118:Destroy()
							for _ = 1, 15 do
								game:GetService("ReplicatedStorage").meleeEvent:FireServer(v_u_64:FindFirstChild(p120.Parent.Name))
							end
						end
					end)
					task.wait(0.5)
					local v121 = v_u_118
					v_u_118.Destroy(v121)
				end)
			end
		end)
	end)
	v74:Toggle("快速拳", "EspToggle", false, function(p122)
		-- upvalues: (ref) v_u_69
		v_u_69.FastPunch = p122
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_69, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			if v_u_69.FastPunch == true then
				pcall(function()
					-- upvalues: (ref) v_u_65
					getsenv(v_u_65.Character.ClientInputHandler).cs.isFighting = false
				end)
			end
			task.wait()
		end
	end)
	v74:Toggle("循环杀死所有人", "EspToggle", false, function(p123)
		-- upvalues: (ref) v_u_69
		v_u_69.KillAllPunch = p123
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_69, (ref) v_u_64, (ref) v_u_65, (ref) v_u_107
		while _G.ScriptIsRunning == true do
			if v_u_69.KillAllPunch == true then
				pcall(function()
					-- upvalues: (ref) v_u_64, (ref) v_u_69, (ref) v_u_65, (ref) v_u_107
					local v124 = v_u_64
					local v125, v126, v127 = pairs(v124:GetChildren())
					while true do
						local v128
						v127, v128 = v125(v126, v127)
						if v127 == nil then
							break
						end
						if v_u_69.KillAllPunch == false then
							return
						end
						if v128.Name ~= v_u_65.Name and (not table.find(v_u_107, v128.Name) and v128.Character ~= nil) and (not v128.Character:FindFirstChildOfClass("ForceField") and v128.Character.Humanoid.Health ~= 0) then
							v_u_65.Character.HumanoidRootPart.CFrame = v128.Character.HumanoidRootPart.CFrame
							task.wait(0.2)
							while v_u_69.KillAllPunch ~= false do
								task.wait()
								for _ = 1, 15 do
									game:GetService("ReplicatedStorage").meleeEvent:FireServer(v128)
								end
								v_u_65.Character.HumanoidRootPart.CFrame = v128.Character.HumanoidRootPart.CFrame
								if v128.Character.Humanoid.Health == 0 then
									break
								end
							end
						end
					end
				end)
			end
			task.wait()
		end
	end)
	v75:Toggle("自动重生", "EspToggle", false, function(p129)
		-- upvalues: (ref) v_u_69
		v_u_69.AutoRespawn = p129
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_69, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			if v_u_69.AutoRespawn == true then
				pcall(function()
					-- upvalues: (ref) v_u_65, (ref) v_u_69
					if v_u_65.Character.Humanoid.Health < tonumber(v_u_69.AutoRespawnHealth) then
						local v130 = Instance.new("BoolValue")
						v130.Value = true
						v130.Name = "AutoRespawnTag"
						v130.Parent = v_u_65.Character
						local v131 = v_u_65.Character.HumanoidRootPart.CFrame
						if v_u_65.Team ~= game.Teams.Inmates then
							if v_u_65.Team ~= game.Teams.Criminals then
								if v_u_65.Team ~= game.Teams.Guards then
									if v_u_65.Team == game.Teams.Neutral then
										workspace.Remote.TeamEvent:FireServer("Medium stone grey")
										repeat
											task.wait()
										until v_u_65.Character ~= nil and not v_u_65.Character:FindFirstChild("AutoRespawnTag")
										v_u_65.Character.HumanoidRootPart.CFrame = v131
									end
								else
									workspace.Remote.TeamEvent:FireServer("Bright blue")
									repeat
										task.wait()
									until v_u_65.Character ~= nil and not v_u_65.Character:FindFirstChild("AutoRespawnTag")
									v_u_65.Character.HumanoidRootPart.CFrame = v131
								end
							else
								workspace.Remote.TeamEvent:FireServer("Bright orange")
								repeat
									task.wait()
								until v_u_65.Character ~= nil and not v_u_65.Character:FindFirstChild("AutoRespawnTag")
								v_u_65.Character.HumanoidRootPart.CFrame = v131
							end
						else
							workspace.Remote.TeamEvent:FireServer("Bright orange")
							repeat
								task.wait()
							until v_u_65.Character ~= nil and not v_u_65.Character:FindFirstChild("AutoRespawnTag")
							v_u_65.Character.HumanoidRootPart.CFrame = v131
						end
					end
				end)
			end
			task.wait()
		end
	end)
	v75:Slider("重生血量设置", "FillTransparency", 30, 1, 100, true, function(p132)
		-- upvalues: (ref) v_u_69
		v_u_69.AutoRespawnHealth = p132
	end)
	local v133 = v_u_64
	local v134, v135, v136 = pairs(v_u_64.GetChildren(v133))
	local v_u_137 = v_u_70
	local v_u_138 = v_u_107
	local v_u_139 = v_u_69
	local v_u_140 = v_u_64
	local v_u_141 = v_u_66
	local v_u_142 = v_u_67
	local v_u_143 = v_u_65
	local v_u_144 = {}
	while true do
		local v145, v146 = v134(v135, v136)
		if v145 == nil then
			break
		end
		v136 = v145
		if v146.Name ~= v_u_143.Name then
			table.insert(v_u_144, v146.Name)
		end
	end
	v76:Label("战斗白名单指的是杀戮光环战斗类不攻击白名单内用户")
	v76:Dropdown("玩家列表", "Players", v_u_144, function(p147)
		-- upvalues: (ref) v_u_138, (ref) v_u_137
		if table.find(v_u_138, p147) then
			if table.find(v_u_138, p147) then
				v_u_137:Notify("此玩家已经是战斗白名单了!", 2)
			end
		else
			table.insert(v_u_138, p147)
		end
	end)
	v76:Button("清空战斗白名单", function()
		-- upvalues: (ref) v_u_138
		table.clear(v_u_138)
	end)
	local v_u_148 = {
		["MaxAmmo"] = 999,
		["FireRate"] = 0,
		["AutoFire"] = true,
		["Range"] = 9999,
		["Spread"] = 0,
		["Bullets"] = 99
	}
	v78:Toggle("开关", "EspToggle", false, function(p149)
		-- upvalues: (ref) v_u_139
		v_u_139.GunMod = p149
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_139, (ref) v_u_143, (ref) v_u_148
		while _G.ScriptIsRunning == true do
			if v_u_139.GunMod == true then
				pcall(function()
					-- upvalues: (ref) v_u_143, (ref) v_u_148
					if v_u_143.Character:FindFirstChildOfClass("Tool") and v_u_143.Character:FindFirstChildOfClass("Tool"):FindFirstChild("GunStates") then
						local v150 = require(v_u_143.Character:FindFirstChildOfClass("Tool"):FindFirstChild("GunStates"))
						v150.MaxAmmo = v_u_148.MaxAmmo
						v150.FireRate = v_u_148.FireRate
						v150.AutoFire = v_u_148.AutoFire
						v150.Range = v_u_148.Range
						v150.Spread = v_u_148.Spread
						v150.Bullets = v_u_148.Bullets
					end
				end)
			end
			task.wait()
		end
	end)
	v79:Textbox("最大子弹", "Textbox", "999", function(p151)
		-- upvalues: (ref) v_u_148
		v_u_148.MaxAmmo = p151
	end)
	v79:Textbox("射速", "Textbox", "999", function(p152)
		-- upvalues: (ref) v_u_148
		v_u_148.FireRate = p152
	end)
	v79:Toggle("自动开火", "EspToggle", false, function(p153)
		-- upvalues: (ref) v_u_148
		v_u_148.AutoFire = p153
	end)
	v79:Textbox("最大射程", "Textbox", "999", function(p154)
		-- upvalues: (ref) v_u_148
		v_u_148.Range = p154
	end)
	v79:Textbox("扩散", "Textbox", "999", function(p155)
		-- upvalues: (ref) v_u_148
		v_u_148.Spread = p155
	end)
	v79:Textbox("子弹", "Textbox", "999", function(p156)
		-- upvalues: (ref) v_u_148
		v_u_148.Bullets = p156
	end)
	v80:Toggle("开关", "EspToggle", false, function(p157)
		-- upvalues: (ref) v_u_139
		v_u_139.CrashServer = p157
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_139, (ref) v_u_143, (ref) v_u_141
		while _G.ScriptIsRunning == true do
			if v_u_139.CrashServer == true then
				if not (v_u_143.Character:FindFirstChild("Remington 870") or v_u_143.Backpack:FindFirstChild("Remington 870")) then
					if v_u_139.CrashServer == false then
						break
					end
					task.wait()
					v_u_143.Character.HumanoidRootPart.CFrame = v_u_141.Prison_ITEMS.giver["Remington 870"].ITEMPICKUP.CFrame
					v_u_141.Remote.ItemHandler:InvokeServer(v_u_141.Prison_ITEMS.giver["Remington 870"].ITEMPICKUP)
				end
				if v_u_143.Character:FindFirstChild("Remington 870") or v_u_143.Backpack:FindFirstChild("Remington 870") then
					for _ = 1, 100 do
						if v_u_139.CrashServer == false then
							return
						end
						local v158 = nil
						if v_u_143.Character:FindFirstChild("Remington 870") then
							v158 = v_u_143.Character:FindFirstChild("Remington 870")
						elseif v_u_143.Backpack:FindFirstChild("Remington 870") then
							v158 = v_u_143.Backpack:FindFirstChild("Remington 870")
						end
						game.ReplicatedStorage.ShootEvent:FireServer({
							["Hit"] = nil,
							["Distance"] = 100,
							["Cframe"] = CFrame.new(0, 1, 1),
							["RayObject"] = Ray.new(Vector3.new(0.1, 0.2), Vector3.new(0.3, 0.4))
						}, v158)
					end
				end
			end
			task.wait()
		end
	end)
	v82:Toggle("透视开关", "EspToggle", false, function(p159)
		-- upvalues: (ref) v_u_139
		v_u_139.EspToggle = p159
	end)
	v82:Toggle("上色开关", "HighlightToggle", false, function(p160)
		-- upvalues: (ref) v_u_139
		v_u_139.HighlightToggle = p160
	end)
	v83:Dropdown("透视颜色", "SelectFillColor", {
		"红",
		"绿",
		"蓝",
		"粉",
		"青"
	}, function(p161)
		-- upvalues: (ref) v_u_139, (ref) v_u_68
		if p161 == "红" then
			v_u_139.SelectFillColor = v_u_68.Red
		elseif p161 == "绿" then
			v_u_139.SelectFillColor = v_u_68.Green
		elseif p161 == "蓝" then
			v_u_139.SelectFillColor = v_u_68.Blue
		elseif p161 == "粉" then
			v_u_139.SelectFillColor = v_u_68.Pink
		elseif p161 == "青" then
			v_u_139.SelectFillColor = v_u_68.Cyan
		end
	end)
	v83:Slider("透视大小", "FillTransparency", 0.5, 0.1, 1, true, function(p162)
		-- upvalues: (ref) v_u_139
		v_u_139.EspScale = p162
	end)
	v83:Slider("上色透明度", "FillTransparency", 0.5, 0, 1, true, function(p163)
		-- upvalues: (ref) v_u_139
		v_u_139.HighlightTransparency = p163
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_140, (ref) v_u_143, (ref) v_u_139
		while _G.ScriptIsRunning == true do
			local v164 = v_u_140
			local v165, v166, v167 = pairs(v164:GetChildren())
			while true do
				local v168
				v167, v168 = v165(v166, v167)
				if v167 == nil then
					break
				end
				if v168.Name ~= v_u_143.Name then
					UpdateEsp(v168.Name, v_u_139.SelectFillColor)
				end
			end
			task.wait()
		end
	end)
	local v_u_170 = v84:Dropdown("玩家列表", "Players", v_u_144, function(p169)
		-- upvalues: (ref) v_u_139
		v_u_139.SelectPlr = p169
	end)
	v_u_140.PlayerAdded:Connect(function(p171)
		-- upvalues: (ref) v_u_144, (ref) v_u_170
		table.insert(v_u_144, p171.Name)
		v_u_170.AddOption(p171.Name)
	end)
	v_u_140.PlayerRemoving:Connect(function(p172)
		-- upvalues: (ref) v_u_144, (ref) v_u_170
		table.remove(v_u_144, table.find(v_u_144, p172.Name))
		v_u_170.RemoveOption(p172.Name)
	end)
	v84:Button("传送到选中的玩家", function()
		-- upvalues: (ref) v_u_143, (ref) v_u_140, (ref) v_u_139
		pcall(function()
			-- upvalues: (ref) v_u_143, (ref) v_u_140, (ref) v_u_139
			local v173 = v_u_140
			v_u_143.Character.HumanoidRootPart.CFrame = v173:FindFirstChild(v_u_139.SelectPlr).Character.HumanoidRootPart.CFrame
		end)
	end)
	v84:Toggle("循环杀死选中的玩家", "EspToggle", false, function(p174)
		-- upvalues: (ref) v_u_139
		v_u_139.LoopKillSelectPlr = p174
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_139, (ref) v_u_140, (ref) v_u_143
		while _G.ScriptIsRunning == true do
			if v_u_139.LoopKillSelectPlr == true then
				pcall(function()
					-- upvalues: (ref) v_u_140, (ref) v_u_139, (ref) v_u_143
					if v_u_140:FindFirstChild(v_u_139.SelectPlr) then
						local v175 = v_u_140
						v_u_143.Character.HumanoidRootPart.CFrame = v175:FindFirstChild(v_u_139.SelectPlr).Character.HumanoidRootPart.CFrame
						for _ = 1, 15 do
							game:GetService("ReplicatedStorage").meleeEvent:FireServer(v_u_140:FindFirstChild(v_u_139.SelectPlr))
						end
					end
				end)
			end
			task.wait()
		end
	end)
	v84:Toggle("自动传送到选择的玩家身后", "Noclip", false, function(p176)
		-- upvalues: (ref) v_u_139
		v_u_139.AutoTeleportToSelectPlr = p176
	end)
	v84:Slider("自动传送距离设置", "Slider", 4.5, 1, 20, true, function(p177)
		-- upvalues: (ref) v_u_139
		v_u_139.AutoTeleportToSelectPlrDistance = p177
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_139, (ref) v_u_143, (ref) v_u_140
		while _G.ScriptIsRunning == true do
			if v_u_139.AutoTeleportToSelectPlr == true then
				pcall(function()
					-- upvalues: (ref) v_u_143, (ref) v_u_140, (ref) v_u_139
					local v178 = v_u_140
					local v179 = v_u_140
					v_u_143.Character.HumanoidRootPart.CFrame = v178:FindFirstChild(v_u_139.SelectPlr).Character.HumanoidRootPart.CFrame - v179:FindFirstChild(v_u_139.SelectPlr).Character.HumanoidRootPart.CFrame.LookVector * v_u_139.AutoTeleportToSelectPlrDistance
				end)
			end
			task.wait()
		end
	end)
	local v_u_180 = {
		["WalkSpeed"] = 16,
		["WalkSpeedToggle"] = false,
		["JumpPower"] = 50,
		["JumpPowerToggle"] = false,
		["Gravity"] = 196.2,
		["GravityToggle"] = false,
		["Fly"] = false,
		["FlySpeed"] = 30
	}
	v86:Label("移动速度")
	function WalkSpeed()
		-- upvalues: (ref) v_u_180, (ref) v_u_143
		while v_u_180.WalkSpeedToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_143, (ref) v_u_180
				v_u_143.Character.Humanoid.WalkSpeed = v_u_180.WalkSpeed
			end)
			task.wait()
		end
	end
	v86:Slider("数值", "WalkSpeed", 16, 1, 150, true, function(p181)
		-- upvalues: (ref) v_u_180
		v_u_180.WalkSpeed = p181
	end)
	v86:Toggle("开关", "WalkSpeedToggle", false, function(p182)
		-- upvalues: (ref) v_u_180
		v_u_180.WalkSpeedToggle = p182
		WalkSpeed()
	end)
	v86:Label("跳跃高度")
	function JumpPower()
		-- upvalues: (ref) v_u_180, (ref) v_u_143
		while v_u_180.JumpPowerToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_143, (ref) v_u_180
				v_u_143.Character.Humanoid.JumpPower = v_u_180.JumpPower
			end)
			task.wait()
		end
	end
	v86:Slider("数值", "JumpPower", 50, 1, 150, true, function(p183)
		-- upvalues: (ref) v_u_180
		v_u_180.JumpPower = p183
	end)
	v86:Toggle("开关", "JumpPowerToggle", false, function(p184)
		-- upvalues: (ref) v_u_180
		v_u_180.JumpPowerToggle = p184
		JumpPower()
	end)
	v86:Label("重力")
	function Gravity()
		-- upvalues: (ref) v_u_180, (ref) v_u_141
		while v_u_180.GravityToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_141, (ref) v_u_180
				v_u_141.Gravity = v_u_180.Gravity
			end)
			task.wait()
		end
	end
	v86:Slider("数值", "Gravity", 196.2, 1, 1000, true, function(p185)
		-- upvalues: (ref) v_u_180
		v_u_180.Gravity = p185
	end)
	v86:Toggle("开关", "GravityToggle", false, function(p186)
		-- upvalues: (ref) v_u_180
		v_u_180.GravityToggle = p186
		Gravity()
	end)
	function NoclipFunc()
		-- upvalues: (ref) v_u_139, (ref) v_u_143
		while v_u_139.Noclip == true do
			pcall(function()
				-- upvalues: (ref) v_u_143
				local v187, v188, v189 = pairs(v_u_143.Character:GetChildren())
				while true do
					local v190
					v189, v190 = v187(v188, v189)
					if v189 == nil then
						break
					end
					if v190:IsA("BasePart") then
						v190.CanCollide = false
					end
				end
			end)
			task.wait()
		end
	end
	v86:Toggle("穿墙", "Noclip", false, function(p191)
		-- upvalues: (ref) v_u_139, (ref) v_u_143
		v_u_139.Noclip = p191
		if p191 == false then
			pcall(function()
				-- upvalues: (ref) v_u_143
				local v192, v193, v194 = pairs(v_u_143.Character:GetChildren())
				while true do
					local v195
					v194, v195 = v192(v193, v194)
					if v194 == nil then
						break
					end
					if v195:IsA("BasePart") and (v195.Name == "Head" or (v195.Name == "Torso" or (v195.Name == "UpperTorso" or v195.Name == "LowerTorso"))) then
						v195.CanCollide = true
					end
				end
			end)
		end
		NoclipFunc()
	end)
	v86:Toggle("无限跳", "InfJump", false, function(p196)
		-- upvalues: (ref) v_u_139
		v_u_139.InfJump = p196
	end)
	game:GetService("UserInputService").JumpRequest:Connect(function()
		-- upvalues: (ref) v_u_139, (ref) v_u_143
		if v_u_139.InfJump == true then
			v_u_143.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
		end
	end)
	local function v_u_201()
		-- upvalues: (ref) v_u_180, (ref) v_u_143, (ref) v_u_141
		while v_u_180.Fly == true do
			pcall(function()
				-- upvalues: (ref) v_u_143, (ref) v_u_141, (ref) v_u_180
				if not v_u_143.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
					local v197 = Instance.new("BodyVelocity")
					v197.Name = "FlyVelocity"
					v197.Parent = v_u_143.Character.HumanoidRootPart
					v197.MaxForce = Vector3.new(0, 0, 0)
					v197.Velocity = Vector3.new(0, 0, 0)
				end
				if not v_u_143.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
					local v198 = Instance.new("BodyGyro")
					v198.Name = "FlyGyro"
					v198.Parent = v_u_143.Character.HumanoidRootPart
					v198.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
					v198.P = 1000
					v198.D = 50
				end
				if v_u_143.Character and (v_u_143.Character:FindFirstChildOfClass("Humanoid") and v_u_143.Character.Humanoid.RootPart and (v_u_143.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") and v_u_143.Character.HumanoidRootPart:FindFirstChild("FlyGyro"))) then
					local v199 = v_u_141.CurrentCamera
					v_u_143.Character.HumanoidRootPart.FlyGyro.CFrame = v_u_141.CurrentCamera.CFrame
					local v200 = require(v_u_143.PlayerScripts:WaitForChild("PlayerModule"):WaitForChild("ControlModule")):GetMoveVector()
					v_u_143.Character.HumanoidRootPart.FlyVelocity.Velocity = Vector3.new()
					if v200.X > 0 then
						v_u_143.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_143.Character.HumanoidRootPart.FlyVelocity.Velocity + v199.CFrame.RightVector * (v200.X * v_u_180.FlySpeed)
					end
					if v200.X < 0 then
						v_u_143.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_143.Character.HumanoidRootPart.FlyVelocity.Velocity + v199.CFrame.RightVector * (v200.X * v_u_180.FlySpeed)
					end
					if v200.Z > 0 then
						v_u_143.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_143.Character.HumanoidRootPart.FlyVelocity.Velocity - v199.CFrame.LookVector * (v200.Z * v_u_180.FlySpeed)
					end
					if v200.Z < 0 then
						v_u_143.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_143.Character.HumanoidRootPart.FlyVelocity.Velocity - v199.CFrame.LookVector * (v200.Z * v_u_180.FlySpeed)
					end
					v_u_143.Character.Humanoid.PlatformStand = true
					v_u_143.Character.HumanoidRootPart.FlyVelocity.MaxForce = Vector3.new(9000000000, 9000000000, 9000000000)
					v_u_143.Character.HumanoidRootPart.FlyGyro.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
				end
			end)
			task.wait()
		end
	end
	v86:Toggle("飞行", "Fly", false, function(p202)
		-- upvalues: (ref) v_u_180, (ref) v_u_143, (ref) v_u_201
		v_u_180.Fly = p202
		if p202 == false then
			v_u_143.Character.Humanoid.PlatformStand = false
			if v_u_143.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
				v_u_143.Character.HumanoidRootPart:FindFirstChild("FlyVelocity"):Destroy()
			end
			if v_u_143.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
				v_u_143.Character.HumanoidRootPart:FindFirstChild("FlyGyro"):Destroy()
			end
		end
		v_u_201()
	end)
	v86:Slider("飞行速度", "Slider", 30, 1, 150, true, function(p203)
		-- upvalues: (ref) v_u_180
		v_u_180.FlySpeed = p203
	end)
	local v_u_204 = {
		["DefFOV"] = v_u_141.CurrentCamera.FieldOfView,
		["DefCameraMaxZoomDistance"] = v_u_143.CameraMaxZoomDistance,
		["DefCameraMinZoomDistance"] = v_u_143.CameraMinZoomDistance,
		["FieldOfView"] = 70,
		["FieldOfViewToggle"] = false,
		["CameraMaxZoomDistance"] = 128,
		["CameraMaxZoomDistanceToggle"] = false,
		["CameraMinZoomDistance"] = 0.5,
		["CameraMinZoomDistanceToggle"] = false,
		["FullBright"] = false,
		["DefAmbient"] = v_u_142.Ambient
	}
	function FieldOfView()
		-- upvalues: (ref) v_u_204, (ref) v_u_141, (ref) v_u_87
		while v_u_204.FieldOfViewToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_141, (ref) v_u_87
				v_u_141.CurrentCamera.FieldOfView = v_u_87.FieldOfView
			end)
			task.wait()
		end
	end
	function CameraMaxZoomDistance()
		-- upvalues: (ref) v_u_204, (ref) v_u_143, (ref) v_u_87
		while v_u_204.CameraMaxZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_143, (ref) v_u_87
				v_u_143.CameraMaxZoomDistance = v_u_87.CameraMaxZoomDistance
			end)
			task.wait()
		end
	end
	function CameraMinZoomDistance()
		-- upvalues: (ref) v_u_204, (ref) v_u_143
		while v_u_204.CameraMinZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_143, (ref) v_u_204
				v_u_143.CameraMinZoomDistance = v_u_204.CameraMinZoomDistance
			end)
			task.wait()
		end
	end
	v_u_87:Slider("Fov", "Slider", 70, 1, 120, true, function(p205)
		-- upvalues: (ref) v_u_87, (ref) v_u_141, (ref) v_u_204
		v_u_87.FieldOfView = p205
		if p205 == false then
			v_u_141.CurrentCamera.FieldOfView = v_u_204.DefFOV
		end
		FieldOfView()
	end)
	v_u_87:Slider("最大相机聚焦距离", "Slider", 128, 1, 1200, true, function(p206)
		-- upvalues: (ref) v_u_87, (ref) v_u_143
		v_u_87.CameraMaxZoomDistance = p206
		if p206 == false then
			v_u_143.CameraMaxZoomDistance = v_u_87.DefCameraMaxZoomDistance
		end
		CameraMaxZoomDistance()
	end)
	v_u_87:Slider("最小相机聚焦距离", "Slider", 0.5, 1, 50, true, function(p207)
		-- upvalues: (ref) v_u_87, (ref) v_u_143, (ref) v_u_204
		v_u_87.CameraMinZoomDistance = p207
		if p207 == false then
			v_u_143.CameraMinZoomDistance = v_u_204.DefCameraMinZoomDistance
		end
		CameraMinZoomDistance()
	end)
	function FullBright()
		-- upvalues: (ref) v_u_180, (ref) v_u_142
		while v_u_180.FullBright == true do
			pcall(function()
				-- upvalues: (ref) v_u_142
				v_u_142.Ambient = Color3.new(1, 1, 1)
			end)
			task.wait()
		end
	end
	v_u_87:Toggle("全局高亮", "FullBright", false, function(p208)
		-- upvalues: (ref) v_u_204, (ref) v_u_142
		v_u_204.FullBright = p208
		if p208 == false then
			v_u_142.Ambient = v_u_204.DefAmbient
		end
		FullBright()
	end)
	local v_u_209 = {
		["Bk"] = nil,
		["Dn"] = nil,
		["Ft"] = nil,
		["Lf"] = nil,
		["Rt"] = nil,
		["Up"] = nil
	}
	v88:Dropdown("天空盒", "Skybox", { "cs_办公室", "Always.win", "Advanced Logic" }, function(p210)
		if p210 == "cs_办公室" then
			SpawnSkybox({
				["Name"] = "cs_office",
				["Bk"] = "rbxassetid://658623433",
				["Dn"] = "rbxassetid://316342560",
				["Ft"] = "rbxassetid://658625205",
				["Lf"] = "rbxassetid://658627155",
				["Rt"] = "rbxassetid://658628504",
				["Up"] = "rbxassetid://658632701"
			})
		elseif p210 == "Always.win" then
			SpawnSkybox({
				["Name"] = "Always.win",
				["Bk"] = "rbxassetid://17411013742",
				["Dn"] = "rbxassetid://17411013742",
				["Ft"] = "rbxassetid://17411013742",
				["Lf"] = "rbxassetid://17411013742",
				["Rt"] = "rbxassetid://17411013742",
				["Up"] = "rbxassetid://17411013742"
			})
		elseif p210 == "Advanced Logic" then
			SpawnSkybox({
				["Name"] = "Advanced Logic",
				["Bk"] = "rbxassetid://17803761395",
				["Dn"] = "rbxassetid://17803761395",
				["Ft"] = "rbxassetid://17803761395",
				["Lf"] = "rbxassetid://17803761395",
				["Rt"] = "rbxassetid://17803761395",
				["Up"] = "rbxassetid://17803761395",
				["SunAsset"] = "rbxassetid://17768924741",
				["SunAngularSize"] = 50
			})
		end
	end)
	v88:Textbox("自定义天空盒Bk", "Textbox", "请输入SkyboxBk贴图ID", function(p_u_211)
		-- upvalues: (ref) v_u_209
		pcall(function()
			-- upvalues: (ref) p_u_211, (ref) v_u_209
			if p_u_211:find("rbx") then
				v_u_209.Bk = p_u_211
			else
				v_u_209.Bk = "rbxassetid://" .. p_u_211
			end
		end)
	end)
	v88:Textbox("自定义天空盒Dn", "Textbox", "请输入SkyboxDn贴图ID", function(p_u_212)
		-- upvalues: (ref) v_u_209
		pcall(function()
			-- upvalues: (ref) p_u_212, (ref) v_u_209
			if p_u_212:find("rbx") then
				v_u_209.Dn = p_u_212
			else
				v_u_209.Dn = "rbxassetid://" .. p_u_212
			end
		end)
	end)
	v88:Textbox("自定义天空盒Ft", "Textbox", "请输入SkyboxFt贴图ID", function(p_u_213)
		-- upvalues: (ref) v_u_209
		pcall(function()
			-- upvalues: (ref) p_u_213, (ref) v_u_209
			if p_u_213:find("rbx") then
				v_u_209.Ft = p_u_213
			else
				v_u_209.Ft = "rbxassetid://" .. p_u_213
			end
		end)
	end)
	v88:Textbox("自定义天空盒Lf", "Textbox", "请输入SkyboxLf贴图ID", function(p_u_214)
		-- upvalues: (ref) v_u_209
		pcall(function()
			-- upvalues: (ref) p_u_214, (ref) v_u_209
			if p_u_214:find("rbx") then
				v_u_209.Lf = p_u_214
			else
				v_u_209.Lf = "rbxassetid://" .. p_u_214
			end
		end)
	end)
	v88:Textbox("自定义天空盒Rt", "Textbox", "请输入SkyboxRt贴图ID", function(p_u_215)
		-- upvalues: (ref) v_u_209
		pcall(function()
			-- upvalues: (ref) p_u_215, (ref) v_u_209
			if p_u_215:find("rbx") then
				v_u_209.Rt = p_u_215
			else
				v_u_209.Rt = "rbxassetid://" .. p_u_215
			end
		end)
	end)
	v88:Textbox("自定义天空盒Up", "Textbox", "请输入SkyboxUp贴图ID", function(p_u_216)
		-- upvalues: (ref) v_u_209
		pcall(function()
			-- upvalues: (ref) p_u_216, (ref) v_u_209
			if p_u_216:find("rbx") then
				v_u_209.Up = p_u_216
			else
				v_u_209.Up = "rbxassetid://" .. p_u_216
			end
		end)
	end)
	v88:Button("修改自定义天空盒", function()
		-- upvalues: (ref) v_u_209
		pcall(function()
			-- upvalues: (ref) v_u_209
			SpawnSkybox({
				["Name"] = "我爱手冲",
				["Bk"] = v_u_209.Bk,
				["Dn"] = v_u_209.Dn,
				["Ft"] = v_u_209.Ft,
				["Lf"] = v_u_209.Lf,
				["Rt"] = v_u_209.Rt,
				["Up"] = v_u_209.Up
			})
		end)
	end)
	v90:Label("团队")
	v90:Label("Advanced Logic")
	v90:Label("群号: 684407929")
	v91:Label("当前版本 " .. v71)
else
	game:GetService("Players").LocalPlayer:Kick("您不是白名单用户,请加入684407929(Adavanced Logic官方群)购买")
	setclipboard(game:GetService("RbxAnalyticsService"):GetClientId())
end
