local v_u_1 = http_request or request or (HttpPost or syn.request)
local v_u_2 = nil
local v_u_3 = 0
local function v_u_9(p4, p5, p6)
	-- upvalues: (ref) v_u_3, (ref) v_u_9
	v_u_3 = v_u_3 + 1
	if p6 then
		local v7 = v_u_9(p4, p5) and v_u_9(p4, p6)
		if v7 then
			v7 = v_u_9(p5, p6)
		end
		return v7
	else
		local v8 = type(p4) == typeof(p5) and (typeof(p4) == type(p5) and (type(p4) == typeof(p5) or typeof(p4) == type(p5))) and (#tostring(p4) == #tostring(p5) and rawequal(p4, p5))
		if v8 then
			if tostring(p4) < tostring(p5) or tostring(p4) > tostring(p5) then
				v8 = false
			else
				v8 = rawequal(tostring(p4), tostring(p5))
			end
		end
		return v8
	end
end
local function v_u_11(p10)
	return ({ ... })[p10]
end
local function v_u_18(p_u_12)
	-- upvalues: (ref) v_u_1, (ref) v_u_2, (ref) v_u_11
	local v_u_13 = false
	local v15 = {
		["__call"] = v_u_1,
		["__index"] = function(_, p14)
			-- upvalues: (ref) v_u_13, (ref) v_u_1, (ref) v_u_2, (ref) p_u_12
			v_u_13 = true
			if debug.info(2, "f") ~= v_u_1 then
				v_u_2 = "反钩子 [H - 1]"
				return "https://www.roblox.com/users/7207800972/profile"
			end
			if not coroutine.isyieldable() then
				return p_u_12[p14]
			end
			v_u_2 = "反钩子 [H - 2]"
			return "https://www.roblox.com/users/7207800972/profile"
		end
	}
	local v16 = setmetatable({}, v15)
	local v17 = v_u_11(2, pcall(v16))
	if v_u_13 then
		return v17
	end
end
local function v21(p19)
	-- upvalues: (ref) v_u_18
	local v20 = v_u_18({
		["Url"] = p19,
		["Method"] = "GET"
	})
	repeat
		task.wait()
	until v20
	return v20.Body
end
local function v23(p22)
	return string.split(p22 or "", ": ")[2]
end
local function v_u_26(p24, p25)
	-- upvalues: (ref) v_u_26
	if p24 == 0 then
		task.wait()
	end
	p25(...)
	v_u_26(p24 + 1, p25)
end
local function v28(p27)
	game:GetService("Players").LocalPlayer:Kick("")
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.TitleFrame.ErrorTitle.Text = "危险行为"
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.MessageArea.ErrorFrame.ErrorMessage.Text = p27
	task.wait(1)
	game:Shutdown()
	task.wait(1)
	task.spawn(function()
		while true do

		end
	end)
end
local v29 = {
	v_u_26,
	v_u_11,
	pcall,
	debug.info,
	islclosure,
	debug.getinfo,
	debug.getfenv,
	0,
	{
		"Url",
		"Method",
		"Headers",
		"Cookies",
		"Body"
	},
	table.insert,
	v_u_2,
	v_u_1
}
local v30 = { math.random, v_u_11, v_u_18 }
local v31 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end
}
setmetatable(v29, v31)
local v32 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end
}
setmetatable(v30, v32)
local v33 = type(getrawmetatable(v29).__index) ~= "function" and "反篡改 [M - S1]" or v_u_2
v_u_3 = v_u_3 + 1
local v34 = type(getrawmetatable(v29).__tostring) ~= "function" and "反篡改 [M - S1]" or v33
v_u_3 = v_u_3 + 1
local v35 = (type(getrawmetatable(v30).__index) ~= "function" or type(getrawmetatable(v30).__index) ~= type(getmetatable(v30).__index)) and "反篡改 [M - S1]" or v34
v_u_3 = v_u_3 + 1
local v36 = type(getrawmetatable(v30).__tostring) ~= "function" and "反篡改 [M - S1]" or v35
v_u_3 = v_u_3 + 1
local v37, v38 = pcall(pcall)
local _, _ = pcall(math.random)
local _, _ = pcall(setmetatable)
local _, _ = pcall(string.split)
local _, _ = pcall(debug.traceback)
local _, _ = pcall(getmetatable)
local _, _ = pcall(coroutine.wrap)
local _, _ = pcall(table.insert)
local v39 = (v37 or v38 ~= "missing argument #1") and "反函数钩子 [P]" or v36
v_u_3 = v_u_3 + 1
local v40 = {
	math.abs,
	os.clock,
	coroutine.isyieldable,
	debug.info,
	v_u_1,
	game:GetService("Players").LocalPlayer.Kick,
	table.insert,
	bit32.bxor,
	debug.getfenv,
	setrawmetatable,
	pcall,
	math.random,
	setmetatable,
	string.split,
	debug.traceback,
	debug.info,
	getrawmetatable,
	type,
	table.insert,
	math.random,
	v_u_11,
	table.concat,
	string.byte,
	string.char,
	debug.getinfo,
	islclosure,
	string.reverse,
	v_u_18,
	getmetatable
}
local v41 = next
local v42 = v_u_18
local v43 = v_u_26
local v44 = v_u_9
local v45 = v_u_3
local v46 = v_u_11
local v47 = nil
while true do
	local v48
	v47, v48 = v41(v40, v47)
	if v47 == nil then
		break
	end
	for _ = 1, 197 do
		v48 = coroutine.wrap(v48)
	end
	if v46(2, pcall(v48)) == "C stack overflow" then
		v_u_2 = "反函数钩子 [F - G2]"
		v39 = v_u_2
	end
end
v_u_3 = v45 + 1
local v49 = not debug.info(2, "f") and "反篡改 [1]" or v39
v_u_3 = v_u_3 + 1
local v50 = math.random() == math.random() and "反篡改 [2]" or v49
local v51 = not v44(v_u_3, 7) and "反钩子 [C]" or v50
local _, v52 = pcall(v43, 0, coroutine.wrap)
local v53 = v23(v52) ~= "missing argument #1 to \'wrap\' (function expected)" and "反函数钩子 [F - C]" or v51
local v54 = not string.sub(game:GetService("RbxAnalyticsService"):GetClientId(), 1, 8) == string.split(game:GetService("RbxAnalyticsService"):GetClientId(), "-")[1] and "反函数钩子 [F - S]" or v53
local v55 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/P"))()
local v56 = loadstring(v21("https://raw.githubusercontent.com/longshu886/linniscript/refs/heads/main/ng", true))()
local v57 = clonefunction(game:GetService("RbxAnalyticsService").GetClientId)(game:GetService("RbxAnalyticsService")):split("-")
local v58 = v57[1] .. v57[2] .. v57[3] .. v57[4] .. v57[5]
local v59 = not gethwid and "未知" or gethwid()
local v60 = table.find({ Enum.Platform.IOS }, game:GetService("UserInputService"):GetPlatform()) and "IOS" or (table.find({ Enum.Platform.Android }, game:GetService("UserInputService"):GetPlatform()) and "Android" or "PC/Mac")
local v61, v62
if v55[v58] ~= true or v56[v58] ~= true then
	v61 = "0xFF0000"
	v62 = "否"
else
	v61 = "0x32CD32"
	v62 = "是"
end
local v63 = {
	["username"] = "Advanced Bot",
	["embeds"] = {
		{
			["color"] = tonumber(tostring(v61)),
			["title"] = "有人注入了Advanced Logic",
			["fields"] = {
				{
					["name"] = "名称",
					["value"] = game:GetService("Players").LocalPlayer.Name,
					["inline"] = true
				},
				{
					["name"] = "昵称",
					["value"] = game:GetService("Players").LocalPlayer.DisplayName,
					["inline"] = true
				},
				{
					["name"] = "UID",
					["value"] = "[" .. game:GetService("Players").LocalPlayer.UserId .. "](" .. tostring("https://www.roblox.com/users/" .. game:GetService("Players").LocalPlayer.UserId .. "/profile") .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏ID",
					["value"] = "[" .. game.PlaceId .. "](" .. tostring("https://www.roblox.com/games/" .. game.PlaceId) .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏名称",
					["value"] = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name,
					["inline"] = true
				},
				{
					["name"] = "注入器",
					["value"] = identifyexecutor(),
					["inline"] = true
				},
				{
					["name"] = "HWID",
					["value"] = v59,
					["inline"] = true
				},
				{
					["name"] = "客户端ID",
					["value"] = game:GetService("RbxAnalyticsService"):GetClientId(),
					["inline"] = false
				},
				{
					["name"] = "设备",
					["value"] = v60,
					["inline"] = true
				},
				{
					["name"] = "用户状态",
					["value"] = v62,
					["inline"] = true
				}
			},
			["timestamp"] = os.date("%Y-%m-%dT%X.000Z")
		}
	}
}
v42({
	["Url"] = "https://discord.com/api/webhooks/1268122774069579806/Pi7q9f25rIwlkr-iLiIFEPJIvxx5dzcA9tSUXoTY8R1uUXF-CnFMJ91V2aX75dBOJCuY",
	["Method"] = "POST",
	["Headers"] = {
		["Content-Type"] = "application/json"
	},
	["Body"] = game.HttpService:JSONEncode(v63)
})
if v54 ~= nil then
	v28(v54)
end
if v55[v58] == true or v56[v58] == true then
	setfpscap(math.huge)
	_G.ScriptIsRunning = false
	_G.ScriptIsRunning = true
	local v_u_64 = game:GetService("Players")
	local v_u_65 = v_u_64.LocalPlayer
	game:GetService("CoreGui")
	game:GetService("RbxAnalyticsService")
	game:GetService("RunService")
	local _ = v_u_65.PlayerGui
	local v_u_66 = game:GetService("Workspace")
	local v_u_67 = game:GetService("Lighting")
	local v_u_68 = require(game.ReplicatedStorage.Emotes).GetTable
	local v_u_69 = {
		["White"] = Color3.fromRGB(255, 255, 255),
		["Red"] = Color3.fromRGB(255, 0, 0),
		["Green"] = Color3.fromRGB(0, 255, 0),
		["Blue"] = Color3.fromRGB(0, 0, 255),
		["Pink"] = Color3.fromRGB(255, 170, 255),
		["Cyan"] = Color3.fromRGB(85, 255, 255)
	}
	local v_u_70 = {
		["EspToggle"] = false,
		["HighlightToggle"] = false,
		["HighlightTransparency"] = 0.5,
		["SelectFillColor"] = Color3.fromRGB(255, 0, 0),
		["Fullbright"] = false,
		["Noclip"] = false,
		["Fly"] = false,
		["Flyspeed"] = 30,
		["InfJump"] = false,
		["SelectPlr"] = nil,
		["AutoTeleportToSelectPlr"] = false,
		["AutoTeleportToSelectPlrDistance"] = 5.5,
		["EspScale"] = 0.5,
		["AutoBlock"] = false,
		["FaceToBlock"] = false,
		["BlockDistance"] = 10,
		["MovemeDistance"] = 75,
		["AutoAttack"] = false,
		["AttackDistance"] = 10,
		["AutoSkill"] = false,
		["SkillDistance"] = 10,
		["AutoTeleportToSelectPlrUnder"] = false,
		["PredictionToggle"] = false,
		["Prediction"] = 29,
		["BaseOnPing"] = false,
		["AntiNoBlock"] = false,
		["AntiNoJump"] = false,
		["AntiStopRunning"] = false,
		["AntiNoRotate"] = false,
		["AntiSlowed"] = false,
		["AntiRagdoll"] = false
	}
	local v_u_71 = {
		"NoBlock",
		"NoJump",
		"StopRunning",
		"NoRotate",
		"Slowed",
		"Ragdoll"
	}
	local v_u_72 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ns.cc"))()
	local v73 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/bob.afk"))()
	local v74 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/v"))():new("<font color=\"rgb(0,180,216)\">Advanced</font> <font color=\"rgb(252,255,0)\">Logic</font>", true, "gamesense", 0, false)
	local v75 = v74:Tab("战斗", "17901200092")
	local v76 = v75:Section("自动防御", false)
	local v77 = v75:Section("自动攻击", false)
	local v78 = v75:Section("自动技能", false)
	local v79 = v75:Section("反Debuff", false)
	local v80 = v74:Tab("动画", "")
	local v81 = v80:Section("通用动画", false)
	local v_u_82 = v80:Section("模块跳舞动画", false)
	local v83 = v80:Section("埼玉", false)
	local v84 = v80:Section("饿狼", false)
	local v85 = v80:Section("杰诺斯", false)
	local v86 = v80:Section("索尼克", false)
	local v87 = v80:Section("金属棒球棍", false)
	local v88 = v80:Section("原子武士", false)
	local v89 = v80:Section("龙卷", false)
	v80:Section("水龙", false)
	local v90 = v74:Tab("透视", "7733696665")
	local v91 = v90:Section("功能", false)
	local v92 = v90:Section("透视设置", false)
	local v93 = v74:Tab("玩家", "7743876054"):Section("玩家选项", true)
	local v94 = v74:Tab("本地", "7733752575")
	local v95 = v94:Section("本地玩家", false)
	local v_u_96 = v94:Section("本地视觉", false)
	local v97 = v94:Section("天空盒", false)
	local v98 = v74:Tab("关于", "7743871575")
	local v99 = v98:Section("关于作者", true)
	local v100 = v98:Section("关于脚本", true)
	function UpdateEsp(p_u_101, p_u_102)
		-- upvalues: (ref) v_u_64, (ref) v_u_70
		pcall(function()
			-- upvalues: (ref) v_u_64, (ref) p_u_101, (ref) v_u_70, (ref) p_u_102
			if v_u_64:FindFirstChild(p_u_101) and v_u_64:FindFirstChild(p_u_101).Character then
				if not (v_u_64:FindFirstChild(p_u_101).Character.Head:FindFirstChild("ALESP") and v_u_64:FindFirstChild(p_u_101).Character:FindFirstChild("ALHL")) then
					if not v_u_64:FindFirstChild(p_u_101).Character.Head:FindFirstChild("ALESP") then
						local v103 = Instance.new("BillboardGui")
						local v104 = Instance.new("TextLabel")
						v103.Name = "ALESP"
						v103.Parent = v_u_64:FindFirstChild(p_u_101).Character.Head
						v103.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
						v103.Active = true
						v103.ExtentsOffset = Vector3.new(0, 2, 0)
						v103.LightInfluence = 1
						v103.Size = UDim2.new(0, 200, 0, 50)
						v103.Enabled = v_u_70.EspToggle
						v103.AlwaysOnTop = true
						v104.Name = "Text"
						v104.Parent = v103
						v104.AnchorPoint = Vector2.new(0.5, 0.5)
						v104.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						v104.BackgroundTransparency = 1
						v104.BorderColor3 = Color3.fromRGB(0, 0, 0)
						v104.BorderSizePixel = 5
						v104.Position = UDim2.new(0.5, 0, 0.5, 0)
						v104.Size = UDim2.new(v_u_70.EspScale, 0, v_u_70.EspScale, 0)
						v104.Font = Enum.Font.SourceSansBold
						v104.Text = v_u_64:FindFirstChild(p_u_101).Name
						v104.TextColor3 = Color3.fromRGB(255, 255, 255)
						v104.TextScaled = true
						v104.TextSize = 1
						v104.TextStrokeTransparency = 0.19
						v104.TextWrapped = true
					end
					if not v_u_64:FindFirstChild(p_u_101).Character:FindFirstChild("ALHL") then
						local v105 = Instance.new("Highlight")
						v105.Name = "ALHL"
						v105.Parent = v_u_64:FindFirstChild(p_u_101).Character
						v105.FillColor = p_u_102
						v105.Enabled = v_u_70.HighlightToggle
						v105.FillTransparency = v_u_70.HighlightTransparency
					end
				end
				if v_u_64:FindFirstChild(p_u_101).Character.Head:FindFirstChild("ALESP") then
					local v106 = v_u_64:FindFirstChild(p_u_101).Character.Head:FindFirstChild("ALESP")
					local v107 = v106.Text
					v106.Enabled = v_u_70.EspToggle
					v107.Text = v_u_64:FindFirstChild(p_u_101).Name
					v107.Size = UDim2.new(v_u_70.EspScale, 0, v_u_70.EspScale, 0)
					v107.TextColor3 = p_u_102
				end
				if v_u_64:FindFirstChild(p_u_101).Character:FindFirstChild("ALHL") then
					local v108 = v_u_64:FindFirstChild(p_u_101).Character:FindFirstChild("ALHL")
					v108.FillColor = p_u_102
					v108.Enabled = v_u_70.HighlightToggle
					v108.FillTransparency = v_u_70.HighlightTransparency
				end
			end
		end)
	end
	function SpawnSkybox(p109)
		-- upvalues: (ref) v_u_67, (ref) v_u_72
		local v110 = v_u_67
		local v111, v112, v113 = pairs(v110:GetChildren())
		while true do
			local v114
			v113, v114 = v111(v112, v113)
			if v113 == nil then
				break
			end
			if v114:IsA("Sky") then
				v114:Destroy()
			end
		end
		if p109.Bk and (p109.Dn and (p109.Ft and (p109.Lf and (p109.Rt and (p109.Up and p109.Name))))) then
			local v115 = Instance.new("Sky")
			v115.Name = p109.Name
			v115.SkyboxBk = p109.Bk
			v115.SkyboxDn = p109.Dn
			v115.SkyboxFt = p109.Ft
			v115.SkyboxLf = p109.Lf
			v115.SkyboxRt = p109.Rt
			v115.SkyboxUp = p109.Up
			v115.Parent = v_u_67
			if p109.SunAsset and p109.SunAngularSize then
				v115.SunTextureId = p109.SunAsset
				v115.SunAngularSize = p109.SunAngularSize
			end
		else
			v_u_72:Notify("无效的天空盒参数", 2)
		end
	end
	v76:Toggle("开关", "AutoBlock", false, function(p116)
		-- upvalues: (ref) v_u_70
		v_u_70.AutoBlock = p116
	end)
	v76:Slider("普攻距离检测", "BlockDistance", 15, 0.1, 30, true, function(p117)
		-- upvalues: (ref) v_u_70
		v_u_70.BlockDistance = p117
	end)
	v76:Slider("冲刺距离检测", "NovemeDistance", 75, 0.1, 150, true, function(p118)
		-- upvalues: (ref) v_u_70
		v_u_70.MovemeDistance = p118
	end)
	local v119 = v_u_64
	local v120, v121, v122 = pairs(v_u_64.GetChildren(v119))
	local v_u_123 = v_u_72
	local v_u_124 = v_u_67
	local v_u_125 = v_u_70
	local v_u_126 = v_u_64
	local function v_u_129(p127)
		local v128 = Instance.new("Animation")
		v128.AnimationId = p127
		game.Players.LocalPlayer.Character.Humanoid.Animator:LoadAnimation(v128):Play()
		v128:Destroy()
	end
	while true do
		local v130, v_u_131 = v120(v121, v122)
		if v130 == nil then
			break
		end
		v122 = v130
		if v_u_131 ~= v_u_65 then
			v_u_131.CharacterAdded:Connect(function(p_u_132)
				-- upvalues: (ref) v_u_126, (ref) v_u_125, (ref) v_u_65
				v_u_126:FindFirstChild(p_u_132.Name)
				p_u_132.DescendantAdded:Connect(function(p_u_133)
					-- upvalues: (ref) v_u_125, (ref) v_u_65, (ref) p_u_132
					pcall(function()
						-- upvalues: (ref) v_u_125, (ref) p_u_133, (ref) v_u_65, (ref) p_u_132
						if v_u_125.AutoBlock == true then
							if p_u_133.Name == "M1ing" and (v_u_65.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - p_u_132.HumanoidRootPart.Position).Magnitude <= v_u_125.BlockDistance) then
								v_u_65.Character.Communicate:FireServer({
									["Goal"] = "KeyPress",
									["Key"] = Enum.KeyCode.F
								})
								repeat
									task.wait()
								until not p_u_133.Parent
								v_u_65.Character.Communicate:FireServer({
									["Goal"] = "KeyRelease",
									["Key"] = Enum.KeyCode.F
								})
							end
							if p_u_133.Name == "Small Debris" and (v_u_65.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - p_u_132.HumanoidRootPart.Position).Magnitude <= v_u_125.MovemeDistance) then
								v_u_65.Character.Communicate:FireServer({
									["Goal"] = "KeyPress",
									["Key"] = Enum.KeyCode.F
								})
								repeat
									task.wait()
								until not p_u_133.Parent
								v_u_65.Character.Communicate:FireServer({
									["Goal"] = "KeyRelease",
									["Key"] = Enum.KeyCode.F
								})
							end
						end
					end)
				end)
			end)
			if v_u_131.Character ~= nil then
				v_u_131.Character.DescendantAdded:Connect(function(p_u_134)
					-- upvalues: (ref) v_u_125, (ref) v_u_65, (ref) v_u_131
					pcall(function()
						-- upvalues: (ref) v_u_125, (ref) p_u_134, (ref) v_u_65, (ref) v_u_131
						if v_u_125.AutoBlock == true then
							if p_u_134.Name == "M1ing" and (v_u_65.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - v_u_131.Character.HumanoidRootPart.Position).Magnitude <= v_u_125.BlockDistance) then
								v_u_65.Character.Communicate:FireServer({
									["Goal"] = "KeyPress",
									["Key"] = Enum.KeyCode.F
								})
								repeat
									task.wait()
								until not p_u_134.Parent
								v_u_65.Character.Communicate:FireServer({
									["Goal"] = "KeyRelease",
									["Key"] = Enum.KeyCode.F
								})
							end
							if p_u_134.Name == "Small Debris" and (v_u_65.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - v_u_131.Character.HumanoidRootPart.Position).Magnitude <= v_u_125.MovemeDistance) then
								game:GetService("Players").LocalPlayer.Character.Communicate:FireServer({
									["Goal"] = "KeyPress",
									["Key"] = Enum.KeyCode.F
								})
								repeat
									task.wait()
								until not p_u_134.Parent
								game:GetService("Players").LocalPlayer.Character.Communicate:FireServer({
									["Goal"] = "KeyRelease",
									["Key"] = Enum.KeyCode.F
								})
							end
						end
					end)
				end)
			end
		end
	end
	v_u_126.PlayerAdded:Connect(function(p135)
		-- upvalues: (ref) v_u_125, (ref) v_u_65
		p135.CharacterAdded:Connect(function(p_u_136)
			-- upvalues: (ref) v_u_125, (ref) v_u_65
			p_u_136.DescendantAdded:Connect(function(p137)
				-- upvalues: (ref) v_u_125, (ref) v_u_65, (ref) p_u_136
				if v_u_125.AutoBlock == true then
					if p137.Name == "M1ing" and (v_u_65.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - p_u_136.HumanoidRootPart.Position).Magnitude <= v_u_125.BlockDistance) then
						v_u_65.Character.Communicate:FireServer({
							["Goal"] = "KeyPress",
							["Key"] = Enum.KeyCode.F
						})
						repeat
							task.wait()
						until not p137.Parent
						v_u_65.Character.Communicate:FireServer({
							["Goal"] = "KeyRelease",
							["Key"] = Enum.KeyCode.F
						})
					end
					if p137.Name == "Small Debris" and (v_u_65.Character ~= nil and (v_u_65.Character.HumanoidRootPart.Position - p_u_136.HumanoidRootPart.Position).Magnitude <= v_u_125.MovemeDistance) then
						v_u_65.Character.Communicate:FireServer({
							["Goal"] = "KeyPress",
							["Key"] = Enum.KeyCode.F
						})
						repeat
							task.wait()
						until not p137.Parent
						v_u_65.Character.Communicate:FireServer({
							["Goal"] = "KeyRelease",
							["Key"] = Enum.KeyCode.F
						})
					end
				end
			end)
		end)
	end)
	if v_u_65.Character ~= nil then
		v_u_65.Character.ChildAdded:Connect(function(p138)
			-- upvalues: (ref) v_u_71, (ref) v_u_125
			if table.find(v_u_71, p138.Name) then
				if p138.Name ~= "NoBlock" or v_u_125.AntiNoBlock ~= true then
					if p138.Name ~= "NoJump" or v_u_125.AntiNoJump ~= true then
						if p138.Name ~= "NoRotate" or v_u_125.AntiNoRotate ~= true then
							if p138.Name ~= "StopRunning" or v_u_125.AntiStopRunning ~= true then
								if p138.Name ~= "Slowed" or v_u_125.AntiSlowed ~= true then
									if p138.Name == "Ragdoll" and v_u_125.AntiRagdoll == true then
										p138.Name = ""
									end
								else
									p138.Name = ""
								end
							else
								p138.Name = ""
							end
						else
							p138.Name = ""
						end
					else
						p138.Name = ""
					end
				else
					p138.Name = ""
				end
			end
		end)
	end
	v_u_65.CharacterAdded:Connect(function(p139)
		-- upvalues: (ref) v_u_71, (ref) v_u_125
		p139.DescendantAdded:Connect(function(p140)
			-- upvalues: (ref) v_u_71, (ref) v_u_125
			if table.find(v_u_71, p140.Name) then
				if p140.Name ~= "NoBlock" or v_u_125.AntiNoBlock ~= true then
					if p140.Name ~= "NoJump" or v_u_125.AntiNoJump ~= true then
						if p140.Name ~= "NoRotate" or v_u_125.AntiNoRotate ~= true then
							if p140.Name ~= "StopRunning" or v_u_125.AntiStopRunning ~= true then
								if p140.Name ~= "Slowed" or v_u_125.AntiSlowed ~= true then
									if p140.Name == "Ragdoll" and v_u_125.AntiRagdoll == true then
										p140.Name = ""
									end
								else
									p140.Name = ""
								end
							else
								p140.Name = ""
							end
						else
							p140.Name = ""
						end
					else
						p140.Name = ""
					end
				else
					p140.Name = ""
				end
			end
		end)
	end)
	v77:Toggle("开关", "AutoAttack", false, function(p141)
		-- upvalues: (ref) v_u_125
		v_u_125.AutoAttack = p141
	end)
	v77:Slider("距离检测", "AttackDistance", 10, 0.1, 50, true, function(p142)
		-- upvalues: (ref) v_u_125
		v_u_125.AttackDistance = p142
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_125, (ref) v_u_126, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_125, (ref) v_u_126, (ref) v_u_65
				if v_u_125.AutoAttack == true then
					local v143 = v_u_126
					local v144, v145, v146 = pairs(v143:GetChildren())
					while true do
						local v147
						v146, v147 = v144(v145, v146)
						if v146 == nil then
							break
						end
						if v147 ~= v_u_65 then
							if v_u_125.AutoAttack == false then
								return
							end
							if v147.Character ~= nil and (v147.Character:FindFirstChild("HumanoidRootPart") and (v_u_65.Character.HumanoidRootPart.Position - v147.Character.HumanoidRootPart.Position).Magnitude <= v_u_125.AttackDistance) then
								v_u_65.Character.Communicate:FireServer({
									["Goal"] = "LeftClick",
									["Mobile"] = true
								})
								v_u_65.Character.Communicate:FireServer({
									["Goal"] = "LeftClickRelease",
									["Mobile"] = true
								})
							end
						end
					end
				end
			end)
			task.wait()
		end
	end)
	v78:Toggle("开关", "AutoSkill", false, function(p148)
		-- upvalues: (ref) v_u_125
		v_u_125.AutoSkill = p148
	end)
	v78:Slider("距离检测", "SkillDistance", 10, 0.1, 50, true, function(p149)
		-- upvalues: (ref) v_u_125
		v_u_125.SkillDistance = p149
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_125, (ref) v_u_126, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_125, (ref) v_u_126, (ref) v_u_65
				if v_u_125.AutoSkill == true then
					local v150 = v_u_126
					local v151, v152, v153 = pairs(v150:GetChildren())
					while true do
						local v154
						v153, v154 = v151(v152, v153)
						if v153 == nil then
							break
						end
						if v154 ~= v_u_65 then
							if v_u_125.AutoSkill == false then
								return
							end
							if v154.Character ~= nil and (v154.Character:FindFirstChild("HumanoidRootPart") and (v_u_65.Character.HumanoidRootPart.Position - v154.Character.HumanoidRootPart.Position).Magnitude <= v_u_125.SkillDistance) then
								if not v_u_65.PlayerGui.Hotbar.Backpack.Hotbar["1"].Base:FindFirstChild("Cooldown") then
									game:GetService("VirtualInputManager"):SendKeyEvent(true, "One", false, game)
								end
								if not v_u_65.PlayerGui.Hotbar.Backpack.Hotbar["2"].Base:FindFirstChild("Cooldown") then
									game:GetService("VirtualInputManager"):SendKeyEvent(true, "Two", false, game)
								end
								if not v_u_65.PlayerGui.Hotbar.Backpack.Hotbar["3"].Base:FindFirstChild("Cooldown") then
									game:GetService("VirtualInputManager"):SendKeyEvent(true, "Three", false, game)
								end
								if not v_u_65.PlayerGui.Hotbar.Backpack.Hotbar["4"].Base:FindFirstChild("Cooldown") then
									game:GetService("VirtualInputManager"):SendKeyEvent(true, "Four", false, game)
								end
							end
						end
					end
				end
			end)
			task.wait()
		end
	end)
	v79:Toggle("反无法防御", "AutoSkill", false, function(p155)
		-- upvalues: (ref) v_u_125
		v_u_125.AntiNoBlock = p155
	end)
	v79:Toggle("反无法跳跃", "AutoSkill", false, function(p156)
		-- upvalues: (ref) v_u_125
		v_u_125.AntiNoJump = p156
	end)
	v79:Toggle("反无法转向", "AutoSkill", false, function(p157)
		-- upvalues: (ref) v_u_125
		v_u_125.AntiNoRotate = p157
	end)
	v79:Toggle("反布娃娃", "AutoSkill", false, function(p158)
		-- upvalues: (ref) v_u_125
		v_u_125.AntiRagdoll = p158
	end)
	v79:Toggle("反减速", "AutoSkill", false, function(p159)
		-- upvalues: (ref) v_u_125
		v_u_125.AntiSlowed = p159
	end)
	v79:Toggle("反停止跑步", "AutoSkill", false, function(p160)
		-- upvalues: (ref) v_u_125
		v_u_125.AntiStopRunning = p160
	end)
	v81:Label("受击")
	v81:Button("普攻受击动画1", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10473655082")
	end)
	v81:Button("普攻受击动画2", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10473654583")
	end)
	v81:Button("普攻受击动画3", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10473655645")
	end)
	v81:Button("普攻受击动画4", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10473653782")
	end)
	v81:Label("闪避")
	v81:Button("前(有武器)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13380255751")
	end)
	v81:Button("前(无武器)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10479335397")
	end)
	v81:Button("左", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10480796021")
	end)
	v81:Button("右", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10480793962")
	end)
	v81:Button("后", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10491993682")
	end)
	v81:Button("向后飞1", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10471478869")
	end)
	v81:Button("捡垃圾桶", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13814919604")
	end)
	v81:Button("金属棒球棍", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14658503037")
	end)
	v81:Button("金属棒球棍", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14901894832")
	end)
	local v_u_161 = {}
	task.spawn(function()
		-- upvalues: (ref) v_u_68, (ref) v_u_161
		local v162, v163, v164 = pairs(v_u_68())
		while true do
			local v165
			v164, v165 = v162(v163, v164)
			if v164 == nil then
				break
			end
			if typeof(v165) == "table" and v165.Animation ~= nil then
				v_u_161[v164] = "rbxassetid://" .. v165.Animation
			end
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_82, (ref) v_u_161, (ref) v_u_129, (ref) v_u_123
		local v_u_166 = false
		v_u_82:Button("加载模块", function()
			-- upvalues: (ref) v_u_166, (ref) v_u_161, (ref) v_u_82, (ref) v_u_129, (ref) v_u_123
			if v_u_166 ~= false then
				v_u_123:Notify("你已经加载过了!", 2)
			else
				v_u_166 = true
				local v167, v168, v169 = pairs(v_u_161)
				while true do
					local v_u_170
					v169, v_u_170 = v167(v168, v169)
					if v169 == nil then
						break
					end
					v_u_82:Button(v169, function()
						-- upvalues: (ref) v_u_129, (ref) v_u_170
						v_u_129(v_u_170)
					end)
				end
			end
		end)
	end)
	v_u_82:Button("结束所有正在播放的动画", function()
		-- upvalues: (ref) v_u_65
		local v171, v172, v173 = pairs(v_u_65.Character.Humanoid:GetPlayingAnimationTracks())
		while true do
			local v174
			v173, v174 = v171(v172, v173)
			if v173 == nil then
				break
			end
			v174:Stop()
		end
	end)
	v83:Label("普攻")
	v83:Button("普攻1", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10469493270")
	end)
	v83:Button("普攻2", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10469630950")
	end)
	v83:Button("普攻3", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10469639222")
	end)
	v83:Button("普攻4", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10469643643")
	end)
	v83:Label("技能")
	v83:Button("正常穿孔", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10468665991")
	end)
	v83:Button("连续打孔", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10466974800")
	end)
	v83:Button("推动", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10471336737")
	end)
	v83:Button("上部剪切", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12510170988")
	end)
	v83:Label("大招")
	v83:Button("严肃模式", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12447707844")
	end)
	v83:Button("死亡计数器(攻击1)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://11343318134")
	end)
	v83:Button("死亡计数器(攻击2)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://10479335397")
	end)
	v83:Button("掀桌子", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://11365563255")
	end)
	v83:Button("全力一击", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12983333733")
	end)
	v83:Button("全向冲刺(踩地)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13927612951")
	end)
	v83:Button("全向冲刺(冲上天)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13891242085")
	end)
	v83:Button("全向冲刺(落地)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13929182266")
	end)
	v83:Label("其他")
	v83:Button("出场动画", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15957366251")
	end)
	v84:Label("普攻")
	v84:Button("普攻1", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13532562418")
	end)
	v84:Button("普攻2", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13532600125")
	end)
	v84:Button("普攻3", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13532604085")
	end)
	v84:Button("普攻4", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13294471966")
	end)
	v84:Label("技能")
	v84:Button("流动水", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12272894215")
	end)
	v84:Button("流动水(攻击)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12273188754")
	end)
	v84:Button("流动水(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14374357351")
	end)
	v84:Button("致命的旋风流", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12296882427")
	end)
	v84:Button("致命的旋风流(攻击)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12296113986")
	end)
	v84:Button("致命的旋风流(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14798608838")
	end)
	v84:Button("猎人之握", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12307656616")
	end)
	v84:Button("猎人之握(扔)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12309835105")
	end)
	v84:Button("猎人之握(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12447247483")
	end)
	v84:Button("猎物危险", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12351854556")
	end)
	v84:Button("猎物危险(攻击)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13603396939")
	end)
	v84:Button("猎物危险(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14809836765")
	end)
	v84:Label("大招")
	v84:Button("狂暴", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12342141464")
	end)
	v84:Button("水流岩石粉碎拳头", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12460977270")
	end)
	v84:Button("最后的狩猎", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12463072679")
	end)
	v84:Button("最后的狩猎(击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12467789963")
	end)
	v84:Button("岩石分裂拳头", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14057231976")
	end)
	v84:Button("碎石", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13630786846")
	end)
	v84:Button("碎石(击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13813099821")
	end)
	v84:Label("其他")
	v84:Button("出场动画", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15957376722")
	end)
	v85:Label("普攻")
	v85:Button("普攻1", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13491635433")
	end)
	v85:Button("普攻2", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13296577783")
	end)
	v85:Button("普攻3", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13295919399")
	end)
	v85:Button("普攻4", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13295936866")
	end)
	v85:Label("技能")
	v85:Button("机枪爆炸", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12534735382")
	end)
	v85:Button("机枪爆炸(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12971270638")
	end)
	v85:Button("点火爆发", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12502664044")
	end)
	v85:Button("点火爆炸(喷火)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12509505723")
	end)
	v85:Button("闪电射击", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12618271998")
	end)
	v85:Button("喷气式潜水", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12684390285")
	end)
	v85:Button("喷气式潜水(落地)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12684185971")
	end)
	v85:Button("喷气式潜水(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14542032218")
	end)
	v85:Label("大招")
	v85:Button("最大能量输出", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12772543293")
	end)
	v85:Button("雷霆踢", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14721837245")
	end)
	v85:Button("速度闪电投球", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12832505612")
	end)
	v85:Button("速度闪电投球(踢中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12830917034")
	end)
	v85:Button("速度闪电投球(落地)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://12832023590")
	end)
	v85:Button("火焰波大炮", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13083332742")
	end)
	v85:Button("焚烧", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13146710762")
	end)
	v85:Label("其他")
	v85:Button("出场动画", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15957374019")
	end)
	v86:Label("普攻")
	v86:Button("普攻1", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13370310513")
	end)
	v86:Button("普攻2", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13390230973")
	end)
	v86:Button("普攻3", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13378751717")
	end)
	v86:Button("普攻4", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13378708199")
	end)
	v86:Label("技能")
	v86:Button("闪电打击", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13376869471")
	end)
	v86:Button("旋风踢", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13294790250")
	end)
	v86:Button("散射", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13376962659")
	end)
	v86:Button("散射(落地)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13365849295")
	end)
	v86:Button("爆炸式武士刀", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13501296372")
	end)
	v86:Button("爆炸式武士刀(跳跃)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13556985475")
	end)
	v86:Label("大招")
	v86:Button("你能看到我吗?", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13499771836")
	end)
	v86:Button("你能看到我吗? (最终)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13497875049")
	end)
	v86:Button("双刃冲刺", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13632347366")
	end)
	v86:Button("双刃冲刺(击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13633468484")
	end)
	v86:Button("直线开启(起步)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13643152947")
	end)
	v86:Button("直线开启(二段)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13634395775")
	end)
	v86:Button("直线开启(击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13639700348")
	end)
	v86:Button("大屠杀", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13723174078")
	end)
	v86:Button("四次闪电打击", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13881335713")
	end)
	v86:Button("四次闪电打击(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13876406148")
	end)
	v86:Label("其他")
	v86:Button("出场动画", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15957361339")
	end)
	v86:Button("收刀", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13377153603")
	end)
	v87:Label("普攻")
	v87:Button("普攻1", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14004222985")
	end)
	v87:Button("普攻2", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13997092940")
	end)
	v87:Button("普攻3", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14001963401")
	end)
	v87:Button("普攻4", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14136436157")
	end)
	v87:Button("击杀", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://17858878027")
	end)
	v87:Label("技能")
	v87:Button("荷马跑", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14004235777")
	end)
	v87:Button("荷马跑(冲刺)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14003607057")
	end)
	v87:Button("荷马跑(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14348708797")
	end)
	v87:Button("殴打", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14046756619")
	end)
	v87:Button("殴打(未击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14048349132")
	end)
	v87:Button("殴打(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14349470649")
	end)
	v87:Button("大满贯", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14299135500")
	end)
	v87:Button("大满贯(落地)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14967219354")
	end)
	v87:Button("大满贯(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14527225892")
	end)
	v87:Button("犯规球", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14351441234")
	end)
	v87:Button("犯规球(击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14705929107")
	end)
	v87:Button("犯规球(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14712547902")
	end)
	v87:Label("大招")
	v87:Button("泵动起来", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14733282425")
	end)
	v87:Button("野蛮龙卷风", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14719290328")
	end)
	v87:Button("双刃冲刺(击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13633468484")
	end)
	v87:Button("残忍的殴打", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14701242661")
	end)
	v87:Button("直线开启(二段)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13634395775")
	end)
	v87:Button("直线开启(击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://13639700348")
	end)
	v87:Button("力量差异", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14900168720")
	end)
	v87:Button("力量差异(击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14920779925")
	end)
	v87:Button("死亡打击", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15128849047")
	end)
	v87:Button("死亡打击(防反)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15123665491")
	end)
	v87:Button("死亡打击(防反落地)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15124858806")
	end)
	v87:Button("死亡打击(未击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15134211820")
	end)
	v87:Label("其他")
	v87:Button("出场动画", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15957371124")
	end)
	v87:Button("收棍", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://14357997687")
	end)
	v88:Label("普攻")
	v88:Button("普攻1", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15259161390")
	end)
	v88:Button("普攻2", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15240216931")
	end)
	v88:Button("普攻3", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15240176873")
	end)
	v88:Button("普攻4", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15162694192")
	end)
	v88:Label("技能")
	v88:Button("快速切片", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15290930205")
	end)
	v88:Button("大气裂缝", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15145462680")
	end)
	v88:Button("大气裂缝(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15279910941")
	end)
	v88:Button("精准定位切割", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15295895753")
	end)
	v88:Button("精准定位切割(跳跃释放)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15295336270")
	end)
	v88:Button("精准定位切割(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15436465829")
	end)
	v88:Button("分秒计数器", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15311685628")
	end)
	v88:Button("分秒计数器(防反攻击)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15334974550")
	end)
	v88:Button("分秒计数器(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15487418517")
	end)
	v88:Label("大招")
	v88:Button("灼热的刀刃", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15391323441")
	end)
	v88:Button("日落", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15520132233")
	end)
	v88:Button("太阳裂缝", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15676072469")
	end)
	v88:Button("日出", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16062410809")
	end)
	v88:Button("日出(攻击)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16062712948")
	end)
	v88:Button("原子斜切", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16082123712")
	end)
	v88:Button("源自斜切(攻击)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16057411888")
	end)
	v88:Label("其他")
	v88:Button("出场动画", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15983615423")
	end)
	v88:Button("收刀", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15271263467")
	end)
	v89:Label("普攻")
	v89:Button("普攻1", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16515503507")
	end)
	v89:Button("普攻2", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16515520431")
	end)
	v89:Button("普攻3", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16515448089")
	end)
	v89:Button("普攻4", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16552234590")
	end)
	v89:Label("技能")
	v89:Button("破碎拉力", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16139108718")
	end)
	v89:Button("破碎拉力(未击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16139402582")
	end)
	v89:Button("破碎拉力(击中)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16139708727")
	end)
	v89:Button("破碎拉力(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16571909908")
	end)
	v89:Button("暴风雨愤怒", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16515850153")
	end)
	v89:Button("石头棺材", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16431491215")
	end)
	v89:Button("石头棺材(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16708190748")
	end)
	v89:Button("驱逐推动", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16597322398")
	end)
	v89:Button("驱逐推动(爆炸)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16597912086")
	end)
	v89:Button("驱逐推动(击杀)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16699717165")
	end)
	v89:Label("大招")
	v89:Button("狂暴", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15391323441")
	end)
	v89:Button("日落", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15520132233")
	end)
	v89:Button("太阳裂缝", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://15676072469")
	end)
	v89:Button("日出", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16062410809")
	end)
	v89:Button("日出(攻击)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16062712948")
	end)
	v89:Button("原子斜切", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16082123712")
	end)
	v89:Button("源自斜切(攻击)", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16057411888")
	end)
	v89:Label("其他")
	v89:Button("出场动画", function()
		-- upvalues: (ref) v_u_129
		v_u_129("rbxassetid://16136144568")
	end)
	v91:Toggle("透视开关", "EspToggle", false, function(p175)
		-- upvalues: (ref) v_u_125
		v_u_125.EspToggle = p175
	end)
	v91:Toggle("上色开关", "HighlightToggle", false, function(p176)
		-- upvalues: (ref) v_u_125
		v_u_125.HighlightToggle = p176
	end)
	v92:Dropdown("透视颜色", "SelectFillColor", {
		"红",
		"绿",
		"蓝",
		"粉",
		"青"
	}, function(p177)
		-- upvalues: (ref) v_u_125, (ref) v_u_69
		if p177 == "红" then
			v_u_125.SelectFillColor = v_u_69.Red
		elseif p177 == "绿" then
			v_u_125.SelectFillColor = v_u_69.Green
		elseif p177 == "蓝" then
			v_u_125.SelectFillColor = v_u_69.Blue
		elseif p177 == "粉" then
			v_u_125.SelectFillColor = v_u_69.Pink
		elseif p177 == "青" then
			v_u_125.SelectFillColor = v_u_69.Cyan
		end
	end)
	v92:Slider("透视大小", "FillTransparency", 0.5, 0.1, 1, true, function(p178)
		-- upvalues: (ref) v_u_125
		v_u_125.EspScale = p178
	end)
	v92:Slider("上色透明度", "FillTransparency", 0.5, 0, 1, true, function(p179)
		-- upvalues: (ref) v_u_125
		v_u_125.HighlightTransparency = p179
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_126, (ref) v_u_65, (ref) v_u_125
		while _G.ScriptIsRunning == true do
			local v180 = v_u_126
			local v181, v182, v183 = pairs(v180:GetChildren())
			while true do
				local v184
				v183, v184 = v181(v182, v183)
				if v183 == nil then
					break
				end
				if v184.Name ~= v_u_65.Name then
					UpdateEsp(v184.Name, v_u_125.SelectFillColor)
				end
			end
			task.wait()
		end
	end)
	local v185, v186, v187 = pairs(v_u_126:GetChildren())
	local v_u_188 = {}
	while true do
		local v189, v190 = v185(v186, v187)
		if v189 == nil then
			break
		end
		v187 = v189
		if v190.Name ~= v_u_65.Name then
			table.insert(v_u_188, v190.Name)
		end
	end
	local v_u_192 = v93:Dropdown("玩家列表", "Players", v_u_188, function(p191)
		-- upvalues: (ref) v_u_125
		v_u_125.SelectPlr = p191
	end)
	v_u_126.PlayerAdded:Connect(function(p193)
		-- upvalues: (ref) v_u_188, (ref) v_u_192
		table.insert(v_u_188, p193.Name)
		v_u_192.AddOption(p193.Name)
	end)
	v_u_126.PlayerRemoving:Connect(function(p194)
		-- upvalues: (ref) v_u_188, (ref) v_u_192
		table.remove(v_u_188, table.find(v_u_188, p194.Name))
		v_u_192.RemoveOption(p194.Name)
	end)
	v93:Button("传送到选中的玩家", function()
		-- upvalues: (ref) v_u_65, (ref) v_u_126, (ref) v_u_125
		pcall(function()
			-- upvalues: (ref) v_u_65, (ref) v_u_126, (ref) v_u_125
			local v195 = v_u_126
			v_u_65.Character.HumanoidRootPart.CFrame = v195:FindFirstChild(v_u_125.SelectPlr).Character.HumanoidRootPart.CFrame
		end)
	end)
	v93:Toggle("自动传送到选择的玩家脚下", "AutoTeleportToSelectPlrUnder", false, function(p196)
		-- upvalues: (ref) v_u_125
		v_u_125.AutoTeleportToSelectPlrUnder = p196
	end)
	v93:Toggle("自动传送到选择的玩家背后", "AutoTeleportToSelectPlrBack", false, function(p197)
		-- upvalues: (ref) v_u_125
		v_u_125.AutoTeleportToSelectPlr = p197
	end)
	v93:Slider("自动传送距离设置", "AutoTeleportToSelectPlrDistance", 5.5, 0.1, 20, true, function(p198)
		-- upvalues: (ref) v_u_125
		v_u_125.AutoTeleportToSelectPlrDistance = p198
	end)
	v93:Toggle("预判", "PredictionToggle", false, function(p199)
		-- upvalues: (ref) v_u_125
		v_u_125.PredictionToggle = p199
	end)
	v93:Toggle("预判基于Ping", "BaseOnPing", false, function(p200)
		-- upvalues: (ref) v_u_125
		v_u_125.BaseOnPing = p200
	end)
	v93:Slider("预判数值", "Prediction", 29, 0.1, 50, true, function(p201)
		-- upvalues: (ref) v_u_125
		v_u_125.Prediction = p201
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_125, (ref) v_u_65, (ref) v_u_126
		while _G.ScriptIsRunning == true do
			if v_u_125.AutoTeleportToSelectPlrUnder == true then
				pcall(function()
					-- upvalues: (ref) v_u_125, (ref) v_u_65, (ref) v_u_126
					local v202
					if v_u_125.PredictionToggle ~= true then
						v202 = 0
					else
						v202 = v_u_125.Prediction
						if v_u_125.BaseOnPing then
							v202 = v202 + v_u_65:GetNetworkPing() * 100
						end
					end
					local v203 = v_u_126
					local v204 = v_u_126
					local v205 = v_u_126
					v_u_65.Character.HumanoidRootPart.CFrame = v203:FindFirstChild(v_u_125.SelectPlr).Character.HumanoidRootPart.CFrame * CFrame.new(0, -v_u_125.AutoTeleportToSelectPlrDistance, 0) + Vector3.new(v204:FindFirstChild(v_u_125.SelectPlr).Character.HumanoidRootPart.Velocity.X * v202 / 100, 0, v205:FindFirstChild(v_u_125.SelectPlr).Character.HumanoidRootPart.Velocity.Z * v202 / 100)
				end)
			end
			task.wait()
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_125, (ref) v_u_65, (ref) v_u_126
		while _G.ScriptIsRunning == true do
			if v_u_125.AutoTeleportToSelectPlr == true then
				pcall(function()
					-- upvalues: (ref) v_u_65, (ref) v_u_126, (ref) v_u_125
					local v206 = v_u_126
					local v207 = v_u_126
					v_u_65.Character.HumanoidRootPart.CFrame = v206:FindFirstChild(v_u_125.SelectPlr).Character.HumanoidRootPart.CFrame - v207:FindFirstChild(v_u_125.SelectPlr).Character.HumanoidRootPart.CFrame.LookVector * v_u_125.AutoTeleportToSelectPlrDistance
				end)
			end
			task.wait()
		end
	end)
	local v_u_208 = {
		["WalkSpeed"] = 16,
		["WalkSpeedToggle"] = false,
		["JumpPower"] = 50,
		["JumpPowerToggle"] = false,
		["Gravity"] = 196.2,
		["GravityToggle"] = false,
		["Fly"] = false,
		["FlySpeed"] = 30
	}
	v95:Label("移动速度")
	function WalkSpeed()
		-- upvalues: (ref) v_u_208, (ref) v_u_65
		while v_u_208.WalkSpeedToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_65, (ref) v_u_208
				v_u_65.Character.Humanoid.WalkSpeed = v_u_208.WalkSpeed
			end)
			task.wait()
		end
	end
	v95:Slider("数值", "WalkSpeed", 16, 1, 150, true, function(p209)
		-- upvalues: (ref) v_u_208
		v_u_208.WalkSpeed = p209
	end)
	v95:Toggle("开关", "WalkSpeedToggle", false, function(p210)
		-- upvalues: (ref) v_u_208
		v_u_208.WalkSpeedToggle = p210
		WalkSpeed()
	end)
	v95:Label("跳跃高度")
	function JumpPower()
		-- upvalues: (ref) v_u_208, (ref) v_u_65
		while v_u_208.JumpPowerToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_65, (ref) v_u_208
				v_u_65.Character.Humanoid.JumpPower = v_u_208.JumpPower
			end)
			task.wait()
		end
	end
	v95:Slider("数值", "JumpPower", 50, 1, 150, true, function(p211)
		-- upvalues: (ref) v_u_208
		v_u_208.JumpPower = p211
	end)
	v95:Toggle("开关", "JumpPowerToggle", false, function(p212)
		-- upvalues: (ref) v_u_208
		v_u_208.JumpPowerToggle = p212
		JumpPower()
	end)
	v95:Label("重力")
	function Gravity()
		-- upvalues: (ref) v_u_208, (ref) v_u_66
		while v_u_208.GravityToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_66, (ref) v_u_208
				v_u_66.Gravity = v_u_208.Gravity
			end)
			task.wait()
		end
	end
	v95:Slider("数值", "Gravity", 196.2, 1, 1000, true, function(p213)
		-- upvalues: (ref) v_u_208
		v_u_208.Gravity = p213
	end)
	v95:Toggle("开关", "GravityToggle", false, function(p214)
		-- upvalues: (ref) v_u_208
		v_u_208.GravityToggle = p214
		Gravity()
	end)
	function NoclipFunc()
		-- upvalues: (ref) v_u_125, (ref) v_u_65
		while v_u_125.Noclip == true do
			pcall(function()
				-- upvalues: (ref) v_u_65
				local v215, v216, v217 = pairs(v_u_65.Character:GetChildren())
				while true do
					local v218
					v217, v218 = v215(v216, v217)
					if v217 == nil then
						break
					end
					if v218:IsA("BasePart") then
						v218.CanCollide = false
					end
				end
			end)
			task.wait()
		end
	end
	v95:Toggle("穿墙", "Noclip", false, function(p219)
		-- upvalues: (ref) v_u_125, (ref) v_u_65
		v_u_125.Noclip = p219
		if p219 == false then
			pcall(function()
				-- upvalues: (ref) v_u_65
				local v220, v221, v222 = pairs(v_u_65.Character:GetChildren())
				while true do
					local v223
					v222, v223 = v220(v221, v222)
					if v222 == nil then
						break
					end
					if v223:IsA("BasePart") and (v223.Name == "Head" or (v223.Name == "Torso" or (v223.Name == "UpperTorso" or v223.Name == "LowerTorso"))) then
						v223.CanCollide = true
					end
				end
			end)
		end
		NoclipFunc()
	end)
	v95:Toggle("无限跳", "InfJump", false, function(p224)
		-- upvalues: (ref) v_u_125
		v_u_125.InfJump = p224
	end)
	game:GetService("UserInputService").JumpRequest:Connect(function()
		-- upvalues: (ref) v_u_125, (ref) v_u_65
		if v_u_125.InfJump == true then
			v_u_65.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
		end
	end)
	local function v_u_229()
		-- upvalues: (ref) v_u_208, (ref) v_u_65, (ref) v_u_66
		while v_u_208.Fly == true do
			pcall(function()
				-- upvalues: (ref) v_u_65, (ref) v_u_66, (ref) v_u_208
				if not v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
					local v225 = Instance.new("BodyVelocity")
					v225.Name = "FlyVelocity"
					v225.Parent = v_u_65.Character.HumanoidRootPart
					v225.MaxForce = Vector3.new(0, 0, 0)
					v225.Velocity = Vector3.new(0, 0, 0)
				end
				if not v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
					local v226 = Instance.new("BodyGyro")
					v226.Name = "FlyGyro"
					v226.Parent = v_u_65.Character.HumanoidRootPart
					v226.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
					v226.P = 1000
					v226.D = 50
				end
				if v_u_65.Character and (v_u_65.Character:FindFirstChildOfClass("Humanoid") and v_u_65.Character.Humanoid.RootPart and (v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") and v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyGyro"))) then
					local v227 = v_u_66.CurrentCamera
					v_u_65.Character.HumanoidRootPart.FlyGyro.CFrame = v_u_66.CurrentCamera.CFrame
					local v228 = require(v_u_65.PlayerScripts:WaitForChild("PlayerModule"):WaitForChild("ControlModule")):GetMoveVector()
					v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity = Vector3.new()
					if v228.X > 0 then
						v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity + v227.CFrame.RightVector * (v228.X * v_u_208.FlySpeed)
					end
					if v228.X < 0 then
						v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity + v227.CFrame.RightVector * (v228.X * v_u_208.FlySpeed)
					end
					if v228.Z > 0 then
						v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity - v227.CFrame.LookVector * (v228.Z * v_u_208.FlySpeed)
					end
					if v228.Z < 0 then
						v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity - v227.CFrame.LookVector * (v228.Z * v_u_208.FlySpeed)
					end
					v_u_65.Character.Humanoid.PlatformStand = true
					v_u_65.Character.HumanoidRootPart.FlyVelocity.MaxForce = Vector3.new(9000000000, 9000000000, 9000000000)
					v_u_65.Character.HumanoidRootPart.FlyGyro.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
				end
			end)
			task.wait()
		end
	end
	v95:Toggle("飞行", "Fly", false, function(p230)
		-- upvalues: (ref) v_u_208, (ref) v_u_65, (ref) v_u_229
		v_u_208.Fly = p230
		if p230 == false then
			v_u_65.Character.Humanoid.PlatformStand = false
			if v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
				v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyVelocity"):Destroy()
			end
			if v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
				v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyGyro"):Destroy()
			end
		end
		v_u_229()
	end)
	v95:Slider("飞行速度", "Slider", 30, 1, 150, true, function(p231)
		-- upvalues: (ref) v_u_208
		v_u_208.FlySpeed = p231
	end)
	local v_u_232 = {
		["DefFOV"] = v_u_66.CurrentCamera.FieldOfView,
		["DefCameraMaxZoomDistance"] = v_u_65.CameraMaxZoomDistance,
		["DefCameraMinZoomDistance"] = v_u_65.CameraMinZoomDistance,
		["FieldOfView"] = 70,
		["FieldOfViewToggle"] = false,
		["CameraMaxZoomDistance"] = 128,
		["CameraMaxZoomDistanceToggle"] = false,
		["CameraMinZoomDistance"] = 0.5,
		["CameraMinZoomDistanceToggle"] = false,
		["FullBright"] = false,
		["DefAmbient"] = v_u_124.Ambient
	}
	function FieldOfView()
		-- upvalues: (ref) v_u_232, (ref) v_u_66, (ref) v_u_96
		while v_u_232.FieldOfViewToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_66, (ref) v_u_96
				v_u_66.CurrentCamera.FieldOfView = v_u_96.FieldOfView
			end)
			task.wait()
		end
	end
	function CameraMaxZoomDistance()
		-- upvalues: (ref) v_u_232, (ref) v_u_65, (ref) v_u_96
		while v_u_232.CameraMaxZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_65, (ref) v_u_96
				v_u_65.CameraMaxZoomDistance = v_u_96.CameraMaxZoomDistance
			end)
			task.wait()
		end
	end
	function CameraMinZoomDistance()
		-- upvalues: (ref) v_u_232, (ref) v_u_65
		while v_u_232.CameraMinZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_65, (ref) v_u_232
				v_u_65.CameraMinZoomDistance = v_u_232.CameraMinZoomDistance
			end)
			task.wait()
		end
	end
	v_u_96:Slider("Fov", "Slider", 70, 1, 120, true, function(p233)
		-- upvalues: (ref) v_u_96, (ref) v_u_66, (ref) v_u_232
		v_u_96.FieldOfView = p233
		if p233 == false then
			v_u_66.CurrentCamera.FieldOfView = v_u_232.DefFOV
		end
		FieldOfView()
	end)
	v_u_96:Slider("最大相机聚焦距离", "Slider", 128, 1, 1200, true, function(p234)
		-- upvalues: (ref) v_u_96, (ref) v_u_65
		v_u_96.CameraMaxZoomDistance = p234
		if p234 == false then
			v_u_65.CameraMaxZoomDistance = v_u_96.DefCameraMaxZoomDistance
		end
		CameraMaxZoomDistance()
	end)
	v_u_96:Slider("最小相机聚焦距离", "Slider", 0.5, 1, 50, true, function(p235)
		-- upvalues: (ref) v_u_96, (ref) v_u_65, (ref) v_u_232
		v_u_96.CameraMinZoomDistance = p235
		if p235 == false then
			v_u_65.CameraMinZoomDistance = v_u_232.DefCameraMinZoomDistance
		end
		CameraMinZoomDistance()
	end)
	function FullBright()
		-- upvalues: (ref) v_u_208, (ref) v_u_124
		while v_u_208.FullBright == true do
			pcall(function()
				-- upvalues: (ref) v_u_124
				v_u_124.Ambient = Color3.new(1, 1, 1)
			end)
			task.wait()
		end
	end
	v_u_96:Toggle("全局高亮", "FullBright", false, function(p236)
		-- upvalues: (ref) v_u_232, (ref) v_u_124
		v_u_232.FullBright = p236
		if p236 == false then
			v_u_124.Ambient = v_u_232.DefAmbient
		end
		FullBright()
	end)
	local v_u_237 = {
		["Bk"] = nil,
		["Dn"] = nil,
		["Ft"] = nil,
		["Lf"] = nil,
		["Rt"] = nil,
		["Up"] = nil
	}
	v97:Dropdown("天空盒", "Skybox", { "cs_办公室", "Always.win", "Advanced Logic" }, function(p238)
		if p238 == "cs_办公室" then
			SpawnSkybox({
				["Name"] = "cs_office",
				["Bk"] = "rbxassetid://658623433",
				["Dn"] = "rbxassetid://316342560",
				["Ft"] = "rbxassetid://658625205",
				["Lf"] = "rbxassetid://658627155",
				["Rt"] = "rbxassetid://658628504",
				["Up"] = "rbxassetid://658632701"
			})
		elseif p238 == "Always.win" then
			SpawnSkybox({
				["Name"] = "Always.win",
				["Bk"] = "rbxassetid://17411013742",
				["Dn"] = "rbxassetid://17411013742",
				["Ft"] = "rbxassetid://17411013742",
				["Lf"] = "rbxassetid://17411013742",
				["Rt"] = "rbxassetid://17411013742",
				["Up"] = "rbxassetid://17411013742"
			})
		elseif p238 == "Advanced Logic" then
			SpawnSkybox({
				["Name"] = "Advanced Logic",
				["Bk"] = "rbxassetid://17803761395",
				["Dn"] = "rbxassetid://17803761395",
				["Ft"] = "rbxassetid://17803761395",
				["Lf"] = "rbxassetid://17803761395",
				["Rt"] = "rbxassetid://17803761395",
				["Up"] = "rbxassetid://17803761395",
				["SunAsset"] = "rbxassetid://17768924741",
				["SunAngularSize"] = 50
			})
		end
	end)
	v97:Textbox("自定义天空盒Bk", "Textbox", "请输入SkyboxBk贴图ID", function(p_u_239)
		-- upvalues: (ref) v_u_237
		pcall(function()
			-- upvalues: (ref) p_u_239, (ref) v_u_237
			if p_u_239:find("rbx") then
				v_u_237.Bk = p_u_239
			else
				v_u_237.Bk = "rbxassetid://" .. p_u_239
			end
		end)
	end)
	v97:Textbox("自定义天空盒Dn", "Textbox", "请输入SkyboxDn贴图ID", function(p_u_240)
		-- upvalues: (ref) v_u_237
		pcall(function()
			-- upvalues: (ref) p_u_240, (ref) v_u_237
			if p_u_240:find("rbx") then
				v_u_237.Dn = p_u_240
			else
				v_u_237.Dn = "rbxassetid://" .. p_u_240
			end
		end)
	end)
	v97:Textbox("自定义天空盒Ft", "Textbox", "请输入SkyboxFt贴图ID", function(p_u_241)
		-- upvalues: (ref) v_u_237
		pcall(function()
			-- upvalues: (ref) p_u_241, (ref) v_u_237
			if p_u_241:find("rbx") then
				v_u_237.Ft = p_u_241
			else
				v_u_237.Ft = "rbxassetid://" .. p_u_241
			end
		end)
	end)
	v97:Textbox("自定义天空盒Lf", "Textbox", "请输入SkyboxLf贴图ID", function(p_u_242)
		-- upvalues: (ref) v_u_237
		pcall(function()
			-- upvalues: (ref) p_u_242, (ref) v_u_237
			if p_u_242:find("rbx") then
				v_u_237.Lf = p_u_242
			else
				v_u_237.Lf = "rbxassetid://" .. p_u_242
			end
		end)
	end)
	v97:Textbox("自定义天空盒Rt", "Textbox", "请输入SkyboxRt贴图ID", function(p_u_243)
		-- upvalues: (ref) v_u_237
		pcall(function()
			-- upvalues: (ref) p_u_243, (ref) v_u_237
			if p_u_243:find("rbx") then
				v_u_237.Rt = p_u_243
			else
				v_u_237.Rt = "rbxassetid://" .. p_u_243
			end
		end)
	end)
	v97:Textbox("自定义天空盒Up", "Textbox", "请输入SkyboxUp贴图ID", function(p_u_244)
		-- upvalues: (ref) v_u_237
		pcall(function()
			-- upvalues: (ref) p_u_244, (ref) v_u_237
			if p_u_244:find("rbx") then
				v_u_237.Up = p_u_244
			else
				v_u_237.Up = "rbxassetid://" .. p_u_244
			end
		end)
	end)
	v97:Button("修改自定义天空盒", function()
		-- upvalues: (ref) v_u_237
		pcall(function()
			-- upvalues: (ref) v_u_237
			SpawnSkybox({
				["Name"] = "我爱手冲",
				["Bk"] = v_u_237.Bk,
				["Dn"] = v_u_237.Dn,
				["Ft"] = v_u_237.Ft,
				["Lf"] = v_u_237.Lf,
				["Rt"] = v_u_237.Rt,
				["Up"] = v_u_237.Up
			})
		end)
	end)
	v99:Label("团队")
	v99:Label("Advanced Logic")
	v99:Label("群号: 684407929")
	v100:Label("当前版本 " .. v73)
else
	game:GetService("Players").LocalPlayer:Kick("您不是白名单用户,请加入684407929(Adavanced Logic官方群)购买")
	setclipboard(game:GetService("RbxAnalyticsService"):GetClientId())
end
