local v_u_1 = http_request or request or (HttpPost or syn.request)
local v_u_2 = nil
local v_u_3 = 0
local function v_u_9(p4, p5, p6)
	-- upvalues: (ref) v_u_3, (ref) v_u_9
	v_u_3 = v_u_3 + 1
	if p6 then
		local v7 = v_u_9(p4, p5) and v_u_9(p4, p6)
		if v7 then
			v7 = v_u_9(p5, p6)
		end
		return v7
	else
		local v8 = type(p4) == typeof(p5) and (typeof(p4) == type(p5) and (type(p4) == typeof(p5) or typeof(p4) == type(p5))) and (#tostring(p4) == #tostring(p5) and rawequal(p4, p5))
		if v8 then
			if tostring(p4) < tostring(p5) or tostring(p4) > tostring(p5) then
				v8 = false
			else
				v8 = rawequal(tostring(p4), tostring(p5))
			end
		end
		return v8
	end
end
local function v_u_11(p10)
	return ({ ... })[p10]
end
local function v_u_18(p_u_12)
	-- upvalues: (ref) v_u_1, (ref) v_u_2, (ref) v_u_11
	local v_u_13 = false
	local v15 = {
		["__call"] = v_u_1,
		["__index"] = function(_, p14)
			-- upvalues: (ref) v_u_13, (ref) v_u_1, (ref) v_u_2, (ref) p_u_12
			v_u_13 = true
			if debug.info(2, "f") ~= v_u_1 then
				v_u_2 = "反钩子 [H - 1]"
				return "https://www.roblox.com/users/7207800972/profile"
			end
			if not coroutine.isyieldable() then
				return p_u_12[p14]
			end
			v_u_2 = "反钩子 [H - 2]"
			return "https://www.roblox.com/users/7207800972/profile"
		end
	}
	local v16 = setmetatable({}, v15)
	local v17 = v_u_11(2, pcall(v16))
	if v_u_13 then
		return v17
	end
end
local function v21(p19)
	-- upvalues: (ref) v_u_18
	local v20 = v_u_18({
		["Url"] = p19,
		["Method"] = "GET"
	})
	repeat
		task.wait()
	until v20
	return v20.Body
end
local function v23(p22)
	return string.split(p22 or "", ": ")[2]
end
local function v_u_26(p24, p25)
	-- upvalues: (ref) v_u_26
	if p24 == 0 then
		task.wait()
	end
	p25(...)
	v_u_26(p24 + 1, p25)
end
local function v28(p27)
	game:GetService("Players").LocalPlayer:Kick("")
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.TitleFrame.ErrorTitle.Text = "危险行为"
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.MessageArea.ErrorFrame.ErrorMessage.Text = p27
	task.wait(1)
	game:Shutdown()
	task.wait(1)
	task.spawn(function()
		while true do

		end
	end)
end
local v29 = {
	v_u_26,
	v_u_11,
	pcall,
	debug.info,
	islclosure,
	debug.getinfo,
	debug.getfenv,
	0,
	{
		"Url",
		"Method",
		"Headers",
		"Cookies",
		"Body"
	},
	table.insert,
	v_u_2,
	v_u_1
}
local v30 = { math.random, v_u_11, v_u_18 }
local v31 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end
}
setmetatable(v29, v31)
local v32 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end
}
setmetatable(v30, v32)
local v33 = type(getrawmetatable(v29).__index) ~= "function" and "反篡改 [M - S1]" or v_u_2
v_u_3 = v_u_3 + 1
local v34 = type(getrawmetatable(v29).__tostring) ~= "function" and "反篡改 [M - S1]" or v33
v_u_3 = v_u_3 + 1
local v35 = (type(getrawmetatable(v30).__index) ~= "function" or type(getrawmetatable(v30).__index) ~= type(getmetatable(v30).__index)) and "反篡改 [M - S1]" or v34
v_u_3 = v_u_3 + 1
local v36 = type(getrawmetatable(v30).__tostring) ~= "function" and "反篡改 [M - S1]" or v35
v_u_3 = v_u_3 + 1
local v37, v38 = pcall(pcall)
local _, _ = pcall(math.random)
local _, _ = pcall(setmetatable)
local _, _ = pcall(string.split)
local _, _ = pcall(debug.traceback)
local _, _ = pcall(getmetatable)
local _, _ = pcall(coroutine.wrap)
local _, _ = pcall(table.insert)
local v39 = (v37 or v38 ~= "missing argument #1") and "反函数钩子 [P]" or v36
v_u_3 = v_u_3 + 1
local v40 = {
	math.abs,
	os.clock,
	coroutine.isyieldable,
	debug.info,
	v_u_1,
	game:GetService("Players").LocalPlayer.Kick,
	table.insert,
	bit32.bxor,
	debug.getfenv,
	setrawmetatable,
	pcall,
	math.random,
	setmetatable,
	string.split,
	debug.traceback,
	debug.info,
	getrawmetatable,
	type,
	table.insert,
	math.random,
	v_u_11,
	table.concat,
	string.byte,
	string.char,
	debug.getinfo,
	islclosure,
	string.reverse,
	v_u_18,
	getmetatable
}
local v41 = next
local v42 = v_u_18
local v43 = v_u_26
local v44 = v_u_9
local v45 = v_u_3
local v46 = v_u_11
local v47 = nil
while true do
	local v48
	v47, v48 = v41(v40, v47)
	if v47 == nil then
		break
	end
	for _ = 1, 197 do
		v48 = coroutine.wrap(v48)
	end
	if v46(2, pcall(v48)) == "C stack overflow" then
		v_u_2 = "反函数钩子 [F - G2]"
		v39 = v_u_2
	end
end
v_u_3 = v45 + 1
local v49 = not debug.info(2, "f") and "反篡改 [1]" or v39
v_u_3 = v_u_3 + 1
local v50 = math.random() == math.random() and "反篡改 [2]" or v49
local v51 = not v44(v_u_3, 7) and "反钩子 [C]" or v50
local _, v52 = pcall(v43, 0, coroutine.wrap)
local v53 = v23(v52) ~= "missing argument #1 to \'wrap\' (function expected)" and "反函数钩子 [F - C]" or v51
local v54 = not string.sub(game:GetService("RbxAnalyticsService"):GetClientId(), 1, 8) == string.split(game:GetService("RbxAnalyticsService"):GetClientId(), "-")[1] and "反函数钩子 [F - S]" or v53
local v55 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/P"))()
local v56 = loadstring(v21("https://raw.githubusercontent.com/longshu886/linniscript/refs/heads/main/ng", true))()
local v57 = clonefunction(game:GetService("RbxAnalyticsService").GetClientId)(game:GetService("RbxAnalyticsService")):split("-")
local v58 = v57[1] .. v57[2] .. v57[3] .. v57[4] .. v57[5]
local v59 = not gethwid and "未知" or gethwid()
local v60 = table.find({ Enum.Platform.IOS }, game:GetService("UserInputService"):GetPlatform()) and "IOS" or (table.find({ Enum.Platform.Android }, game:GetService("UserInputService"):GetPlatform()) and "Android" or "PC/Mac")
local v61, v62
if v55[v58] ~= true or v56[v58] ~= true then
	v61 = "0xFF0000"
	v62 = "否"
else
	v61 = "0x32CD32"
	v62 = "是"
end
local v63 = {
	["username"] = "Advanced Bot",
	["embeds"] = {
		{
			["color"] = tonumber(tostring(v61)),
			["title"] = "有人注入了Advanced Logic",
			["fields"] = {
				{
					["name"] = "名称",
					["value"] = game:GetService("Players").LocalPlayer.Name,
					["inline"] = true
				},
				{
					["name"] = "昵称",
					["value"] = game:GetService("Players").LocalPlayer.DisplayName,
					["inline"] = true
				},
				{
					["name"] = "UID",
					["value"] = "[" .. game:GetService("Players").LocalPlayer.UserId .. "](" .. tostring("https://www.roblox.com/users/" .. game:GetService("Players").LocalPlayer.UserId .. "/profile") .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏ID",
					["value"] = "[" .. game.PlaceId .. "](" .. tostring("https://www.roblox.com/games/" .. game.PlaceId) .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏名称",
					["value"] = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name,
					["inline"] = true
				},
				{
					["name"] = "注入器",
					["value"] = identifyexecutor(),
					["inline"] = true
				},
				{
					["name"] = "HWID",
					["value"] = v59,
					["inline"] = true
				},
				{
					["name"] = "客户端ID",
					["value"] = game:GetService("RbxAnalyticsService"):GetClientId(),
					["inline"] = false
				},
				{
					["name"] = "设备",
					["value"] = v60,
					["inline"] = true
				},
				{
					["name"] = "用户状态",
					["value"] = v62,
					["inline"] = true
				}
			},
			["timestamp"] = os.date("%Y-%m-%dT%X.000Z")
		}
	}
}
v42({
	["Url"] = "https://discord.com/api/webhooks/1268122774069579806/Pi7q9f25rIwlkr-iLiIFEPJIvxx5dzcA9tSUXoTY8R1uUXF-CnFMJ91V2aX75dBOJCuY",
	["Method"] = "POST",
	["Headers"] = {
		["Content-Type"] = "application/json"
	},
	["Body"] = game.HttpService:JSONEncode(v63)
})
if v54 ~= nil then
	v28(v54)
end
if v55[v58] == true or v56[v58] == true then
	setfpscap(math.huge)
	_G.ScriptIsRunning = false
	_G.ScriptIsRunning = true
	local v_u_64 = game:GetService("Players")
	local v_u_65 = v_u_64.LocalPlayer
	game:GetService("CoreGui")
	game:GetService("RbxAnalyticsService")
	game:GetService("RunService")
	local _ = v_u_65.PlayerGui
	local v_u_66 = game:GetService("Workspace")
	local v_u_67 = game:GetService("Lighting")
	local v_u_68 = {
		["Real"] = {
			["白色"] = Color3.fromRGB(255, 255, 255),
			["红色"] = Color3.fromRGB(255, 0, 0),
			["绿色"] = Color3.fromRGB(0, 255, 0),
			["蓝色"] = Color3.fromRGB(0, 0, 255),
			["粉色"] = Color3.fromRGB(255, 170, 255),
			["紫色"] = Color3.fromRGB(85, 255, 255)
		},
		["Visual"] = {
			"白色",
			"红色",
			"绿色",
			"蓝色",
			"粉色",
			"紫色"
		}
	}
	local v_u_69 = {
		["MasterSwitch"] = false,
		["NameEsp"] = false,
		["HighlightEsp"] = false,
		["EspScale"] = 0.5,
		["HighlightTransparency"] = 0.5,
		["SelectFillColor"] = Color3.fromRGB(255, 255, 255)
	}
	local v_u_70 = {
		["SelectPlr"] = nil,
		["AutoTeleportToSelectPlr"] = false,
		["AutoTeleportToSelectPlrDistance"] = 4.5
	}
	local v_u_71 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ns.cc"))()
	local v72 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/bob.afk"))()
	local v73 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/v"))():new("<font color=\"rgb(0,180,216)\">Advanced</font> <font color=\"rgb(252,255,0)\">Logic</font>", true, "gamesense", 0, false)
	local v74 = v73:Tab("透视", "7733696665")
	local v75 = v74:Section("功能", false)
	local v76 = v74:Section("透视设置", false)
	local v77 = v73:Tab("玩家", "7743876054"):Section("玩家选项", true)
	local v78 = v73:Tab("本地", "7733752575")
	local v79 = v78:Section("本地玩家", false)
	local v_u_80 = v78:Section("本地视觉", false)
	local v81 = v78:Section("天空盒", false)
	local v82 = v73:Tab("关于", "7743871575")
	local v83 = v82:Section("关于作者", true)
	local v84 = v82:Section("关于脚本", true)
	local function v_u_97(p_u_85, p_u_86, p_u_87, p_u_88, p_u_89, p_u_90)
		-- upvalues: (ref) v_u_69
		pcall(function()
			-- upvalues: (ref) p_u_85, (ref) p_u_90, (ref) p_u_87, (ref) p_u_86, (ref) v_u_69, (ref) p_u_89, (ref) p_u_88
			if p_u_85 and p_u_90 then
				if not (p_u_85:FindFirstChild("ALBill") and p_u_87:FindFirstChild("ALHighlight")) then
					if not p_u_85:FindFirstChild("ALBill") then
						local v91 = Instance.new("BillboardGui")
						local v92 = Instance.new("TextLabel")
						v91.Name = "ALBill"
						v91.Parent = p_u_85
						v91.Active = true
						v91.ExtentsOffset = Vector3.new(0, 2, 0)
						v91.Size = UDim2.new(0, 200, 0, 50)
						v91.Enabled = p_u_86
						v91.AlwaysOnTop = true
						v92.Name = "TextLabel"
						v92.Parent = v91
						v92.AnchorPoint = Vector2.new(0.5, 0.5)
						v92.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						v92.BackgroundTransparency = 1
						v92.BorderColor3 = Color3.fromRGB(0, 0, 0)
						v92.Position = UDim2.new(0.5, 0, 0.5, 0)
						v92.Size = UDim2.new(v_u_69.EspScale, 0, v_u_69.EspScale, 0)
						v92.Text = p_u_89
						v92.TextColor3 = p_u_90
						v92.TextScaled = true
						v92.TextStrokeTransparency = 0.19
					end
					if not p_u_87:FindFirstChild("ALHighlight") then
						local v93 = Instance.new("Highlight")
						v93.Name = "ALHighlight"
						v93.Parent = p_u_87
						v93.FillColor = p_u_90
						v93.Enabled = p_u_88
						v93.FillTransparency = v_u_69.HighlightTransparency
					end
				end
				if p_u_85:FindFirstChild("ALBill") then
					local v94 = p_u_85:FindFirstChild("ALBill")
					local v95 = v94.TextLabel
					v94.Enabled = p_u_86
					v95.Text = p_u_89
					v95.Size = UDim2.new(v_u_69.EspScale, 0, v_u_69.EspScale, 0)
					v95.TextColor3 = p_u_90
				end
				if p_u_87:FindFirstChild("ALHighlight") then
					local v96 = p_u_87:FindFirstChild("ALHighlight")
					v96.FillColor = p_u_90
					v96.Enabled = p_u_88
					v96.FillTransparency = v_u_69.HighlightTransparency
				end
			end
		end)
	end
	local function v_u_105(p98)
		-- upvalues: (ref) v_u_67, (ref) v_u_71
		local v99 = v_u_67
		local v100, v101, v102 = pairs(v99:GetChildren())
		while true do
			local v103
			v102, v103 = v100(v101, v102)
			if v102 == nil then
				break
			end
			if v103:IsA("Sky") then
				v103:Destroy()
			end
		end
		if p98.Bk and (p98.Dn and (p98.Ft and (p98.Lf and (p98.Rt and (p98.Up and p98.Name))))) then
			local v104 = Instance.new("Sky")
			v104.Name = p98.Name
			v104.SkyboxBk = p98.Bk
			v104.SkyboxDn = p98.Dn
			v104.SkyboxFt = p98.Ft
			v104.SkyboxLf = p98.Lf
			v104.SkyboxRt = p98.Rt
			v104.SkyboxUp = p98.Up
			v104.Parent = v_u_67
			if p98.SunAsset and p98.SunAngularSize then
				v104.SunTextureId = p98.SunAsset
				v104.SunAngularSize = p98.SunAngularSize
			end
		else
			v_u_71:Notify("无效的天空盒参数", 2)
		end
	end
	local function v_u_115()
		-- upvalues: (ref) v_u_69, (ref) v_u_64, (ref) v_u_65, (ref) v_u_97
		while v_u_69.MasterSwitch == true do
			local v106 = v_u_64
			local v107, v108, v109 = pairs(v106:GetChildren())
			while true do
				local v_u_110
				v109, v_u_110 = v107(v108, v109)
				if v109 == nil then
					break
				end
				pcall(function()
					-- upvalues: (ref) v_u_69, (ref) v_u_110, (ref) v_u_65, (ref) v_u_97
					local v111 = false
					local v112 = false
					if v_u_69.MasterSwitch == true and v_u_110 ~= v_u_65 then
						local v113 = v_u_69.NameEsp == true and true or v111
						local v114 = v_u_69.HighlightEsp == true and true or v112
						v_u_97(v_u_110.Character.HumanoidRootPart, v113, v_u_110.Character, v114, v_u_110.DisplayName .. " | " .. v_u_110.Name, v_u_69.SelectFillColor)
					end
				end)
			end
			task.wait()
		end
	end
	v75:Toggle("透视开关", "EspToggle", false, function(p116)
		-- upvalues: (ref) v_u_69, (ref) v_u_115
		v_u_69.MasterSwitch = p116
		v_u_115()
	end)
	v75:Toggle("用户名透视", "UsernameEsp", false, function(p117)
		-- upvalues: (ref) v_u_69
		v_u_69.NameEsp = p117
	end)
	v75:Toggle("上色开关", "HighlightToggle", false, function(p118)
		-- upvalues: (ref) v_u_69
		v_u_69.HighlightEsp = p118
	end)
	v76:Dropdown("透视颜色", "SelectFillColor", v_u_68.Visual, function(p119)
		-- upvalues: (ref) v_u_69, (ref) v_u_68
		v_u_69.SelectFillColor = v_u_68.Real[p119]
	end)
	v76:Slider("透视大小", "EspScale", 0.5, 0.1, 1, true, function(p120)
		-- upvalues: (ref) v_u_69
		v_u_69.EspScale = p120
	end)
	v76:Slider("上色透明度", "FillTransparency", 0.5, 0, 1, true, function(p121)
		-- upvalues: (ref) v_u_69
		v_u_69.HighlightTransparency = p121
	end)
	local v122 = v_u_64
	local v123, v124, v125 = pairs(v_u_64.GetChildren(v122))
	local v_u_126 = v_u_67
	local v_u_127 = v_u_64
	local v_u_128 = v_u_65
	local v_u_129 = {}
	while true do
		local v130, v131 = v123(v124, v125)
		if v130 == nil then
			break
		end
		v125 = v130
		if v131.Name ~= v_u_128.Name then
			table.insert(v_u_129, v131.Name)
		end
	end
	local v_u_133 = v77:Dropdown("玩家列表", "Players", v_u_129, function(p132)
		-- upvalues: (ref) v_u_70
		v_u_70.SelectPlr = p132
	end)
	v_u_127.PlayerAdded:Connect(function(p134)
		-- upvalues: (ref) v_u_129, (ref) v_u_133
		table.insert(v_u_129, p134.Name)
		v_u_133.AddOption(p134.Name)
	end)
	v_u_127.PlayerRemoving:Connect(function(p135)
		-- upvalues: (ref) v_u_129, (ref) v_u_133
		table.remove(v_u_129, table.find(v_u_129, p135.Name))
		v_u_133.RemoveOption(p135.Name)
	end)
	v77:Button("传送到选中的玩家", function()
		-- upvalues: (ref) v_u_128, (ref) v_u_127, (ref) v_u_70
		pcall(function()
			-- upvalues: (ref) v_u_128, (ref) v_u_127, (ref) v_u_70
			local v136 = v_u_127
			v_u_128.Character.HumanoidRootPart.CFrame = v136:FindFirstChild(v_u_70.SelectPlr).Character.HumanoidRootPart.CFrame
		end)
	end)
	v77:Toggle("自动传送到选择的玩家身后", "Noclip", false, function(p137)
		-- upvalues: (ref) v_u_70
		v_u_70.AutoTeleportToSelectPlr = p137
	end)
	v77:Slider("自动传送距离设置", "Slider", 4.5, 1, 20, true, function(p138)
		-- upvalues: (ref) v_u_70
		v_u_70.AutoTeleportToSelectPlrDistance = p138
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_70, (ref) v_u_128, (ref) v_u_127
		while _G.ScriptIsRunning == true do
			if v_u_70.AutoTeleportToSelectPlr == true then
				pcall(function()
					-- upvalues: (ref) v_u_128, (ref) v_u_127, (ref) v_u_70
					local v139 = v_u_127
					local v140 = v_u_127
					v_u_128.Character.HumanoidRootPart.CFrame = v139:FindFirstChild(v_u_70.SelectPlr).Character.HumanoidRootPart.CFrame - v140:FindFirstChild(v_u_70.SelectPlr).Character.HumanoidRootPart.CFrame.LookVector * v_u_70.AutoTeleportToSelectPlrDistance
				end)
			end
			task.wait()
		end
	end)
	local v_u_141 = {
		["WalkSpeed"] = 16,
		["WalkSpeedToggle"] = false,
		["JumpPower"] = 50,
		["JumpPowerToggle"] = false,
		["Gravity"] = 196.2,
		["GravityToggle"] = false,
		["Fly"] = false,
		["FlySpeed"] = 30,
		["Noclip"] = false,
		["InfJump"] = false
	}
	v79:Label("移动速度")
	local function v_u_142()
		-- upvalues: (ref) v_u_141, (ref) v_u_128
		while v_u_141.WalkSpeedToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_128, (ref) v_u_141
				v_u_128.Character.Humanoid.WalkSpeed = v_u_141.WalkSpeed
			end)
			task.wait()
		end
	end
	v79:Slider("数值", "WalkSpeed", 16, 1, 150, true, function(p143)
		-- upvalues: (ref) v_u_141
		v_u_141.WalkSpeed = p143
	end)
	v79:Toggle("开关", "WalkSpeedToggle", false, function(p144)
		-- upvalues: (ref) v_u_141, (ref) v_u_142
		v_u_141.WalkSpeedToggle = p144
		v_u_142()
	end)
	v79:Label("跳跃高度")
	local function v_u_145()
		-- upvalues: (ref) v_u_141, (ref) v_u_128
		while v_u_141.JumpPowerToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_128, (ref) v_u_141
				v_u_128.Character.Humanoid.JumpPower = v_u_141.JumpPower
			end)
			task.wait()
		end
	end
	v79:Slider("数值", "JumpPower", 50, 1, 150, true, function(p146)
		-- upvalues: (ref) v_u_141
		v_u_141.JumpPower = p146
	end)
	v79:Toggle("开关", "JumpPowerToggle", false, function(p147)
		-- upvalues: (ref) v_u_141, (ref) v_u_145
		v_u_141.JumpPowerToggle = p147
		v_u_145()
	end)
	v79:Label("重力")
	local function v_u_148()
		-- upvalues: (ref) v_u_141, (ref) v_u_66
		while v_u_141.GravityToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_66, (ref) v_u_141
				v_u_66.Gravity = v_u_141.Gravity
			end)
			task.wait()
		end
	end
	v79:Slider("数值", "Gravity", 196.2, 1, 1000, true, function(p149)
		-- upvalues: (ref) v_u_141
		v_u_141.Gravity = p149
	end)
	v79:Toggle("开关", "GravityToggle", false, function(p150)
		-- upvalues: (ref) v_u_141, (ref) v_u_148
		v_u_141.GravityToggle = p150
		v_u_148()
	end)
	local function v_u_155()
		-- upvalues: (ref) v_u_141, (ref) v_u_128
		while v_u_141.Noclip == true do
			pcall(function()
				-- upvalues: (ref) v_u_128
				local v151, v152, v153 = pairs(v_u_128.Character:GetChildren())
				while true do
					local v154
					v153, v154 = v151(v152, v153)
					if v153 == nil then
						break
					end
					if v154:IsA("BasePart") then
						v154.CanCollide = false
					end
				end
			end)
			task.wait()
		end
	end
	v79:Toggle("穿墙", "Noclip", false, function(p156)
		-- upvalues: (ref) v_u_141, (ref) v_u_128, (ref) v_u_155
		v_u_141.Noclip = p156
		if p156 == false then
			pcall(function()
				-- upvalues: (ref) v_u_128
				local v157, v158, v159 = pairs(v_u_128.Character:GetChildren())
				while true do
					local v160
					v159, v160 = v157(v158, v159)
					if v159 == nil then
						break
					end
					if v160:IsA("BasePart") and (v160.Name == "Head" or (v160.Name == "Torso" or (v160.Name == "UpperTorso" or v160.Name == "LowerTorso"))) then
						v160.CanCollide = true
					end
				end
			end)
		end
		v_u_155()
	end)
	v79:Toggle("无限跳", "InfJump", false, function(p161)
		-- upvalues: (ref) v_u_141
		v_u_141.InfJump = p161
	end)
	game:GetService("UserInputService").JumpRequest:Connect(function()
		-- upvalues: (ref) v_u_141, (ref) v_u_128
		if v_u_141.InfJump == true then
			v_u_128.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
		end
	end)
	local function v_u_166()
		-- upvalues: (ref) v_u_141, (ref) v_u_128, (ref) v_u_66
		while v_u_141.Fly == true do
			pcall(function()
				-- upvalues: (ref) v_u_128, (ref) v_u_66, (ref) v_u_141
				if not v_u_128.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
					local v162 = Instance.new("BodyVelocity")
					v162.Name = "FlyVelocity"
					v162.Parent = v_u_128.Character.HumanoidRootPart
					v162.MaxForce = Vector3.new(0, 0, 0)
					v162.Velocity = Vector3.new(0, 0, 0)
				end
				if not v_u_128.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
					local v163 = Instance.new("BodyGyro")
					v163.Name = "FlyGyro"
					v163.Parent = v_u_128.Character.HumanoidRootPart
					v163.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
					v163.P = 1000
					v163.D = 50
				end
				if v_u_128.Character and (v_u_128.Character:FindFirstChildOfClass("Humanoid") and v_u_128.Character.Humanoid.RootPart and (v_u_128.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") and v_u_128.Character.HumanoidRootPart:FindFirstChild("FlyGyro"))) then
					local v164 = v_u_66.CurrentCamera
					v_u_128.Character.HumanoidRootPart.FlyGyro.CFrame = v_u_66.CurrentCamera.CFrame
					local v165 = require(v_u_128.PlayerScripts:WaitForChild("PlayerModule"):WaitForChild("ControlModule")):GetMoveVector()
					v_u_128.Character.HumanoidRootPart.FlyVelocity.Velocity = Vector3.new()
					if v165.X > 0 then
						v_u_128.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_128.Character.HumanoidRootPart.FlyVelocity.Velocity + v164.CFrame.RightVector * (v165.X * v_u_141.FlySpeed)
					end
					if v165.X < 0 then
						v_u_128.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_128.Character.HumanoidRootPart.FlyVelocity.Velocity + v164.CFrame.RightVector * (v165.X * v_u_141.FlySpeed)
					end
					if v165.Z > 0 then
						v_u_128.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_128.Character.HumanoidRootPart.FlyVelocity.Velocity - v164.CFrame.LookVector * (v165.Z * v_u_141.FlySpeed)
					end
					if v165.Z < 0 then
						v_u_128.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_128.Character.HumanoidRootPart.FlyVelocity.Velocity - v164.CFrame.LookVector * (v165.Z * v_u_141.FlySpeed)
					end
					v_u_128.Character.Humanoid.PlatformStand = true
					v_u_128.Character.HumanoidRootPart.FlyVelocity.MaxForce = Vector3.new(9000000000, 9000000000, 9000000000)
					v_u_128.Character.HumanoidRootPart.FlyGyro.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
				end
			end)
			task.wait()
		end
	end
	v79:Toggle("飞行", "Fly", false, function(p167)
		-- upvalues: (ref) v_u_141, (ref) v_u_128, (ref) v_u_166
		v_u_141.Fly = p167
		if p167 == false then
			v_u_128.Character.Humanoid.PlatformStand = false
			if v_u_128.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
				v_u_128.Character.HumanoidRootPart:FindFirstChild("FlyVelocity"):Destroy()
			end
			if v_u_128.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
				v_u_128.Character.HumanoidRootPart:FindFirstChild("FlyGyro"):Destroy()
			end
		end
		v_u_166()
	end)
	v79:Slider("飞行速度", "Slider", 30, 1, 150, true, function(p168)
		-- upvalues: (ref) v_u_141
		v_u_141.FlySpeed = p168
	end)
	local v_u_169 = {
		["DefFOV"] = v_u_66.CurrentCamera.FieldOfView,
		["DefCameraMaxZoomDistance"] = v_u_128.CameraMaxZoomDistance,
		["DefCameraMinZoomDistance"] = v_u_128.CameraMinZoomDistance,
		["FieldOfView"] = 70,
		["FieldOfViewToggle"] = false,
		["CameraMaxZoomDistance"] = 128,
		["CameraMaxZoomDistanceToggle"] = false,
		["CameraMinZoomDistance"] = 0.5,
		["CameraMinZoomDistanceToggle"] = false,
		["FullBright"] = false,
		["DefAmbient"] = v_u_126.Ambient
	}
	local function v_u_170()
		-- upvalues: (ref) v_u_169, (ref) v_u_66, (ref) v_u_80
		while v_u_169.FieldOfViewToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_66, (ref) v_u_80
				v_u_66.CurrentCamera.FieldOfView = v_u_80.FieldOfView
			end)
			task.wait()
		end
	end
	local function v_u_171()
		-- upvalues: (ref) v_u_169, (ref) v_u_128, (ref) v_u_80
		while v_u_169.CameraMaxZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_128, (ref) v_u_80
				v_u_128.CameraMaxZoomDistance = v_u_80.CameraMaxZoomDistance
			end)
			task.wait()
		end
	end
	local function v_u_172()
		-- upvalues: (ref) v_u_169, (ref) v_u_128
		while v_u_169.CameraMinZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_128, (ref) v_u_169
				v_u_128.CameraMinZoomDistance = v_u_169.CameraMinZoomDistance
			end)
			task.wait()
		end
	end
	v_u_80:Slider("FOV", "FOV", 70, 1, 120, true, function(p173)
		-- upvalues: (ref) v_u_80, (ref) v_u_66, (ref) v_u_169, (ref) v_u_170
		v_u_80.FieldOfView = p173
		if p173 == false then
			v_u_66.CurrentCamera.FieldOfView = v_u_169.DefFOV
		end
		v_u_170()
	end)
	v_u_80:Toggle("FOV开关", "FOVToggle", false, function(p174)
		-- upvalues: (ref) v_u_80
		v_u_80.FieldOfViewToggle = p174
	end)
	v_u_80:Slider("最大相机聚焦距离", "CameraMaxZoomDistance", 128, 1, 1200, true, function(p175)
		-- upvalues: (ref) v_u_80, (ref) v_u_128, (ref) v_u_171
		v_u_80.CameraMaxZoomDistance = p175
		if p175 == false then
			v_u_128.CameraMaxZoomDistance = v_u_80.DefCameraMaxZoomDistance
		end
		v_u_171()
	end)
	v_u_80:Toggle("最大相机聚焦距离开关", "CameraMaxZoomDistanceToggle", false, function(p176)
		-- upvalues: (ref) v_u_80
		v_u_80.CameraMaxZoomDistanceToggle = p176
	end)
	v_u_80:Slider("最小相机聚焦距离", "Slider", 0.5, 1, 50, true, function(p177)
		-- upvalues: (ref) v_u_80, (ref) v_u_128, (ref) v_u_169, (ref) v_u_172
		v_u_80.CameraMinZoomDistance = p177
		if p177 == false then
			v_u_128.CameraMinZoomDistance = v_u_169.DefCameraMinZoomDistance
		end
		v_u_172()
	end)
	v_u_80:Toggle("最小相机聚焦距离开关", "CameraMinZoomDistanceToggle", false, function(p178)
		-- upvalues: (ref) v_u_80
		v_u_80.CameraMinZoomDistanceToggle = p178
	end)
	local function v_u_179()
		-- upvalues: (ref) v_u_141, (ref) v_u_126
		while v_u_141.FullBright == true do
			pcall(function()
				-- upvalues: (ref) v_u_126
				v_u_126.Ambient = Color3.new(1, 1, 1)
			end)
			task.wait()
		end
	end
	v_u_80:Toggle("全局高亮", "FullBright", false, function(p180)
		-- upvalues: (ref) v_u_169, (ref) v_u_126, (ref) v_u_179
		v_u_169.FullBright = p180
		if p180 == false then
			v_u_126.Ambient = v_u_169.DefAmbient
		end
		v_u_179()
	end)
	local v_u_181 = {
		["Bk"] = nil,
		["Dn"] = nil,
		["Ft"] = nil,
		["Lf"] = nil,
		["Rt"] = nil,
		["Up"] = nil
	}
	v81:Dropdown("天空盒", "Skybox", { "cs_办公室", "Always.win", "Advanced Logic" }, function(p182)
		-- upvalues: (ref) v_u_105
		if p182 == "cs_办公室" then
			v_u_105({
				["Name"] = "cs_office",
				["Bk"] = "rbxassetid://658623433",
				["Dn"] = "rbxassetid://316342560",
				["Ft"] = "rbxassetid://658625205",
				["Lf"] = "rbxassetid://658627155",
				["Rt"] = "rbxassetid://658628504",
				["Up"] = "rbxassetid://658632701"
			})
		elseif p182 == "Always.win" then
			v_u_105({
				["Name"] = "Always.win",
				["Bk"] = "rbxassetid://17411013742",
				["Dn"] = "rbxassetid://17411013742",
				["Ft"] = "rbxassetid://17411013742",
				["Lf"] = "rbxassetid://17411013742",
				["Rt"] = "rbxassetid://17411013742",
				["Up"] = "rbxassetid://17411013742"
			})
		elseif p182 == "Advanced Logic" then
			v_u_105({
				["Name"] = "Advanced Logic",
				["Bk"] = "rbxassetid://17803761395",
				["Dn"] = "rbxassetid://17803761395",
				["Ft"] = "rbxassetid://17803761395",
				["Lf"] = "rbxassetid://17803761395",
				["Rt"] = "rbxassetid://17803761395",
				["Up"] = "rbxassetid://17803761395",
				["SunAsset"] = "rbxassetid://17768924741",
				["SunAngularSize"] = 50
			})
		end
	end)
	v81:Textbox("自定义天空盒Bk", "Textbox", "请输入SkyboxBk贴图ID", function(p_u_183)
		-- upvalues: (ref) v_u_181
		pcall(function()
			-- upvalues: (ref) p_u_183, (ref) v_u_181
			if p_u_183:find("rbxassetid://") then
				v_u_181.Bk = p_u_183
			else
				v_u_181.Bk = "rbxassetid://" .. p_u_183
			end
		end)
	end)
	v81:Textbox("自定义天空盒Dn", "Textbox", "请输入SkyboxDn贴图ID", function(p_u_184)
		-- upvalues: (ref) v_u_181
		pcall(function()
			-- upvalues: (ref) p_u_184, (ref) v_u_181
			if p_u_184:find("rbxassetid://://") then
				v_u_181.Dn = p_u_184
			else
				v_u_181.Dn = "rbxassetid://" .. p_u_184
			end
		end)
	end)
	v81:Textbox("自定义天空盒Ft", "Textbox", "请输入SkyboxFt贴图ID", function(p_u_185)
		-- upvalues: (ref) v_u_181
		pcall(function()
			-- upvalues: (ref) p_u_185, (ref) v_u_181
			if p_u_185:find("rbxassetid://") then
				v_u_181.Ft = p_u_185
			else
				v_u_181.Ft = "rbxassetid://" .. p_u_185
			end
		end)
	end)
	v81:Textbox("自定义天空盒Lf", "Textbox", "请输入SkyboxLf贴图ID", function(p_u_186)
		-- upvalues: (ref) v_u_181
		pcall(function()
			-- upvalues: (ref) p_u_186, (ref) v_u_181
			if p_u_186:find("rbxassetid://") then
				v_u_181.Lf = p_u_186
			else
				v_u_181.Lf = "rbxassetid://" .. p_u_186
			end
		end)
	end)
	v81:Textbox("自定义天空盒Rt", "Textbox", "请输入SkyboxRt贴图ID", function(p_u_187)
		-- upvalues: (ref) v_u_181
		pcall(function()
			-- upvalues: (ref) p_u_187, (ref) v_u_181
			if p_u_187:find("rbxassetid://") then
				v_u_181.Rt = p_u_187
			else
				v_u_181.Rt = "rbxassetid://" .. p_u_187
			end
		end)
	end)
	v81:Textbox("自定义天空盒Up", "Textbox", "请输入SkyboxUp贴图ID", function(p_u_188)
		-- upvalues: (ref) v_u_181
		pcall(function()
			-- upvalues: (ref) p_u_188, (ref) v_u_181
			if p_u_188:find("rbxassetid://") then
				v_u_181.Up = p_u_188
			else
				v_u_181.Up = "rbxassetid://" .. p_u_188
			end
		end)
	end)
	v81:Button("修改自定义天空盒", function()
		-- upvalues: (ref) v_u_105, (ref) v_u_181
		pcall(function()
			-- upvalues: (ref) v_u_105, (ref) v_u_181
			v_u_105({
				["Name"] = "我爱手冲",
				["Bk"] = v_u_181.Bk,
				["Dn"] = v_u_181.Dn,
				["Ft"] = v_u_181.Ft,
				["Lf"] = v_u_181.Lf,
				["Rt"] = v_u_181.Rt,
				["Up"] = v_u_181.Up
			})
		end)
	end)
	v83:Label("团队")
	v83:Label("Advanced Logic")
	v83:Label("群号: 684407929")
	v84:Label("当前版本 " .. v72)
	v_u_128.Idled:Connect(function()
		game:GetService("VirtualUser"):CaptureController()
		game:GetService("VirtualUser"):ClickButton2(Vector2.new())
	end)
	if game:GetService("TextChatService").ChatVersion == Enum.ChatVersion.LegacyChatService then
		rawset(require(v_u_128:FindFirstChild("PlayerScripts"):FindFirstChild("ChatScript").ChatMain), "MessagePosted", {
			["fire"] = function(p189)
				return p189
			end,
			["wait"] = function() end,
			["connect"] = function() end
		})
	end
else
	game:GetService("Players").LocalPlayer:Kick("您不是白名单用户,请加入684407929(Adavanced Logic官方群)购买")
	setclipboard(game:GetService("RbxAnalyticsService"):GetClientId())
end
