local v_u_1 = http_request or request or (HttpPost or syn.request)
local v_u_2 = nil
local v_u_3 = 0
local function v_u_9(p4, p5, p6)
	-- upvalues: (ref) v_u_3, (ref) v_u_9
	v_u_3 = v_u_3 + 1
	if p6 then
		local v7 = v_u_9(p4, p5) and v_u_9(p4, p6)
		if v7 then
			v7 = v_u_9(p5, p6)
		end
		return v7
	else
		local v8 = type(p4) == typeof(p5) and (typeof(p4) == type(p5) and (type(p4) == typeof(p5) or typeof(p4) == type(p5))) and (#tostring(p4) == #tostring(p5) and rawequal(p4, p5))
		if v8 then
			if tostring(p4) < tostring(p5) or tostring(p4) > tostring(p5) then
				v8 = false
			else
				v8 = rawequal(tostring(p4), tostring(p5))
			end
		end
		return v8
	end
end
local function v_u_11(p10)
	return ({ ... })[p10]
end
local function v_u_18(p_u_12)
	-- upvalues: (ref) v_u_1, (ref) v_u_2, (ref) v_u_11
	local v_u_13 = false
	local v15 = {
		["__call"] = v_u_1,
		["__index"] = function(_, p14)
			-- upvalues: (ref) v_u_13, (ref) v_u_1, (ref) v_u_2, (ref) p_u_12
			v_u_13 = true
			if debug.info(2, "f") ~= v_u_1 then
				v_u_2 = "反钩子 [H - 1]"
				return "https://www.roblox.com/users/7207800972/profile"
			end
			if not coroutine.isyieldable() then
				return p_u_12[p14]
			end
			v_u_2 = "反钩子 [H - 2]"
			return "https://www.roblox.com/users/7207800972/profile"
		end
	}
	local v16 = setmetatable({}, v15)
	local v17 = v_u_11(2, pcall(v16))
	if v_u_13 then
		return v17
	end
end
local function v21(p19)
	-- upvalues: (ref) v_u_18
	local v20 = v_u_18({
		["Url"] = p19,
		["Method"] = "GET"
	})
	repeat
		task.wait()
	until v20
	return v20.Body
end
local function v23(p22)
	return string.split(p22 or "", ": ")[2]
end
local function v_u_26(p24, p25)
	-- upvalues: (ref) v_u_26
	if p24 == 0 then
		task.wait()
	end
	p25(...)
	v_u_26(p24 + 1, p25)
end
local function v28(p27)
	game:GetService("Players").LocalPlayer:Kick("")
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.TitleFrame.ErrorTitle.Text = "危险行为"
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.MessageArea.ErrorFrame.ErrorMessage.Text = p27
	task.wait(1)
	game:Shutdown()
	task.wait(1)
	task.spawn(function()
		while true do

		end
	end)
end
local v29 = {
	v_u_26,
	v_u_11,
	pcall,
	debug.info,
	islclosure,
	debug.getinfo,
	debug.getfenv,
	0,
	{
		"Url",
		"Method",
		"Headers",
		"Cookies",
		"Body"
	},
	table.insert,
	v_u_2,
	v_u_1
}
local v30 = { math.random, v_u_11, v_u_18 }
local v31 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end
}
setmetatable(v29, v31)
local v32 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end
}
setmetatable(v30, v32)
local v33 = type(getrawmetatable(v29).__index) ~= "function" and "反篡改 [M - S1]" or v_u_2
v_u_3 = v_u_3 + 1
local v34 = type(getrawmetatable(v29).__tostring) ~= "function" and "反篡改 [M - S1]" or v33
v_u_3 = v_u_3 + 1
local v35 = (type(getrawmetatable(v30).__index) ~= "function" or type(getrawmetatable(v30).__index) ~= type(getmetatable(v30).__index)) and "反篡改 [M - S1]" or v34
v_u_3 = v_u_3 + 1
local v36 = type(getrawmetatable(v30).__tostring) ~= "function" and "反篡改 [M - S1]" or v35
v_u_3 = v_u_3 + 1
local v37, v38 = pcall(pcall)
local _, _ = pcall(math.random)
local _, _ = pcall(setmetatable)
local _, _ = pcall(string.split)
local _, _ = pcall(debug.traceback)
local _, _ = pcall(getmetatable)
local _, _ = pcall(coroutine.wrap)
local _, _ = pcall(table.insert)
local v39 = (v37 or v38 ~= "missing argument #1") and "反函数钩子 [P]" or v36
v_u_3 = v_u_3 + 1
local v40 = {
	math.abs,
	os.clock,
	coroutine.isyieldable,
	debug.info,
	v_u_1,
	game:GetService("Players").LocalPlayer.Kick,
	table.insert,
	bit32.bxor,
	debug.getfenv,
	setrawmetatable,
	pcall,
	math.random,
	setmetatable,
	string.split,
	debug.traceback,
	debug.info,
	getrawmetatable,
	type,
	table.insert,
	math.random,
	v_u_11,
	table.concat,
	string.byte,
	string.char,
	debug.getinfo,
	islclosure,
	string.reverse,
	v_u_18,
	getmetatable
}
local v41 = next
local v42 = v_u_18
local v43 = v_u_26
local v44 = v_u_9
local v45 = v_u_3
local v46 = v_u_11
local v47 = nil
while true do
	local v48
	v47, v48 = v41(v40, v47)
	if v47 == nil then
		break
	end
	for _ = 1, 197 do
		v48 = coroutine.wrap(v48)
	end
	if v46(2, pcall(v48)) == "C stack overflow" then
		v_u_2 = "反函数钩子 [F - G2]"
		v39 = v_u_2
	end
end
v_u_3 = v45 + 1
local v49 = not debug.info(2, "f") and "反篡改 [1]" or v39
v_u_3 = v_u_3 + 1
local v50 = math.random() == math.random() and "反篡改 [2]" or v49
local v51 = not v44(v_u_3, 7) and "反钩子 [C]" or v50
local _, v52 = pcall(v43, 0, coroutine.wrap)
local v53 = v23(v52) ~= "missing argument #1 to \'wrap\' (function expected)" and "反函数钩子 [F - C]" or v51
local v54 = not string.sub(game:GetService("RbxAnalyticsService"):GetClientId(), 1, 8) == string.split(game:GetService("RbxAnalyticsService"):GetClientId(), "-")[1] and "反函数钩子 [F - S]" or v53
local v55 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/P"))()
local v56 = loadstring(v21("https://raw.githubusercontent.com/longshu886/linniscript/refs/heads/main/ng", true))()
local v57 = clonefunction(game:GetService("RbxAnalyticsService").GetClientId)(game:GetService("RbxAnalyticsService")):split("-")
local v58 = v57[1] .. v57[2] .. v57[3] .. v57[4] .. v57[5]
local v59 = not gethwid and "未知" or gethwid()
local v60 = table.find({ Enum.Platform.IOS }, game:GetService("UserInputService"):GetPlatform()) and "IOS" or (table.find({ Enum.Platform.Android }, game:GetService("UserInputService"):GetPlatform()) and "Android" or "PC/Mac")
local v61, v62
if v55[v58] ~= true or v56[v58] ~= true then
	v61 = "0xFF0000"
	v62 = "否"
else
	v61 = "0x32CD32"
	v62 = "是"
end
local v63 = {
	["username"] = "Advanced Bot",
	["embeds"] = {
		{
			["color"] = tonumber(tostring(v61)),
			["title"] = "有人注入了Advanced Logic",
			["fields"] = {
				{
					["name"] = "名称",
					["value"] = game:GetService("Players").LocalPlayer.Name,
					["inline"] = true
				},
				{
					["name"] = "昵称",
					["value"] = game:GetService("Players").LocalPlayer.DisplayName,
					["inline"] = true
				},
				{
					["name"] = "UID",
					["value"] = "[" .. game:GetService("Players").LocalPlayer.UserId .. "](" .. tostring("https://www.roblox.com/users/" .. game:GetService("Players").LocalPlayer.UserId .. "/profile") .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏ID",
					["value"] = "[" .. game.PlaceId .. "](" .. tostring("https://www.roblox.com/games/" .. game.PlaceId) .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏名称",
					["value"] = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name,
					["inline"] = true
				},
				{
					["name"] = "注入器",
					["value"] = identifyexecutor(),
					["inline"] = true
				},
				{
					["name"] = "HWID",
					["value"] = v59,
					["inline"] = true
				},
				{
					["name"] = "客户端ID",
					["value"] = game:GetService("RbxAnalyticsService"):GetClientId(),
					["inline"] = false
				},
				{
					["name"] = "设备",
					["value"] = v60,
					["inline"] = true
				},
				{
					["name"] = "用户状态",
					["value"] = v62,
					["inline"] = true
				}
			},
			["timestamp"] = os.date("%Y-%m-%dT%X.000Z")
		}
	}
}
v42({
	["Url"] = "https://discord.com/api/webhooks/1268122774069579806/Pi7q9f25rIwlkr-iLiIFEPJIvxx5dzcA9tSUXoTY8R1uUXF-CnFMJ91V2aX75dBOJCuY",
	["Method"] = "POST",
	["Headers"] = {
		["Content-Type"] = "application/json"
	},
	["Body"] = game.HttpService:JSONEncode(v63)
})
if v54 ~= nil then
	v28(v54)
end
if v55[v58] == true or v56[v58] == true then
	setfpscap(math.huge)
	_G.ScriptIsRunning = false
	_G.ScriptIsRunning = true
	local v_u_64 = game:GetService("Players")
	local v_u_65 = v_u_64.LocalPlayer
	game:GetService("CoreGui")
	game:GetService("RbxAnalyticsService")
	game:GetService("RunService")
	local _ = v_u_65.PlayerGui
	local v_u_66 = game:GetService("Workspace")
	local v_u_67 = game:GetService("Lighting")
	local v_u_68 = {
		["Real"] = {
			["白色"] = Color3.fromRGB(255, 255, 255),
			["红色"] = Color3.fromRGB(255, 0, 0),
			["绿色"] = Color3.fromRGB(0, 255, 0),
			["蓝色"] = Color3.fromRGB(0, 0, 255),
			["粉色"] = Color3.fromRGB(255, 170, 255),
			["紫色"] = Color3.fromRGB(85, 255, 255)
		},
		["Visual"] = {
			"白色",
			"红色",
			"绿色",
			"蓝色",
			"粉色",
			"紫色"
		}
	}
	local v_u_69 = {
		["MasterSwitch"] = false,
		["NameEsp"] = false,
		["HighlightEsp"] = false,
		["EspScale"] = 0.5,
		["HighlightTransparency"] = 0.5,
		["SelectFillColor"] = Color3.fromRGB(255, 255, 255)
	}
	local v_u_70 = {
		["SelectPlr"] = nil,
		["AutoTeleportToSelectPlr"] = false,
		["AutoTeleportToSelectPlrDistance"] = 4.5,
		["KillAura"] = false,
		["KillAuraDistance"] = 15,
		["LockBowStrength"] = false,
		["BowStrength"] = 4
	}
	local v_u_71 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ns.cc"))()
	local v72 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/bob.afk"))()
	local v73 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/v"))():new("<font color=\"rgb(0,180,216)\">Advanced</font> <font color=\"rgb(252,255,0)\">Logic</font>", true, "gamesense", 0, false)
	local v74 = v73:Tab("主要", "7733960981")
	local v75 = v74:Section("杀戮光环", false)
	local v76 = v74:Section("弓箭", false)
	local v77 = v73:Tab("透视", "7733696665")
	local v78 = v77:Section("功能", false)
	local v79 = v77:Section("透视设置", false)
	local v80 = v73:Tab("玩家", "7743876054"):Section("玩家选项", true)
	local v81 = v73:Tab("本地", "7733752575")
	local v82 = v81:Section("本地玩家", false)
	local v_u_83 = v81:Section("本地视觉", false)
	local v84 = v81:Section("天空盒", false)
	local v85 = v73:Tab("关于", "7743871575")
	local v86 = v85:Section("关于作者", true)
	local v87 = v85:Section("关于脚本", true)
	local function v_u_100(p_u_88, p_u_89, p_u_90, p_u_91, p_u_92, p_u_93)
		-- upvalues: (ref) v_u_69
		pcall(function()
			-- upvalues: (ref) p_u_88, (ref) p_u_93, (ref) p_u_90, (ref) p_u_89, (ref) v_u_69, (ref) p_u_92, (ref) p_u_91
			if p_u_88 and p_u_93 then
				if not (p_u_88:FindFirstChild("ALBill") and p_u_90:FindFirstChild("ALHighlight")) then
					if not p_u_88:FindFirstChild("ALBill") then
						local v94 = Instance.new("BillboardGui")
						local v95 = Instance.new("TextLabel")
						v94.Name = "ALBill"
						v94.Parent = p_u_88
						v94.Active = true
						v94.ExtentsOffset = Vector3.new(0, 2, 0)
						v94.Size = UDim2.new(0, 200, 0, 50)
						v94.Enabled = p_u_89
						v94.AlwaysOnTop = true
						v95.Name = "TextLabel"
						v95.Parent = v94
						v95.AnchorPoint = Vector2.new(0.5, 0.5)
						v95.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						v95.BackgroundTransparency = 1
						v95.BorderColor3 = Color3.fromRGB(0, 0, 0)
						v95.Position = UDim2.new(0.5, 0, 0.5, 0)
						v95.Size = UDim2.new(v_u_69.EspScale, 0, v_u_69.EspScale, 0)
						v95.Text = p_u_92
						v95.TextColor3 = p_u_93
						v95.TextScaled = true
						v95.TextStrokeTransparency = 0.19
					end
					if not p_u_90:FindFirstChild("ALHighlight") then
						local v96 = Instance.new("Highlight")
						v96.Name = "ALHighlight"
						v96.Parent = p_u_90
						v96.FillColor = p_u_93
						v96.Enabled = p_u_91
						v96.FillTransparency = v_u_69.HighlightTransparency
					end
				end
				if p_u_88:FindFirstChild("ALBill") then
					local v97 = p_u_88:FindFirstChild("ALBill")
					local v98 = v97.TextLabel
					v97.Enabled = p_u_89
					v98.Text = p_u_92
					v98.Size = UDim2.new(v_u_69.EspScale, 0, v_u_69.EspScale, 0)
					v98.TextColor3 = p_u_93
				end
				if p_u_90:FindFirstChild("ALHighlight") then
					local v99 = p_u_90:FindFirstChild("ALHighlight")
					v99.FillColor = p_u_93
					v99.Enabled = p_u_91
					v99.FillTransparency = v_u_69.HighlightTransparency
				end
			end
		end)
	end
	local function v_u_108(p101)
		-- upvalues: (ref) v_u_67, (ref) v_u_71
		local v102 = v_u_67
		local v103, v104, v105 = pairs(v102:GetChildren())
		while true do
			local v106
			v105, v106 = v103(v104, v105)
			if v105 == nil then
				break
			end
			if v106:IsA("Sky") then
				v106:Destroy()
			end
		end
		if p101.Bk and (p101.Dn and (p101.Ft and (p101.Lf and (p101.Rt and (p101.Up and p101.Name))))) then
			local v107 = Instance.new("Sky")
			v107.Name = p101.Name
			v107.SkyboxBk = p101.Bk
			v107.SkyboxDn = p101.Dn
			v107.SkyboxFt = p101.Ft
			v107.SkyboxLf = p101.Lf
			v107.SkyboxRt = p101.Rt
			v107.SkyboxUp = p101.Up
			v107.Parent = v_u_67
			if p101.SunAsset and p101.SunAngularSize then
				v107.SunTextureId = p101.SunAsset
				v107.SunAngularSize = p101.SunAngularSize
			end
		else
			v_u_71:Notify("无效的天空盒参数", 2)
		end
	end
	local function v_u_117(p_u_109)
		local v_u_110 = math.huge
		local v111, v112, v113 = pairs(game:GetService("Players"):GetChildren())
		local v_u_114 = nil
		while true do
			local v_u_115
			v113, v_u_115 = v111(v112, v113)
			if v113 == nil then
				break
			end
			if v_u_115 ~= game:GetService("Players").LocalPlayer then
				if #game:GetService("Teams"):GetChildren() > 0 and v_u_115.Team == game:GetService("Players").LocalPlayer.Team then
					return
				end
				pcall(function()
					-- upvalues: (ref) v_u_115, (ref) p_u_109, (ref) v_u_110, (ref) v_u_114
					local v116 = (game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.Position - v_u_115.Character.HumanoidRootPart.Position).Magnitude
					if v116 < p_u_109 then
						warn(v116, v_u_110)
						warn(v116 < v_u_110)
						if v116 < v_u_110 then
							v_u_110 = v116
							v_u_114 = v_u_115
						end
					end
				end)
			end
		end
		warn(v_u_114)
		return v_u_114
	end
	local function v_u_120()
		-- upvalues: (ref) v_u_70, (ref) v_u_117
		while v_u_70.KillAura do
			pcall(function()
				-- upvalues: (ref) v_u_117, (ref) v_u_70
				local v118 = v_u_117(v_u_70.KillAuraDistance)
				if v118 then
					print("current target is " .. v118.Name)
					local v119 = { v118.Character, true, "WoodenSword" }
					game:GetService("ReplicatedStorage").Modules.Knit.Services.ToolService.RF.AttackPlayerWithSword:InvokeServer(unpack(v119))
				end
			end)
			task.wait()
		end
	end
	v75:Toggle("开关", "KillAura", false, function(p121)
		-- upvalues: (ref) v_u_70, (ref) v_u_120
		v_u_70.KillAura = p121
		v_u_120()
	end)
	v75:Slider("杀戮距离", "KillAuraDistance", 15, 1, 20, true, function(p122)
		-- upvalues: (ref) v_u_70
		v_u_70.KillAuraDistance = p122
	end)
	local v_u_123 = nil
	v_u_123 = hookmetamethod(game, "__namecall", function(p124)
		-- upvalues: (ref) v_u_70, (ref) v_u_123
		local v125 = { ... }
		if getnamecallmethod() == "InvokeServer" and (tostring(p124) == "Fire" and v_u_70.LockBowStrength == true) then
			v125[2] = v_u_70.BowStrength
		end
		return v_u_123(p124, unpack(v125))
	end)
	v76:Toggle("锁定初始箭速", "LockBowStrength", false, function(p126)
		-- upvalues: (ref) v_u_70
		v_u_70.LockBowStrength = p126
	end)
	v76:Slider("箭速", "BowStrength", 4, 1, 20, true, function(p127)
		-- upvalues: (ref) v_u_70
		v_u_70.BowStrength = p127
	end)
	local function v_u_137()
		-- upvalues: (ref) v_u_69, (ref) v_u_64, (ref) v_u_65, (ref) v_u_100
		while v_u_69.MasterSwitch == true do
			local v128 = v_u_64
			local v129, v130, v131 = pairs(v128:GetChildren())
			while true do
				local v_u_132
				v131, v_u_132 = v129(v130, v131)
				if v131 == nil then
					break
				end
				pcall(function()
					-- upvalues: (ref) v_u_69, (ref) v_u_132, (ref) v_u_65, (ref) v_u_100
					local v133 = false
					local v134 = false
					if v_u_69.MasterSwitch == true and v_u_132 ~= v_u_65 then
						local v135 = v_u_69.NameEsp == true and true or v133
						local v136 = v_u_69.HighlightEsp == true and true or v134
						v_u_100(v_u_132.Character.HumanoidRootPart, v135, v_u_132.Character, v136, v_u_132.DisplayName .. " | " .. v_u_132.Name, v_u_69.SelectFillColor)
					end
				end)
			end
			task.wait()
		end
	end
	v78:Toggle("透视开关", "EspToggle", false, function(p138)
		-- upvalues: (ref) v_u_69, (ref) v_u_137
		v_u_69.MasterSwitch = p138
		v_u_137()
	end)
	v78:Toggle("用户名透视", "UsernameEsp", false, function(p139)
		-- upvalues: (ref) v_u_69
		v_u_69.NameEsp = p139
	end)
	v78:Toggle("上色开关", "HighlightToggle", false, function(p140)
		-- upvalues: (ref) v_u_69
		v_u_69.HighlightEsp = p140
	end)
	v79:Dropdown("透视颜色", "SelectFillColor", v_u_68.Visual, function(p141)
		-- upvalues: (ref) v_u_69, (ref) v_u_68
		v_u_69.SelectFillColor = v_u_68.Real[p141]
	end)
	v79:Slider("透视大小", "EspScale", 0.5, 0.1, 1, true, function(p142)
		-- upvalues: (ref) v_u_69
		v_u_69.EspScale = p142
	end)
	v79:Slider("上色透明度", "FillTransparency", 0.5, 0, 1, true, function(p143)
		-- upvalues: (ref) v_u_69
		v_u_69.HighlightTransparency = p143
	end)
	local v144 = v_u_64
	local v145, v146, v147 = pairs(v_u_64.GetChildren(v144))
	local v_u_148 = v_u_67
	local v_u_149 = v_u_64
	local v_u_150 = v_u_70
	local v_u_151 = v_u_65
	local v_u_152 = {}
	while true do
		local v153, v154 = v145(v146, v147)
		if v153 == nil then
			break
		end
		v147 = v153
		if v154.Name ~= v_u_151.Name then
			table.insert(v_u_152, v154.Name)
		end
	end
	local v_u_156 = v80:Dropdown("玩家列表", "Players", v_u_152, function(p155)
		-- upvalues: (ref) v_u_150
		v_u_150.SelectPlr = p155
	end)
	v_u_149.PlayerAdded:Connect(function(p157)
		-- upvalues: (ref) v_u_152, (ref) v_u_156
		table.insert(v_u_152, p157.Name)
		v_u_156.AddOption(p157.Name)
	end)
	v_u_149.PlayerRemoving:Connect(function(p158)
		-- upvalues: (ref) v_u_152, (ref) v_u_156
		table.remove(v_u_152, table.find(v_u_152, p158.Name))
		v_u_156.RemoveOption(p158.Name)
	end)
	v80:Button("传送到选中的玩家", function()
		-- upvalues: (ref) v_u_151, (ref) v_u_149, (ref) v_u_150
		pcall(function()
			-- upvalues: (ref) v_u_151, (ref) v_u_149, (ref) v_u_150
			local v159 = v_u_149
			v_u_151.Character.HumanoidRootPart.CFrame = v159:FindFirstChild(v_u_150.SelectPlr).Character.HumanoidRootPart.CFrame
		end)
	end)
	v80:Toggle("自动传送到选择的玩家身后", "Noclip", false, function(p160)
		-- upvalues: (ref) v_u_150
		v_u_150.AutoTeleportToSelectPlr = p160
	end)
	v80:Slider("自动传送距离设置", "Slider", 4.5, 1, 20, true, function(p161)
		-- upvalues: (ref) v_u_150
		v_u_150.AutoTeleportToSelectPlrDistance = p161
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_150, (ref) v_u_151, (ref) v_u_149
		while _G.ScriptIsRunning == true do
			if v_u_150.AutoTeleportToSelectPlr == true then
				pcall(function()
					-- upvalues: (ref) v_u_151, (ref) v_u_149, (ref) v_u_150
					local v162 = v_u_149
					local v163 = v_u_149
					v_u_151.Character.HumanoidRootPart.CFrame = v162:FindFirstChild(v_u_150.SelectPlr).Character.HumanoidRootPart.CFrame - v163:FindFirstChild(v_u_150.SelectPlr).Character.HumanoidRootPart.CFrame.LookVector * v_u_150.AutoTeleportToSelectPlrDistance
				end)
			end
			task.wait()
		end
	end)
	local v_u_164 = {
		["WalkSpeed"] = 16,
		["WalkSpeedToggle"] = false,
		["JumpPower"] = 50,
		["JumpPowerToggle"] = false,
		["Gravity"] = 196.2,
		["GravityToggle"] = false,
		["Fly"] = false,
		["FlySpeed"] = 30,
		["Noclip"] = false,
		["InfJump"] = false
	}
	v82:Label("移动速度")
	local function v_u_165()
		-- upvalues: (ref) v_u_164, (ref) v_u_151
		while v_u_164.WalkSpeedToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_151, (ref) v_u_164
				v_u_151.Character.Humanoid.WalkSpeed = v_u_164.WalkSpeed
			end)
			task.wait()
		end
	end
	v82:Slider("数值", "WalkSpeed", 16, 1, 150, true, function(p166)
		-- upvalues: (ref) v_u_164
		v_u_164.WalkSpeed = p166
	end)
	v82:Toggle("开关", "WalkSpeedToggle", false, function(p167)
		-- upvalues: (ref) v_u_164, (ref) v_u_165
		v_u_164.WalkSpeedToggle = p167
		v_u_165()
	end)
	v82:Label("跳跃高度")
	local function v_u_168()
		-- upvalues: (ref) v_u_164, (ref) v_u_151
		while v_u_164.JumpPowerToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_151, (ref) v_u_164
				v_u_151.Character.Humanoid.JumpPower = v_u_164.JumpPower
			end)
			task.wait()
		end
	end
	v82:Slider("数值", "JumpPower", 50, 1, 150, true, function(p169)
		-- upvalues: (ref) v_u_164
		v_u_164.JumpPower = p169
	end)
	v82:Toggle("开关", "JumpPowerToggle", false, function(p170)
		-- upvalues: (ref) v_u_164, (ref) v_u_168
		v_u_164.JumpPowerToggle = p170
		v_u_168()
	end)
	v82:Label("重力")
	local function v_u_171()
		-- upvalues: (ref) v_u_164, (ref) v_u_66
		while v_u_164.GravityToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_66, (ref) v_u_164
				v_u_66.Gravity = v_u_164.Gravity
			end)
			task.wait()
		end
	end
	v82:Slider("数值", "Gravity", 196.2, 1, 1000, true, function(p172)
		-- upvalues: (ref) v_u_164
		v_u_164.Gravity = p172
	end)
	v82:Toggle("开关", "GravityToggle", false, function(p173)
		-- upvalues: (ref) v_u_164, (ref) v_u_171
		v_u_164.GravityToggle = p173
		v_u_171()
	end)
	local function v_u_178()
		-- upvalues: (ref) v_u_164, (ref) v_u_151
		while v_u_164.Noclip == true do
			pcall(function()
				-- upvalues: (ref) v_u_151
				local v174, v175, v176 = pairs(v_u_151.Character:GetChildren())
				while true do
					local v177
					v176, v177 = v174(v175, v176)
					if v176 == nil then
						break
					end
					if v177:IsA("BasePart") then
						v177.CanCollide = false
					end
				end
			end)
			task.wait()
		end
	end
	v82:Toggle("穿墙", "Noclip", false, function(p179)
		-- upvalues: (ref) v_u_164, (ref) v_u_151, (ref) v_u_178
		v_u_164.Noclip = p179
		if p179 == false then
			pcall(function()
				-- upvalues: (ref) v_u_151
				local v180, v181, v182 = pairs(v_u_151.Character:GetChildren())
				while true do
					local v183
					v182, v183 = v180(v181, v182)
					if v182 == nil then
						break
					end
					if v183:IsA("BasePart") and (v183.Name == "Head" or (v183.Name == "Torso" or (v183.Name == "UpperTorso" or v183.Name == "LowerTorso"))) then
						v183.CanCollide = true
					end
				end
			end)
		end
		v_u_178()
	end)
	v82:Toggle("无限跳", "InfJump", false, function(p184)
		-- upvalues: (ref) v_u_164
		v_u_164.InfJump = p184
	end)
	game:GetService("UserInputService").JumpRequest:Connect(function()
		-- upvalues: (ref) v_u_164, (ref) v_u_151
		if v_u_164.InfJump == true then
			v_u_151.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
		end
	end)
	local function v_u_189()
		-- upvalues: (ref) v_u_164, (ref) v_u_151, (ref) v_u_66
		while v_u_164.Fly == true do
			pcall(function()
				-- upvalues: (ref) v_u_151, (ref) v_u_66, (ref) v_u_164
				if not v_u_151.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
					local v185 = Instance.new("BodyVelocity")
					v185.Name = "FlyVelocity"
					v185.Parent = v_u_151.Character.HumanoidRootPart
					v185.MaxForce = Vector3.new(0, 0, 0)
					v185.Velocity = Vector3.new(0, 0, 0)
				end
				if not v_u_151.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
					local v186 = Instance.new("BodyGyro")
					v186.Name = "FlyGyro"
					v186.Parent = v_u_151.Character.HumanoidRootPart
					v186.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
					v186.P = 1000
					v186.D = 50
				end
				if v_u_151.Character and (v_u_151.Character:FindFirstChildOfClass("Humanoid") and v_u_151.Character.Humanoid.RootPart and (v_u_151.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") and v_u_151.Character.HumanoidRootPart:FindFirstChild("FlyGyro"))) then
					local v187 = v_u_66.CurrentCamera
					v_u_151.Character.HumanoidRootPart.FlyGyro.CFrame = v_u_66.CurrentCamera.CFrame
					local v188 = require(v_u_151.PlayerScripts:WaitForChild("PlayerModule"):WaitForChild("ControlModule")):GetMoveVector()
					v_u_151.Character.HumanoidRootPart.FlyVelocity.Velocity = Vector3.new()
					if v188.X > 0 then
						v_u_151.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_151.Character.HumanoidRootPart.FlyVelocity.Velocity + v187.CFrame.RightVector * (v188.X * v_u_164.FlySpeed)
					end
					if v188.X < 0 then
						v_u_151.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_151.Character.HumanoidRootPart.FlyVelocity.Velocity + v187.CFrame.RightVector * (v188.X * v_u_164.FlySpeed)
					end
					if v188.Z > 0 then
						v_u_151.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_151.Character.HumanoidRootPart.FlyVelocity.Velocity - v187.CFrame.LookVector * (v188.Z * v_u_164.FlySpeed)
					end
					if v188.Z < 0 then
						v_u_151.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_151.Character.HumanoidRootPart.FlyVelocity.Velocity - v187.CFrame.LookVector * (v188.Z * v_u_164.FlySpeed)
					end
					v_u_151.Character.Humanoid.PlatformStand = true
					v_u_151.Character.HumanoidRootPart.FlyVelocity.MaxForce = Vector3.new(9000000000, 9000000000, 9000000000)
					v_u_151.Character.HumanoidRootPart.FlyGyro.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
				end
			end)
			task.wait()
		end
	end
	v82:Toggle("飞行", "Fly", false, function(p190)
		-- upvalues: (ref) v_u_164, (ref) v_u_151, (ref) v_u_189
		v_u_164.Fly = p190
		if p190 == false then
			v_u_151.Character.Humanoid.PlatformStand = false
			if v_u_151.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
				v_u_151.Character.HumanoidRootPart:FindFirstChild("FlyVelocity"):Destroy()
			end
			if v_u_151.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
				v_u_151.Character.HumanoidRootPart:FindFirstChild("FlyGyro"):Destroy()
			end
		end
		v_u_189()
	end)
	v82:Slider("飞行速度", "Slider", 30, 1, 150, true, function(p191)
		-- upvalues: (ref) v_u_164
		v_u_164.FlySpeed = p191
	end)
	local v_u_192 = {
		["DefFOV"] = v_u_66.CurrentCamera.FieldOfView,
		["DefCameraMaxZoomDistance"] = v_u_151.CameraMaxZoomDistance,
		["DefCameraMinZoomDistance"] = v_u_151.CameraMinZoomDistance,
		["FieldOfView"] = 70,
		["FieldOfViewToggle"] = false,
		["CameraMaxZoomDistance"] = 128,
		["CameraMaxZoomDistanceToggle"] = false,
		["CameraMinZoomDistance"] = 0.5,
		["CameraMinZoomDistanceToggle"] = false,
		["FullBright"] = false,
		["DefAmbient"] = v_u_148.Ambient
	}
	local function v_u_193()
		-- upvalues: (ref) v_u_192, (ref) v_u_66, (ref) v_u_83
		while v_u_192.FieldOfViewToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_66, (ref) v_u_83
				v_u_66.CurrentCamera.FieldOfView = v_u_83.FieldOfView
			end)
			task.wait()
		end
	end
	local function v_u_194()
		-- upvalues: (ref) v_u_192, (ref) v_u_151, (ref) v_u_83
		while v_u_192.CameraMaxZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_151, (ref) v_u_83
				v_u_151.CameraMaxZoomDistance = v_u_83.CameraMaxZoomDistance
			end)
			task.wait()
		end
	end
	local function v_u_195()
		-- upvalues: (ref) v_u_192, (ref) v_u_151
		while v_u_192.CameraMinZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_151, (ref) v_u_192
				v_u_151.CameraMinZoomDistance = v_u_192.CameraMinZoomDistance
			end)
			task.wait()
		end
	end
	v_u_83:Slider("FOV", "FOV", 70, 1, 120, true, function(p196)
		-- upvalues: (ref) v_u_83, (ref) v_u_66, (ref) v_u_192, (ref) v_u_193
		v_u_83.FieldOfView = p196
		if p196 == false then
			v_u_66.CurrentCamera.FieldOfView = v_u_192.DefFOV
		end
		v_u_193()
	end)
	v_u_83:Toggle("FOV开关", "FOVToggle", false, function(p197)
		-- upvalues: (ref) v_u_83
		v_u_83.FieldOfViewToggle = p197
	end)
	v_u_83:Slider("最大相机聚焦距离", "CameraMaxZoomDistance", 128, 1, 1200, true, function(p198)
		-- upvalues: (ref) v_u_83, (ref) v_u_151, (ref) v_u_194
		v_u_83.CameraMaxZoomDistance = p198
		if p198 == false then
			v_u_151.CameraMaxZoomDistance = v_u_83.DefCameraMaxZoomDistance
		end
		v_u_194()
	end)
	v_u_83:Toggle("最大相机聚焦距离开关", "CameraMaxZoomDistanceToggle", false, function(p199)
		-- upvalues: (ref) v_u_83
		v_u_83.CameraMaxZoomDistanceToggle = p199
	end)
	v_u_83:Slider("最小相机聚焦距离", "Slider", 0.5, 1, 50, true, function(p200)
		-- upvalues: (ref) v_u_83, (ref) v_u_151, (ref) v_u_192, (ref) v_u_195
		v_u_83.CameraMinZoomDistance = p200
		if p200 == false then
			v_u_151.CameraMinZoomDistance = v_u_192.DefCameraMinZoomDistance
		end
		v_u_195()
	end)
	v_u_83:Toggle("最小相机聚焦距离开关", "CameraMinZoomDistanceToggle", false, function(p201)
		-- upvalues: (ref) v_u_83
		v_u_83.CameraMinZoomDistanceToggle = p201
	end)
	local function v_u_202()
		-- upvalues: (ref) v_u_164, (ref) v_u_148
		while v_u_164.FullBright == true do
			pcall(function()
				-- upvalues: (ref) v_u_148
				v_u_148.Ambient = Color3.new(1, 1, 1)
			end)
			task.wait()
		end
	end
	v_u_83:Toggle("全局高亮", "FullBright", false, function(p203)
		-- upvalues: (ref) v_u_192, (ref) v_u_148, (ref) v_u_202
		v_u_192.FullBright = p203
		if p203 == false then
			v_u_148.Ambient = v_u_192.DefAmbient
		end
		v_u_202()
	end)
	local v_u_204 = {
		["Bk"] = nil,
		["Dn"] = nil,
		["Ft"] = nil,
		["Lf"] = nil,
		["Rt"] = nil,
		["Up"] = nil
	}
	v84:Dropdown("天空盒", "Skybox", { "cs_办公室", "Always.win", "Advanced Logic" }, function(p205)
		-- upvalues: (ref) v_u_108
		if p205 == "cs_办公室" then
			v_u_108({
				["Name"] = "cs_office",
				["Bk"] = "rbxassetid://658623433",
				["Dn"] = "rbxassetid://316342560",
				["Ft"] = "rbxassetid://658625205",
				["Lf"] = "rbxassetid://658627155",
				["Rt"] = "rbxassetid://658628504",
				["Up"] = "rbxassetid://658632701"
			})
		elseif p205 == "Always.win" then
			v_u_108({
				["Name"] = "Always.win",
				["Bk"] = "rbxassetid://17411013742",
				["Dn"] = "rbxassetid://17411013742",
				["Ft"] = "rbxassetid://17411013742",
				["Lf"] = "rbxassetid://17411013742",
				["Rt"] = "rbxassetid://17411013742",
				["Up"] = "rbxassetid://17411013742"
			})
		elseif p205 == "Advanced Logic" then
			v_u_108({
				["Name"] = "Advanced Logic",
				["Bk"] = "rbxassetid://17803761395",
				["Dn"] = "rbxassetid://17803761395",
				["Ft"] = "rbxassetid://17803761395",
				["Lf"] = "rbxassetid://17803761395",
				["Rt"] = "rbxassetid://17803761395",
				["Up"] = "rbxassetid://17803761395",
				["SunAsset"] = "rbxassetid://17768924741",
				["SunAngularSize"] = 50
			})
		end
	end)
	v84:Textbox("自定义天空盒Bk", "Textbox", "请输入SkyboxBk贴图ID", function(p_u_206)
		-- upvalues: (ref) v_u_204
		pcall(function()
			-- upvalues: (ref) p_u_206, (ref) v_u_204
			if p_u_206:find("rbxassetid://") then
				v_u_204.Bk = p_u_206
			else
				v_u_204.Bk = "rbxassetid://" .. p_u_206
			end
		end)
	end)
	v84:Textbox("自定义天空盒Dn", "Textbox", "请输入SkyboxDn贴图ID", function(p_u_207)
		-- upvalues: (ref) v_u_204
		pcall(function()
			-- upvalues: (ref) p_u_207, (ref) v_u_204
			if p_u_207:find("rbxassetid://://") then
				v_u_204.Dn = p_u_207
			else
				v_u_204.Dn = "rbxassetid://" .. p_u_207
			end
		end)
	end)
	v84:Textbox("自定义天空盒Ft", "Textbox", "请输入SkyboxFt贴图ID", function(p_u_208)
		-- upvalues: (ref) v_u_204
		pcall(function()
			-- upvalues: (ref) p_u_208, (ref) v_u_204
			if p_u_208:find("rbxassetid://") then
				v_u_204.Ft = p_u_208
			else
				v_u_204.Ft = "rbxassetid://" .. p_u_208
			end
		end)
	end)
	v84:Textbox("自定义天空盒Lf", "Textbox", "请输入SkyboxLf贴图ID", function(p_u_209)
		-- upvalues: (ref) v_u_204
		pcall(function()
			-- upvalues: (ref) p_u_209, (ref) v_u_204
			if p_u_209:find("rbxassetid://") then
				v_u_204.Lf = p_u_209
			else
				v_u_204.Lf = "rbxassetid://" .. p_u_209
			end
		end)
	end)
	v84:Textbox("自定义天空盒Rt", "Textbox", "请输入SkyboxRt贴图ID", function(p_u_210)
		-- upvalues: (ref) v_u_204
		pcall(function()
			-- upvalues: (ref) p_u_210, (ref) v_u_204
			if p_u_210:find("rbxassetid://") then
				v_u_204.Rt = p_u_210
			else
				v_u_204.Rt = "rbxassetid://" .. p_u_210
			end
		end)
	end)
	v84:Textbox("自定义天空盒Up", "Textbox", "请输入SkyboxUp贴图ID", function(p_u_211)
		-- upvalues: (ref) v_u_204
		pcall(function()
			-- upvalues: (ref) p_u_211, (ref) v_u_204
			if p_u_211:find("rbxassetid://") then
				v_u_204.Up = p_u_211
			else
				v_u_204.Up = "rbxassetid://" .. p_u_211
			end
		end)
	end)
	v84:Button("修改自定义天空盒", function()
		-- upvalues: (ref) v_u_108, (ref) v_u_204
		pcall(function()
			-- upvalues: (ref) v_u_108, (ref) v_u_204
			v_u_108({
				["Name"] = "我爱手冲",
				["Bk"] = v_u_204.Bk,
				["Dn"] = v_u_204.Dn,
				["Ft"] = v_u_204.Ft,
				["Lf"] = v_u_204.Lf,
				["Rt"] = v_u_204.Rt,
				["Up"] = v_u_204.Up
			})
		end)
	end)
	v86:Label("团队")
	v86:Label("Advanced Logic")
	v86:Label("群号: 684407929")
	v87:Label("当前版本 " .. v72)
	task.spawn(function()
		-- upvalues: (ref) v_u_151
		v_u_151.Idled:Connect(function()
			game:GetService("VirtualUser"):CaptureController()
			game:GetService("VirtualUser"):ClickButton2(Vector2.new())
		end)
		if game:GetService("TextChatService").ChatVersion == Enum.ChatVersion.LegacyChatService then
			rawset(require(v_u_151:FindFirstChild("PlayerScripts"):FindFirstChild("ChatScript").ChatMain), "MessagePosted", {
				["fire"] = function(p212)
					return p212
				end,
				["wait"] = function() end,
				["connect"] = function() end
			})
		end
	end)
else
	game:GetService("Players").LocalPlayer:Kick("您不是白名单用户,请加入684407929(Adavanced Logic官方群)购买")
	setclipboard(game:GetService("RbxAnalyticsService"):GetClientId())
end
