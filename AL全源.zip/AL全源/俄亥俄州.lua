local v_u_1 = http_request or request or (HttpPost or syn.request)
local v_u_2 = nil
local v_u_3 = 0
local function v_u_9(p4, p5, p6)
	-- upvalues: (ref) v_u_3, (ref) v_u_9
	v_u_3 = v_u_3 + 1
	if p6 then
		local v7 = v_u_9(p4, p5) and v_u_9(p4, p6)
		if v7 then
			v7 = v_u_9(p5, p6)
		end
		return v7
	else
		local v8 = type(p4) == typeof(p5) and (typeof(p4) == type(p5) and (type(p4) == typeof(p5) or typeof(p4) == type(p5))) and (#tostring(p4) == #tostring(p5) and rawequal(p4, p5))
		if v8 then
			if tostring(p4) < tostring(p5) or tostring(p4) > tostring(p5) then
				v8 = false
			else
				v8 = rawequal(tostring(p4), tostring(p5))
			end
		end
		return v8
	end
end
local function v_u_11(p10)
	return ({ ... })[p10]
end
local function v_u_18(p_u_12)
	-- upvalues: (ref) v_u_1, (ref) v_u_2, (ref) v_u_11
	local v_u_13 = false
	local v15 = {
		["__call"] = v_u_1,
		["__index"] = function(_, p14)
			-- upvalues: (ref) v_u_13, (ref) v_u_1, (ref) v_u_2, (ref) p_u_12
			v_u_13 = true
			if debug.info(2, "f") ~= v_u_1 then
				v_u_2 = "反钩子 [H - 1]"
				return "https://www.roblox.com/users/7207800972/profile"
			end
			if not coroutine.isyieldable() then
				return p_u_12[p14]
			end
			v_u_2 = "反钩子 [H - 2]"
			return "https://www.roblox.com/users/7207800972/profile"
		end
	}
	local v16 = setmetatable({}, v15)
	local v17 = v_u_11(2, pcall(v16))
	if v_u_13 then
		return v17
	end
end
local function v21(p19)
	-- upvalues: (ref) v_u_18
	local v20 = v_u_18({
		["Url"] = p19,
		["Method"] = "GET"
	})
	repeat
		task.wait()
	until v20
	return v20.Body
end
local function v23(p22)
	return string.split(p22 or "", ": ")[2]
end
local function v_u_26(p24, p25)
	-- upvalues: (ref) v_u_26
	if p24 == 0 then
		task.wait()
	end
	p25(...)
	v_u_26(p24 + 1, p25)
end
local function v28(p27)
	game:GetService("Players").LocalPlayer:Kick("")
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.TitleFrame.ErrorTitle.Text = "危险行为"
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.MessageArea.ErrorFrame.ErrorMessage.Text = p27
	task.wait(1)
	game:Shutdown()
	task.wait(1)
	task.spawn(function()
		while true do

		end
	end)
end
local v29 = {
	v_u_26,
	v_u_11,
	pcall,
	debug.info,
	islclosure,
	debug.getinfo,
	debug.getfenv,
	0,
	{
		"Url",
		"Method",
		"Headers",
		"Cookies",
		"Body"
	},
	table.insert,
	v_u_2,
	v_u_1
}
local v30 = { math.random, v_u_11, v_u_18 }
local v31 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end
}
setmetatable(v29, v31)
local v32 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end
}
setmetatable(v30, v32)
local v33 = type(getrawmetatable(v29).__index) ~= "function" and "反篡改 [M - S1]" or v_u_2
v_u_3 = v_u_3 + 1
local v34 = type(getrawmetatable(v29).__tostring) ~= "function" and "反篡改 [M - S1]" or v33
v_u_3 = v_u_3 + 1
local v35 = (type(getrawmetatable(v30).__index) ~= "function" or type(getrawmetatable(v30).__index) ~= type(getmetatable(v30).__index)) and "反篡改 [M - S1]" or v34
v_u_3 = v_u_3 + 1
local v36 = type(getrawmetatable(v30).__tostring) ~= "function" and "反篡改 [M - S1]" or v35
v_u_3 = v_u_3 + 1
local v37, v38 = pcall(pcall)
local _, _ = pcall(math.random)
local _, _ = pcall(setmetatable)
local _, _ = pcall(string.split)
local _, _ = pcall(debug.traceback)
local _, _ = pcall(getmetatable)
local _, _ = pcall(coroutine.wrap)
local _, _ = pcall(table.insert)
local v39 = (v37 or v38 ~= "missing argument #1") and "反函数钩子 [P]" or v36
v_u_3 = v_u_3 + 1
local v40 = {
	math.abs,
	os.clock,
	coroutine.isyieldable,
	debug.info,
	v_u_1,
	game:GetService("Players").LocalPlayer.Kick,
	table.insert,
	bit32.bxor,
	debug.getfenv,
	setrawmetatable,
	pcall,
	math.random,
	setmetatable,
	string.split,
	debug.traceback,
	debug.info,
	getrawmetatable,
	type,
	table.insert,
	math.random,
	v_u_11,
	table.concat,
	string.byte,
	string.char,
	debug.getinfo,
	islclosure,
	string.reverse,
	v_u_18,
	getmetatable
}
local v41 = next
local v42 = v_u_18
local v43 = v_u_26
local v44 = v_u_9
local v45 = v_u_3
local v46 = v_u_11
local v47 = nil
while true do
	local v48
	v47, v48 = v41(v40, v47)
	if v47 == nil then
		break
	end
	for _ = 1, 197 do
		v48 = coroutine.wrap(v48)
	end
	if v46(2, pcall(v48)) == "C stack overflow" then
		v_u_2 = "反函数钩子 [F - G2]"
		v39 = v_u_2
	end
end
v_u_3 = v45 + 1
local v49 = not debug.info(2, "f") and "反篡改 [1]" or v39
v_u_3 = v_u_3 + 1
local v50 = math.random() == math.random() and "反篡改 [2]" or v49
local v51 = not v44(v_u_3, 7) and "反钩子 [C]" or v50
local _, v52 = pcall(v43, 0, coroutine.wrap)
local v53 = v23(v52) ~= "missing argument #1 to \'wrap\' (function expected)" and "反函数钩子 [F - C]" or v51
local v54 = not string.sub(game:GetService("RbxAnalyticsService"):GetClientId(), 1, 8) == string.split(game:GetService("RbxAnalyticsService"):GetClientId(), "-")[1] and "反函数钩子 [F - S]" or v53
local v55 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/P"))()
local v56 = loadstring(v21("https://raw.githubusercontent.com/longshu886/linniscript/refs/heads/main/ng", true))()
local v57 = string.split(game:GetService("RbxAnalyticsService"):GetClientId(), "-")
local v58 = v57[1] .. v57[2] .. v57[3] .. v57[4] .. v57[5]
local v59 = not gethwid and "未知" or gethwid()
local v60 = table.find({ Enum.Platform.IOS }, game:GetService("UserInputService"):GetPlatform()) and "IOS" or (table.find({ Enum.Platform.Android }, game:GetService("UserInputService"):GetPlatform()) and "Android" or "PC/Mac")
local v61, v62
if v55[v58] ~= true or v56[v58] ~= true then
	v61 = "0xFF0000"
	v62 = "否"
else
	v61 = "0x32CD32"
	v62 = "是"
end
local v63 = {
	["username"] = "Advanced Bot",
	["embeds"] = {
		{
			["color"] = tonumber(tostring(v61)),
			["title"] = "有人注入了Advanced Logic",
			["fields"] = {
				{
					["name"] = "名称",
					["value"] = game:GetService("Players").LocalPlayer.Name,
					["inline"] = true
				},
				{
					["name"] = "昵称",
					["value"] = game:GetService("Players").LocalPlayer.DisplayName,
					["inline"] = true
				},
				{
					["name"] = "UID",
					["value"] = "[" .. game:GetService("Players").LocalPlayer.UserId .. "](" .. tostring("https://www.roblox.com/users/" .. game:GetService("Players").LocalPlayer.UserId .. "/profile") .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏ID",
					["value"] = "[" .. game.PlaceId .. "](" .. tostring("https://www.roblox.com/games/" .. game.PlaceId) .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏名称",
					["value"] = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name,
					["inline"] = true
				},
				{
					["name"] = "注入器",
					["value"] = identifyexecutor(),
					["inline"] = true
				},
				{
					["name"] = "HWID",
					["value"] = v59,
					["inline"] = true
				},
				{
					["name"] = "客户端ID",
					["value"] = game:GetService("RbxAnalyticsService"):GetClientId(),
					["inline"] = false
				},
				{
					["name"] = "设备",
					["value"] = v60,
					["inline"] = true
				},
				{
					["name"] = "用户状态",
					["value"] = v62,
					["inline"] = true
				}
			},
			["timestamp"] = os.date("%Y-%m-%dT%X.000Z")
		}
	}
}
v42({
	["Url"] = "https://discord.com/api/webhooks/1268122774069579806/Pi7q9f25rIwlkr-iLiIFEPJIvxx5dzcA9tSUXoTY8R1uUXF-CnFMJ91V2aX75dBOJCuY",
	["Method"] = "POST",
	["Headers"] = {
		["Content-Type"] = "application/json"
	},
	["Body"] = game.HttpService:JSONEncode(v63)
})
if v54 == nil then
	if v55[v58] == true or v56[v58] == true then
		setfpscap(math.huge)
		_G.ScriptIsRunning = false
		_G.ScriptIsRunning = true
		local v_u_64 = game:GetService("Players")
		local v_u_65 = game:GetService("UserInputService")
		local v_u_66 = v_u_64.LocalPlayer
		game:GetService("CoreGui")
		game:GetService("RbxAnalyticsService")
		local v_u_67 = game:GetService("RunService")
		local v_u_68 = v_u_66.PlayerGui
		local v_u_69 = game:GetService("Workspace")
		local v_u_70 = game:GetService("Lighting")
		local v_u_71 = v_u_69.CurrentCamera
		local v72 = v_u_69:WaitForChild("Game")
		local v73 = v72:WaitForChild("Props")
		local v_u_74 = v72:WaitForChild("Entities")
		local v_u_75 = v72:WaitForChild("Airdrops")
		local v_u_76 = v_u_74:WaitForChild("CashBundle")
		local v_u_77 = v_u_74:WaitForChild("ItemPickup")
		local v78 = v_u_69:WaitForChild("GemRobbery")
		local v_u_79 = v_u_69:WaitForChild("BankRobbery")
		local v_u_80 = v78:WaitForChild("JewelryCases")
		local v_u_81 = v_u_69:WaitForChild("BlackMarket")
		local v_u_82 = v_u_69:WaitForChild("ItemsOnSale")
		local v_u_83 = v_u_69:WaitForChild("Christmas"):WaitForChild("Mobs")
		local v84 = v_u_68:WaitForChild("Billboards"):WaitForChild("itemStore")
		local v_u_85 = game:GetService("ReplicatedStorage").devv
		local v_u_86 = v_u_85.client.Objects.v3item
		local v87 = v_u_85.client.Helpers.remotes.Signal
		local v_u_88 = require(v87).FireServer
		local v_u_89 = require(v87).InvokeServer
		debug.getupvalue(v_u_88, 1)
		local v90 = v_u_85.datum.state
		local v_u_91 = {}
		task.spawn(function()
			-- upvalues: (ref) v_u_85, (ref) v_u_91, (ref) v_u_64, (ref) v_u_66
			local v92, v93, v94 = pairs(require(v_u_85).data.specialroles)
			while true do
				local v95
				v94, v95 = v92(v93, v94)
				if v94 == nil then
					break
				end
				if v94 == "developer" or (v94 == "admins" or v94 == "heros") then
					local v96, v97, v98 = pairs(v95.users)
					while true do
						local v99
						v98, v99 = v96(v97, v98)
						if v98 == nil then
							break
						end
						table.insert(v_u_91, v99)
					end
				end
			end
			local v100 = v_u_64
			local v101, v102, v103 = pairs(v100:GetChildren())
			while true do
				local v104
				v103, v104 = v101(v102, v103)
				if v103 == nil then
					break
				end
				if table.find(v_u_91, v104.UserId) then
					v_u_66:Kick("服务器存在管理员/作者")
				end
			end
			v_u_64.PlayerAdded:Connect(function(p105)
				-- upvalues: (ref) v_u_91, (ref) v_u_66
				if table.find(v_u_91, p105.UserId) then
					v_u_66:Kick("管理员/作者 加入了此服务器")
				end
			end)
		end)
		local v_u_106 = {
			["Red"] = Color3.fromRGB(255, 0, 0),
			["Green"] = Color3.fromRGB(0, 255, 0),
			["Blue"] = Color3.fromRGB(0, 0, 255),
			["Pink"] = Color3.fromRGB(255, 170, 255),
			["Cyan"] = Color3.fromRGB(85, 255, 255)
		}
		local v_u_107 = {
			["EspToggle"] = false,
			["HighlightToggle"] = false,
			["HighlightTransparency"] = 0.5,
			["SelectFillColor"] = Color3.fromRGB(255, 0, 0),
			["Fullbright"] = false,
			["Noclip"] = false,
			["Fly"] = false,
			["Flyspeed"] = 3,
			["InfJump"] = false,
			["SelectPlr"] = nil,
			["Aimbot"] = false,
			["SilentAim"] = false,
			["HitboxToggle"] = false,
			["SnipePlr"] = false,
			["EspMoneys"] = false,
			["EspItems"] = false,
			["SnipeToHeadLookVector"] = false,
			["MoneyFarm"] = false,
			["ItemsFarm"] = false,
			["BringPlayerDistance"] = 6,
			["BankFarm"] = false,
			["ATMFarm"] = false,
			["HitboxHeadToggle"] = false,
			["AutoFarmAirdrop"] = false,
			["SuperPunch"] = false,
			["MoneyAura"] = false,
			["ItemAura"] = false,
			["EspScale"] = 0.5,
			["GetRemoteOfAttack"] = false,
			["AutoSpammer"] = false,
			["AutoSpammerText"] = "B赞搜索灾难蛋购买脚本!",
			["JewelryCasesAura"] = false,
			["AutoFarmJewelryCases"] = false,
			["CombatWeapon"] = "拳头",
			["AutoTreasure"] = false,
			["KillAuraDistance"] = 25,
			["AttackNonKnockedFirst"] = false,
			["Attack1096First"] = false,
			["PredValue"] = 2,
			["RespawnAtDeadPos"] = false,
			["RespawnAtDeadPosWait"] = 1,
			["EspName"] = false,
			["FunAmmo"] = false,
			["FunTarget"] = nil,
			["FunPart"] = "Head",
			["ShowLocker"] = false,
			["AnimateSelect"] = "无",
			["ChangeAnimate"] = false,
			["StompAura"] = false,
			["StompAuraDistance"] = 25,
			["SemiGod"] = false,
			["BringDistance"] = 10,
			["BringUnAnchored"] = false,
			["GrabAura"] = false,
			["GrabAuraDistance"] = 25,
			["BuyItem"] = nil,
			["MessageSpammer"] = false,
			["MessageNuke"] = false,
			["MessageSpammerText"] = "B赞搜索灾难蛋购买脚本!",
			["PhoneSpammer"] = false,
			["InstantPrompt"] = false,
			["KillAuraAutoEquipPunch"] = false,
			["AutoHealth"] = false,
			["AutoHealthLimit"] = 90,
			["Invisible"] = false,
			["SelectLocate"] = nil,
			["Christmas"] = false
		}
		local v_u_108 = {
			"advent259",
			"Zainandan1337",
			"DangweiDan",
			"AdvancedLogic_Dev",
			"ojwvs65lq",
			"KSBWKJJ",
			"AkiraDank",
			"sbsbsbsbnba",
			"woshinibbjjjj",
			"KELE_889",
			"tangmeiLONG",
			"longsu_long",
			"cnmdnmsbsb123"
		}
		local v_u_109 = {}
		game:GetService("ProximityPromptService").PromptButtonHoldBegan:Connect(function(p110)
			-- upvalues: (ref) v_u_107
			if v_u_107.InstantPrompt == true then
				fireproximityprompt(p110)
			end
		end)
		local v_u_111 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ns.cc"))()
		local v112 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/bob.afk"))()
		local v113 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/v"))():new("<font color=\"rgb(0,180,216)\">Advanced</font> <font color=\"rgb(252,255,0)\">Logic</font>", true, "gamesense", 0, false)
		local v114 = v113:Tab("战斗类", "17901200092")
		local v115 = v114:Section("战斗类", false)
		local v116 = v114:Section("防吸人", false)
		local v117 = v114:Section("杀戮光环", false)
		local v118 = v114:Section("杀死全体", false)
		local v119 = v114:Section("踩人光环", false)
		local v120 = v114:Section("抱人光环", false)
		local v121 = v114:Section("范围", false)
		local v122 = v114:Section("自动嘲讽", false)
		local v123 = v114:Section("原地复活", false)
		local v124 = v113:Tab("瞄准", "6922963617"):Section("自瞄", false)
		local v125 = v113:Tab("物品", "7734056747")
		local v126 = v125:Section("互动", false)
		local v127 = v125:Section("黑市", false)
		local v128 = v125:Section("储物柜", false)
		local v129 = v125:Section("购买物品", false)
		local v130 = v113:Tab("自动", "15332132816")
		local v131 = v130:Section("圣诞节", false)
		local v132 = v130:Section("钱", false)
		local v133 = v130:Section("物品", false)
		local v134 = v130:Section("银行", false)
		local v135 = v130:Section("珠宝店", false)
		local v136 = v130:Section("保险柜", false)
		local v137 = v130:Section("空投", false)
		local v138 = v113:Tab("传送", "7733992469"):Section("地点")
		local v139 = v113:Tab("娱乐", "10683794445"):Section("娱乐", true)
		local v140 = v113:Tab("数据", "7743866778")
		local v141 = v140:Section("金钱数据", false)
		local v142 = v140:Section("封禁数据", false)
		local v143 = v113:Tab("透视", "7733696665")
		local v144 = v143:Section("功能", false)
		local v145 = v143:Section("透视设置", false)
		local v146 = v113:Tab("玩家", "7743876054"):Section("玩家选项", true)
		local v147 = v113:Tab("本地", "7733752575")
		local v148 = v147:Section("本地玩家", false)
		local v149 = v147:Section("聊天", false)
		local v_u_150 = v147:Section("本地视觉", false)
		local v151 = v147:Section("天空盒", false)
		local v152 = v113:Tab("关于", "7743871575")
		local v153 = v152:Section("关于作者", true)
		local v154 = v152:Section("关于脚本", true)
		function UpdateEsp(p_u_155, p_u_156)
			-- upvalues: (ref) v_u_64, (ref) v_u_107
			pcall(function()
				-- upvalues: (ref) v_u_64, (ref) p_u_155, (ref) v_u_107, (ref) p_u_156
				if v_u_64:FindFirstChild(p_u_155) and v_u_64:FindFirstChild(p_u_155).Character then
					local v157 = v_u_107.EspToggle == true and v_u_107.EspName == true
					if v_u_64:FindFirstChild(p_u_155).Character.Head.Transparency == 0 and not v_u_64:FindFirstChild(p_u_155).Character.Head:FindFirstChild("ALESP") or not v_u_64:FindFirstChild(p_u_155).Character:FindFirstChild("ALHL") then
						if not v_u_64:FindFirstChild(p_u_155).Character.Head:FindFirstChild("ALESP") then
							local v158 = Instance.new("BillboardGui")
							local v159 = Instance.new("TextLabel")
							v158.Name = "ALESP"
							v158.Parent = v_u_64:FindFirstChild(p_u_155).Character.Head
							v158.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
							v158.Active = true
							v158.ExtentsOffset = Vector3.new(0, 2, 0)
							v158.LightInfluence = 1
							v158.Size = UDim2.new(0, 200, 0, 50)
							v158.Enabled = v157
							v158.AlwaysOnTop = true
							v159.Name = "Text"
							v159.Parent = v158
							v159.AnchorPoint = Vector2.new(0.5, 0.5)
							v159.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
							v159.BackgroundTransparency = 1
							v159.BorderColor3 = Color3.fromRGB(0, 0, 0)
							v159.BorderSizePixel = 5
							v159.Position = UDim2.new(0.5, 0, 0.5, 0)
							v159.Size = UDim2.new(v_u_107.EspScale, 0, v_u_107.EspScale, 0)
							v159.Font = Enum.Font.SourceSansBold
							v159.Text = v_u_64:FindFirstChild(p_u_155).Name
							v159.TextColor3 = Color3.fromRGB(255, 255, 255)
							v159.TextScaled = true
							v159.TextSize = 1
							v159.TextStrokeTransparency = 0.19
							v159.TextWrapped = true
						end
						if not v_u_64:FindFirstChild(p_u_155).Character:FindFirstChild("ALHL") then
							local v160 = Instance.new("Highlight")
							v160.Name = "ALHL"
							v160.Parent = v_u_64:FindFirstChild(p_u_155).Character
							v160.FillColor = p_u_156
							v160.Enabled = v_u_107.HighlightToggle
							v160.FillTransparency = v_u_107.HighlightTransparency
						end
					end
					if v_u_64:FindFirstChild(p_u_155).Character.Head:FindFirstChild("ALESP") then
						local v161 = v_u_64:FindFirstChild(p_u_155).Character.Head:FindFirstChild("ALESP")
						local v162 = v161.Text
						v161.Enabled = v157
						v162.Text = v_u_64:FindFirstChild(p_u_155).Name
						v162.Size = UDim2.new(v_u_107.EspScale, 0, v_u_107.EspScale, 0)
						v162.TextColor3 = p_u_156
					end
					if v_u_64:FindFirstChild(p_u_155).Character:FindFirstChild("ALHL") then
						local v163 = v_u_64:FindFirstChild(p_u_155).Character:FindFirstChild("ALHL")
						v163.FillColor = p_u_156
						v163.Enabled = v_u_107.HighlightToggle
						v163.FillTransparency = v_u_107.HighlightTransparency
					end
				end
			end)
		end
		function MoneyUpdateEsp(p_u_164, p_u_165, p_u_166)
			-- upvalues: (ref) v_u_107
			pcall(function()
				-- upvalues: (ref) p_u_165, (ref) v_u_107, (ref) p_u_164, (ref) p_u_166
				if p_u_165 then
					local v167 = v_u_107.EspToggle == true and v_u_107.EspMoneys == true
					if not (p_u_165:FindFirstChild("ALESP") or p_u_165:FindFirstChild("ALESP")) then
						local v168 = Instance.new("BillboardGui")
						local v169 = Instance.new("ImageLabel")
						local v170 = Instance.new("TextLabel")
						v168.Name = "ALESP"
						v168.Parent = p_u_165
						v168.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
						v168.Active = true
						v168.ExtentsOffset = Vector3.new(0, 2, 0)
						v168.LightInfluence = 1
						v168.Size = UDim2.new(0, 50, 0, 50)
						v168.Enabled = v167
						v168.AlwaysOnTop = true
						v169.Name = "Image"
						v169.Parent = v168
						v169.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						v169.BackgroundTransparency = 1
						v169.BorderColor3 = Color3.fromRGB(0, 0, 0)
						v169.BorderSizePixel = 0
						v169.Size = UDim2.new(v_u_107.EspScale, 0, v_u_107.EspScale, 0)
						v169.Image = "rbxassetid://5567568456"
						v169.AnchorPoint = Vector2.new(0.5, 0.5)
						v169.Position = UDim2.new(0.5, 0, 0.5, 0)
						v170.Name = "Text"
						v170.Parent = v168
						v170.AnchorPoint = Vector2.new(0.5, 0.5)
						v170.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						v170.BackgroundTransparency = 1
						v170.BorderColor3 = Color3.fromRGB(0, 0, 0)
						v170.BorderSizePixel = 5
						v170.Position = UDim2.new(0.5, 0, 0.5, 0)
						v170.Size = UDim2.new(v_u_107.EspScale, 0, v_u_107.EspScale, 0)
						v170.Font = Enum.Font.SourceSansBold
						v170.Text = p_u_164
						v170.TextColor3 = Color3.fromRGB(255, 255, 255)
						v170.TextScaled = true
						v170.TextSize = 1
						v170.TextStrokeTransparency = 0.19
						v170.TextWrapped = true
					end
					if p_u_165:FindFirstChild("ALESP") then
						local v171 = p_u_165:FindFirstChild("ALESP")
						local v172 = v171.Text
						v171.Enabled = v167
						v172.Text = p_u_164
						v172.TextColor3 = p_u_166
						p_u_164.Size = UDim2.new(v_u_107.EspScale, 0, v_u_107.EspScale, 0)
					end
				end
			end)
		end
		function ItemUpdateEsp(p_u_173, p_u_174, p_u_175)
			-- upvalues: (ref) v_u_107
			pcall(function()
				-- upvalues: (ref) p_u_174, (ref) v_u_107, (ref) p_u_173, (ref) p_u_175
				if p_u_174 then
					local v176 = v_u_107.EspToggle == true and v_u_107.EspItems == true
					if not (p_u_174:FindFirstChild("ALESP") or p_u_174:FindFirstChild("ALESP")) then
						local v177 = Instance.new("BillboardGui")
						local v178 = Instance.new("TextLabel")
						v177.Name = "ALESP"
						v177.Parent = p_u_174
						v177.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
						v177.Active = true
						v177.ExtentsOffset = Vector3.new(0, 2, 0)
						v177.LightInfluence = 1
						v177.Size = UDim2.new(0, 200, 0, 50)
						v177.Enabled = v176
						v177.AlwaysOnTop = true
						v178.Name = "Text"
						v178.Parent = v177
						v178.AnchorPoint = Vector2.new(0.5, 0.5)
						v178.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						v178.BackgroundTransparency = 1
						v178.BorderColor3 = Color3.fromRGB(0, 0, 0)
						v178.BorderSizePixel = 5
						v178.Position = UDim2.new(0.5, 0, 0.5, 0)
						v178.Size = UDim2.new(v_u_107.EspScale, 0, v_u_107.EspScale, 0)
						v178.Font = Enum.Font.SourceSansBold
						v178.Text = p_u_173
						v178.TextColor3 = Color3.fromRGB(255, 255, 255)
						v178.TextScaled = true
						v178.TextSize = 1
						v178.TextStrokeTransparency = 0.19
						v178.TextWrapped = true
					end
					if p_u_174:FindFirstChild("ALESP") then
						local v179 = p_u_174:FindFirstChild("ALESP")
						local v180 = v179.Text
						v179.Enabled = v176
						v180.Text = p_u_173
						v180.TextColor3 = p_u_175
						p_u_173.Size = UDim2.new(v_u_107.EspScale, 0, v_u_107.EspScale, 0)
					end
				end
			end)
		end
		function SpawnSkybox(p181)
			-- upvalues: (ref) v_u_70, (ref) v_u_111
			local v182 = v_u_70
			local v183, v184, v185 = pairs(v182:GetChildren())
			while true do
				local v186
				v185, v186 = v183(v184, v185)
				if v185 == nil then
					break
				end
				if v186:IsA("Sky") then
					v186:Destroy()
				end
			end
			if p181.Bk and (p181.Dn and (p181.Ft and (p181.Lf and (p181.Rt and (p181.Up and p181.Name))))) then
				local v187 = Instance.new("Sky")
				v187.Name = p181.Name
				v187.SkyboxBk = p181.Bk
				v187.SkyboxDn = p181.Dn
				v187.SkyboxFt = p181.Ft
				v187.SkyboxLf = p181.Lf
				v187.SkyboxRt = p181.Rt
				v187.SkyboxUp = p181.Up
				v187.Parent = v_u_70
				if p181.SunAsset and p181.SunAngularSize then
					v187.SunTextureId = p181.SunAsset
					v187.SunAngularSize = p181.SunAngularSize
				end
			else
				v_u_111:Notify("无效的天空盒参数", 2)
			end
		end
		local v_u_188 = {
			["AimPart"] = "Head",
			["WallCheck"] = false,
			["Enemy"] = nil,
			["LockEnemy"] = nil,
			["Line"] = Drawing.new("Line"),
			["LineEnabled"] = false,
			["Circle"] = {
				["Circle"] = Drawing.new("Circle"),
				["Visible"] = false,
				["Transparency"] = 0.5,
				["Radius"] = 200,
				["Filled"] = false,
				["Thickness"] = 1,
				["Color"] = Color3.fromRGB(255, 255, 255)
			},
			["Aimbot"] = {
				["Epitaph"] = 17.6,
				["ShowEpitaph"] = false,
				["EpitaphCircle"] = Drawing.new("Circle"),
				["StickAim"] = false
			}
		}
		v_u_188.Aimbot.EpitaphCircle.Visible = false
		v_u_188.Aimbot.EpitaphCircle.Filled = true
		v_u_188.Aimbot.EpitaphCircle.Radius = 5
		v_u_188.Aimbot.EpitaphCircle.Transparency = 1
		v_u_188.Aimbot.EpitaphCircle.Thickness = 1
		v_u_188.Aimbot.EpitaphCircle.Color = Color3.fromRGB(255, 255, 255)
		v_u_188.Line.Visible = false
		v_u_188.Line.Thickness = 1
		v_u_188.Line.From = Vector2.new(v_u_71.ViewportSize.X / 2, v_u_71.ViewportSize.Y / 2)
		v_u_188.Line.To = Vector2.new(0, 0)
		v_u_188.Line.Color = Color3.fromRGB(255, 255, 255)
		v_u_188.Line.Transparency = 1
		v_u_188.Line.ZIndex = 999
		local function v_u_199()
			-- upvalues: (ref) v_u_64, (ref) v_u_66, (ref) v_u_108, (ref) v_u_109, (ref) v_u_71, (ref) v_u_188
			local v_u_189 = math.huge
			local v_u_190 = nil
			pcall(function()
				-- upvalues: (ref) v_u_64, (ref) v_u_66, (ref) v_u_108, (ref) v_u_109, (ref) v_u_71, (ref) v_u_188, (ref) v_u_189, (ref) v_u_190
				local v191, v192, v193 = pairs(v_u_64:GetPlayers())
				while true do
					local v194
					v193, v194 = v191(v192, v193)
					if v193 == nil then
						break
					end
					if v194 ~= v_u_66 then
						if table.find(v_u_108, v194.Name) or table.find(v_u_109, v194.Name) then
							return
						end
						if v194.Character.FindFirstChild(v194.Character, "Humanoid") and (v194.Character.FindFirstChild(v194.Character, "Humanoid").Health > 0 and (v194.Character.FindFirstChild(v194.Character, "HumanoidRootPart") and v194)) then
							local v195 = v194.Character
							local v196, v197 = v_u_71:WorldToViewportPoint(v195[v_u_188.AimPart].Position)
							if v197 and (v_u_188.WallCheck ~= true or #v_u_71:GetPartsObscuringTarget({ v194.Character[v_u_188.AimPart].Position }, { v_u_71, v_u_66.Character, v194.Character }) <= 0) then
								local v198 = (Vector2.new(v_u_71.ViewportSize.X / 2, v_u_71.ViewportSize.Y / 2) - Vector2.new(v196.X, v196.Y)).Magnitude
								if v198 < v_u_189 and v198 < v_u_188.Circle.Radius then
									v_u_189 = v198
									v_u_190 = v195
								end
							end
						end
					end
				end
			end)
			return v_u_190
		end
		local function v_u_202()
			-- upvalues: (ref) v_u_188, (ref) v_u_71
			if v_u_188.Circle.Circle == nil then
				v_u_188.Circle.Circle = Drawing.new("Circle")
				UpdateCircle()
			else
				local v200 = v_u_188.Circle
				local v201 = v200.Circle
				v201.Visible = v200.Visible
				v201.Transparency = v200.Transparency
				v201.Radius = v200.Radius
				v201.Filled = v200.Filled
				v201.Position = Vector2.new(v_u_71.ViewportSize.X / 2, v_u_71.ViewportSize.Y / 2)
				v201.Thickness = v200.Thickness
				v201.Color = v200.Color
			end
		end
		local function v_u_205(p203, p204)
			-- upvalues: (ref) v_u_71
			v_u_71.CFrame = CFrame.new(p203, p204)
		end
		function getTimeString(p206)
			local v207 = math.floor(p206 / 3600)
			local v208 = math.floor(p206 % 3600 / 60)
			local v209 = math.floor(p206 % 60)
			if v207 < 10 then
				v207 = "0" .. v207
			end
			if v208 < 10 then
				v208 = "0" .. v208
			end
			if v209 < 10 then
				v209 = "0" .. v209
			end
			return "" .. v207 .. ":" .. v208 .. ":" .. v209
		end
		local v210 = v_u_64
		local v211, v212, v213 = pairs(v_u_64.GetChildren(v210))
		local v_u_214 = v_u_70
		local v_u_215 = v_u_111
		local v_u_216 = v_u_71
		local v_u_217 = v_u_188
		local v_u_218 = v_u_85
		local v_u_219 = v_u_109
		local v_u_220 = v_u_64
		local v_u_221 = v_u_107
		local v_u_222 = v_u_108
		local v_u_223 = v_u_66
		local v_u_224 = {}
		local function v_u_227(p225, p226)
			return (p226 - p225).Unit * 1000
		end
		local function v_u_231(p_u_228)
			pcall(function()
				-- upvalues: (ref) p_u_228
				if p_u_228:FindFirstChildOfClass("ClickDetector") then
					local v229 = p_u_228
					fireclickdetector(v229:FindFirstChildOfClass("ClickDetector"))
				elseif p_u_228:FindFirstChildOfClass("Part") then
					local v230 = p_u_228:FindFirstChildOfClass("Part")
					fireclickdetector(v230:FindFirstChildOfClass("ClickDetector"))
				end
			end)
		end
		while true do
			local v232, v233 = v211(v212, v213)
			if v232 == nil then
				break
			end
			v213 = v232
			if v233.Name ~= v_u_223.Name then
				table.insert(v_u_224, v233.Name)
			end
		end
		local v_u_234 = "战斗白名单:"
		local v_u_235 = v115:Label(v_u_234)
		local v_u_236 = nil
		local v_u_238 = v115:Dropdown("玩家列表", "Players", v_u_224, function(p237)
			-- upvalues: (ref) v_u_236
			v_u_236 = p237
		end)
		v115:Button("添加战斗白名单", function()
			-- upvalues: (ref) v_u_236, (ref) v_u_219, (ref) v_u_234, (ref) v_u_235
			pcall(function()
				-- upvalues: (ref) v_u_236, (ref) v_u_219, (ref) v_u_234, (ref) v_u_235
				if v_u_236 ~= nil then
					table.insert(v_u_219, v_u_236)
					v_u_234 = v_u_234 .. "/" .. v_u_236
					v_u_235:Set(v_u_234)
				end
			end)
		end)
		v115:Button("重置战斗白名单", function()
			-- upvalues: (ref) v_u_219, (ref) v_u_234, (ref) v_u_235
			pcall(function()
				-- upvalues: (ref) v_u_219, (ref) v_u_234, (ref) v_u_235
				table.clear(v_u_219)
				v_u_234 = "战斗白名单:"
				v_u_235:Set(v_u_234)
			end)
		end)
		local v_u_239 = nil
		v116:Button("防吸人", function()
			-- upvalues: (ref) v_u_239, (ref) v_u_223
			pcall(function()
				-- upvalues: (ref) v_u_239, (ref) v_u_223
				if v_u_239 and v_u_239.Occupant == nil then
					v_u_239.CFrame = v_u_223.Character.HumanoidRootPart.CFrame
					v_u_239:Sit(v_u_223.Character.Humanoid)
				else
					v_u_239 = nil
					local v240, v241, v242 = pairs(game.Workspace:GetDescendants())
					while true do
						local v243
						v242, v243 = v240(v241, v242)
						if v242 == nil then
							break
						end
						if v_u_239 then
							return
						end
						if v243:IsA("Seat") and v243.Occupant == nil then
							v243.CFrame = v_u_223.Character.HumanoidRootPart.CFrame
							v243:Sit(v_u_223.Character.Humanoid)
							v_u_239 = v243
						end
					end
				end
			end)
		end)
		v115:Label("如果你想在倒地之后打人请在倒地之前装备武器")
		function SemiGod()
			-- upvalues: (ref) v_u_221, (ref) v_u_218, (ref) v_u_223
			while v_u_221.SemiGod == true and _G.ScriptIsRunning ~= false do
				pcall(function()
					-- upvalues: (ref) v_u_218, (ref) v_u_223
					local v244 = require(v_u_218.datum.state).properties[v_u_223]
					if v244.knocked == true then
						v244.knocked = false
					end
				end)
				task.wait()
			end
		end
		v115:Toggle("防倒地", "EspToggle", false, function(p245)
			-- upvalues: (ref) v_u_221
			v_u_221.SemiGod = p245
			SemiGod()
		end)
		v115:Toggle("超级拳", "EspToggle", false, function(p246)
			-- upvalues: (ref) v_u_221
			v_u_221.SuperPunch = p246
		end)
		v115:Toggle("超级刀", "EspToggle", false, function(p247)
			-- upvalues: (ref) v_u_221
			v_u_221.SuperKnife = p247
		end)
		local function v_u_259()
			-- upvalues: (ref) v_u_221, (ref) v_u_86, (ref) v_u_223, (ref) v_u_218, (ref) v_u_88, (ref) v_u_89
			local v_u_248 = {}
			local v_u_249 = ""
			while v_u_221.AutoHealth == true do
				task.spawn(function()
					-- upvalues: (ref) v_u_248, (ref) v_u_86
					pcall(function()
						-- upvalues: (ref) v_u_248, (ref) v_u_86
						table.clear(v_u_248)
						local v250, v251, v252 = pairs(require(v_u_86).inventory.items)
						while true do
							local v253
							v252, v253 = v250(v251, v252)
							if v252 == nil then
								break
							end
							if not table.find(v_u_248, v252) and (v253.type and v253.type == "Consumable") then
								table.insert(v_u_248, v252)
							end
						end
					end)
				end)
				pcall(function()
					-- upvalues: (ref) v_u_223, (ref) v_u_221, (ref) v_u_218, (ref) v_u_86, (ref) v_u_248, (ref) v_u_249, (ref) v_u_88, (ref) v_u_89
					if v_u_223.Character.Humanoid.Health <= v_u_221.AutoHealthLimit and require(v_u_218.datum.state).properties[v_u_223].knocked == false then
						local v254, v255, v256 = pairs(require(v_u_86).inventory.items)
						local v257 = 0
						while true do
							local v258
							v256, v258 = v254(v255, v256)
							if v256 == nil then
								break
							end
							if v258.equipped == true and not table.find(v_u_248, v256) then
								v_u_249 = v256
							end
						end
						if v257 == 0 then
							v_u_249 = ""
						end
						if #v_u_248 == 0 then
							v_u_89("attemptPurchase", "Bandage")
							v_u_89("attemptPurchaseAmmo", "Bandage")
							v_u_89("attemptPurchaseAmmo", "Bandage")
						else
							if require(v_u_86).inventory.items[v_u_248[1]] and require(v_u_86).inventory.items[v_u_248[1]].equipped ~= true then
								Equip:FireServer(v_u_248[1])
								require(v_u_86).inventory.items[v_u_248[1]].equipped = true
							end
							v_u_88("useConsumable", v_u_248[1])
							v_u_88("removeItem", v_u_248[1])
							v_u_88("equip", v_u_249)
							require(v_u_86).inventory.items[v_u_249].equipped = true
						end
					end
				end)
				task.wait()
			end
		end
		v115:Toggle("自动打药(并且会自动买绷带)", "AutoHealth", false, function(p260)
			-- upvalues: (ref) v_u_221, (ref) v_u_259
			v_u_221.AutoHealth = p260
			v_u_259()
		end)
		v115:Slider("打药血量", "KillAuraDistance", 90, 1, 185, true, function(p261)
			-- upvalues: (ref) v_u_221
			v_u_221.AutoHealthLimit = p261
		end)
		local v_u_262 = nil
		v_u_262 = hookmetamethod(game, "__namecall", function(p_u_263)
			-- upvalues: (ref) v_u_221, (ref) v_u_262
			local v_u_264 = { ... }
			local v_u_265 = getnamecallmethod()
			pcall(function()
				-- upvalues: (ref) v_u_265, (ref) v_u_264, (ref) v_u_221, (ref) v_u_262, (ref) p_u_263
				if v_u_265 and v_u_265 == "FireServer" then
					if typeof(v_u_264) == "table" and (v_u_264[1] and tostring(v_u_264[1]) ~= "player") and tostring(v_u_264[1]):find("melee") then
						if v_u_221.SuperPunch == true then
							v_u_264[1] = "meleemegapunch"
							return v_u_262(p_u_263, unpack(v_u_264))
						end
						if v_u_221.SuperKnife == true then
							v_u_264[1] = "meleemegaswing"
							return v_u_262(p_u_263, unpack(v_u_264))
						end
					end
					if typeof(v_u_264) == "table" and (v_u_264[1] and (tostring(v_u_264[1]) == "player" and (tostring(v_u_264[2]) and (typeof(v_u_264[2]) == "table" and (v_u_264[2].meleeType and tostring(v_u_264[2].meleeType) ~= "meleemegapunch"))))) then
						if v_u_221.SuperPunch == true then
							v_u_264[2].meleeType = "meleemegapunch"
							return v_u_262(p_u_263, unpack(v_u_264))
						end
						if v_u_221.SuperKnife == true then
							v_u_264[2].meleeType = "meleemegaswing"
							local _ = unpack
						end
					end
				end
			end)
			return v_u_262(p_u_263, ...)
		end)
		local function v_u_276()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223, (ref) v_u_219, (ref) v_u_222, (ref) v_u_86, (ref) v_u_88
			while v_u_221.KillAura == true and _G.ScriptIsRunning ~= false do
				pcall(function()
					-- upvalues: (ref) v_u_220, (ref) v_u_221, (ref) v_u_223, (ref) v_u_219, (ref) v_u_222, (ref) v_u_86, (ref) v_u_88
					local v266 = v_u_220
					local v267, v268, v269 = pairs(v266:GetChildren())
					while true do
						local v270
						v269, v270 = v267(v268, v269)
						if v269 == nil then
							break
						end
						if v_u_221.KillAura == false then
							return
						end
						if v270 ~= v_u_223 and not (table.find(v_u_219, v270.Name) or table.find(v_u_222, v270.Name)) and (not v270.Character:FindFirstChildOfClass("ForceField") and (v270.Character.Humanoid.Health > 10 and (v_u_223.Character.HumanoidRootPart.Position - v270.Character.HumanoidRootPart.Position).Magnitude < v_u_221.KillAuraDistance)) then
							local v_u_271 = require(v_u_86).inventory.items
							pcall(function()
								-- upvalues: (ref) v_u_271, (ref) v_u_88
								local v272, v273, v274 = pairs(v_u_271)
								while true do
									local v275
									v274, v275 = v272(v273, v274)
									if v274 == nil then
										break
									end
									if v275.name and (v275.name == "Fists" and v275.equipped ~= true) then
										warn("yes")
										v_u_88("equip", v274)
									end
								end
							end)
							v_u_88("meleeItemHit", "player", {
								["meleeType"] = "meleemegapunch",
								["hitPlayerId"] = v270.UserId
							})
						end
					end
				end)
				task.wait()
			end
		end
		v117:Toggle("杀戮光环", "KillAura", false, function(p277)
			-- upvalues: (ref) v_u_221, (ref) v_u_276
			v_u_221.KillAura = p277
			v_u_276()
		end)
		v117:Slider("杀戮距离", "KillAuraDistance", 25, 0.1, 40, true, function(p278)
			-- upvalues: (ref) v_u_221
			v_u_221.KillAuraDistance = p278
		end)
		function KillAll()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223, (ref) v_u_219, (ref) v_u_222, (ref) v_u_86, (ref) v_u_88
			while v_u_221.KillAll == true do
				if _G.ScriptIsRunning == false then
					return
				end
				pcall(function()
					-- upvalues: (ref) v_u_220, (ref) v_u_221, (ref) v_u_223, (ref) v_u_219, (ref) v_u_222, (ref) v_u_86, (ref) v_u_88
					local v279 = v_u_220
					local v280, v281, v282 = pairs(v279:GetChildren())
					while true do
						local v283
						v282, v283 = v280(v281, v282)
						if v282 == nil then
							break
						end
						if v_u_221.KillAll == false then
							return
						end
						if v283 ~= v_u_223 and not (table.find(v_u_219, v283.Name) or table.find(v_u_222, v283.Name)) and (not v283.Character:FindFirstChildOfClass("ForceField") and v283.Character.Humanoid.Health ~= 0) then
							local v284 = 0
							local v_u_285 = require(v_u_86).inventory.items
							if v_u_223.Character.Humanoid.Health < 10 then
								v_u_223.Character.Humanoid.Health = 0
							end
							if v_u_223.Character.Humanoid.Sit == true then
								v_u_223.Character.Humanoid.Sit = false
							end
							pcall(function()
								-- upvalues: (ref) v_u_285, (ref) v_u_88
								local v286, v287, v288 = pairs(v_u_285)
								while true do
									local v289
									v288, v289 = v286(v287, v288)
									if v288 == nil then
										break
									end
									if v289.name and (v289.name == "Fists" and v289.equipped ~= true) then
										v_u_88("equip", v288)
									end
								end
							end)
							while true do
								task.wait()
								if v_u_221.KillAll == false or (v283.Character:FindFirstChildOfClass("ForceField") or v283.Character.Humanoid.Health == 0) then
									break
								end
								v_u_223.Character.HumanoidRootPart.CFrame = v283.Character.HumanoidRootPart.CFrame - v283.Character.HumanoidRootPart.CFrame.LookVector * 4.5
								v284 = v284 + 1
								meleeHit:FireServer("player", {
									["meleeType"] = "meleemegapunch",
									["hitPlayerId"] = v283.UserId
								})
								if v_u_223.Character.Humanoid.Health < 10 then
									v_u_223.Character.Humanoid.Health = 0
								end
								if v_u_223.Character.Humanoid.Sit == true then
									v_u_223.Character.Humanoid.Sit = false
								end
								if v283.Character.Humanoid.Health < 5 or (not v283.Character or 25 <= v284) then
									break
								end
							end
							v_u_88("stomp", v283)
							task.wait(0.4)
						end
					end
				end)
				task.wait()
			end
		end
		v118:Toggle("自动杀死全体玩家", "EspToggle", false, function(p290)
			-- upvalues: (ref) v_u_221
			v_u_221.KillAll = p290
			KillAll()
		end)
		local function v_u_296()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223, (ref) v_u_219, (ref) v_u_222, (ref) v_u_88
			while v_u_221.StompAura == true do
				if _G.ScriptIsRunning == false then
					return
				end
				pcall(function()
					-- upvalues: (ref) v_u_220, (ref) v_u_221, (ref) v_u_223, (ref) v_u_219, (ref) v_u_222, (ref) v_u_88
					local v291 = v_u_220
					local v292, v293, v294 = pairs(v291:GetChildren())
					while true do
						local v295
						v294, v295 = v292(v293, v294)
						if v294 == nil then
							break
						end
						if v_u_221.StompAura == false then
							return
						end
						if v295 ~= v_u_223 and (not table.find(v_u_219, v295.Name) and (not table.find(v_u_222, v295.Name) and ((v_u_223.Character.HumanoidRootPart.Position - v295.Character.HumanoidRootPart.Position).Magnitude < v_u_221.StompAuraDistance and (v295.Character.Humanoid.Health < 10 and v295.Character.Humanoid.Health ~= 0)))) then
							v_u_88("stomp", v295)
						end
					end
				end)
				task.wait()
			end
		end
		v119:Toggle("踩人光环", "EspToggle", false, function(p297)
			-- upvalues: (ref) v_u_221, (ref) v_u_296
			v_u_221.StompAura = p297
			v_u_296()
		end)
		v119:Slider("踩人距离", "Slider", 25, 0.1, 100, true, function(p298)
			-- upvalues: (ref) v_u_221
			v_u_221.StompAuraDistance = p298
		end)
		function GrabAura()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223, (ref) v_u_219, (ref) v_u_222, (ref) v_u_88
			while v_u_221.GrabAura == true do
				if _G.ScriptIsRunning == false then
					return
				end
				pcall(function()
					-- upvalues: (ref) v_u_220, (ref) v_u_221, (ref) v_u_223, (ref) v_u_219, (ref) v_u_222, (ref) v_u_88
					local v299 = v_u_220
					local v300, v301, v302 = pairs(v299:GetChildren())
					while true do
						local v303
						v302, v303 = v300(v301, v302)
						if v302 == nil then
							break
						end
						if v_u_221.GrabAura == false then
							return
						end
						if v303 ~= v_u_223 and (not table.find(v_u_219, v303.Name) and (not table.find(v_u_222, v303.Name) and ((v_u_223.Character.HumanoidRootPart.Position - v303.Character.HumanoidRootPart.Position).Magnitude < v_u_221.GrabAuraDistance and (v303.Character.Humanoid.Health < 10 and v303.Character.Humanoid.Health ~= 0)))) then
							v_u_88("grabPlayer", v303)
						end
					end
				end)
				task.wait()
			end
		end
		v120:Toggle("抱人光环", "EspToggle", false, function(p304)
			-- upvalues: (ref) v_u_221
			v_u_221.GrabAura = p304
			GrabAura()
		end)
		v120:Slider("抱人距离", "Slider", 25, 0.1, 100, true, function(p305)
			-- upvalues: (ref) v_u_221
			v_u_221.GrabAuraDistance = p305
		end)
		local v306, v307, v308 = pairs(game.CoreGui:GetChildren())
		while true do
			local v309, v310 = v306(v307, v308)
			if v309 == nil then
				break
			end
			v308 = v309
			if v310.Name == "ALbot" and v310:IsA("ScreenGui") then
				v310:Destroy()
			end
		end
		local v311 = Instance.new("ScreenGui")
		local v_u_312 = Instance.new("Frame")
		local v_u_313 = Instance.new("ImageButton")
		local v314 = Instance.new("UICorner")
		local v315 = Instance.new("UIStroke")
		v311.Name = "ALbot"
		v311.Parent = game.CoreGui
		v_u_312.Name = "AimButton"
		v_u_312.Parent = v311
		v_u_312.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
		v_u_312.BackgroundTransparency = 0.5
		v_u_312.Position = UDim2.new(0.0485268645, 0, 0.269377351, 0)
		v_u_312.Size = UDim2.new(0, 54, 0, 54)
		v_u_313.Parent = v_u_312
		v_u_313.BackgroundTransparency = 1
		v_u_313.Size = UDim2.new(1, 0, 1, 0)
		v_u_313.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_313.Position = UDim2.new(0.5, 0, 0.5, 0)
		v_u_313.Image = "rbxassetid://6922963617"
		v_u_313.AutoButtonColor = false
		v314.CornerRadius = UDim.new(0.3, 0)
		v314.Name = "UIC"
		v314.Parent = v_u_312
		v315.Transparency = 0.5
		v315.Name = "UIS"
		v315.Parent = v_u_312
		local v_u_316 = 0
		v_u_313.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_221, (ref) v_u_312, (ref) v_u_217
			if v_u_221.Aimbot ~= false then
				task.spawn(function()
					-- upvalues: (ref) v_u_312
					game:GetService("TweenService"):Create(v_u_312, TweenInfo.new(0.5), {
						["BackgroundColor3"] = Color3.fromRGB(255, 0, 0)
					}):Play()
				end)
				v_u_221.Aimbot = false
				v_u_217.Enemy = nil
			else
				task.spawn(function()
					-- upvalues: (ref) v_u_312
					game:GetService("TweenService"):Create(v_u_312, TweenInfo.new(0.5), {
						["BackgroundColor3"] = Color3.fromRGB(0, 255, 0)
					}):Play()
				end)
				v_u_221.Aimbot = true
				v_u_217.Enemy = nil
			end
		end)
		v_u_67.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_221, (ref) v_u_316, (ref) v_u_313
			if v_u_221.Aimbot ~= true then
				v_u_316 = 0
				v_u_313.Rotation = v_u_316
			else
				v_u_316 = v_u_316 + 1
				v_u_313.Rotation = v_u_316
			end
		end)
		v124:Toggle("子弹追踪", "SilentAim", false, function(p317)
			-- upvalues: (ref) v_u_221, (ref) v_u_217
			v_u_221.SilentAim = p317
			v_u_217.Line.Visible = false
		end)
		v124:Toggle("显示范围", "EspToggle", false, function(p318)
			-- upvalues: (ref) v_u_217, (ref) v_u_202
			v_u_217.Circle.Visible = p318
			v_u_202()
		end)
		v124:Toggle("范围填充", "EspToggle", false, function(p319)
			-- upvalues: (ref) v_u_217, (ref) v_u_202
			v_u_217.Circle.Filled = p319
			v_u_202()
		end)
		v124:Slider("自瞄范围", "FillTncy", 200, 1, 600, true, function(p320)
			-- upvalues: (ref) v_u_217, (ref) v_u_202
			v_u_217.Circle.Radius = p320
			v_u_202()
		end)
		v124:Toggle("目标连线", "EspToggle", false, function(p321)
			-- upvalues: (ref) v_u_217
			v_u_217.LineEnabled = p321
		end)
		v124:Slider("范围厚度", "FillTncy", 1, 1, 10, true, function(p322)
			-- upvalues: (ref) v_u_217, (ref) v_u_202
			v_u_217.Circle.Thickness = p322
			v_u_202()
		end)
		v124:Slider("范围透明度", "FillTncy", 1, 0, 1, true, function(p323)
			-- upvalues: (ref) v_u_217, (ref) v_u_202
			v_u_217.Circle.Transparency = p323
			v_u_202()
		end)
		v124:Dropdown("范围颜色", "SelectFillColor", {
			"白",
			"红",
			"绿",
			"蓝",
			"粉",
			"青"
		}, function(p324)
			-- upvalues: (ref) v_u_217, (ref) v_u_202, (ref) v_u_106
			if p324 == "白" then
				v_u_217.Circle.Color = Color3.fromRGB(255, 255, 255)
				v_u_202()
			elseif p324 == "红" then
				v_u_217.Circle.Color = v_u_106.Red
				v_u_202()
			elseif p324 == "绿" then
				v_u_217.Circle.Color = v_u_106.Green
				v_u_202()
			elseif p324 == "蓝" then
				v_u_217.Circle.Color = v_u_106.Blue
				v_u_202()
			elseif p324 == "粉" then
				v_u_217.Circle.Color = v_u_106.Pink
				v_u_202()
			elseif p324 == "青" then
				v_u_217.Circle.Color = v_u_106.Cyan
				v_u_202()
			end
		end)
		v124:Slider("预判自瞄", "Slider", 17.6, 0.1, 25, true, function(p325)
			-- upvalues: (ref) v_u_217
			v_u_217.Aimbot.Epitaph = p325
		end)
		v124:Toggle("显示预判自瞄", "EspToggle", false, function(p326)
			-- upvalues: (ref) v_u_217
			v_u_217.Aimbot.ShowEpitaph = p326
		end)
		v124:Dropdown("自瞄部位", "AimPart", {
			"头",
			"上身",
			"鸡巴",
			"左大臂",
			"左小臂",
			"左手",
			"右大臂",
			"右小臂",
			"右手",
			"左大腿",
			"左小腿",
			"左脚",
			"右大腿",
			"右小腿",
			"右脚"
		}, function(p327)
			-- upvalues: (ref) v_u_217
			if p327 == "头" then
				v_u_217.AimPart = "Head"
			elseif p327 == "上身" then
				v_u_217.AimPart = "UpperTorso"
			elseif p327 == "鸡巴" then
				v_u_217.AimPart = "LowerTorso"
			elseif p327 == "左上臂" then
				v_u_217.AimPart = "LeftUpperArm"
			elseif p327 == "左小臂" then
				v_u_217.AimPart = "LeftLowerArm"
			elseif p327 == "左手" then
				v_u_217.AimPart = "LeftHand"
			elseif p327 == "右上臂" then
				v_u_217.AimPart = "RightUpperArm"
			elseif p327 == "右小臂" then
				v_u_217.AimPart = "RightLowerArm"
			elseif p327 == "右手" then
				v_u_217.AimPart = "RightHand"
			elseif p327 == "左大腿" then
				v_u_217.AimPart = "LeftUpperLeg"
			elseif p327 == "左小腿" then
				v_u_217.AimPart = "LeftLowerLeg"
			elseif p327 == "左脚" then
				v_u_217.AimPart = "LeftFoot"
			elseif p327 == "右大腿" then
				v_u_217.AimPart = "RightUpperLeg"
			elseif p327 == "右小腿" then
				v_u_217.AimPart = "RightLowerLeg"
			elseif p327 == "右脚" then
				v_u_217.AimPart = "RightFoot"
			end
		end)
		v124:Toggle("墙壁检测", "EspToggle", false, function(p328)
			-- upvalues: (ref) v_u_217
			v_u_217.WallCheck = p328
		end)
		v124:Toggle("粘性自瞄", "EspToggle", false, function(p329)
			-- upvalues: (ref) v_u_217
			v_u_217.StickAim = p329
			if p329 == false then
				v_u_217.Enemy = nil
			end
		end)
		local v_u_330 = v124:Label("当前锁定玩家: " .. tostring(v_u_217.Enemy))
		local v_u_331 = nil
		v_u_331 = v_u_67.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_330, (ref) v_u_217, (ref) v_u_69, (ref) v_u_331, (ref) v_u_216, (ref) v_u_221, (ref) v_u_199, (ref) v_u_205
			v_u_330:Set("当前锁定玩家: " .. tostring(v_u_217.Enemy))
			v_u_69.FallenPartsDestroyHeight = -math.huge
			if _G.ScriptIsRunning == false then
				v_u_331:Disconnect()
			end
			if v_u_217.LineEnabled == true then
				if v_u_217.Enemy == nil then
					v_u_217.Line.Visible = false
				else
					local v332, v333 = v_u_216:WorldToViewportPoint(v_u_217.Enemy[v_u_217.AimPart].Position)
					if v333 then
						v_u_217.Line.To = Vector2.new(v332.X, v332.Y)
						v_u_217.Line.Visible = true
					end
				end
			end
			pcall(function()
				-- upvalues: (ref) v_u_221, (ref) v_u_217, (ref) v_u_199, (ref) v_u_216, (ref) v_u_205
				if v_u_221.Aimbot == true and v_u_221.SilentAim == false then
					local v334
					if v_u_217.StickAim ~= true or v_u_217.Enemy ~= nil then
						v334 = v_u_199()
					else
						v334 = v_u_199()
					end
					v_u_217.Enemy = v334
					if v_u_217.Enemy == nil then
						v_u_217.Aimbot.EpitaphCircle.Visible = false
					else
						local v335 = v_u_217.Enemy[v_u_217.AimPart].CFrame + v_u_217.Enemy[v_u_217.AimPart].Velocity * v_u_217.Aimbot.Epitaph / 100
						if v_u_217.Aimbot.ShowEpitaph == true then
							local v336 = v_u_216:WorldToViewportPoint(v335.Position)
							v_u_217.Aimbot.EpitaphCircle.Visible = true
							v_u_217.Aimbot.EpitaphCircle.Position = v336
						end
						v_u_205(v_u_216.CFrame.p, v335.Position)
					end
				end
			end)
		end)
		local v_u_337 = nil
		v_u_337 = hookmetamethod(game, "__namecall", function(p338)
			-- upvalues: (ref) v_u_221, (ref) v_u_199, (ref) v_u_217, (ref) v_u_227, (ref) v_u_337
			local v339 = { ... }
			if getnamecallmethod() ~= "Raycast" or v_u_221.SilentAim ~= true then
				return v_u_337(p338, ...)
			end
			local v340 = v339[1]
			local v341 = v_u_199()
			v_u_217.Enemy = v341
			if v_u_217.Enemy ~= nil then
				v339[2] = v_u_227(v340, v341[v_u_217.AimPart].Position)
			end
			return v_u_337(p338, unpack(v339))
		end)
		local v_u_342 = {
			["HitboxSize"] = 10
		}
		function HRPHitbox()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223, (ref) v_u_342
			while v_u_221.HitboxToggle == true do
				pcall(function()
					-- upvalues: (ref) v_u_220, (ref) v_u_221, (ref) v_u_223, (ref) v_u_342
					local v343 = v_u_220
					local v344, v345, v346 = pairs(v343:GetChildren())
					while true do
						local v347
						v346, v347 = v344(v345, v346)
						if v346 == nil then
							break
						end
						if v_u_221.HitboxToggle == false then
							return
						end
						if v347.Name ~= v_u_223.Name and v347.Character ~= nil then
							v347.Character.HumanoidRootPart.Size = Vector3.new(v_u_342.HitboxSize, v_u_342.HitboxSize, v_u_342.HitboxSize)
							v347.Character.HumanoidRootPart.CanCollide = false
							v347.Character.HumanoidRootPart.Transparency = 0.5
						end
					end
				end)
				task.wait()
			end
		end
		v121:Toggle("近战范围开关", "DDD29F", false, function(p348)
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223
			v_u_221.HitboxToggle = p348
			HRPHitbox()
			if p348 == false then
				pcall(function()
					-- upvalues: (ref) v_u_220, (ref) v_u_223
					local v349 = v_u_220
					local v350, v351, v352 = pairs(v349:GetChildren())
					while true do
						local v353
						v352, v353 = v350(v351, v352)
						if v352 == nil then
							break
						end
						if v353.Name ~= v_u_223.Name and v353.Character ~= nil then
							v353.Character.HumanoidRootPart.Size = Vector3.new(2, 2, 1)
							v353.Character.HumanoidRootPart.CanCollide = true
							v353.Character.HumanoidRootPart.Transparency = 1
						end
					end
				end)
			end
		end)
		v121:Slider("范围", "FillTncy", 10, 1, 100, true, function(p354)
			-- upvalues: (ref) v_u_342
			v_u_342.HitboxSize = p354
		end)
		v122:Toggle("开关", "EspToggle", false, function(p355)
			-- upvalues: (ref) v_u_221
			v_u_221.AutoSpammer = p355
		end)
		v122:Textbox("嘲讽内容", "Textbox", "B赞搜索灾难蛋购买脚本!", function(p356)
			-- upvalues: (ref) v_u_221
			v_u_221.AutoSpammerText = p356
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_220, (ref) v_u_223, (ref) v_u_221
			pcall(function()
				-- upvalues: (ref) v_u_220, (ref) v_u_223, (ref) v_u_221
				local v357 = v_u_220
				local v358, v359, v360 = pairs(v357:GetChildren())
				while true do
					local v_u_361
					v360, v_u_361 = v358(v359, v360)
					if v360 == nil then
						break
					end
					if v_u_361 ~= v_u_223 then
						if v_u_361.Character ~= nil and v_u_361.Character:FindFirstChildOfClass("Humanoid") then
							v_u_361.Character:FindFirstChildOfClass("Humanoid").Died:Connect(function()
								-- upvalues: (ref) v_u_221, (ref) v_u_223, (ref) v_u_361
								if v_u_221.AutoSpammer == true and (v_u_223.Character.HumanoidRootPart.Position - v_u_361.Character.HumanoidRootPart.Position).Magnitude < 12 then
									game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(tostring(v_u_221.AutoSpammerText), "All")
								end
							end)
						end
						v_u_361.CharacterAdded:Connect(function(p_u_362)
							-- upvalues: (ref) v_u_221, (ref) v_u_223
							repeat
								task.wait()
							until p_u_362:FindFirstChild("Humanoid")
							p_u_362.Humanoid.Died:Connect(function()
								-- upvalues: (ref) v_u_221, (ref) v_u_223, (ref) p_u_362
								if v_u_221.AutoSpammer == true and (v_u_223.Character.HumanoidRootPart.Position - p_u_362.HumanoidRootPart.Position).Magnitude < 12 then
									game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(tostring(v_u_221.AutoSpammerText), "All")
								end
							end)
						end)
					end
				end
			end)
		end)
		v_u_220.PlayerAdded:Connect(function(p_u_363)
			-- upvalues: (ref) v_u_221, (ref) v_u_223
			if p_u_363.Character ~= nil and p_u_363.Character:FindFirstChild("Humanoid") then
				p_u_363.Character:FindFirstChild("Humanoid").Died:Connect(function()
					-- upvalues: (ref) v_u_221, (ref) v_u_223, (ref) p_u_363
					if v_u_221.AutoSpammer == true and (v_u_223.Character.HumanoidRootPart.Position - p_u_363.Character.HumanoidRootPart.Position).Magnitude < 12 then
						game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(tostring(v_u_221.AutoSpammerText), "All")
					end
				end)
			end
			p_u_363.CharacterAdded:Connect(function(p_u_364)
				-- upvalues: (ref) v_u_221, (ref) v_u_223
				repeat
					task.wait()
				until p_u_364:FindFirstChild("Humanoid")
				p_u_364.Humanoid.Died:Connect(function()
					-- upvalues: (ref) v_u_221, (ref) v_u_223, (ref) p_u_364
					if v_u_221.AutoSpammer == true and (v_u_223.Character.HumanoidRootPart.Position - p_u_364.HumanoidRootPart.Position).Magnitude < 12 then
						game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(tostring(v_u_221.AutoSpammerText), "All")
					end
				end)
			end)
		end)
		function RespawnAtDeadPos()
			-- upvalues: (ref) v_u_221, (ref) v_u_223
			while v_u_221.RespawnAtDeadPos == true do
				pcall(function()
					-- upvalues: (ref) v_u_223, (ref) v_u_221
					if v_u_223.Character.Humanoid.Health == 0 and not v_u_223.Character:FindFirstChild("Tag") then
						local v365 = v_u_223.Character.HumanoidRootPart.CFrame
						local v366 = Instance.new("BoolValue")
						v366.Parent = v_u_223.Character
						v366.Name = "Tag"
						repeat
							task.wait()
						until v_u_223.Character ~= nil and v366.Parent ~= v_u_223.Character
						task.wait(v_u_221.RespawnAtDeadPosWait)
						v_u_223.Character.HumanoidRootPart.CFrame = v365
					end
				end)
				task.wait()
			end
		end
		v123:Toggle("开关", "EspToggle", false, function(p367)
			-- upvalues: (ref) v_u_221
			v_u_221.RespawnAtDeadPos = p367
			RespawnAtDeadPos()
		end)
		v123:Slider("等待时间", "FillTransparency", 1, 0.1, 5, true, function(p368)
			-- upvalues: (ref) v_u_221
			v_u_221.RespawnAtDeadPosWait = p368
		end)
		v126:Toggle("快速互动", "InstantPrompt", false, function(p369)
			-- upvalues: (ref) v_u_221
			v_u_221.InstantPrompt = p369
		end)
		v127:Button("售卖手中的物品", function()
			-- upvalues: (ref) v_u_81
			pcall(function()
				-- upvalues: (ref) v_u_81
				fireproximityprompt(v_u_81.Dealer.Dealer.ProximityPrompt)
			end)
		end)
		function ShowLocker()
			-- upvalues: (ref) v_u_221, (ref) v_u_68
			while v_u_221.ShowLocker == true do
				pcall(function()
					-- upvalues: (ref) v_u_68
					v_u_68.Backpack.Enabled = true
					v_u_68.Backpack.Holder.Locker.Visible = true
				end)
				task.wait()
			end
		end
		v128:Toggle("显示储存柜", "ShowLocker", false, function(p370)
			-- upvalues: (ref) v_u_221
			v_u_221.ShowLocker = p370
			ShowLocker()
		end)
		local v371, v372, v373 = pairs(v_u_82:GetChildren())
		local v_u_374 = {}
		local v375 = {}
		while true do
			local v376, v377 = v371(v372, v373)
			if v376 == nil then
				break
			end
			v373 = v376
			if not table.find(v_u_374, v377.Name) then
				table.insert(v_u_374, v377.Name)
			end
		end
		local v378, v379, v380 = pairs(v84:GetChildren())
		while true do
			local v381, v382 = v378(v379, v380)
			if v381 == nil then
				break
			end
			v380 = v381
			if v382:FindFirstChild("TopLabel") and v382.Adornee ~= nil then
				if table.find(v_u_374, v382.Adornee.Parent.Name) then
					v_u_374[v382.Adornee.Parent.Name] = v382:FindFirstChild("TopLabel").LocalizedText
				end
				if not table.find(v375, v382:FindFirstChild("TopLabel").LocalizedText) then
					table.insert(v375, v382:FindFirstChild("TopLabel").LocalizedText)
					v375[v382:FindFirstChild("TopLabel").LocalizedText] = v382.Adornee.Parent.Name
				end
			end
		end
		v129:Dropdown("道具列表", "sb", v375, function(p383)
			-- upvalues: (ref) v_u_374, (ref) v_u_221
			local v384, v385, v386 = pairs(v_u_374)
			while true do
				local v387
				v386, v387 = v384(v385, v386)
				if v386 == nil then
					break
				end
				if v387 == p383 then
					v_u_221.BuyItem = v386
				end
			end
		end)
		v129:Button("购买物品", function()
			-- upvalues: (ref) v_u_221, (ref) v_u_89, (ref) v_u_215
			if v_u_221.BuyItem == nil then
				v_u_215:Notify("未选择物品", 1)
			else
				v_u_89("attemptPurchase", v_u_221.BuyItem)
				v_u_215:Notify("购买成功 " .. v_u_221.BuyItem, 1)
			end
		end)
		v129:Button("购买子弹", function()
			-- upvalues: (ref) v_u_221, (ref) v_u_89, (ref) v_u_215
			if v_u_221.BuyItem == nil then
				v_u_215:Notify("未选择物品", 1)
			else
				v_u_89("attemptPurchaseAmmo", v_u_221.BuyItem)
				v_u_215:Notify("购买成功 " .. v_u_221.BuyItem, 1)
			end
		end)
		v129:Button("传送到购买点", function()
			-- upvalues: (ref) v_u_221, (ref) v_u_82, (ref) v_u_223, (ref) v_u_215
			if v_u_221.BuyItem == nil then
				v_u_215:Notify("未选择物品", 1)
			elseif v_u_82:FindFirstChild(v_u_221.BuyItem) then
				local v388 = v_u_82:FindFirstChild(v_u_221.BuyItem)
				if v388:FindFirstChild("Button") then
					v_u_223.Character.HumanoidRootPart.CFrame = v388.Button.CFrame
				else
					v_u_215:Notify("购买按钮未加载", 1)
				end
			else
				v_u_215:Notify("无效的物品", 1)
			end
		end)
		local function v_u_394()
			-- upvalues: (ref) v_u_221, (ref) v_u_83, (ref) v_u_89, (ref) v_u_88
			while v_u_221.Christmas == true do
				local v389 = v_u_83
				local v390, v391, v392 = pairs(v389:GetChildren())
				while true do
					local v393
					v392, v393 = v390(v391, v392)
					if v392 == nil then
						break
					end
					if v_u_221.Christmas ~= true then
						return
					end
					if v393:GetAttribute("mobName") then
						v393:SetAttribute("health", 0)
						v_u_89("attemptCollectMob", v393:GetAttribute("mobName"), v393.Name)
						task.wait(0.1)
						for _ = 1, 4 do
							v_u_88("collectGingerbread", 40)
						end
					end
				end
				task.wait()
			end
		end
		v131:Toggle("开关", "Christmas", false, function(p395)
			-- upvalues: (ref) v_u_221, (ref) v_u_394
			v_u_221.Christmas = p395
			v_u_394()
		end)
		local v_u_396 = {
			["MinRandomWait"] = 0.5,
			["MaxRandomWait"] = 2,
			["MinMoney"] = 300
		}
		function MoneyFarm()
			-- upvalues: (ref) v_u_221, (ref) v_u_76, (ref) v_u_396, (ref) v_u_215, (ref) v_u_223, (ref) v_u_231
			while v_u_221.MoneyFarm == true do
				local v397 = v_u_76
				local v398, v399, v400 = pairs(v397:GetChildren())
				while true do
					local v_u_401
					v400, v_u_401 = v398(v399, v400)
					if v400 == nil then
						break
					end
					if v_u_221.MoneyFarm == false then
						return
					end
					pcall(function()
						-- upvalues: (ref) v_u_401, (ref) v_u_396, (ref) v_u_215, (ref) v_u_223, (ref) v_u_231
						if v_u_401:FindFirstChildOfClass("IntValue").Value >= v_u_396.MinMoney then
							v_u_215:Notify("传送到金钱", 0.5)
							local v402 = v_u_401
							v_u_223.Character.HumanoidRootPart.CFrame = v402:FindFirstChildOfClass("Part").CFrame * CFrame.new(0, 4, 0)
							task.wait(math.random(v_u_396.MinRandomWait, v_u_396.MaxRandomWait))
							v_u_215:Notify("尝试拾取金钱", 0.5)
							v_u_231(v_u_401)
							task.wait(math.random(v_u_396.MinRandomWait, v_u_396.MaxRandomWait))
						end
					end)
				end
				task.wait()
			end
		end
		v132:Toggle("自动捡钱", "EspToggle", false, function(p403)
			-- upvalues: (ref) v_u_221
			v_u_221.MoneyFarm = p403
			MoneyFarm()
		end)
		function MoneyAura()
			-- upvalues: (ref) v_u_221, (ref) v_u_76, (ref) v_u_223, (ref) v_u_231
			while v_u_221.MoneyAura == true do
				local v404 = v_u_76
				local v405, v406, v407 = pairs(v404:GetChildren())
				while true do
					local v_u_408
					v407, v_u_408 = v405(v406, v407)
					if v407 == nil then
						break
					end
					if v_u_221.MoneyAura == false then
						return
					end
					pcall(function()
						-- upvalues: (ref) v_u_223, (ref) v_u_408, (ref) v_u_231
						local v409 = v_u_408
						if (v_u_223.Character.HumanoidRootPart.Position - v409:FindFirstChildOfClass("Part").Position).Magnitude <= 6.5 then
							v_u_231(v_u_408)
						end
					end)
				end
				task.wait()
			end
		end
		v132:Toggle("捡钱光环", "EspToggle", false, function(p410)
			-- upvalues: (ref) v_u_221
			v_u_221.MoneyAura = p410
			MoneyAura()
		end)
		v132:Slider("最小钱数", "FillTransparency", 300, 20, 100000, true, function(p411)
			-- upvalues: (ref) v_u_396
			v_u_396.MinMoney = p411
		end)
		v132:Slider("最小随机等待数值", "FillTransparency", 0.5, 0.5, 2, true, function(p412)
			-- upvalues: (ref) v_u_396
			v_u_396.MinRandomWait = p412
		end)
		v132:Slider("最大随机等待数值", "FillTransparency", 2, 2, 5, true, function(p413)
			-- upvalues: (ref) v_u_396
			v_u_396.MaxRandomWait = p413
		end)
		local v_u_414 = {
			["IsSelectItem"] = false,
			["MinRandomWait"] = 0.5,
			["MaxRandomWait"] = 2,
			["SelectItem"] = {}
		}
		function ItemsFarm()
			-- upvalues: (ref) v_u_221, (ref) v_u_77, (ref) v_u_414, (ref) v_u_215, (ref) v_u_223, (ref) v_u_231
			while v_u_221.ItemsFarm == true do
				pcall(function()
					-- upvalues: (ref) v_u_77, (ref) v_u_221, (ref) v_u_414, (ref) v_u_215, (ref) v_u_223, (ref) v_u_231
					local v415 = v_u_77
					local v416, v417, v418 = pairs(v415:GetChildren())
					while true do
						local v419
						v418, v419 = v416(v417, v418)
						if v418 == nil then
							return
						end
						if v_u_221.ItemsFarm == false then
							return
						end
						local v420
						if v_u_414.IsSelectItem ~= true then
							v420 = true
						else
							local v421, v422, v423 = pairs(v419:GetDescendants())
							v420 = false
							while true do
								local v424
								v423, v424 = v421(v422, v423)
								if v423 == nil then
									break
								end
								if v424:IsA("ProximityPrompt") and table.find(v_u_414.SelectItem, v424.ObjectText) then
									v420 = true
									break
								end
							end
						end
						if v420 == true then
							v_u_215:Notify("传送到物品", 0.5)
							v_u_223.Character.HumanoidRootPart.CFrame = v419:FindFirstChildOfClass("Part").CFrame * CFrame.new(0, 4, 0)
							task.wait(math.random(v_u_414.MinRandomWait, v_u_414.MaxRandomWait))
							v_u_215:Notify("尝试拾取物品", 0.5)
							v_u_231(v419)
							task.wait(math.random(v_u_414.MinRandomWait, v_u_414.MaxRandomWait))
						end
					end
				end)
				task.wait()
			end
		end
		v133:Toggle("自动捡物品", "EspToggle", false, function(p425)
			-- upvalues: (ref) v_u_221
			v_u_221.ItemsFarm = p425
			ItemsFarm()
		end)
		function ItemAura()
			-- upvalues: (ref) v_u_221, (ref) v_u_77, (ref) v_u_223, (ref) v_u_231
			while v_u_221.ItemAura == true do
				pcall(function()
					-- upvalues: (ref) v_u_77, (ref) v_u_221, (ref) v_u_223, (ref) v_u_231
					local v426 = v_u_77
					local v427, v428, v429 = pairs(v426:GetChildren())
					while true do
						local v430
						v429, v430 = v427(v428, v429)
						if v429 == nil then
							break
						end
						if v_u_221.ItemAura == false then
							return
						end
						if (v_u_223.Character.HumanoidRootPart.Position - v430:FindFirstChildOfClass("Part").Position).Magnitude <= 6.5 then
							v_u_231(v430)
						end
					end
				end)
				task.wait()
			end
		end
		v133:Toggle("物品光环", "EspToggle", false, function(p431)
			-- upvalues: (ref) v_u_221
			v_u_221.ItemAura = p431
			ItemAura()
		end)
		v133:Label("设置")
		v133:Slider("最小随机等待数值", "FillTransparency", 0.5, 0.5, 2, true, function(p432)
			-- upvalues: (ref) v_u_414
			v_u_414.MinRandomWait = p432
		end)
		v133:Slider("最大随机等待数值", "FillTransparency", 2, 2, 5, true, function(p433)
			-- upvalues: (ref) v_u_414
			v_u_414.MaxRandomWait = p433
		end)
		local v_u_434 = "选中的物品: "
		local v_u_435 = v133:Label(v_u_434)
		v133:Dropdown("道具列表", "sb", { "红卡", "蓝卡", "印钞机" }, function(p436)
			-- upvalues: (ref) v_u_414, (ref) v_u_434, (ref) v_u_435
			if p436 == "红卡" then
				table.insert(v_u_414.SelectItem, "Military Armory Keycard")
				v_u_434 = v_u_434 .. "/" .. p436
				v_u_435:Set(v_u_434)
			elseif p436 == "蓝卡" then
				table.insert(v_u_414.SelectItem, "Police Armory Keycard")
				v_u_434 = v_u_434 .. "/" .. p436
				v_u_435:Set(v_u_434)
			elseif p436 == "印钞机" then
				table.insert(v_u_414.SelectItem, "Money Printer")
				v_u_434 = v_u_434 .. "/" .. p436
				v_u_435:Set(v_u_434)
			end
		end)
		v133:Button("清空选中物品", function()
			-- upvalues: (ref) v_u_414, (ref) v_u_434, (ref) v_u_435
			pcall(function()
				-- upvalues: (ref) v_u_414, (ref) v_u_434, (ref) v_u_435
				table.clear(v_u_414.SelectItem)
				v_u_434 = "选中的物品: "
				v_u_435:Set(v_u_434)
			end)
		end)
		v133:Toggle("仅自动捡起选中的道具", "EspToggle", false, function(p437)
			-- upvalues: (ref) v_u_414
			v_u_414.IsSelectItem = p437
		end)
		local v_u_438 = {
			["MinRandomWait"] = 0.1,
			["MaxRandomWait"] = 1,
			["RobLoots"] = false
		}
		function BankFarm()
			-- upvalues: (ref) v_u_221, (ref) v_u_79, (ref) v_u_223, (ref) v_u_438
			while v_u_221.BankFarm == true do
				pcall(function()
					-- upvalues: (ref) v_u_79, (ref) v_u_223, (ref) v_u_438
					if #v_u_79.BankCash.Cash:GetChildren() > 0 then
						if v_u_79.VaultDoor.Door.Attachment.ProximityPrompt.Enabled ~= true then
							v_u_223.Character.HumanoidRootPart.CFrame = v_u_79.BankCash.Main.CFrame
							task.wait(math.random(v_u_438.MinRandomWait, v_u_438.MaxRandomWait))
							fireproximityprompt(v_u_79.BankCash.Main.Attachment.ProximityPrompt)
						else
							v_u_223.Character.HumanoidRootPart.CFrame = v_u_79.VaultDoor.Door.CFrame
							task.wait(math.random(v_u_438.MinRandomWait, v_u_438.MaxRandomWait))
							fireproximityprompt(v_u_79.VaultDoor.Door.Attachment.ProximityPrompt)
						end
					end
				end)
				task.wait()
			end
		end
		v134:Toggle("自动抢银行", "EspToggle", false, function(p439)
			-- upvalues: (ref) v_u_221
			v_u_221.BankFarm = p439
			BankFarm()
		end)
		v134:Slider("最小随机等待数值", "FillTransparency", 0.3, 0, 1, true, function(p440)
			-- upvalues: (ref) v_u_438
			v_u_438.MinRandomWait = p440
		end)
		v134:Slider("最小随机等待数值", "FillTransparency", 1, 1, 2, true, function(p441)
			-- upvalues: (ref) v_u_438
			v_u_438.MaxRandomWait = p441
		end)
		function JewelryCasesAura()
			-- upvalues: (ref) v_u_221, (ref) v_u_80, (ref) v_u_223
			while v_u_221.JewelryCasesAura == true do
				pcall(function()
					-- upvalues: (ref) v_u_80, (ref) v_u_221, (ref) v_u_223
					local v442, v443, v444 = pairs(v_u_80.LowYieldSpawns:GetChildren())
					while true do
						local v445
						v444, v445 = v442(v443, v444)
						if v444 == nil then
							break
						end
						if v_u_221.JewelryCasesAura == false then
							return
						end
						if v445.Name ~= "Case" and v445.Name ~= "Glass" then
							local v446, v447, v448 = pairs(v445:GetDescendants())
							while true do
								local v449
								v448, v449 = v446(v447, v448)
								if v448 == nil then
									break
								end
								if v_u_221.JewelryCasesAura == false then
									return
								end
								if v449:IsA("ProximityPrompt") and (v449.Enabled == true and (v_u_223.Character.HumanoidRootPart.Position - v449.Parent.Position).Magnitude <= 3) then
									fireproximityprompt(v449)
								end
							end
						end
					end
					local v450, v451, v452 = pairs(v_u_80.HighYieldSpawns:GetChildren())
					while true do
						local v453
						v452, v453 = v450(v451, v452)
						if v452 == nil then
							break
						end
						if v_u_221.JewelryCasesAura == false then
							return
						end
						if v453.Name ~= "Case" and v453.Name ~= "Glass" then
							local v454, v455, v456 = pairs(v453:GetDescendants())
							while true do
								local v457
								v456, v457 = v454(v455, v456)
								if v456 == nil then
									break
								end
								if v_u_221.JewelryCasesAura == false then
									return
								end
								if v457:IsA("ProximityPrompt") and (v457.Enabled == true and (v_u_223.Character.HumanoidRootPart.Position - v457.Parent.Position).Magnitude <= 3) then
									fireproximityprompt(v457)
								end
							end
						end
					end
				end)
				task.wait()
			end
		end
		v135:Toggle("珠宝光环", "EspToggle", false, function(p458)
			-- upvalues: (ref) v_u_221
			v_u_221.JewelryCasesAura = p458
			JewelryCasesAura()
		end)
		function AutoFarmJewelryCases()
			-- upvalues: (ref) v_u_221, (ref) v_u_80, (ref) v_u_223
			while v_u_221.AutoFarmJewelryCases == true do
				pcall(function()
					-- upvalues: (ref) v_u_80, (ref) v_u_221, (ref) v_u_223
					local v459, v460, v461 = pairs(v_u_80.LowYieldSpawns:GetChildren())
					while true do
						local v462
						v461, v462 = v459(v460, v461)
						if v461 == nil then
							break
						end
						if v_u_221.AutoFarmJewelryCases == false then
							return
						end
						if v462.Name ~= "Case" and v462.Name ~= "Glass" then
							local v463, v464, v465 = pairs(v462:GetChildren())
							while true do
								local v466
								v465, v466 = v463(v464, v465)
								if v465 == nil then
									break
								end
								if v_u_221.AutoFarmJewelryCases == false then
									return
								end
								if v466:IsA("ProximityPrompt") and v466.Enabled == true then
									v_u_223.Character.HumanoidRootPart.CFrame = v466.Parent.CFrame
									task.wait(0.1)
									fireproximityprompt(v466)
									task.wait(0.3)
								end
							end
						end
					end
					local v467, v468, v469 = pairs(v_u_80.HighYieldSpawns:GetChildren())
					while true do
						local v470
						v469, v470 = v467(v468, v469)
						if v469 == nil then
							break
						end
						if v_u_221.AutoFarmJewelryCases == false then
							return
						end
						if v470.Name ~= "Case" and v470.Name ~= "Glass" then
							local v471, v472, v473 = pairs(v470:GetChildren())
							while true do
								local v474
								v473, v474 = v471(v472, v473)
								if v473 == nil then
									break
								end
								if v_u_221.AutoFarmJewelryCases == false then
									return
								end
								if v474:FindFirstChild("Box") and (v474.Box:FindFirstChildOfClass("ProximityPrompt") and (v474:IsA("ProximityPrompt") and v474.Enabled == true)) then
									v_u_223.Character.HumanoidRootPart.CFrame = v474.Parent.CFrame
									task.wait(0.1)
									fireproximityprompt(v474)
									task.wait(0.3)
								end
							end
						end
					end
				end)
				task.wait()
			end
		end
		v135:Toggle("自动捡珠宝", "EspToggle", false, function(p475)
			-- upvalues: (ref) v_u_221
			v_u_221.AutoFarmJewelryCases = p475
			AutoFarmJewelryCases()
		end)
		function AutoFarmSafes()
			-- upvalues: (ref) v_u_221, (ref) v_u_74, (ref) v_u_223
			while v_u_221.AutoFarmSafes == true do
				pcall(function()
					-- upvalues: (ref) v_u_74, (ref) v_u_221, (ref) v_u_223
					local v476, v477, v478 = pairs(v_u_74.JewelSafe:GetChildren())
					while true do
						local v479
						v478, v479 = v476(v477, v478)
						if v478 == nil then
							break
						end
						if v_u_221.AutoFarmSafes == false then
							return
						end
						if v479:IsA("Model") and v479:FindFirstChild("Door") then
							local v480, v481, v482 = pairs(v479:GetDescendants())
							while true do
								local v483
								v482, v483 = v480(v481, v482)
								if v482 == nil then
									break
								end
								if v483:IsA("ProximityPrompt") and v483.Enabled == true then
									v_u_223.Character.HumanoidRootPart.CFrame = v479.SafeMain.CFrame
									task.wait(0.5)
									fireproximityprompt(v483)
									task.wait(0.5)
								end
							end
						end
					end
					local v484, v485, v486 = pairs(v_u_74.GoldJewelSafe:GetChildren())
					while true do
						local v487
						v486, v487 = v484(v485, v486)
						if v486 == nil then
							break
						end
						if v_u_221.AutoFarmSafes == false then
							return
						end
						if v487:IsA("Model") and v487:FindFirstChild("Door") then
							local v488, v489, v490 = pairs(v487:GetDescendants())
							while true do
								local v491
								v490, v491 = v488(v489, v490)
								if v490 == nil then
									break
								end
								if v491:IsA("ProximityPrompt") and v491.Enabled == true then
									v_u_223.Character.HumanoidRootPart.CFrame = v487.SafeMain.CFrame
									task.wait(0.5)
									fireproximityprompt(v491)
									task.wait(0.5)
								end
							end
						end
					end
					local v492, v493, v494 = pairs(v_u_74.SmallSafe:GetChildren())
					while true do
						local v495
						v494, v495 = v492(v493, v494)
						if v494 == nil then
							break
						end
						if v_u_221.AutoFarmSafes == false then
							return
						end
						if v495:IsA("Model") and v495:FindFirstChild("Door") then
							local v496, v497, v498 = pairs(v495:GetDescendants())
							while true do
								local v499
								v498, v499 = v496(v497, v498)
								if v498 == nil then
									break
								end
								if v499:IsA("ProximityPrompt") and v499.Enabled == true then
									v_u_223.Character.HumanoidRootPart.CFrame = v495.SafeMain.CFrame
									task.wait(0.5)
									fireproximityprompt(v499)
									task.wait(0.5)
								end
							end
						end
					end
					local v500, v501, v502 = pairs(v_u_74.MediumSafe:GetChildren())
					while true do
						local v503
						v502, v503 = v500(v501, v502)
						if v502 == nil then
							break
						end
						if v_u_221.AutoFarmSafes == false then
							return
						end
						if v503:IsA("Model") and v503:FindFirstChild("Door") then
							local v504, v505, v506 = pairs(v503:GetDescendants())
							while true do
								local v507
								v506, v507 = v504(v505, v506)
								if v506 == nil then
									break
								end
								if v507:IsA("ProximityPrompt") and v507.Enabled == true then
									v_u_223.Character.HumanoidRootPart.CFrame = v503.SafeMain.CFrame
									task.wait(0.5)
									fireproximityprompt(v507)
									task.wait(0.5)
								end
							end
						end
					end
					local v508, v509, v510 = pairs(v_u_74.LargeSafe:GetChildren())
					while true do
						local v511
						v510, v511 = v508(v509, v510)
						if v510 == nil then
							break
						end
						if v_u_221.AutoFarmSafes == false then
							return
						end
						if v511:IsA("Model") and v511:FindFirstChild("Door") then
							local v512, v513, v514 = pairs(v511:GetDescendants())
							while true do
								local v515
								v514, v515 = v512(v513, v514)
								if v514 == nil then
									break
								end
								if v515:IsA("ProximityPrompt") and v515.Enabled == true then
									v_u_223.Character.HumanoidRootPart.CFrame = v511.SafeMain.CFrame
									task.wait(0.5)
									fireproximityprompt(v515)
									task.wait(0.5)
								end
							end
						end
					end
				end)
				task.wait()
			end
		end
		v136:Toggle("自动开保险柜开关", "AutoFarmSafes", false, function(p516)
			-- upvalues: (ref) v_u_221
			v_u_221.AutoFarmSafes = p516
			AutoFarmSafes()
		end)
		function SafesAura()
			-- upvalues: (ref) v_u_221, (ref) v_u_74, (ref) v_u_223
			while v_u_221.SafesAura == true do
				pcall(function()
					-- upvalues: (ref) v_u_74, (ref) v_u_221, (ref) v_u_223
					local v517, v518, v519 = pairs(v_u_74.JewelSafe:GetChildren())
					while true do
						local v520
						v519, v520 = v517(v518, v519)
						if v519 == nil then
							break
						end
						if v_u_221.SafesAura == false then
							return
						end
						if v520:IsA("Model") and (v520:FindFirstChild("Door") and (v_u_223.Character.HumanoidRootPart.Position - v520.SafeMain.Position).Magnitude < 10) then
							local v521, v522, v523 = pairs(v520:GetDescendants())
							while true do
								local v524
								v523, v524 = v521(v522, v523)
								if v523 == nil then
									break
								end
								if v524:IsA("ProximityPrompt") and v524.Enabled == true then
									fireproximityprompt(v524)
								end
							end
						end
					end
					local v525, v526, v527 = pairs(v_u_74.GoldJewelSafe:GetChildren())
					while true do
						local v528
						v527, v528 = v525(v526, v527)
						if v527 == nil then
							break
						end
						if v_u_221.SafesAura == false then
							return
						end
						if v528:IsA("Model") and (v528:FindFirstChild("Door") and (v_u_223.Character.HumanoidRootPart.Position - v528.SafeMain.Position).Magnitude < 10) then
							local v529, v530, v531 = pairs(v528:GetDescendants())
							while true do
								local v532
								v531, v532 = v529(v530, v531)
								if v531 == nil then
									break
								end
								if v532:IsA("ProximityPrompt") and v532.Enabled == true then
									fireproximityprompt(v532)
								end
							end
						end
					end
					local v533, v534, v535 = pairs(v_u_74.SmallSafe:GetChildren())
					while true do
						local v536
						v535, v536 = v533(v534, v535)
						if v535 == nil then
							break
						end
						if v_u_221.SafesAura == false then
							return
						end
						if v536:IsA("Model") and (v536:FindFirstChild("Door") and (v_u_223.Character.HumanoidRootPart.Position - v536.SafeMain.Position).Magnitude < 10) then
							local v537, v538, v539 = pairs(v536:GetDescendants())
							while true do
								local v540
								v539, v540 = v537(v538, v539)
								if v539 == nil then
									break
								end
								if v540:IsA("ProximityPrompt") and v540.Enabled == true then
									fireproximityprompt(v540)
								end
							end
						end
					end
					local v541, v542, v543 = pairs(v_u_74.MediumSafe:GetChildren())
					while true do
						local v544
						v543, v544 = v541(v542, v543)
						if v543 == nil then
							break
						end
						if v_u_221.SafesAura == false then
							return
						end
						if v544:IsA("Model") and (v544:FindFirstChild("Door") and (v_u_223.Character.HumanoidRootPart.Position - v544.SafeMain.Position).Magnitude < 10) then
							local v545, v546, v547 = pairs(v544:GetDescendants())
							while true do
								local v548
								v547, v548 = v545(v546, v547)
								if v547 == nil then
									break
								end
								if v548:IsA("ProximityPrompt") and v548.Enabled == true then
									fireproximityprompt(v548)
								end
							end
						end
					end
					local v549, v550, v551 = pairs(v_u_74.LargeSafe:GetChildren())
					while true do
						local v552
						v551, v552 = v549(v550, v551)
						if v551 == nil then
							break
						end
						if v_u_221.SafesAura == false then
							return
						end
						if v552:IsA("Model") and (v552:FindFirstChild("Door") and (v_u_223.Character.HumanoidRootPart.Position - v552.SafeMain.Position).Magnitude < 10) then
							local v553, v554, v555 = pairs(v552:GetDescendants())
							while true do
								local v556
								v555, v556 = v553(v554, v555)
								if v555 == nil then
									break
								end
								if v556:IsA("ProximityPrompt") and v556.Enabled == true then
									fireproximityprompt(v556)
								end
							end
						end
					end
				end)
				task.wait()
			end
		end
		v136:Toggle("保险柜光环", "SafesAura", false, function(p557)
			-- upvalues: (ref) v_u_221
			v_u_221.SafesAura = p557
			SafesAura()
		end)
		local function v_u_563()
			-- upvalues: (ref) v_u_221, (ref) v_u_75
			while v_u_221.AutoFarmAirdrop == true do
				pcall(function()
					-- upvalues: (ref) v_u_75
					local v558 = v_u_75
					local v559, v560, v561 = pairs(v558:GetChildren())
					while true do
						local v562
						v561, v562 = v559(v560, v561)
						if v561 == nil then
							break
						end
						if v562:FindFirstChild("Airdrop") and v562:FindFirstChild("Airdrop"):FindFirstChildOfClass("ProximityPrompt") then
							game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = v562:FindFirstChild("Airdrop").CFrame
							task.wait(0.2)
							fireproximityprompt(v562:FindFirstChild("Airdrop"):FindFirstChildOfClass("ProximityPrompt"))
						end
					end
				end)
				task.wait()
			end
		end
		v137:Toggle("自动捡空投", "SafesAura", false, function(p564)
			-- upvalues: (ref) v_u_221, (ref) v_u_563
			v_u_221.AutoFarmAirdrop = p564
			v_u_563()
		end)
		local v_u_565 = {
			["商店"] = CFrame.new(674, 6, -694),
			["家具店"] = CFrame.new(891, 6, -774),
			["便利店"] = CFrame.new(913, 6, -894),
			["游戏厅"] = CFrame.new(836, 6, -906),
			["警察局"] = CFrame.new(646, 9, -865),
			["披萨餐厅"] = CFrame.new(469, 8, -861),
			["高级家具城"] = CFrame.new(375, -5, -408),
			["黑市"] = CFrame.new(655, -16, -77),
			["银行"] = CFrame.new(1084, 8, -380),
			["咖啡餐厅"] = CFrame.new(1331, 8, -329),
			["游乐场"] = CFrame.new(1177, 13, -25),
			["珠宝店"] = CFrame.new(1579, 8, -689),
			["健身房"] = CFrame.new(1593, 6, -317),
			["医院"] = CFrame.new(1152, 6, -974),
			["手机店"] = CFrame.new(853, 6, -1048),
			["军事基地"] = CFrame.new(796, 25, -1336)
		}
		v138:Dropdown("地点列表", "Locates", {
			"商店",
			"家具店",
			"便利店",
			"游戏厅",
			"警察局",
			"披萨餐厅",
			"高级家具城",
			"黑市",
			"银行",
			"咖啡餐厅",
			"游乐场",
			"珠宝店",
			"健身房",
			"医院",
			"手机店",
			"军事基地"
		}, function(p566)
			-- upvalues: (ref) v_u_221, (ref) v_u_565
			v_u_221.SelectLocate = v_u_565[p566]
		end)
		v138:Button("传送到地点", function()
			-- upvalues: (ref) v_u_223, (ref) v_u_221
			pcall(function()
				-- upvalues: (ref) v_u_223, (ref) v_u_221
				v_u_223.Character.HumanoidRootPart.CFrame = v_u_221.SelectLocate
			end)
		end)
		local v567, v568, v569 = pairs(v73:GetDescendants())
		local v_u_570 = {}
		local v_u_571 = {}
		while true do
			local v572
			v569, v572 = v567(v568, v569)
			if v569 == nil then
				break
			end
			if v572:IsA("BasePart") or v572:IsA("UnionOperation") then
				table.insert(v_u_570, v572)
			end
		end
		v73.DescendantAdded:Connect(function(p573)
			-- upvalues: (ref) v_u_570, (ref) v_u_221, (ref) v_u_571
			if p573:IsA("BasePart") or p573:IsA("UnionOperation") then
				table.insert(v_u_570, p573)
				if v_u_221.BringUnAnchored == true then
					p573.CanCollide = true
					local v574 = Instance.new("BodyPosition")
					v574.Parent = p573
					v574.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
					table.insert(v_u_571, v574)
				end
			end
		end)
		v139:Toggle("吸物体到身体前面", "EspToggle", false, function(p575)
			-- upvalues: (ref) v_u_221, (ref) v_u_570, (ref) v_u_571
			v_u_221.BringUnAnchored = p575
			if p575 == true then
				local v576, v577, v578 = pairs(v_u_570)
				while true do
					local v_u_579
					v578, v_u_579 = v576(v577, v578)
					if v578 == nil then
						break
					end
					pcall(function()
						-- upvalues: (ref) v_u_579, (ref) v_u_571
						local v580 = v_u_579
						local v581, v582, v583 = pairs(v580:GetChildren())
						while true do
							local v584
							v583, v584 = v581(v582, v583)
							if v583 == nil then
								break
							end
							if v584:IsA("BodyPosition") or v584:IsA("BodyGyro") then
								v584:Destroy()
							end
						end
						v_u_579.CanCollide = true
						local v585 = Instance.new("BodyPosition")
						v585.Parent = v_u_579
						v585.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
						table.insert(v_u_571, v585)
					end)
				end
			elseif p575 == false then
				local v586, v587, v588 = pairs(v_u_571)
				while true do
					local v_u_589
					v588, v_u_589 = v586(v587, v588)
					if v588 == nil then
						break
					end
					pcall(function()
						-- upvalues: (ref) v_u_589
						v_u_589:Destroy()
					end)
				end
			end
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_221, (ref) v_u_571, (ref) v_u_223
			while _G.ScriptIsRunning == true do
				pcall(function()
					-- upvalues: (ref) v_u_221, (ref) v_u_571, (ref) v_u_223
					if v_u_221.BringUnAnchored == true then
						local v590, v591, v592 = pairs(v_u_571)
						while true do
							local v593
							v592, v593 = v590(v591, v592)
							if v592 == nil then
								break
							end
							if v_u_221.BringUnAnchored == false then
								return
							end
							v593.Position = v_u_223.Character.HumanoidRootPart.Position
						end
					end
				end)
				task.wait()
			end
		end)
		local v_u_595 = v139:Dropdown("玩家列表", "Players", v_u_224, function(p594)
			-- upvalues: (ref) v_u_221
			v_u_221.FunTarget = p594
		end)
		v139:Label("改的动作全部人可以看见")
		function MessageSpammer()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_88
			while v_u_221.MessageSpammer == true do
				if v_u_220:FindFirstChild(v_u_221.FunTarget) then
					v_u_88("sendMessage", v_u_220:FindFirstChild(v_u_221.FunTarget).UserId, v_u_221.MessageSpammerText)
				end
				task.wait()
			end
		end
		function MESSAGENUKE()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223, (ref) v_u_88
			while v_u_221.MessageNuke == true do
				local v596 = v_u_220
				local v597, v598, v599 = pairs(v596:GetChildren())
				while true do
					local v600
					v599, v600 = v597(v598, v599)
					if v599 == nil then
						break
					end
					if v600 ~= v_u_223 then
						v_u_88("sendMessage", v600.UserId, v_u_221.MessageSpammerText)
					end
				end
				task.wait()
			end
		end
		v139:Textbox("轰炸信息", "Textbox", "B赞搜索灾难蛋购买脚本!", function(p601)
			-- upvalues: (ref) v_u_221
			v_u_221.MessageSpammerText = p601
		end)
		v139:Toggle("手机信息轰炸(个人)", "EspToggle", false, function(p602)
			-- upvalues: (ref) v_u_221
			v_u_221.MessageSpammer = p602
			MessageSpammer()
		end)
		v139:Toggle("手机信息轰炸(全体)", "EspToggle", false, function(p603)
			-- upvalues: (ref) v_u_221
			v_u_221.MessageNuke = p603
			MESSAGENUKE()
		end)
		function PhoneSpammer()
			-- upvalues: (ref) v_u_221, (ref) v_u_89, (ref) v_u_220
			while v_u_221.PhoneSpammer == true do
				pcall(function()
					-- upvalues: (ref) v_u_89, (ref) v_u_220, (ref) v_u_221
					v_u_89("attemptCall", v_u_220:FindFirstChild(v_u_221.FunTarget).UserId)
				end)
				task.wait()
			end
		end
		v139:Toggle("电话骚扰", "EspToggle", false, function(p604)
			-- upvalues: (ref) v_u_221
			v_u_221.PhoneSpammer = p604
			PhoneSpammer()
		end)
		function ChangeAnimate()
			-- upvalues: (ref) v_u_221, (ref) v_u_223
			while v_u_221.ChangeAnimate == true do
				pcall(function()
					-- upvalues: (ref) v_u_221, (ref) v_u_223
					if v_u_221.AnimateSelect ~= "宇航员" then
						if v_u_221.AnimateSelect ~= "卡通" then
							if v_u_221.AnimateSelect ~= "开心" then
								if v_u_221.AnimateSelect ~= "长老" then
									if v_u_221.AnimateSelect ~= "悬空人" then
										if v_u_221.AnimateSelect ~= "骑士" then
											if v_u_221.AnimateSelect ~= "忍者" then
												if v_u_221.AnimateSelect ~= "大法师" then
													if v_u_221.AnimateSelect ~= "机器人" then
														if v_u_221.AnimateSelect ~= "海盗" then
															if v_u_221.AnimateSelect ~= "超级英雄" then
																if v_u_221.AnimateSelect ~= "优雅" then
																	if v_u_221.AnimateSelect ~= "吸血鬼" then
																		if v_u_221.AnimateSelect ~= "玩具人" then
																			if v_u_221.AnimateSelect ~= "僵尸" then
																				if v_u_221.AnimateSelect ~= "狼人" then
																					if v_u_221.AnimateSelect ~= "自信人" then
																						if v_u_221.AnimateSelect ~= "巡逻警察" then
																							if v_u_221.AnimateSelect ~= "牛仔" then
																								if v_u_221.AnimateSelect ~= "明星" then
																									if v_u_221.AnimateSelect ~= "小偷" then
																										if v_u_221.AnimateSelect ~= "幽灵" then
																											if v_u_221.AnimateSelect ~= "国王" then
																												if v_u_221.AnimateSelect == "无" then
																													local v605 = v_u_223.Character
																													local v606 = v605 and v605.Animate
																													if v606 then
																														v606.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=0"
																														v606.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=0"
																														v606.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=0"
																														v606.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=0"
																														v606.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=0"
																														v606.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=0"
																														v606.swimidle.SwimIdle.AnimationId = "http://www.roblox.com/asset/?id=0"
																														v606.swim.Swim.AnimationId = "http://www.roblox.com/asset/?id=0"
																													end
																												end
																											else
																												local v607 = v_u_223.Character
																												local v608 = v607 and v607.Animate
																												if v608 then
																													v608.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=941003647"
																													v608.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=941013098"
																													v608.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=941028902"
																													v608.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=941015281"
																													v608.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=941008832"
																													v608.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=940996062"
																													v608.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=941000007"
																												end
																											end
																										else
																											local v609 = v_u_223.Character
																											local v610 = v609 and v609.Animate
																											if v610 then
																												v610.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=616006778"
																												v610.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=616008087"
																												v610.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=616013216"
																												v610.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=616013216"
																												v610.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=616008936"
																												v610.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=616005863"
																												v610.swimidle.SwimIdle.AnimationId = "http://www.roblox.com/asset/?id=616012453"
																												v610.swim.Swim.AnimationId = "http://www.roblox.com/asset/?id=616011509"
																											end
																										end
																									else
																										local v611 = v_u_223.Character
																										local v612 = v611 and v611.Animate
																										if v612 then
																											v612.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=1132473842"
																											v612.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=1132477671"
																											v612.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=1132510133"
																											v612.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=1132494274"
																											v612.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=1132489853"
																											v612.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=1132461372"
																											v612.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=1132469004"
																										end
																									end
																								else
																									local v613 = v_u_223.Character
																									local v614 = v613 and v613.Animate
																									if v614 then
																										v614.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=1212900985"
																										v614.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=1150842221"
																										v614.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=1212980338"
																										v614.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=1212980348"
																										v614.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=1212954642"
																										v614.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=1213044953"
																										v614.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=1212900995"
																									end
																								end
																							else
																								local v615 = v_u_223.Character
																								local v616 = v615 and v615.Animate
																								if v616 then
																									v616.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=1014390418"
																									v616.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=1014398616"
																									v616.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=1014421541"
																									v616.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=1014401683"
																									v616.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=1014394726"
																									v616.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=1014380606"
																									v616.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=1014384571"
																								end
																							end
																						else
																							local v617 = v_u_223.Character
																							local v618 = v617 and v617.Animate
																							if v618 then
																								v618.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=1149612882"
																								v618.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=1150842221"
																								v618.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=1151231493"
																								v618.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=1150967949"
																								v618.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=1148811837"
																								v618.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=1148811837"
																								v618.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=1148863382"
																							end
																						end
																					else
																						local v619 = v_u_223.Character
																						local v620 = v619 and v619.Animate
																						if v620 then
																							v620.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=1069977950"
																							v620.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=1069987858"
																							v620.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=1070017263"
																							v620.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=1070001516"
																							v620.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=1069984524"
																							v620.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=1069946257"
																							v620.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=1069973677"
																						end
																					end
																				else
																					local v621 = v_u_223.Character
																					local v622 = v621 and v621.Animate
																					if v622 then
																						v622.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=1083195517"
																						v622.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=1083214717"
																						v622.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=1083178339"
																						v622.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=1083216690"
																						v622.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=1083218792"
																						v622.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=1083182000"
																						v622.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=1083189019"
																					end
																				end
																			else
																				local v623 = v_u_223.Character
																				local v624 = v623 and v623.Animate
																				if v624 then
																					v624.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=616158929"
																					v624.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=616160636"
																					v624.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=616168032"
																					v624.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=616163682"
																					v624.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=616161997"
																					v624.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=616156119"
																					v624.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=616157476"
																				end
																			end
																		else
																			local v625 = v_u_223.Character
																			local v626 = v625 and v625.Animate
																			if v626 then
																				v626.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=782841498"
																				v626.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=782845736"
																				v626.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=782843345"
																				v626.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=782842708"
																				v626.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=782847020"
																				v626.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=782843869"
																				v626.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=782846423"
																			end
																		end
																	else
																		local v627 = v_u_223.Character
																		local v628 = v627 and v627.Animate
																		if v628 then
																			v628.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=1083445855"
																			v628.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=1083450166"
																			v628.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=1083473930"
																			v628.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=1083462077"
																			v628.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=1083455352"
																			v628.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=1083439238"
																			v628.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=1083443587"
																		end
																	end
																else
																	local v629 = v_u_223.Character
																	local v630 = v629 and v629.Animate
																	if v630 then
																		v630.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=616136790"
																		v630.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=616138447"
																		v630.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=616146177"
																		v630.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=616140816"
																		v630.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=616139451"
																		v630.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=616133594"
																		v630.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=616134815"
																	end
																end
															else
																local v631 = v_u_223.Character
																local v632 = v631 and v631.Animate
																if v632 then
																	v632.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=616111295"
																	v632.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=616113536"
																	v632.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=616122287"
																	v632.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=616117076"
																	v632.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=616115533"
																	v632.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=616104706"
																	v632.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=616108001"
																end
															end
														else
															local v633 = v_u_223.Character
															local v634 = v633 and v633.Animate
															if v634 then
																v634.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=750781874"
																v634.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=750782770"
																v634.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=750785693"
																v634.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=750783738"
																v634.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=750782230"
																v634.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=750779899"
																v634.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=750780242"
															end
														end
													else
														local v635 = v_u_223.Character
														local v636 = v635 and v635.Animate
														if v636 then
															v636.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=616088211"
															v636.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=616089559"
															v636.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=616095330"
															v636.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=616091570"
															v636.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=616090535"
															v636.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=616086039"
															v636.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=616087089"
														end
													end
												else
													local v637 = v_u_223.Character
													local v638 = v637 and v637.Animate
													if v638 then
														v638.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=707742142"
														v638.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=707855907"
														v638.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=707897309"
														v638.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=707861613"
														v638.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=707853694"
														v638.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=707826056"
														v638.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=707829716"
													end
												end
											else
												local v639 = v_u_223.Character
												local v640 = v639 and v639.Animate
												if v640 then
													v640.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=656117400"
													v640.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=656118341"
													v640.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=656121766"
													v640.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=656118852"
													v640.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=656117878"
													v640.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=656114359"
													v640.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=656115606"
												end
											end
										else
											local v641 = v_u_223.Character
											local v642 = v641 and v641.Animate
											if v642 then
												v642.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=657595757"
												v642.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=657568135"
												v642.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=657552124"
												v642.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=657564596"
												v642.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=658409194"
												v642.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=658360781"
												v642.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=657600338"
											end
										end
									else
										local v643 = v_u_223.Character
										local v644 = v643 and v643.Animate
										if v644 then
											v644.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=616006778"
											v644.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=616008087"
											v644.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=616013216"
											v644.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=616010382"
											v644.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=616008936"
											v644.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=616003713"
											v644.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=616005863"
										end
									end
								else
									local v645 = v_u_223.Character
									local v646 = v645 and v645.Animate
									if v646 then
										v646.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=845397899"
										v646.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=845400520"
										v646.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=845403856"
										v646.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=845386501"
										v646.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=845398858"
										v646.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=845392038"
										v646.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=845396048"
									end
								end
							else
								local v647 = v_u_223.Character
								local v648 = v647 and v647.Animate
								if v648 then
									v648.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=910004836"
									v648.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=910009958"
									v648.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=910034870"
									v648.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=910025107"
									v648.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=910016857"
									v648.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=910001910"
									v648.swimidle.SwimIdle.AnimationId = "http://www.roblox.com/asset/?id=910030921"
									v648.swim.Swim.AnimationId = "http://www.roblox.com/asset/?id=910028158"
								end
							end
						else
							local v649 = v_u_223.Character
							local v650 = v649 and v649.Animate
							if v650 then
								v650.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=742637544"
								v650.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=742638445"
								v650.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=742640026"
								v650.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=742638842"
								v650.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=742637942"
								v650.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=742636889"
								v650.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=742637151"
							end
						end
					else
						local v651 = v_u_223.Character and v_u_223.Character.Animate
						if v651 then
							v651.idle.Animation1.AnimationId = "http://www.roblox.com/asset/?id=891621366"
							v651.idle.Animation2.AnimationId = "http://www.roblox.com/asset/?id=891633237"
							v651.walk.WalkAnim.AnimationId = "http://www.roblox.com/asset/?id=891667138"
							v651.run.RunAnim.AnimationId = "http://www.roblox.com/asset/?id=891636393"
							v651.jump.JumpAnim.AnimationId = "http://www.roblox.com/asset/?id=891627522"
							v651.climb.ClimbAnim.AnimationId = "http://www.roblox.com/asset/?id=891609353"
							v651.fall.FallAnim.AnimationId = "http://www.roblox.com/asset/?id=891617961"
						end
					end
				end)
				task.wait()
			end
		end
		v139:Dropdown("选择修改的动作包", "sb", {
			"宇航员",
			"卡通",
			"开心",
			"长老",
			"悬空人",
			"骑士",
			"忍者",
			"大法师",
			"机器人",
			"海盗",
			"超级英雄",
			"优雅",
			"吸血鬼",
			"玩具人",
			"僵尸",
			"狼人",
			"自信人",
			"巡逻警察",
			"牛仔",
			"明星",
			"小偷",
			"幽灵",
			"国王",
			"无"
		}, function(p652)
			-- upvalues: (ref) v_u_221
			v_u_221.AnimateSelect = p652
		end)
		v139:Toggle("修改动画开关", "EspToggle", false, function(p653)
			-- upvalues: (ref) v_u_221
			v_u_221.ChangeAnimate = p653
			ChangeAnimate()
		end)
		local v654 = require(v90).data.shadowbannedExpires
		local v655 = require(v90).data.shadowbannedAt
		local v656 = require(v90).data.shadowbanned
		local v657 = require(v90).data.numshadowbans
		local v658 = not v654 and "无" or os.date("%Y-%m-%d %H:%M:%S", v654)
		local v659 = not v655 and "无" or os.date("%Y-%m-%d %H:%M:%S", v655)
		local v660 = not (v654 and v655) and 0 or getTimeString(v654 - v655)
		v141:Label("当前钱数 " .. require(v90).data.money)
		v141:Label("历史总钱数 " .. require(v90).data.totalMoneyEarned)
		v141:Label("当前Robux花费 " .. require(v90).data.robuxSpent)
		v141:Label("ATM抢劫金钱 " .. require(v90).data.atmsRobbed)
		v141:Label("宝石抢劫金钱 " .. require(v90).data.gemsRobbed)
		v141:Label("历史最高连续登陆 " .. require(v90).data.topLoginStreak)
		v141:Label("工作赚钱金钱 " .. require(v90).data.jobEarnings)
		v142:Label("封禁结束期 " .. v658)
		v142:Label("封禁开始期 " .. v659)
		v142:Label("剩余封禁时间 " .. v660)
		v142:Label("历史封禁次数 " .. (v657 or 0))
		v142:Label("封禁原因 " .. (v656 or "无"))
		v144:Toggle("透视开关", "EspToggle", false, function(p661)
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223
			v_u_221.EspToggle = p661
			if p661 == false then
				local v662 = v_u_220
				local v663, v664, v665 = pairs(v662:GetChildren())
				while true do
					local v666
					v665, v666 = v663(v664, v665)
					if v665 == nil then
						break
					end
					if v666 ~= v_u_223 then
						UpdateEsp(v666.Name, v_u_221.SelectFillColor)
					end
				end
			end
		end)
		v144:Toggle("上色开关", "HighlightToggle", false, function(p667)
			-- upvalues: (ref) v_u_221
			v_u_221.HighlightToggle = p667
		end)
		v145:Dropdown("透视颜色", "SelectFillColor", {
			"红",
			"绿",
			"蓝",
			"粉",
			"青"
		}, function(p668)
			-- upvalues: (ref) v_u_221, (ref) v_u_106
			if p668 == "红" then
				v_u_221.SelectFillColor = v_u_106.Red
			elseif p668 == "绿" then
				v_u_221.SelectFillColor = v_u_106.Green
			elseif p668 == "蓝" then
				v_u_221.SelectFillColor = v_u_106.Blue
			elseif p668 == "粉" then
				v_u_221.SelectFillColor = v_u_106.Pink
			elseif p668 == "青" then
				v_u_221.SelectFillColor = v_u_106.Cyan
			end
		end)
		v145:Toggle("显示用户名", "HighlightToggle", false, function(p669)
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223
			v_u_221.EspName = p669
			if p669 == false then
				local v670 = v_u_220
				local v671, v672, v673 = pairs(v670:GetChildren())
				while true do
					local v674
					v673, v674 = v671(v672, v673)
					if v673 == nil then
						break
					end
					if v674 ~= v_u_223 then
						UpdateEsp(v674.Name, v_u_221.SelectFillColor)
					end
				end
			end
		end)
		v145:Toggle("透视金钱", "HighlightToggle", false, function(p675)
			-- upvalues: (ref) v_u_221, (ref) v_u_76, (ref) v_u_106
			v_u_221.EspMoneys = p675
			if p675 == false then
				local v676 = v_u_76
				local v677, v678, v679 = pairs(v676:GetChildren())
				while true do
					local v680
					v679, v680 = v677(v678, v679)
					if v679 == nil then
						break
					end
					if v680:FindFirstChildOfClass("Part") then
						MoneyUpdateEsp(v680:FindFirstChildOfClass("IntValue").Value, v680:FindFirstChildOfClass("Part"), v_u_106.Green)
					end
				end
			end
		end)
		v145:Toggle("透视物品", "HighlightToggle", false, function(p681)
			-- upvalues: (ref) v_u_221, (ref) v_u_77, (ref) v_u_106
			v_u_221.EspItems = p681
			if p681 == false then
				local v682 = v_u_77
				local v683, v684, v685 = pairs(v682:GetChildren())
				while true do
					local v686
					v685, v686 = v683(v684, v685)
					if v685 == nil then
						break
					end
					if v686:FindFirstChildOfClass("Part") then
						ItemUpdateEsp(v686:FindFirstChildOfClass("Part"):FindFirstChildOfClass("ProximityPrompt").ObjectText, v686:FindFirstChildOfClass("Part"), v_u_106.Red)
					end
				end
			end
		end)
		v145:Slider("透视大小", "FillTransparency", 0.5, 0.1, 1, true, function(p687)
			-- upvalues: (ref) v_u_221
			v_u_221.EspScale = p687
		end)
		v145:Slider("上色透明度", "FillTransparency", 0.5, 0, 1, true, function(p688)
			-- upvalues: (ref) v_u_221
			v_u_221.HighlightTransparency = p688
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_221, (ref) v_u_76, (ref) v_u_106
			while _G.ScriptIsRunning == true do
				pcall(function()
					-- upvalues: (ref) v_u_221, (ref) v_u_76, (ref) v_u_106
					if v_u_221.EspToggle == true and v_u_221.EspMoneys == true then
						local v689 = v_u_76
						local v690, v691, v692 = pairs(v689:GetChildren())
						while true do
							local v693
							v692, v693 = v690(v691, v692)
							if v692 == nil then
								break
							end
							if v693:FindFirstChildOfClass("Part") then
								MoneyUpdateEsp(v693:FindFirstChildOfClass("IntValue").Value, v693:FindFirstChildOfClass("Part"), v_u_106.Green)
							end
						end
					end
				end)
				task.wait()
			end
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_221, (ref) v_u_77, (ref) v_u_106
			while _G.ScriptIsRunning == true do
				pcall(function()
					-- upvalues: (ref) v_u_221, (ref) v_u_77, (ref) v_u_106
					if v_u_221.EspToggle == true and v_u_221.EspItems == true then
						local v694 = v_u_77
						local v695, v696, v697 = pairs(v694:GetChildren())
						while true do
							local v698
							v697, v698 = v695(v696, v697)
							if v697 == nil then
								break
							end
							if v698:FindFirstChildOfClass("Part") then
								ItemUpdateEsp(v698:FindFirstChildOfClass("Part"):FindFirstChildOfClass("ProximityPrompt").ObjectText, v698:FindFirstChildOfClass("Part"), v_u_106.Red)
							end
						end
					end
				end)
				task.wait()
			end
		end)
		task.spawn(function()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223
			while _G.ScriptIsRunning == true do
				pcall(function()
					-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223
					if v_u_221.EspToggle == true and v_u_221.EspName == true then
						local v699 = v_u_220
						local v700, v701, v702 = pairs(v699:GetChildren())
						while true do
							local v703
							v702, v703 = v700(v701, v702)
							if v702 == nil then
								break
							end
							if v703.Name ~= v_u_223.Name then
								UpdateEsp(v703.Name, v_u_221.SelectFillColor)
							end
						end
					end
				end)
				task.wait()
			end
		end)
		local v_u_705 = v146:Dropdown("玩家列表", "Players", v_u_224, function(p704)
			-- upvalues: (ref) v_u_221
			v_u_221.SelectPlr = p704
		end)
		v_u_220.PlayerAdded:Connect(function(p706)
			-- upvalues: (ref) v_u_224, (ref) v_u_705, (ref) v_u_238, (ref) v_u_595
			table.insert(v_u_224, p706.Name)
			v_u_705.AddOption(p706.Name)
			v_u_238.AddOption(p706.Name)
			v_u_595.AddOption(p706.Name)
		end)
		v_u_220.PlayerRemoving:Connect(function(p707)
			-- upvalues: (ref) v_u_224, (ref) v_u_705, (ref) v_u_238, (ref) v_u_595
			table.remove(v_u_224, table.find(v_u_224, p707.Name))
			v_u_705.RemoveOption(p707.Name)
			v_u_238.RemoveOption(p707.Name)
			v_u_595.RemoveOption(p707.Name)
		end)
		v146:Button("传送到选中的玩家", function()
			-- upvalues: (ref) v_u_223, (ref) v_u_220, (ref) v_u_221
			pcall(function()
				-- upvalues: (ref) v_u_223, (ref) v_u_220, (ref) v_u_221
				local v708 = v_u_220
				v_u_223.Character.HumanoidRootPart.CFrame = v708:FindFirstChild(v_u_221.SelectPlr).Character.HumanoidRootPart.CFrame
			end)
		end)
		function PredTeleport()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223
			while v_u_221.PredTeleport == true do
				pcall(function()
					-- upvalues: (ref) v_u_220, (ref) v_u_221, (ref) v_u_223
					if v_u_220:FindFirstChild(v_u_221.SelectPlr).Character.Humanoid.Health ~= 0 then
						local v709 = v_u_220
						local v710 = v_u_223
						local v711 = v_u_220:FindFirstChild(v_u_221.SelectPlr).Character.HumanoidRootPart.CFrame + v709:FindFirstChild(v_u_221.SelectPlr).Character.HumanoidRootPart.Velocity * (v710:GetNetworkPing() * 2) * v_u_221.PredValue
						v_u_223.Character.HumanoidRootPart.CFrame = v711
					end
				end)
				task.wait()
			end
		end
		v146:Toggle("循环预判传送", "Snipe", false, function(p712)
			-- upvalues: (ref) v_u_221
			v_u_221.PredTeleport = p712
			PredTeleport()
		end)
		v146:Slider("预判传送倍数", "FillTransparency", 2, 0.1, 300, true, function(p713)
			-- upvalues: (ref) v_u_221
			v_u_221.PredValue = p713
		end)
		function SnipePlr()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223
			while v_u_221.SnipePlr == true do
				pcall(function()
					-- upvalues: (ref) v_u_220, (ref) v_u_221, (ref) v_u_223
					if v_u_220:FindFirstChild(v_u_221.SelectPlr).Character.Humanoid.Health ~= 0 then
						local v714 = v_u_220
						local v715 = v_u_220
						v_u_223.Character.HumanoidRootPart.CFrame = v714:FindFirstChild(v_u_221.SelectPlr).Character.HumanoidRootPart.CFrame - v715:FindFirstChild(v_u_221.SelectPlr).Character.HumanoidRootPart.CFrame.LookVector * v_u_221.BringPlayerDistance
					end
				end)
				task.wait()
			end
		end
		v146:Toggle("循环传送到玩家身后", "Snipe", false, function(p716)
			-- upvalues: (ref) v_u_221
			v_u_221.SnipePlr = p716
			SnipePlr()
		end)
		function SnipeToHeadLookVector()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223
			while v_u_221.SnipeToHeadLookVector == true do
				pcall(function()
					-- upvalues: (ref) v_u_220, (ref) v_u_221, (ref) v_u_223
					if v_u_220:FindFirstChild(v_u_221.SelectPlr).Character.Humanoid.Health ~= 0 then
						if v_u_220:FindFirstChild(v_u_221.SelectPlr).Character.Humanoid.SeatPart then
							v_u_220:FindFirstChild(v_u_221.SelectPlr).Character.Humanoid.SeatPart.CFrame = v_u_223.Character.Head.CFrame + v_u_223.Character.Head.CFrame.LookVector * v_u_221.BringPlayerDistance
						else
							v_u_220:FindFirstChild(v_u_221.SelectPlr).Character.HumanoidRootPart.CFrame = v_u_223.Character.Head.CFrame + v_u_223.Character.Head.CFrame.LookVector * v_u_221.BringPlayerDistance
						end
					end
				end)
				task.wait()
			end
		end
		v146:Toggle("吸选中的玩家", "Snipe", false, function(p717)
			-- upvalues: (ref) v_u_221
			v_u_221.SnipeToHeadLookVector = p717
			SnipeToHeadLookVector()
		end)
		function SnipeAllPlrs()
			-- upvalues: (ref) v_u_221, (ref) v_u_220, (ref) v_u_223
			while v_u_221.SnipeAllPlrs == true do
				pcall(function()
					-- upvalues: (ref) v_u_220, (ref) v_u_221, (ref) v_u_223
					local v718 = v_u_220
					local v719, v720, v721 = pairs(v718:GetChildren())
					while true do
						local v722
						v721, v722 = v719(v720, v721)
						if v721 == nil then
							break
						end
						if v_u_221.SnipeAllPlrs == false then
							return
						end
						if v722 ~= v_u_223 and (v722.Character ~= nil and v722.Character.Humanoid.Health ~= 0) then
							v722.Character.HumanoidRootPart.CFrame = v_u_223.Character.Head.CFrame + v_u_223.Character.Head.CFrame.LookVector * v_u_221.BringPlayerDistance
						end
					end
				end)
				task.wait()
			end
		end
		v146:Toggle("吸全体玩家", "Snipe", false, function(p723)
			-- upvalues: (ref) v_u_221
			v_u_221.SnipeAllPlrs = p723
			SnipeAllPlrs()
		end)
		v146:Slider("距离", "FillTransparency", 6, 0, 20, true, function(p724)
			-- upvalues: (ref) v_u_221
			v_u_221.BringPlayerDistance = p724
		end)
		local v_u_725 = {
			["Tpwalk"] = 0
		}
		local v_u_726 = nil
		v_u_726 = game:GetService("RunService").RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_726, (ref) v_u_223, (ref) v_u_725
			if _G.ScriptIsRunning == false then
				v_u_726:Disconnect()
			end
			pcall(function()
				-- upvalues: (ref) v_u_223, (ref) v_u_725
				if v_u_223.Character.Humanoid.MoveDirection.Magnitude > 0 then
					v_u_223.Character:TranslateBy(v_u_223.Character.Humanoid.MoveDirection * v_u_725.Tpwalk / 10)
				end
			end)
		end)
		v148:Slider("移动速度", "Slider", 0, 0, 300, true, function(p727)
			-- upvalues: (ref) v_u_725
			v_u_725.Tpwalk = p727
		end)
		function NoclipFunc()
			-- upvalues: (ref) v_u_221, (ref) v_u_223
			while v_u_221.Noclip == true do
				pcall(function()
					-- upvalues: (ref) v_u_223
					local v728, v729, v730 = pairs(v_u_223.Character:GetChildren())
					while true do
						local v731
						v730, v731 = v728(v729, v730)
						if v730 == nil then
							break
						end
						if v731:IsA("BasePart") then
							v731.CanCollide = false
						end
					end
				end)
				task.wait()
			end
		end
		v148:Toggle("穿墙", "Noclip", false, function(p732)
			-- upvalues: (ref) v_u_221, (ref) v_u_223
			v_u_221.Noclip = p732
			if p732 == false then
				pcall(function()
					-- upvalues: (ref) v_u_223
					local v733, v734, v735 = pairs(v_u_223.Character:GetChildren())
					while true do
						local v736
						v735, v736 = v733(v734, v735)
						if v735 == nil then
							break
						end
						if v736:IsA("BasePart") and (v736.Name == "Head" or (v736.Name == "Torso" or (v736.Name == "UpperTorso" or v736.Name == "LowerTorso"))) then
							v736.CanCollide = true
						end
					end
				end)
			end
			NoclipFunc()
		end)
		v149:Toggle("显示聊天框", "InfJump", false, function(p737)
			-- upvalues: (ref) v_u_68
			v_u_68.Chat.Frame.ChatChannelParentFrame.Visible = p737
			v_u_68.Chat.Frame.ChatChannelParentFrame.Selectable = p737
			v_u_68.Chat.Frame.ChatBarParentFrame.Position = v_u_68.Chat.Frame.ChatChannelParentFrame.Position + UDim2.new(UDim.new(), v_u_68.Chat.Frame.ChatChannelParentFrame.Size.Y)
		end)
		v148:Toggle("无限跳", "InfJump", false, function(p738)
			-- upvalues: (ref) v_u_221
			v_u_221.InfJump = p738
		end)
		game:GetService("UserInputService").JumpRequest:Connect(function()
			-- upvalues: (ref) v_u_221, (ref) v_u_223
			if v_u_221.InfJump == true then
				v_u_223.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
			end
		end)
		function FlyFunc()
			-- upvalues: (ref) v_u_221, (ref) v_u_69, (ref) v_u_223, (ref) v_u_65
			while v_u_221.Fly == true do
				pcall(function()
					-- upvalues: (ref) v_u_69, (ref) v_u_223, (ref) v_u_65
					v_u_69.Gravity = 0
					local v739 = v_u_223.Character:FindFirstChild("Humanoid")
					local v740 = Enum.HumanoidStateType:GetEnumItems()
					table.remove(v740, table.find(v740, Enum.HumanoidStateType.None))
					local v741, v742, v743 = pairs(v740)
					while true do
						local v744
						v743, v744 = v741(v742, v743)
						if v743 == nil then
							break
						end
						v739:SetStateEnabled(v744, false)
					end
					v739:ChangeState(Enum.HumanoidStateType.Swimming)
					v_u_223.Character.HumanoidRootPart.Velocity = (v739.MoveDirection ~= Vector3.new() or v_u_65:IsKeyDown(Enum.KeyCode.Space)) and v_u_223.Character.HumanoidRootPart.Velocity or Vector3.new()
				end)
				task.wait()
			end
		end
		local v_u_745 = v_u_69.Gravity
		v148:Toggle("飞行", "Fly", false, function(p746)
			-- upvalues: (ref) v_u_221, (ref) v_u_69, (ref) v_u_745, (ref) v_u_223
			v_u_221.Fly = p746
			if p746 == false then
				v_u_69.Gravity = v_u_745
				local v747 = v_u_223.Character:FindFirstChild("Humanoid")
				local v748 = Enum.HumanoidStateType:GetEnumItems()
				local v749, v750, v751 = pairs(v748)
				while true do
					local v752
					v751, v752 = v749(v750, v751)
					if v751 == nil then
						break
					end
					v747:SetStateEnabled(v752, true)
				end
			end
			FlyFunc()
		end)
		function Fling()
			-- upvalues: (ref) v_u_221, (ref) v_u_67, (ref) v_u_223
			if v_u_221.Fling == true then
				repeat
					v_u_67.Heartbeat:Wait()
					pcall(function()
						-- upvalues: (ref) v_u_223, (ref) v_u_67
						local v753 = v_u_223.Character
						local v754 = v753.HumanoidRootPart
						local v755 = 0.1
						while not (v753 and (v753.Parent and (v754 and v754.Parent))) do
							v_u_67.Heartbeat:Wait()
							v753 = v_u_223.Character
							v754 = v753.HumanoidRootPart
						end
						local v756 = v754.Velocity
						v754.Velocity = v756 * 1000000 + Vector3.new(0, 1000000, 0)
						v_u_67.RenderStepped:Wait()
						if v753 and (v753.Parent and (v754 and v754.Parent)) then
							v754.Velocity = v756
						end
						v_u_67.Stepped:Wait()
						if v753 and (v753.Parent and (v754 and v754.Parent)) then
							v754.Velocity = v756 + Vector3.new(0, v755, 0)
							local _ = v755 * -1
						end
					end)
				until v_u_221.Fling ~= true
			end
		end
		v148:Toggle("撞飞", "Fling", false, function(p757)
			-- upvalues: (ref) v_u_221
			v_u_221.Fling = p757
			Fling()
		end)
		local v_u_758 = {
			["DefFOV"] = v_u_216.FieldOfView,
			["DefCameraMaxZoomDistance"] = v_u_223.CameraMaxZoomDistance,
			["DefCameraMinZoomDistance"] = v_u_223.CameraMinZoomDistance,
			["FieldOfView"] = 70,
			["FieldOfViewToggle"] = false,
			["CameraMaxZoomDistance"] = 128,
			["CameraMaxZoomDistanceToggle"] = false,
			["CameraMinZoomDistance"] = 0.5,
			["CameraMinZoomDistanceToggle"] = false,
			["FullBright"] = false,
			["DefAmbient"] = v_u_214.Ambient
		}
		local function v_u_759()
			-- upvalues: (ref) v_u_758, (ref) v_u_216, (ref) v_u_150
			while v_u_758.FieldOfViewToggle == true do
				v_u_216.FieldOfView = v_u_150.FieldOfView
				task.wait()
			end
		end
		local function v_u_760()
			-- upvalues: (ref) v_u_758, (ref) v_u_223, (ref) v_u_150
			while v_u_758.CameraMaxZoomDistanceToggle == true do
				v_u_223.CameraMaxZoomDistance = v_u_150.CameraMaxZoomDistance
				task.wait()
			end
		end
		local function v_u_761()
			-- upvalues: (ref) v_u_758, (ref) v_u_223
			while v_u_758.CameraMinZoomDistanceToggle == true do
				v_u_223.CameraMinZoomDistance = v_u_758.CameraMinZoomDistance
				task.wait()
			end
		end
		v_u_150:Slider("FOV", "FOV", 70, 1, 120, true, function(p762)
			-- upvalues: (ref) v_u_150
			v_u_150.FieldOfView = p762
		end)
		v_u_150:Toggle("FOV开关", "FOVToggle", false, function(p763)
			-- upvalues: (ref) v_u_758, (ref) v_u_216, (ref) v_u_759
			v_u_758.FieldOfViewToggle = p763
			if p763 == false then
				v_u_216.FieldOfView = v_u_758.DefFOV
			else
				v_u_759()
			end
		end)
		v_u_150:Slider("最大相机聚焦距离", "CameraMaxZoomDistance", 128, 1, 1200, true, function(p764)
			-- upvalues: (ref) v_u_150
			v_u_150.CameraMaxZoomDistance = p764
		end)
		v_u_150:Toggle("最大相机聚焦距离开关", "CameraMaxZoomDistanceToggle", false, function(p765)
			-- upvalues: (ref) v_u_758, (ref) v_u_223, (ref) v_u_150, (ref) v_u_760
			v_u_758.CameraMaxZoomDistanceToggle = p765
			if p765 == false then
				v_u_223.CameraMaxZoomDistance = v_u_150.DefCameraMaxZoomDistance
			else
				v_u_760()
			end
		end)
		v_u_150:Slider("最小相机聚焦距离", "Slider", 0.5, 1, 50, true, function(p766)
			-- upvalues: (ref) v_u_150
			v_u_150.CameraMinZoomDistance = p766
		end)
		v_u_150:Toggle("最小相机聚焦距离开关", "CameraMinZoomDistanceToggle", false, function(p767)
			-- upvalues: (ref) v_u_758, (ref) v_u_223, (ref) v_u_761
			v_u_758.CameraMinZoomDistanceToggle = p767
			if p767 == false then
				v_u_223.CameraMinZoomDistance = v_u_758.DefCameraMinZoomDistance
			else
				v_u_761()
			end
		end)
		local function v_u_768()
			-- upvalues: (ref) v_u_725, (ref) v_u_214
			while v_u_725.FullBright == true do
				pcall(function()
					-- upvalues: (ref) v_u_214
					v_u_214.Ambient = Color3.new(1, 1, 1)
				end)
				task.wait()
			end
		end
		v_u_150:Toggle("全局高亮", "FullBright", false, function(p769)
			-- upvalues: (ref) v_u_758, (ref) v_u_214, (ref) v_u_768
			v_u_758.FullBright = p769
			if p769 == false then
				v_u_214.Ambient = v_u_758.DefAmbient
			end
			v_u_768()
		end)
		local v_u_770 = {
			["Bk"] = nil,
			["Dn"] = nil,
			["Ft"] = nil,
			["Lf"] = nil,
			["Rt"] = nil,
			["Up"] = nil
		}
		v151:Dropdown("天空盒", "Skybox", { "cs_办公室", "Always.win", "Advanced Logic" }, function(p771)
			if p771 == "cs_办公室" then
				SpawnSkybox({
					["Name"] = "cs_office",
					["Bk"] = "rbxassetid://658623433",
					["Dn"] = "rbxassetid://316342560",
					["Ft"] = "rbxassetid://658625205",
					["Lf"] = "rbxassetid://658627155",
					["Rt"] = "rbxassetid://658628504",
					["Up"] = "rbxassetid://658632701"
				})
			elseif p771 == "Always.win" then
				SpawnSkybox({
					["Name"] = "Always.win",
					["Bk"] = "rbxassetid://17411013742",
					["Dn"] = "rbxassetid://17411013742",
					["Ft"] = "rbxassetid://17411013742",
					["Lf"] = "rbxassetid://17411013742",
					["Rt"] = "rbxassetid://17411013742",
					["Up"] = "rbxassetid://17411013742"
				})
			elseif p771 == "Advanced Logic" then
				SpawnSkybox({
					["Name"] = "Advanced Logic",
					["Bk"] = "rbxassetid://17803761395",
					["Dn"] = "rbxassetid://17803761395",
					["Ft"] = "rbxassetid://17803761395",
					["Lf"] = "rbxassetid://17803761395",
					["Rt"] = "rbxassetid://17803761395",
					["Up"] = "rbxassetid://17803761395",
					["SunAsset"] = "rbxassetid://17768924741",
					["SunAngularSize"] = 50
				})
			end
		end)
		v151:Textbox("自定义天空盒Bk", "Textbox", "请输入SkyboxBk贴图ID", function(p_u_772)
			-- upvalues: (ref) v_u_770
			pcall(function()
				-- upvalues: (ref) p_u_772, (ref) v_u_770
				if p_u_772:find("rbx") then
					v_u_770.Bk = p_u_772
				else
					v_u_770.Bk = "rbxassetid://" .. p_u_772
				end
			end)
		end)
		v151:Textbox("自定义天空盒Dn", "Textbox", "请输入SkyboxDn贴图ID", function(p_u_773)
			-- upvalues: (ref) v_u_770
			pcall(function()
				-- upvalues: (ref) p_u_773, (ref) v_u_770
				if p_u_773:find("rbx") then
					v_u_770.Dn = p_u_773
				else
					v_u_770.Dn = "rbxassetid://" .. p_u_773
				end
			end)
		end)
		v151:Textbox("自定义天空盒Ft", "Textbox", "请输入SkyboxFt贴图ID", function(p_u_774)
			-- upvalues: (ref) v_u_770
			pcall(function()
				-- upvalues: (ref) p_u_774, (ref) v_u_770
				if p_u_774:find("rbx") then
					v_u_770.Ft = p_u_774
				else
					v_u_770.Ft = "rbxassetid://" .. p_u_774
				end
			end)
		end)
		v151:Textbox("自定义天空盒Lf", "Textbox", "请输入SkyboxLf贴图ID", function(p_u_775)
			-- upvalues: (ref) v_u_770
			pcall(function()
				-- upvalues: (ref) p_u_775, (ref) v_u_770
				if p_u_775:find("rbx") then
					v_u_770.Lf = p_u_775
				else
					v_u_770.Lf = "rbxassetid://" .. p_u_775
				end
			end)
		end)
		v151:Textbox("自定义天空盒Rt", "Textbox", "请输入SkyboxRt贴图ID", function(p_u_776)
			-- upvalues: (ref) v_u_770
			pcall(function()
				-- upvalues: (ref) p_u_776, (ref) v_u_770
				if p_u_776:find("rbx") then
					v_u_770.Rt = p_u_776
				else
					v_u_770.Rt = "rbxassetid://" .. p_u_776
				end
			end)
		end)
		v151:Textbox("自定义天空盒Up", "Textbox", "请输入SkyboxUp贴图ID", function(p_u_777)
			-- upvalues: (ref) v_u_770
			pcall(function()
				-- upvalues: (ref) p_u_777, (ref) v_u_770
				if p_u_777:find("rbx") then
					v_u_770.Up = p_u_777
				else
					v_u_770.Up = "rbxassetid://" .. p_u_777
				end
			end)
		end)
		v151:Button("修改自定义天空盒", function()
			-- upvalues: (ref) v_u_770
			pcall(function()
				-- upvalues: (ref) v_u_770
				SpawnSkybox({
					["Name"] = "我爱手冲",
					["Bk"] = v_u_770.Bk,
					["Dn"] = v_u_770.Dn,
					["Ft"] = v_u_770.Ft,
					["Lf"] = v_u_770.Lf,
					["Rt"] = v_u_770.Rt,
					["Up"] = v_u_770.Up
				})
			end)
		end)
		v153:Label("团队")
		v153:Label("Advanced Logic")
		v153:Label("群号: 684407929")
		v154:Label("当前版本 " .. v112)
		v_u_223.Idled:Connect(function()
			game:GetService("VirtualUser"):CaptureController()
			game:GetService("VirtualUser"):ClickButton2(Vector2.new())
		end)
		if game:GetService("TextChatService").ChatVersion == Enum.ChatVersion.LegacyChatService then
			rawset(require(v_u_223:FindFirstChild("PlayerScripts"):FindFirstChild("ChatScript").ChatMain), "MessagePosted", {
				["fire"] = function(p778)
					return p778
				end,
				["wait"] = function() end,
				["connect"] = function() end
			})
		end
	else
		game:GetService("Players").LocalPlayer:Kick("您不是白名单用户,请加入684407929(Adavanced Logic官方群)购买")
		setclipboard(game:GetService("RbxAnalyticsService"):GetClientId())
	end
else
	v28(v54)
	return
end
