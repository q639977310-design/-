local v_u_1 = http_request or request or (HttpPost or syn.request)
local v_u_2 = nil
local v_u_3 = 0
local function v_u_9(p4, p5, p6)
	-- upvalues: (ref) v_u_3, (ref) v_u_9
	v_u_3 = v_u_3 + 1
	if p6 then
		local v7 = v_u_9(p4, p5) and v_u_9(p4, p6)
		if v7 then
			v7 = v_u_9(p5, p6)
		end
		return v7
	else
		local v8 = type(p4) == typeof(p5) and (typeof(p4) == type(p5) and (type(p4) == typeof(p5) or typeof(p4) == type(p5))) and (#tostring(p4) == #tostring(p5) and rawequal(p4, p5))
		if v8 then
			if tostring(p4) < tostring(p5) or tostring(p4) > tostring(p5) then
				v8 = false
			else
				v8 = rawequal(tostring(p4), tostring(p5))
			end
		end
		return v8
	end
end
local function v_u_11(p10)
	return ({ ... })[p10]
end
local function v_u_18(p_u_12)
	-- upvalues: (ref) v_u_1, (ref) v_u_2, (ref) v_u_11
	local v_u_13 = false
	local v15 = {
		["__call"] = v_u_1,
		["__index"] = function(_, p14)
			-- upvalues: (ref) v_u_13, (ref) v_u_1, (ref) v_u_2, (ref) p_u_12
			v_u_13 = true
			if debug.info(2, "f") ~= v_u_1 then
				v_u_2 = "反钩子 [H - 1]"
				return "https://www.roblox.com/users/7207800972/profile"
			end
			if not coroutine.isyieldable() then
				return p_u_12[p14]
			end
			v_u_2 = "反钩子 [H - 2]"
			return "https://www.roblox.com/users/7207800972/profile"
		end
	}
	local v16 = setmetatable({}, v15)
	local v17 = v_u_11(2, pcall(v16))
	if v_u_13 then
		return v17
	end
end
local function v21(p19)
	-- upvalues: (ref) v_u_18
	local v20 = v_u_18({
		["Url"] = p19,
		["Method"] = "GET"
	})
	repeat
		task.wait()
	until v20
	return v20.Body
end
local function v23(p22)
	return string.split(p22 or "", ": ")[2]
end
local function v_u_26(p24, p25)
	-- upvalues: (ref) v_u_26
	if p24 == 0 then
		task.wait()
	end
	p25(...)
	v_u_26(p24 + 1, p25)
end
local function v28(p27)
	game:GetService("Players").LocalPlayer:Kick("")
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.TitleFrame.ErrorTitle.Text = "危险行为"
	game.CoreGui.RobloxPromptGui.promptOverlay.ErrorPrompt.MessageArea.ErrorFrame.ErrorMessage.Text = p27
	task.wait(1)
	game:Shutdown()
	task.wait(1)
	task.spawn(function()
		while true do

		end
	end)
end
local v29 = {
	v_u_26,
	v_u_11,
	pcall,
	debug.info,
	islclosure,
	debug.getinfo,
	debug.getfenv,
	0,
	{
		"Url",
		"Method",
		"Headers",
		"Cookies",
		"Body"
	},
	table.insert,
	v_u_2,
	v_u_1
}
local v30 = { math.random, v_u_11, v_u_18 }
local v31 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S1 - 1]"
	end
}
setmetatable(v29, v31)
local v32 = {
	["__index"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end,
	["__tostring"] = function()
		-- upvalues: (ref) v_u_2
		v_u_2 = "反钩子 [S2 - F1]"
	end
}
setmetatable(v30, v32)
local v33 = type(getrawmetatable(v29).__index) ~= "function" and "反篡改 [M - S1]" or v_u_2
v_u_3 = v_u_3 + 1
local v34 = type(getrawmetatable(v29).__tostring) ~= "function" and "反篡改 [M - S1]" or v33
v_u_3 = v_u_3 + 1
local v35 = (type(getrawmetatable(v30).__index) ~= "function" or type(getrawmetatable(v30).__index) ~= type(getmetatable(v30).__index)) and "反篡改 [M - S1]" or v34
v_u_3 = v_u_3 + 1
local v36 = type(getrawmetatable(v30).__tostring) ~= "function" and "反篡改 [M - S1]" or v35
v_u_3 = v_u_3 + 1
local v37, v38 = pcall(pcall)
local _, _ = pcall(math.random)
local _, _ = pcall(setmetatable)
local _, _ = pcall(string.split)
local _, _ = pcall(debug.traceback)
local _, _ = pcall(getmetatable)
local _, _ = pcall(coroutine.wrap)
local _, _ = pcall(table.insert)
local v39 = (v37 or v38 ~= "missing argument #1") and "反函数钩子 [P]" or v36
v_u_3 = v_u_3 + 1
local v40 = {
	math.abs,
	os.clock,
	coroutine.isyieldable,
	debug.info,
	v_u_1,
	game:GetService("Players").LocalPlayer.Kick,
	table.insert,
	bit32.bxor,
	debug.getfenv,
	setrawmetatable,
	pcall,
	math.random,
	setmetatable,
	string.split,
	debug.traceback,
	debug.info,
	getrawmetatable,
	type,
	table.insert,
	math.random,
	v_u_11,
	table.concat,
	string.byte,
	string.char,
	debug.getinfo,
	islclosure,
	string.reverse,
	v_u_18,
	getmetatable
}
local v41 = next
local v42 = v_u_18
local v43 = v_u_26
local v44 = v_u_9
local v45 = v_u_3
local v46 = v_u_11
local v47 = nil
while true do
	local v48
	v47, v48 = v41(v40, v47)
	if v47 == nil then
		break
	end
	for _ = 1, 197 do
		v48 = coroutine.wrap(v48)
	end
	if v46(2, pcall(v48)) == "C stack overflow" then
		v_u_2 = "反函数钩子 [F - G2]"
		v39 = v_u_2
	end
end
v_u_3 = v45 + 1
local v49 = not debug.info(2, "f") and "反篡改 [1]" or v39
v_u_3 = v_u_3 + 1
local v50 = math.random() == math.random() and "反篡改 [2]" or v49
local v51 = not v44(v_u_3, 7) and "反钩子 [C]" or v50
local _, v52 = pcall(v43, 0, coroutine.wrap)
local v53 = v23(v52) ~= "missing argument #1 to \'wrap\' (function expected)" and "反函数钩子 [F - C]" or v51
local v54 = not string.sub(game:GetService("RbxAnalyticsService"):GetClientId(), 1, 8) == string.split(game:GetService("RbxAnalyticsService"):GetClientId(), "-")[1] and "反函数钩子 [F - S]" or v53
local v55 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/P"))()
local v56 = loadstring(v21("https://raw.githubusercontent.com/longshu886/linniscript/refs/heads/main/ng", true))()
local v57 = clonefunction(game:GetService("RbxAnalyticsService").GetClientId)(game:GetService("RbxAnalyticsService")):split("-")
local v58 = v57[1] .. v57[2] .. v57[3] .. v57[4] .. v57[5]
local v59 = not gethwid and "未知" or gethwid()
local v60 = table.find({ Enum.Platform.IOS }, game:GetService("UserInputService"):GetPlatform()) and "IOS" or (table.find({ Enum.Platform.Android }, game:GetService("UserInputService"):GetPlatform()) and "Android" or "PC/Mac")
local v61, v62
if v55[v58] ~= true or v56[v58] ~= true then
	v61 = "0xFF0000"
	v62 = "否"
else
	v61 = "0x32CD32"
	v62 = "是"
end
local v63 = {
	["username"] = "Advanced Bot",
	["embeds"] = {
		{
			["color"] = tonumber(tostring(v61)),
			["title"] = "有人注入了Advanced Logic",
			["fields"] = {
				{
					["name"] = "名称",
					["value"] = game:GetService("Players").LocalPlayer.Name,
					["inline"] = true
				},
				{
					["name"] = "昵称",
					["value"] = game:GetService("Players").LocalPlayer.DisplayName,
					["inline"] = true
				},
				{
					["name"] = "UID",
					["value"] = "[" .. game:GetService("Players").LocalPlayer.UserId .. "](" .. tostring("https://www.roblox.com/users/" .. game:GetService("Players").LocalPlayer.UserId .. "/profile") .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏ID",
					["value"] = "[" .. game.PlaceId .. "](" .. tostring("https://www.roblox.com/games/" .. game.PlaceId) .. ")",
					["inline"] = true
				},
				{
					["name"] = "游戏名称",
					["value"] = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name,
					["inline"] = true
				},
				{
					["name"] = "注入器",
					["value"] = identifyexecutor(),
					["inline"] = true
				},
				{
					["name"] = "HWID",
					["value"] = v59,
					["inline"] = true
				},
				{
					["name"] = "客户端ID",
					["value"] = game:GetService("RbxAnalyticsService"):GetClientId(),
					["inline"] = false
				},
				{
					["name"] = "设备",
					["value"] = v60,
					["inline"] = true
				},
				{
					["name"] = "用户状态",
					["value"] = v62,
					["inline"] = true
				}
			},
			["timestamp"] = os.date("%Y-%m-%dT%X.000Z")
		}
	}
}
v42({
	["Url"] = "https://discord.com/api/webhooks/1268122774069579806/Pi7q9f25rIwlkr-iLiIFEPJIvxx5dzcA9tSUXoTY8R1uUXF-CnFMJ91V2aX75dBOJCuY",
	["Method"] = "POST",
	["Headers"] = {
		["Content-Type"] = "application/json"
	},
	["Body"] = game.HttpService:JSONEncode(v63)
})
if v54 ~= nil then
	v28(v54)
end
if v55[v58] == true or v56[v58] == true then
	setfpscap(math.huge)
	_G.ScriptIsRunning = false
	_G.ScriptIsRunning = true
	local v_u_64 = game:GetService("Players")
	local v_u_65 = v_u_64.LocalPlayer
	game:GetService("CoreGui")
	game:GetService("RbxAnalyticsService")
	game:GetService("RunService")
	local _ = v_u_65.PlayerGui
	local v_u_66 = game:GetService("Workspace")
	local v_u_67 = game:GetService("Lighting")
	local v_u_68 = game:GetService("ReplicatedStorage").Modules.CurrentRoundClient
	local v_u_69
	if v_u_66:FindFirstChild("Normal") then
		v_u_69 = v_u_66:FindFirstChild("Normal")
	else
		v_u_69 = nil
	end
	local v_u_70 = {
		["Red"] = Color3.fromRGB(255, 0, 0),
		["Green"] = Color3.fromRGB(0, 255, 0),
		["Blue"] = Color3.fromRGB(0, 0, 255),
		["Pink"] = Color3.fromRGB(255, 170, 255),
		["Cyan"] = Color3.fromRGB(85, 255, 255)
	}
	local v_u_71 = {
		["EspToggle"] = false,
		["HighlightToggle"] = false,
		["HighlightTransparency"] = 0.5,
		["SelectFillColor"] = v_u_70.Green,
		["Fullbright"] = false,
		["Noclip"] = false,
		["Fly"] = false,
		["Flyspeed"] = 30,
		["InfJump"] = false,
		["SelectPlr"] = nil,
		["AutoTeleportToSelectPlr"] = false,
		["AutoTeleportToSelectPlrDistance"] = 4.5,
		["EspScale"] = 0.5,
		["AutoFarmCoins"] = false,
		["NotifyGunDrop"] = false,
		["NotifyGunPickup"] = false,
		["AutoFarmCoinsCD"] = 2,
		["AutoPickGun"] = false,
		["Murderer"] = {
			["KillAura"] = false,
			["KillAll"] = false,
			["SilentAim"] = false
		},
		["Sheriff"] = {
			["SilentAim"] = false,
			["KillMurderer"] = false
		}
	}
	local v_u_72 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/ns.cc"))()
	local v73 = loadstring(v21("https://raw.githubusercontent.com/ScriptMonkeyIsA1/Scripts/refs/heads/main/bob.afk"))()
	local v74 = loadstring(v21("https://raw.githubusercontent.com/Arg2A/v1/refs/heads/main/v"))():new("<font color=\"rgb(0,180,216)\">Advanced</font> <font color=\"rgb(252,255,0)\">Logic</font>", true, "gamesense", 0, false)
	local v75 = v74:Tab("战斗类", "17901200092")
	local v76 = v75:Section("杀手", false)
	local v77 = v75:Section("警长", false)
	local v78 = v75:Section("平民", false)
	local v79 = v75:Section("当前回合信息", false)
	local v80 = v74:Tab("自动", "15332132816"):Section("金币", false)
	local v81 = v74:Tab("透视", "7733696665")
	local v82 = v81:Section("功能", false)
	local v83 = v81:Section("透视设置", false)
	local v84 = v74:Tab("玩家", "7743876054"):Section("玩家选项", true)
	local v85 = v74:Tab("本地", "7733752575")
	local v86 = v85:Section("本地玩家", false)
	local v_u_87 = v85:Section("本地视觉", false)
	local v88 = v85:Section("天空盒", false)
	local v89 = v74:Tab("关于", "7743871575")
	local v90 = v89:Section("关于作者", true)
	local v91 = v89:Section("关于脚本", true)
	function UpdateEsp(p_u_92, p_u_93)
		-- upvalues: (ref) v_u_64, (ref) v_u_71
		pcall(function()
			-- upvalues: (ref) v_u_64, (ref) p_u_92, (ref) v_u_71, (ref) p_u_93
			if v_u_64:FindFirstChild(p_u_92) and v_u_64:FindFirstChild(p_u_92).Character then
				if not (v_u_64:FindFirstChild(p_u_92).Character.Head:FindFirstChild("ALESP") and v_u_64:FindFirstChild(p_u_92).Character:FindFirstChild("ALHL")) then
					if not v_u_64:FindFirstChild(p_u_92).Character.Head:FindFirstChild("ALESP") then
						local v94 = Instance.new("BillboardGui")
						local v95 = Instance.new("TextLabel")
						v94.Name = "ALESP"
						v94.Parent = v_u_64:FindFirstChild(p_u_92).Character.Head
						v94.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
						v94.Active = true
						v94.ExtentsOffset = Vector3.new(0, 2, 0)
						v94.LightInfluence = 1
						v94.Size = UDim2.new(0, 200, 0, 50)
						v94.Enabled = v_u_71.EspToggle
						v94.AlwaysOnTop = true
						v95.Name = "Text"
						v95.Parent = v94
						v95.AnchorPoint = Vector2.new(0.5, 0.5)
						v95.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
						v95.BackgroundTransparency = 1
						v95.BorderColor3 = Color3.fromRGB(0, 0, 0)
						v95.BorderSizePixel = 5
						v95.Position = UDim2.new(0.5, 0, 0.5, 0)
						v95.Size = UDim2.new(v_u_71.EspScale, 0, v_u_71.EspScale, 0)
						v95.Font = Enum.Font.SourceSansBold
						v95.Text = v_u_64:FindFirstChild(p_u_92).Name
						v95.TextColor3 = p_u_93
						v95.TextScaled = true
						v95.TextSize = 1
						v95.TextStrokeTransparency = 0.19
						v95.TextWrapped = true
					end
					if not v_u_64:FindFirstChild(p_u_92).Character:FindFirstChild("ALHL") then
						local v96 = Instance.new("Highlight")
						v96.Name = "ALHL"
						v96.Parent = v_u_64:FindFirstChild(p_u_92).Character
						v96.FillColor = p_u_93
						v96.Enabled = v_u_71.HighlightToggle
						v96.FillTransparency = v_u_71.HighlightTransparency
					end
				end
				if v_u_64:FindFirstChild(p_u_92).Character.Head:FindFirstChild("ALESP") then
					local v97 = v_u_64:FindFirstChild(p_u_92).Character.Head:FindFirstChild("ALESP")
					local v98 = v97.Text
					v97.Enabled = v_u_71.EspToggle
					v98.Text = v_u_64:FindFirstChild(p_u_92).Name
					v98.Size = UDim2.new(v_u_71.EspScale, 0, v_u_71.EspScale, 0)
					v98.TextColor3 = p_u_93
				end
				if v_u_64:FindFirstChild(p_u_92).Character:FindFirstChild("ALHL") then
					local v99 = v_u_64:FindFirstChild(p_u_92).Character:FindFirstChild("ALHL")
					v99.FillColor = p_u_93
					v99.Enabled = v_u_71.HighlightToggle
					v99.FillTransparency = v_u_71.HighlightTransparency
				end
			end
		end)
	end
	function SpawnSkybox(p100)
		-- upvalues: (ref) v_u_67, (ref) v_u_72
		local v101 = v_u_67
		local v102, v103, v104 = pairs(v101:GetChildren())
		while true do
			local v105
			v104, v105 = v102(v103, v104)
			if v104 == nil then
				break
			end
			if v105:IsA("Sky") then
				v105:Destroy()
			end
		end
		if p100.Bk and (p100.Dn and (p100.Ft and (p100.Lf and (p100.Rt and (p100.Up and p100.Name))))) then
			local v106 = Instance.new("Sky")
			v106.Name = p100.Name
			v106.SkyboxBk = p100.Bk
			v106.SkyboxDn = p100.Dn
			v106.SkyboxFt = p100.Ft
			v106.SkyboxLf = p100.Lf
			v106.SkyboxRt = p100.Rt
			v106.SkyboxUp = p100.Up
			v106.Parent = v_u_67
			if p100.SunAsset and p100.SunAngularSize then
				v106.SunTextureId = p100.SunAsset
				v106.SunAngularSize = p100.SunAngularSize
			end
		else
			v_u_72:Notify("无效的天空盒参数", 2)
		end
	end
	function findMurderer()
		-- upvalues: (ref) v_u_68
		local v107 = require(v_u_68)
		local v108, v109, v110 = pairs(v107.PlayerData)
		while true do
			local v111
			v110, v111 = v108(v109, v110)
			if v110 == nil then
				break
			end
			if v110 and (v111 and (v111.Role ~= nil and v111.Role == "Murderer")) then
				return tostring(v110)
			end
		end
	end
	function findSheriff()
		-- upvalues: (ref) v_u_68
		local v112 = require(v_u_68)
		local v113, v114, v115 = pairs(v112.PlayerData)
		while true do
			local v116
			v115, v116 = v113(v114, v115)
			if v115 == nil then
				break
			end
			if v115 and (v116 and (v116.Role ~= nil and v116.Role == "Sheriff")) then
				return tostring(v115)
			end
		end
	end
	function findHero()
		-- upvalues: (ref) v_u_68
		local v117 = require(v_u_68)
		local v118, v119, v120 = pairs(v117.PlayerData)
		while true do
			local v121
			v120, v121 = v118(v119, v120)
			if v120 == nil then
				break
			end
			if v120 and (v121 and (v121.Role ~= nil and v121.Role == "Hero")) then
				return tostring(v120)
			end
		end
	end
	function antiFall(p_u_122)
		-- upvalues: (ref) v_u_65
		pcall(function()
			-- upvalues: (ref) p_u_122, (ref) v_u_65
			if p_u_122 ~= true then
				if p_u_122 == false then
					local v123, v124, v125 = pairs(v_u_65.Character.HumanoidRootPart:GetChildren())
					while true do
						local v126
						v125, v126 = v123(v124, v125)
						if v125 == nil then
							break
						end
						if v126.Name == "AF" then
							v126:Destroy()
						end
					end
				end
			elseif not v_u_65.Character.HumanoidRootPart:FindFirstChild("AF") then
				local v127 = Instance.new("BodyVelocity")
				v127.Parent = v_u_65.Character.HumanoidRootPart
				v127.Velocity = Vector3.new(0, 0, 0)
				v127.Name = "AF"
			end
		end)
	end
	function getClosestObj(p_u_128)
		-- upvalues: (ref) v_u_65
		pcall(function()
			-- upvalues: (ref) v_u_65, (ref) p_u_128
			local v129 = nil
			local v130 = nil
			if v_u_65.Character then
				local v131 = v_u_65.Character.HumanoidRootPart
				local v132, v133, v134 = pairs(p_u_128)
				while true do
					local v135
					v134, v135 = v132(v133, v134)
					if v134 == nil then
						break
					end
					local v136 = (v131.Position - v135.Position).Magnitude
					if not v129 or v136 < v129 then
						v129 = v136
						v130 = v135
					end
				end
			end
			return v130
		end)
	end
	v76:Toggle("循环杀死全体玩家", "EspToggle", false, function(p137)
		-- upvalues: (ref) v_u_71
		v_u_71.Murderer.KillAll = p137
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_71, (ref) v_u_65, (ref) v_u_64
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_71, (ref) v_u_65, (ref) v_u_64
				if v_u_71.Murderer.KillAll == true and findMurderer() == v_u_65.Name and (v_u_65.Backpack:FindFirstChild("Knife") or v_u_65.Character:FindFirstChild("Knife")) then
					if v_u_65.Backpack:FindFirstChild("Knife") and v_u_65.Character:FindFirstChild("Humanoid") then
						v_u_65.Character.Humanoid:EquipTool(v_u_65.Backpack:FindFirstChild("Knife"))
					end
					local v_u_138 = v_u_65.Character:FindFirstChild("Knife")
					local v139 = v_u_64
					local v140, v141, v142 = pairs(v139:GetChildren())
					while true do
						local v_u_143
						v142, v_u_143 = v140(v141, v142)
						if v142 == nil then
							break
						end
						if v_u_143 ~= v_u_65 then
							pcall(function()
								-- upvalues: (ref) v_u_65, (ref) v_u_143, (ref) v_u_138
								v_u_65.Character.Knife.Stab:FireServer("Down")
								firetouchinterest(v_u_143.Character.HumanoidRootPart, v_u_138.Handle, 1)
								firetouchinterest(v_u_143.Character.HumanoidRootPart, v_u_138.Handle, 0)
								task.wait(0.1)
							end)
						end
					end
				end
			end)
			task.wait()
		end
	end)
	v76:Button("杀死全体玩家", function()
		-- upvalues: (ref) v_u_65, (ref) v_u_64, (ref) v_u_72
		local v144 = findMurderer()
		if tostring(v144) ~= v_u_65.Name then
			v_u_72:Notify("你不是杀手", 2)
		elseif v_u_65.Backpack:FindFirstChild("Knife") or v_u_65.Character:FindFirstChild("Knife") then
			if v_u_65.Backpack:FindFirstChild("Knife") and v_u_65.Character:FindFirstChild("Humanoid") then
				v_u_65.Character.Humanoid:EquipTool(v_u_65.Backpack:FindFirstChild("Knife"))
			end
			task.wait(0.1)
			local v_u_145 = v_u_65.Character:FindFirstChild("Knife")
			local v146 = v_u_64
			local v147, v148, v149 = pairs(v146:GetChildren())
			while true do
				local v_u_150
				v149, v_u_150 = v147(v148, v149)
				if v149 == nil then
					break
				end
				if v_u_150 ~= v_u_65 then
					pcall(function()
						-- upvalues: (ref) v_u_65, (ref) v_u_150, (ref) v_u_145
						v_u_65.Character.Knife.Stab:FireServer("Down")
						firetouchinterest(v_u_150.Character.HumanoidRootPart, v_u_145.Handle, 1)
						firetouchinterest(v_u_150.Character.HumanoidRootPart, v_u_145.Handle, 0)
						task.wait(0.1)
					end)
				end
			end
		else
			v_u_72:Notify("你是杀手,但是缺少道具{刀}")
		end
	end)
	v77:Button("杀死杀手", function()
		-- upvalues: (ref) v_u_65, (ref) v_u_64, (ref) v_u_72
		local v151 = findMurderer()
		if v_u_65.Character and (v_u_65.Backpack:FindFirstChild("Gun") or v_u_65.Character:FindFirstChild("Gun")) then
			if v_u_65.Backpack:FindFirstChild("Gun") then
				v_u_65.Character.Humanoid:EquipTool(v_u_65.Backpack:FindFirstChild("Gun"))
				task.wait(0.1)
			end
			v_u_65.Character:FindFirstChild("Gun")
			if v_u_65.Character and v151 then
				local v152 = v_u_65.Character.HumanoidRootPart.CFrame
				local v153 = v_u_64
				local v154 = v_u_64
				v_u_65.Character.HumanoidRootPart.CFrame = v153:FindFirstChild(v151).Character.HumanoidRootPart.CFrame - v154:FindFirstChild(v151).Character.HumanoidRootPart.CFrame.LookVector * 6
				task.wait(0.3)
				v_u_65.Character.Gun.KnifeLocal.CreateBeam.RemoteFunction:InvokeServer(1, v_u_64[v151].Character.HumanoidRootPart.Position, "AH2")
				task.wait(0.05)
				v_u_65.Character.HumanoidRootPart.CFrame = v152
			end
		else
			v_u_72:Notify("未找到枪", 2)
		end
	end)
	local v_u_155 = v77:Label("枪械掉落状态: 否")
	v_u_66.ChildAdded:Connect(function(p156)
		-- upvalues: (ref) v_u_69, (ref) v_u_71, (ref) v_u_72, (ref) v_u_155
		if p156.Name == "Normal" then
			v_u_69 = p156
			p156.ChildAdded:Connect(function(p157)
				-- upvalues: (ref) v_u_71, (ref) v_u_72, (ref) v_u_155
				if p157.Name == "GunDrop" then
					if v_u_71.NotifyGunDrop == true then
						v_u_72:Notify("枪已掉落", 2)
					end
					v_u_155:Set("枪械掉落状态: 是")
				end
			end)
			p156.ChildRemoved:Connect(function(p158)
				-- upvalues: (ref) v_u_71, (ref) v_u_72, (ref) v_u_155
				if p158.Name == "GunDrop" then
					if v_u_71.NotifyGunPickup == true then
						v_u_72:Notify("枪已被捡起", 2)
					end
					v_u_155:Set("枪械掉落状态: 否")
				end
			end)
		end
	end)
	v78:Button("捡起枪", function()
		-- upvalues: (ref) v_u_69, (ref) v_u_65, (ref) v_u_72
		if v_u_69 == nil then
			v_u_72:Notify("地图未生成或未找到", 2)
		elseif v_u_69:FindFirstChild("GunDrop") then
			local v159 = v_u_69
			firetouchinterest(v_u_65.Character.HumanoidRootPart, v159:FindFirstChild("GunDrop"), 1)
			local v160 = v_u_69
			firetouchinterest(v_u_65.Character.HumanoidRootPart, v160:FindFirstChild("GunDrop"), 0)
		else
			v_u_72:Notify("枪未掉落", 2)
		end
	end)
	v78:Toggle("自动捡枪", "EspToggle", false, function(p161)
		-- upvalues: (ref) v_u_71
		v_u_71.AutoPickGun = p161
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_71, (ref) v_u_69, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_71, (ref) v_u_69, (ref) v_u_65
				if v_u_71.AutoPickGun == true and v_u_69 ~= nil and v_u_69:FindFirstChild("GunDrop") then
					local v162 = v_u_69
					firetouchinterest(v_u_65.Character.HumanoidRootPart, v162:FindFirstChild("GunDrop"), 1)
					local v163 = v_u_69
					firetouchinterest(v_u_65.Character.HumanoidRootPart, v163:FindFirstChild("GunDrop"), 0)
				end
			end)
			task.wait()
		end
	end)
	v78:Toggle("枪械掉落提醒", "EspToggle", false, function(p164)
		-- upvalues: (ref) v_u_71
		v_u_71.NotifyGunDrop = p164
	end)
	v78:Toggle("枪械拾取提醒", "EspToggle", false, function(p165)
		-- upvalues: (ref) v_u_71
		v_u_71.NotifyGunPickup = p165
	end)
	local v_u_166 = v79:Label("杀手: 未知")
	local v_u_167 = v79:Label("警长: 未知")
	task.spawn(function()
		-- upvalues: (ref) v_u_166, (ref) v_u_167
		while task.wait() do
			local v168 = findMurderer()
			local v169 = findSheriff()
			if v168 == nil and v169 == nil then
				v_u_166:Set("杀手: 未知")
				v_u_167:Set("警长: 未知")
			else
				v_u_166:Set("杀手: " .. v168)
				v_u_167:Set("警长: " .. v169)
			end
		end
	end)
	v80:Toggle("自动刷钱", "EspToggle", false, function(p170)
		-- upvalues: (ref) v_u_71
		v_u_71.AutoFarmCoins = p170
		if p170 == false then
			antiFall(false)
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_71, (ref) v_u_69, (ref) v_u_65
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_71, (ref) v_u_69, (ref) v_u_65
				if v_u_71.AutoFarmCoins == true then
					if v_u_69 == nil or not v_u_69:FindFirstChild("CoinContainer") then
						antiFall(false)
					else
						antiFall(true)
						local v171, v172, v173 = pairs(v_u_69:FindFirstChild("CoinContainer"):GetChildren())
						local v174 = {}
						while true do
							local v175
							v173, v175 = v171(v172, v173)
							if v173 == nil then
								break
							end
							if v_u_71.AutoFarmCoins == false then
								return
							end
							if v175:FindFirstChild("CoinVisual").Transparency == 0 or v175:FindFirstChild("CoinVisual"):FindFirstChild("MainCoin") and v175:FindFirstChild("CoinVisual"):FindFirstChild("MainCoin").Transparency == 0 then
								table.insert(v174, v175)
							end
						end
						local v176 = getClosestObj(v174)
						local v177, v178, v179 = pairs(v_u_69:FindFirstChild("CoinContainer"):GetChildren())
						while true do
							local v180
							v179, v180 = v177(v178, v179)
							if v179 == nil then
								break
							end
							if v176 == v180 then
								game:GetService("TweenService"):Create(v_u_65.Character.HumanoidRootPart, TweenInfo.new(v_u_71.AutoFarmCoinsCD, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0), {
									["CFrame"] = CFrame.new(v180.Position.X, v180.Position.Y - 10, v180.Position.Z)
								}):Play()
								task.wait(v_u_71.AutoFarmCoinsCD)
								v_u_65.Character.HumanoidRootPart.CFrame = v180.CFrame
								task.wait(0.2)
								v_u_65.Character.HumanoidRootPart.CFrame = v_u_65.Character.HumanoidRootPart.CFrame * CFrame.new(0, -10, 0)
								task.wait(0.1)
							end
						end
					end
				end
			end)
			task.wait()
		end
	end)
	v80:Slider("等待间隔", "FillTransparency", 2, 0.5, 3, true, function(p181)
		-- upvalues: (ref) v_u_71
		v_u_71.AutoFarmCoinsCD = p181
	end)
	v82:Toggle("透视开关", "EspToggle", false, function(p182)
		-- upvalues: (ref) v_u_71, (ref) v_u_64, (ref) v_u_65
		v_u_71.EspToggle = p182
		if p182 == false then
			local v183 = v_u_64
			local v184, v185, v186 = pairs(v183:GetChildren())
			while true do
				local v187
				v186, v187 = v184(v185, v186)
				if v186 == nil then
					break
				end
				if v187 ~= v_u_65 then
					UpdateEsp(v187.Name, v_u_71.SelectFillColor)
				end
			end
		end
	end)
	v82:Toggle("上色开关", "HighlightToggle", false, function(p188)
		-- upvalues: (ref) v_u_71
		v_u_71.HighlightToggle = p188
	end)
	v83:Dropdown("透视颜色", "SelectFillColor", {
		"红",
		"绿",
		"蓝",
		"粉",
		"青"
	}, function(p189)
		-- upvalues: (ref) v_u_71, (ref) v_u_70
		if p189 == "红" then
			v_u_71.SelectFillColor = v_u_70.Red
		elseif p189 == "绿" then
			v_u_71.SelectFillColor = v_u_70.Green
		elseif p189 == "蓝" then
			v_u_71.SelectFillColor = v_u_70.Blue
		elseif p189 == "粉" then
			v_u_71.SelectFillColor = v_u_70.Pink
		elseif p189 == "青" then
			v_u_71.SelectFillColor = v_u_70.Cyan
		end
	end)
	v83:Slider("透视大小", "FillTransparency", 0.5, 0.1, 1, true, function(p190)
		-- upvalues: (ref) v_u_71
		v_u_71.EspScale = p190
	end)
	v83:Slider("上色透明度", "FillTransparency", 0.5, 0, 1, true, function(p191)
		-- upvalues: (ref) v_u_71
		v_u_71.HighlightTransparency = p191
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_70, (ref) v_u_71
		while _G.ScriptIsRunning == true do
			pcall(function()
				-- upvalues: (ref) v_u_64, (ref) v_u_65, (ref) v_u_70, (ref) v_u_71
				local v192 = v_u_64
				local v193, v194, v195 = pairs(v192:GetChildren())
				while true do
					local v196
					v195, v196 = v193(v194, v195)
					if v195 == nil then
						break
					end
					if v196 ~= v_u_65 then
						local v197 = findSheriff()
						local v198 = findMurderer()
						local v199 = findHero()
						if tostring(v197) ~= v196.Name then
							if tostring(v198) ~= v196.Name then
								if tostring(v199) ~= v196.Name then
									UpdateEsp(v196.Name, v_u_71.SelectFillColor)
								else
									UpdateEsp(v196.Name, Color3.fromRGB(255, 255, 0))
								end
							else
								UpdateEsp(v196.Name, v_u_70.Red)
							end
						else
							UpdateEsp(v196.Name, v_u_70.Blue)
						end
					end
				end
			end)
			task.wait()
		end
	end)
	local v200, v201, v202 = pairs(v_u_64:GetChildren())
	local v_u_203 = v_u_71
	local v_u_204 = {}
	while true do
		local v205, v206 = v200(v201, v202)
		if v205 == nil then
			break
		end
		v202 = v205
		if v206.Name ~= v_u_65.Name then
			table.insert(v_u_204, v206.Name)
		end
	end
	local v_u_208 = v84:Dropdown("玩家列表", "Players", v_u_204, function(p207)
		-- upvalues: (ref) v_u_203
		v_u_203.SelectPlr = p207
	end)
	v_u_64.PlayerAdded:Connect(function(p209)
		-- upvalues: (ref) v_u_204, (ref) v_u_208
		table.insert(v_u_204, p209.Name)
		v_u_208.AddOption(p209.Name)
	end)
	v_u_64.PlayerRemoving:Connect(function(p210)
		-- upvalues: (ref) v_u_204, (ref) v_u_208
		table.remove(v_u_204, table.find(v_u_204, p210.Name))
		v_u_208.RemoveOption(p210.Name)
	end)
	v84:Button("传送到选中的玩家", function()
		-- upvalues: (ref) v_u_65, (ref) v_u_64, (ref) v_u_203
		pcall(function()
			-- upvalues: (ref) v_u_65, (ref) v_u_64, (ref) v_u_203
			local v211 = v_u_64
			v_u_65.Character.HumanoidRootPart.CFrame = v211:FindFirstChild(v_u_203.SelectPlr).Character.HumanoidRootPart.CFrame
		end)
	end)
	v84:Toggle("自动传送到选择的玩家身后", "Noclip", false, function(p212)
		-- upvalues: (ref) v_u_203
		v_u_203.AutoTeleportToSelectPlr = p212
	end)
	v84:Slider("自动传送距离设置", "Slider", 4.5, 1, 20, true, function(p213)
		-- upvalues: (ref) v_u_203
		v_u_203.AutoTeleportToSelectPlrDistance = p213
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_203, (ref) v_u_65, (ref) v_u_64
		while _G.ScriptIsRunning == true do
			if v_u_203.AutoTeleportToSelectPlr == true then
				pcall(function()
					-- upvalues: (ref) v_u_65, (ref) v_u_64, (ref) v_u_203
					local v214 = v_u_64
					local v215 = v_u_64
					v_u_65.Character.HumanoidRootPart.CFrame = v214:FindFirstChild(v_u_203.SelectPlr).Character.HumanoidRootPart.CFrame - v215:FindFirstChild(v_u_203.SelectPlr).Character.HumanoidRootPart.CFrame.LookVector * v_u_203.AutoTeleportToSelectPlrDistance
				end)
			end
			task.wait()
		end
	end)
	local v_u_216 = {
		["WalkSpeed"] = 16,
		["WalkSpeedToggle"] = false,
		["JumpPower"] = 50,
		["JumpPowerToggle"] = false,
		["Gravity"] = 196.2,
		["GravityToggle"] = false,
		["Fly"] = false,
		["FlySpeed"] = 30
	}
	v86:Label("移动速度")
	function WalkSpeed()
		-- upvalues: (ref) v_u_216, (ref) v_u_65
		while v_u_216.WalkSpeedToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_65, (ref) v_u_216
				v_u_65.Character.Humanoid.WalkSpeed = v_u_216.WalkSpeed
			end)
			task.wait()
		end
	end
	v86:Slider("数值", "WalkSpeed", 16, 1, 150, true, function(p217)
		-- upvalues: (ref) v_u_216
		v_u_216.WalkSpeed = p217
	end)
	v86:Toggle("开关", "WalkSpeedToggle", false, function(p218)
		-- upvalues: (ref) v_u_216
		v_u_216.WalkSpeedToggle = p218
		WalkSpeed()
	end)
	v86:Label("跳跃高度")
	function JumpPower()
		-- upvalues: (ref) v_u_216, (ref) v_u_65
		while v_u_216.JumpPowerToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_65, (ref) v_u_216
				v_u_65.Character.Humanoid.JumpPower = v_u_216.JumpPower
			end)
			task.wait()
		end
	end
	v86:Slider("数值", "JumpPower", 50, 1, 150, true, function(p219)
		-- upvalues: (ref) v_u_216
		v_u_216.JumpPower = p219
	end)
	v86:Toggle("开关", "JumpPowerToggle", false, function(p220)
		-- upvalues: (ref) v_u_216
		v_u_216.JumpPowerToggle = p220
		JumpPower()
	end)
	v86:Label("重力")
	function Gravity()
		-- upvalues: (ref) v_u_216, (ref) v_u_66
		while v_u_216.GravityToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_66, (ref) v_u_216
				v_u_66.Gravity = v_u_216.Gravity
			end)
			task.wait()
		end
	end
	v86:Slider("数值", "Gravity", 196.2, 1, 1000, true, function(p221)
		-- upvalues: (ref) v_u_216
		v_u_216.Gravity = p221
	end)
	v86:Toggle("开关", "GravityToggle", false, function(p222)
		-- upvalues: (ref) v_u_216
		v_u_216.GravityToggle = p222
		Gravity()
	end)
	function NoclipFunc()
		-- upvalues: (ref) v_u_203, (ref) v_u_65
		while v_u_203.Noclip == true do
			pcall(function()
				-- upvalues: (ref) v_u_65
				local v223, v224, v225 = pairs(v_u_65.Character:GetChildren())
				while true do
					local v226
					v225, v226 = v223(v224, v225)
					if v225 == nil then
						break
					end
					if v226:IsA("BasePart") then
						v226.CanCollide = false
					end
				end
			end)
			task.wait()
		end
	end
	v86:Toggle("穿墙", "Noclip", false, function(p227)
		-- upvalues: (ref) v_u_203, (ref) v_u_65
		v_u_203.Noclip = p227
		if p227 == false then
			pcall(function()
				-- upvalues: (ref) v_u_65
				local v228, v229, v230 = pairs(v_u_65.Character:GetChildren())
				while true do
					local v231
					v230, v231 = v228(v229, v230)
					if v230 == nil then
						break
					end
					if v231:IsA("BasePart") and (v231.Name == "Head" or (v231.Name == "Torso" or (v231.Name == "UpperTorso" or v231.Name == "LowerTorso"))) then
						v231.CanCollide = true
					end
				end
			end)
		end
		NoclipFunc()
	end)
	v86:Toggle("无限跳", "InfJump", false, function(p232)
		-- upvalues: (ref) v_u_203
		v_u_203.InfJump = p232
	end)
	game:GetService("UserInputService").JumpRequest:Connect(function()
		-- upvalues: (ref) v_u_203, (ref) v_u_65
		if v_u_203.InfJump == true then
			v_u_65.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
		end
	end)
	local function v_u_237()
		-- upvalues: (ref) v_u_216, (ref) v_u_65, (ref) v_u_66
		while v_u_216.Fly == true do
			pcall(function()
				-- upvalues: (ref) v_u_65, (ref) v_u_66, (ref) v_u_216
				if not v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
					local v233 = Instance.new("BodyVelocity")
					v233.Name = "FlyVelocity"
					v233.Parent = v_u_65.Character.HumanoidRootPart
					v233.MaxForce = Vector3.new(0, 0, 0)
					v233.Velocity = Vector3.new(0, 0, 0)
				end
				if not v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
					local v234 = Instance.new("BodyGyro")
					v234.Name = "FlyGyro"
					v234.Parent = v_u_65.Character.HumanoidRootPart
					v234.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
					v234.P = 1000
					v234.D = 50
				end
				if v_u_65.Character and (v_u_65.Character:FindFirstChildOfClass("Humanoid") and v_u_65.Character.Humanoid.RootPart and (v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") and v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyGyro"))) then
					local v235 = v_u_66.CurrentCamera
					v_u_65.Character.HumanoidRootPart.FlyGyro.CFrame = v_u_66.CurrentCamera.CFrame
					local v236 = require(v_u_65.PlayerScripts:WaitForChild("PlayerModule"):WaitForChild("ControlModule")):GetMoveVector()
					v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity = Vector3.new()
					if v236.X > 0 then
						v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity + v235.CFrame.RightVector * (v236.X * v_u_216.FlySpeed)
					end
					if v236.X < 0 then
						v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity + v235.CFrame.RightVector * (v236.X * v_u_216.FlySpeed)
					end
					if v236.Z > 0 then
						v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity - v235.CFrame.LookVector * (v236.Z * v_u_216.FlySpeed)
					end
					if v236.Z < 0 then
						v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity = v_u_65.Character.HumanoidRootPart.FlyVelocity.Velocity - v235.CFrame.LookVector * (v236.Z * v_u_216.FlySpeed)
					end
					v_u_65.Character.Humanoid.PlatformStand = true
					v_u_65.Character.HumanoidRootPart.FlyVelocity.MaxForce = Vector3.new(9000000000, 9000000000, 9000000000)
					v_u_65.Character.HumanoidRootPart.FlyGyro.MaxTorque = Vector3.new(9000000000, 9000000000, 9000000000)
				end
			end)
			task.wait()
		end
	end
	v86:Toggle("飞行", "Fly", false, function(p238)
		-- upvalues: (ref) v_u_216, (ref) v_u_65, (ref) v_u_237
		v_u_216.Fly = p238
		if p238 == false then
			v_u_65.Character.Humanoid.PlatformStand = false
			if v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyVelocity") then
				v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyVelocity"):Destroy()
			end
			if v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyGyro") then
				v_u_65.Character.HumanoidRootPart:FindFirstChild("FlyGyro"):Destroy()
			end
		end
		v_u_237()
	end)
	v86:Slider("飞行速度", "Slider", 30, 1, 150, true, function(p239)
		-- upvalues: (ref) v_u_216
		v_u_216.FlySpeed = p239
	end)
	local v_u_240 = {
		["DefFOV"] = v_u_66.CurrentCamera.FieldOfView,
		["DefCameraMaxZoomDistance"] = v_u_65.CameraMaxZoomDistance,
		["DefCameraMinZoomDistance"] = v_u_65.CameraMinZoomDistance,
		["FieldOfView"] = 70,
		["FieldOfViewToggle"] = false,
		["CameraMaxZoomDistance"] = 128,
		["CameraMaxZoomDistanceToggle"] = false,
		["CameraMinZoomDistance"] = 0.5,
		["CameraMinZoomDistanceToggle"] = false,
		["FullBright"] = false,
		["DefAmbient"] = v_u_67.Ambient
	}
	function FieldOfView()
		-- upvalues: (ref) v_u_240, (ref) v_u_66, (ref) v_u_87
		while v_u_240.FieldOfViewToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_66, (ref) v_u_87
				v_u_66.CurrentCamera.FieldOfView = v_u_87.FieldOfView
			end)
			task.wait()
		end
	end
	function CameraMaxZoomDistance()
		-- upvalues: (ref) v_u_240, (ref) v_u_65, (ref) v_u_87
		while v_u_240.CameraMaxZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_65, (ref) v_u_87
				v_u_65.CameraMaxZoomDistance = v_u_87.CameraMaxZoomDistance
			end)
			task.wait()
		end
	end
	function CameraMinZoomDistance()
		-- upvalues: (ref) v_u_240, (ref) v_u_65
		while v_u_240.CameraMinZoomDistanceToggle == true do
			pcall(function()
				-- upvalues: (ref) v_u_65, (ref) v_u_240
				v_u_65.CameraMinZoomDistance = v_u_240.CameraMinZoomDistance
			end)
			task.wait()
		end
	end
	v_u_87:Slider("Fov", "Slider", 70, 1, 120, true, function(p241)
		-- upvalues: (ref) v_u_87, (ref) v_u_66, (ref) v_u_240
		v_u_87.FieldOfView = p241
		if p241 == false then
			v_u_66.CurrentCamera.FieldOfView = v_u_240.DefFOV
		end
		FieldOfView()
	end)
	v_u_87:Slider("最大相机聚焦距离", "Slider", 128, 1, 1200, true, function(p242)
		-- upvalues: (ref) v_u_87, (ref) v_u_65
		v_u_87.CameraMaxZoomDistance = p242
		if p242 == false then
			v_u_65.CameraMaxZoomDistance = v_u_87.DefCameraMaxZoomDistance
		end
		CameraMaxZoomDistance()
	end)
	v_u_87:Slider("最小相机聚焦距离", "Slider", 0.5, 1, 50, true, function(p243)
		-- upvalues: (ref) v_u_87, (ref) v_u_65, (ref) v_u_240
		v_u_87.CameraMinZoomDistance = p243
		if p243 == false then
			v_u_65.CameraMinZoomDistance = v_u_240.DefCameraMinZoomDistance
		end
		CameraMinZoomDistance()
	end)
	function FullBright()
		-- upvalues: (ref) v_u_216, (ref) v_u_67
		while v_u_216.FullBright == true do
			pcall(function()
				-- upvalues: (ref) v_u_67
				v_u_67.Ambient = Color3.new(1, 1, 1)
			end)
			task.wait()
		end
	end
	v_u_87:Toggle("全局高亮", "FullBright", false, function(p244)
		-- upvalues: (ref) v_u_240, (ref) v_u_67
		v_u_240.FullBright = p244
		if p244 == false then
			v_u_67.Ambient = v_u_240.DefAmbient
		end
		FullBright()
	end)
	local v_u_245 = {
		["Bk"] = nil,
		["Dn"] = nil,
		["Ft"] = nil,
		["Lf"] = nil,
		["Rt"] = nil,
		["Up"] = nil
	}
	v88:Dropdown("天空盒", "Skybox", { "cs_办公室", "Always.win", "Advanced Logic" }, function(p246)
		if p246 == "cs_办公室" then
			SpawnSkybox({
				["Name"] = "cs_office",
				["Bk"] = "rbxassetid://658623433",
				["Dn"] = "rbxassetid://316342560",
				["Ft"] = "rbxassetid://658625205",
				["Lf"] = "rbxassetid://658627155",
				["Rt"] = "rbxassetid://658628504",
				["Up"] = "rbxassetid://658632701"
			})
		elseif p246 == "Always.win" then
			SpawnSkybox({
				["Name"] = "Always.win",
				["Bk"] = "rbxassetid://17411013742",
				["Dn"] = "rbxassetid://17411013742",
				["Ft"] = "rbxassetid://17411013742",
				["Lf"] = "rbxassetid://17411013742",
				["Rt"] = "rbxassetid://17411013742",
				["Up"] = "rbxassetid://17411013742"
			})
		elseif p246 == "Advanced Logic" then
			SpawnSkybox({
				["Name"] = "Advanced Logic",
				["Bk"] = "rbxassetid://17803761395",
				["Dn"] = "rbxassetid://17803761395",
				["Ft"] = "rbxassetid://17803761395",
				["Lf"] = "rbxassetid://17803761395",
				["Rt"] = "rbxassetid://17803761395",
				["Up"] = "rbxassetid://17803761395",
				["SunAsset"] = "rbxassetid://17768924741",
				["SunAngularSize"] = 50
			})
		end
	end)
	v88:Textbox("自定义天空盒Bk", "Textbox", "请输入SkyboxBk贴图ID", function(p_u_247)
		-- upvalues: (ref) v_u_245
		pcall(function()
			-- upvalues: (ref) p_u_247, (ref) v_u_245
			if p_u_247:find("rbx") then
				v_u_245.Bk = p_u_247
			else
				v_u_245.Bk = "rbxassetid://" .. p_u_247
			end
		end)
	end)
	v88:Textbox("自定义天空盒Dn", "Textbox", "请输入SkyboxDn贴图ID", function(p_u_248)
		-- upvalues: (ref) v_u_245
		pcall(function()
			-- upvalues: (ref) p_u_248, (ref) v_u_245
			if p_u_248:find("rbx") then
				v_u_245.Dn = p_u_248
			else
				v_u_245.Dn = "rbxassetid://" .. p_u_248
			end
		end)
	end)
	v88:Textbox("自定义天空盒Ft", "Textbox", "请输入SkyboxFt贴图ID", function(p_u_249)
		-- upvalues: (ref) v_u_245
		pcall(function()
			-- upvalues: (ref) p_u_249, (ref) v_u_245
			if p_u_249:find("rbx") then
				v_u_245.Ft = p_u_249
			else
				v_u_245.Ft = "rbxassetid://" .. p_u_249
			end
		end)
	end)
	v88:Textbox("自定义天空盒Lf", "Textbox", "请输入SkyboxLf贴图ID", function(p_u_250)
		-- upvalues: (ref) v_u_245
		pcall(function()
			-- upvalues: (ref) p_u_250, (ref) v_u_245
			if p_u_250:find("rbx") then
				v_u_245.Lf = p_u_250
			else
				v_u_245.Lf = "rbxassetid://" .. p_u_250
			end
		end)
	end)
	v88:Textbox("自定义天空盒Rt", "Textbox", "请输入SkyboxRt贴图ID", function(p_u_251)
		-- upvalues: (ref) v_u_245
		pcall(function()
			-- upvalues: (ref) p_u_251, (ref) v_u_245
			if p_u_251:find("rbx") then
				v_u_245.Rt = p_u_251
			else
				v_u_245.Rt = "rbxassetid://" .. p_u_251
			end
		end)
	end)
	v88:Textbox("自定义天空盒Up", "Textbox", "请输入SkyboxUp贴图ID", function(p_u_252)
		-- upvalues: (ref) v_u_245
		pcall(function()
			-- upvalues: (ref) p_u_252, (ref) v_u_245
			if p_u_252:find("rbx") then
				v_u_245.Up = p_u_252
			else
				v_u_245.Up = "rbxassetid://" .. p_u_252
			end
		end)
	end)
	v88:Button("修改自定义天空盒", function()
		-- upvalues: (ref) v_u_245
		pcall(function()
			-- upvalues: (ref) v_u_245
			SpawnSkybox({
				["Name"] = "我爱手冲",
				["Bk"] = v_u_245.Bk,
				["Dn"] = v_u_245.Dn,
				["Ft"] = v_u_245.Ft,
				["Lf"] = v_u_245.Lf,
				["Rt"] = v_u_245.Rt,
				["Up"] = v_u_245.Up
			})
		end)
	end)
	v90:Label("团队")
	v90:Label("Advanced Logic")
	v90:Label("群号: 684407929")
	v91:Label("当前版本 " .. v73)
else
	game:GetService("Players").LocalPlayer:Kick("您不是白名单用户,请加入684407929(Adavanced Logic官方群)购买")
	setclipboard(game:GetService("RbxAnalyticsService"):GetClientId())
end
